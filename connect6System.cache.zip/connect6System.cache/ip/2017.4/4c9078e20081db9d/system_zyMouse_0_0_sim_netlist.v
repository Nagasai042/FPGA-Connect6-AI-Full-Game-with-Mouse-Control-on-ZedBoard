// Copyright 1986-2017 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2017.4 (win64) Build 2086221 Fri Dec 15 20:55:39 MST 2017
// Date        : Thu Apr  2 23:14:57 2026
// Host        : DESKTOP-VKRMBR2 running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode funcsim -rename_top decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix -prefix
//               decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_ system_zyMouse_0_0_sim_netlist.v
// Design      : system_zyMouse_0_0
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7z020clg484-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

module decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_debounce
   (\counter_reg[31]_0 ,
    s00_axi_aclk,
    CO,
    i_button_down);
  output \counter_reg[31]_0 ;
  input s00_axi_aclk;
  input [0:0]CO;
  input i_button_down;

  wire [0:0]CO;
  wire button_down;
  wire counter;
  wire counter1_carry__0_i_1__0_n_0;
  wire counter1_carry__0_i_2__0_n_0;
  wire counter1_carry__0_i_3__0_n_0;
  wire counter1_carry__0_i_4__2_n_0;
  wire counter1_carry__0_i_5__2_n_0;
  wire counter1_carry__0_i_6__2_n_0;
  wire counter1_carry__0_i_7__2_n_0;
  wire counter1_carry__0_n_0;
  wire counter1_carry__0_n_1;
  wire counter1_carry__0_n_2;
  wire counter1_carry__0_n_3;
  wire counter1_carry__1_i_1__2_n_0;
  wire counter1_carry__1_i_2__2_n_0;
  wire counter1_carry__1_i_3__2_n_0;
  wire counter1_carry__1_i_4__2_n_0;
  wire counter1_carry__1_n_0;
  wire counter1_carry__1_n_1;
  wire counter1_carry__1_n_2;
  wire counter1_carry__1_n_3;
  wire counter1_carry__2_i_1__2_n_0;
  wire counter1_carry__2_n_3;
  wire counter1_carry_i_1__0_n_0;
  wire counter1_carry_i_2__0_n_0;
  wire counter1_carry_i_3__2_n_0;
  wire counter1_carry_i_4__2_n_0;
  wire counter1_carry_i_5__2_n_0;
  wire counter1_carry_i_6__2_n_0;
  wire counter1_carry_n_0;
  wire counter1_carry_n_1;
  wire counter1_carry_n_2;
  wire counter1_carry_n_3;
  wire \counter[0]_i_3__2_n_0 ;
  wire [31:0]counter_reg;
  wire \counter_reg[0]_i_2__2_n_0 ;
  wire \counter_reg[0]_i_2__2_n_1 ;
  wire \counter_reg[0]_i_2__2_n_2 ;
  wire \counter_reg[0]_i_2__2_n_3 ;
  wire \counter_reg[0]_i_2__2_n_4 ;
  wire \counter_reg[0]_i_2__2_n_5 ;
  wire \counter_reg[0]_i_2__2_n_6 ;
  wire \counter_reg[0]_i_2__2_n_7 ;
  wire \counter_reg[12]_i_1__2_n_0 ;
  wire \counter_reg[12]_i_1__2_n_1 ;
  wire \counter_reg[12]_i_1__2_n_2 ;
  wire \counter_reg[12]_i_1__2_n_3 ;
  wire \counter_reg[12]_i_1__2_n_4 ;
  wire \counter_reg[12]_i_1__2_n_5 ;
  wire \counter_reg[12]_i_1__2_n_6 ;
  wire \counter_reg[12]_i_1__2_n_7 ;
  wire \counter_reg[16]_i_1__2_n_0 ;
  wire \counter_reg[16]_i_1__2_n_1 ;
  wire \counter_reg[16]_i_1__2_n_2 ;
  wire \counter_reg[16]_i_1__2_n_3 ;
  wire \counter_reg[16]_i_1__2_n_4 ;
  wire \counter_reg[16]_i_1__2_n_5 ;
  wire \counter_reg[16]_i_1__2_n_6 ;
  wire \counter_reg[16]_i_1__2_n_7 ;
  wire \counter_reg[20]_i_1__2_n_0 ;
  wire \counter_reg[20]_i_1__2_n_1 ;
  wire \counter_reg[20]_i_1__2_n_2 ;
  wire \counter_reg[20]_i_1__2_n_3 ;
  wire \counter_reg[20]_i_1__2_n_4 ;
  wire \counter_reg[20]_i_1__2_n_5 ;
  wire \counter_reg[20]_i_1__2_n_6 ;
  wire \counter_reg[20]_i_1__2_n_7 ;
  wire \counter_reg[24]_i_1__2_n_0 ;
  wire \counter_reg[24]_i_1__2_n_1 ;
  wire \counter_reg[24]_i_1__2_n_2 ;
  wire \counter_reg[24]_i_1__2_n_3 ;
  wire \counter_reg[24]_i_1__2_n_4 ;
  wire \counter_reg[24]_i_1__2_n_5 ;
  wire \counter_reg[24]_i_1__2_n_6 ;
  wire \counter_reg[24]_i_1__2_n_7 ;
  wire \counter_reg[28]_i_1__2_n_1 ;
  wire \counter_reg[28]_i_1__2_n_2 ;
  wire \counter_reg[28]_i_1__2_n_3 ;
  wire \counter_reg[28]_i_1__2_n_4 ;
  wire \counter_reg[28]_i_1__2_n_5 ;
  wire \counter_reg[28]_i_1__2_n_6 ;
  wire \counter_reg[28]_i_1__2_n_7 ;
  wire \counter_reg[31]_0 ;
  wire \counter_reg[4]_i_1__2_n_0 ;
  wire \counter_reg[4]_i_1__2_n_1 ;
  wire \counter_reg[4]_i_1__2_n_2 ;
  wire \counter_reg[4]_i_1__2_n_3 ;
  wire \counter_reg[4]_i_1__2_n_4 ;
  wire \counter_reg[4]_i_1__2_n_5 ;
  wire \counter_reg[4]_i_1__2_n_6 ;
  wire \counter_reg[4]_i_1__2_n_7 ;
  wire \counter_reg[8]_i_1__2_n_0 ;
  wire \counter_reg[8]_i_1__2_n_1 ;
  wire \counter_reg[8]_i_1__2_n_2 ;
  wire \counter_reg[8]_i_1__2_n_3 ;
  wire \counter_reg[8]_i_1__2_n_4 ;
  wire \counter_reg[8]_i_1__2_n_5 ;
  wire \counter_reg[8]_i_1__2_n_6 ;
  wire \counter_reg[8]_i_1__2_n_7 ;
  wire i_button_down;
  wire o_press_i_1__2_n_0;
  wire o_press_i_2__2_n_0;
  wire o_press_i_3__2_n_0;
  wire o_press_i_4__2_n_0;
  wire o_press_i_5__2_n_0;
  wire o_press_i_6__2_n_0;
  wire o_press_i_7__2_n_0;
  wire o_press_i_8__2_n_0;
  wire o_press_i_9__2_n_0;
  wire s00_axi_aclk;
  wire [3:0]NLW_counter1_carry_O_UNCONNECTED;
  wire [3:0]NLW_counter1_carry__0_O_UNCONNECTED;
  wire [3:0]NLW_counter1_carry__1_O_UNCONNECTED;
  wire [3:1]NLW_counter1_carry__2_CO_UNCONNECTED;
  wire [3:0]NLW_counter1_carry__2_O_UNCONNECTED;
  wire [3:3]\NLW_counter_reg[28]_i_1__2_CO_UNCONNECTED ;

  CARRY4 counter1_carry
       (.CI(1'b0),
        .CO({counter1_carry_n_0,counter1_carry_n_1,counter1_carry_n_2,counter1_carry_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,counter1_carry_i_1__0_n_0,counter1_carry_i_2__0_n_0}),
        .O(NLW_counter1_carry_O_UNCONNECTED[3:0]),
        .S({counter1_carry_i_3__2_n_0,counter1_carry_i_4__2_n_0,counter1_carry_i_5__2_n_0,counter1_carry_i_6__2_n_0}));
  CARRY4 counter1_carry__0
       (.CI(counter1_carry_n_0),
        .CO({counter1_carry__0_n_0,counter1_carry__0_n_1,counter1_carry__0_n_2,counter1_carry__0_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,counter1_carry__0_i_1__0_n_0,counter1_carry__0_i_2__0_n_0,counter1_carry__0_i_3__0_n_0}),
        .O(NLW_counter1_carry__0_O_UNCONNECTED[3:0]),
        .S({counter1_carry__0_i_4__2_n_0,counter1_carry__0_i_5__2_n_0,counter1_carry__0_i_6__2_n_0,counter1_carry__0_i_7__2_n_0}));
  LUT2 #(
    .INIT(4'h7)) 
    counter1_carry__0_i_1__0
       (.I0(counter_reg[18]),
        .I1(counter_reg[19]),
        .O(counter1_carry__0_i_1__0_n_0));
  LUT2 #(
    .INIT(4'h7)) 
    counter1_carry__0_i_2__0
       (.I0(counter_reg[16]),
        .I1(counter_reg[17]),
        .O(counter1_carry__0_i_2__0_n_0));
  LUT2 #(
    .INIT(4'h1)) 
    counter1_carry__0_i_3__0
       (.I0(counter_reg[14]),
        .I1(counter_reg[15]),
        .O(counter1_carry__0_i_3__0_n_0));
  LUT2 #(
    .INIT(4'h1)) 
    counter1_carry__0_i_4__2
       (.I0(counter_reg[20]),
        .I1(counter_reg[21]),
        .O(counter1_carry__0_i_4__2_n_0));
  LUT2 #(
    .INIT(4'h8)) 
    counter1_carry__0_i_5__2
       (.I0(counter_reg[18]),
        .I1(counter_reg[19]),
        .O(counter1_carry__0_i_5__2_n_0));
  LUT2 #(
    .INIT(4'h8)) 
    counter1_carry__0_i_6__2
       (.I0(counter_reg[16]),
        .I1(counter_reg[17]),
        .O(counter1_carry__0_i_6__2_n_0));
  LUT2 #(
    .INIT(4'h2)) 
    counter1_carry__0_i_7__2
       (.I0(counter_reg[14]),
        .I1(counter_reg[15]),
        .O(counter1_carry__0_i_7__2_n_0));
  CARRY4 counter1_carry__1
       (.CI(counter1_carry__0_n_0),
        .CO({counter1_carry__1_n_0,counter1_carry__1_n_1,counter1_carry__1_n_2,counter1_carry__1_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(NLW_counter1_carry__1_O_UNCONNECTED[3:0]),
        .S({counter1_carry__1_i_1__2_n_0,counter1_carry__1_i_2__2_n_0,counter1_carry__1_i_3__2_n_0,counter1_carry__1_i_4__2_n_0}));
  LUT2 #(
    .INIT(4'h1)) 
    counter1_carry__1_i_1__2
       (.I0(counter_reg[28]),
        .I1(counter_reg[29]),
        .O(counter1_carry__1_i_1__2_n_0));
  LUT2 #(
    .INIT(4'h1)) 
    counter1_carry__1_i_2__2
       (.I0(counter_reg[26]),
        .I1(counter_reg[27]),
        .O(counter1_carry__1_i_2__2_n_0));
  LUT2 #(
    .INIT(4'h1)) 
    counter1_carry__1_i_3__2
       (.I0(counter_reg[24]),
        .I1(counter_reg[25]),
        .O(counter1_carry__1_i_3__2_n_0));
  LUT2 #(
    .INIT(4'h1)) 
    counter1_carry__1_i_4__2
       (.I0(counter_reg[22]),
        .I1(counter_reg[23]),
        .O(counter1_carry__1_i_4__2_n_0));
  CARRY4 counter1_carry__2
       (.CI(counter1_carry__1_n_0),
        .CO({NLW_counter1_carry__2_CO_UNCONNECTED[3:1],counter1_carry__2_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,counter_reg[31]}),
        .O(NLW_counter1_carry__2_O_UNCONNECTED[3:0]),
        .S({1'b0,1'b0,1'b0,counter1_carry__2_i_1__2_n_0}));
  LUT2 #(
    .INIT(4'h1)) 
    counter1_carry__2_i_1__2
       (.I0(counter_reg[31]),
        .I1(counter_reg[30]),
        .O(counter1_carry__2_i_1__2_n_0));
  LUT1 #(
    .INIT(2'h1)) 
    counter1_carry_i_1__0
       (.I0(counter_reg[9]),
        .O(counter1_carry_i_1__0_n_0));
  LUT2 #(
    .INIT(4'h1)) 
    counter1_carry_i_2__0
       (.I0(counter_reg[6]),
        .I1(counter_reg[7]),
        .O(counter1_carry_i_2__0_n_0));
  LUT2 #(
    .INIT(4'h1)) 
    counter1_carry_i_3__2
       (.I0(counter_reg[12]),
        .I1(counter_reg[13]),
        .O(counter1_carry_i_3__2_n_0));
  LUT2 #(
    .INIT(4'h1)) 
    counter1_carry_i_4__2
       (.I0(counter_reg[10]),
        .I1(counter_reg[11]),
        .O(counter1_carry_i_4__2_n_0));
  LUT2 #(
    .INIT(4'h2)) 
    counter1_carry_i_5__2
       (.I0(counter_reg[9]),
        .I1(counter_reg[8]),
        .O(counter1_carry_i_5__2_n_0));
  LUT2 #(
    .INIT(4'h2)) 
    counter1_carry_i_6__2
       (.I0(counter_reg[6]),
        .I1(counter_reg[7]),
        .O(counter1_carry_i_6__2_n_0));
  LUT2 #(
    .INIT(4'h7)) 
    \counter[0]_i_1__1 
       (.I0(button_down),
        .I1(CO),
        .O(\counter_reg[31]_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \counter[0]_i_1__6 
       (.I0(i_button_down),
        .O(counter));
  LUT1 #(
    .INIT(2'h1)) 
    \counter[0]_i_3__2 
       (.I0(counter_reg[0]),
        .O(\counter[0]_i_3__2_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[0] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[0]_i_2__2_n_7 ),
        .Q(counter_reg[0]),
        .R(counter));
  CARRY4 \counter_reg[0]_i_2__2 
       (.CI(1'b0),
        .CO({\counter_reg[0]_i_2__2_n_0 ,\counter_reg[0]_i_2__2_n_1 ,\counter_reg[0]_i_2__2_n_2 ,\counter_reg[0]_i_2__2_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b1}),
        .O({\counter_reg[0]_i_2__2_n_4 ,\counter_reg[0]_i_2__2_n_5 ,\counter_reg[0]_i_2__2_n_6 ,\counter_reg[0]_i_2__2_n_7 }),
        .S({counter_reg[3:1],\counter[0]_i_3__2_n_0 }));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[10] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[8]_i_1__2_n_5 ),
        .Q(counter_reg[10]),
        .R(counter));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[11] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[8]_i_1__2_n_4 ),
        .Q(counter_reg[11]),
        .R(counter));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[12] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[12]_i_1__2_n_7 ),
        .Q(counter_reg[12]),
        .R(counter));
  CARRY4 \counter_reg[12]_i_1__2 
       (.CI(\counter_reg[8]_i_1__2_n_0 ),
        .CO({\counter_reg[12]_i_1__2_n_0 ,\counter_reg[12]_i_1__2_n_1 ,\counter_reg[12]_i_1__2_n_2 ,\counter_reg[12]_i_1__2_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\counter_reg[12]_i_1__2_n_4 ,\counter_reg[12]_i_1__2_n_5 ,\counter_reg[12]_i_1__2_n_6 ,\counter_reg[12]_i_1__2_n_7 }),
        .S(counter_reg[15:12]));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[13] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[12]_i_1__2_n_6 ),
        .Q(counter_reg[13]),
        .R(counter));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[14] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[12]_i_1__2_n_5 ),
        .Q(counter_reg[14]),
        .R(counter));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[15] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[12]_i_1__2_n_4 ),
        .Q(counter_reg[15]),
        .R(counter));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[16] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[16]_i_1__2_n_7 ),
        .Q(counter_reg[16]),
        .R(counter));
  CARRY4 \counter_reg[16]_i_1__2 
       (.CI(\counter_reg[12]_i_1__2_n_0 ),
        .CO({\counter_reg[16]_i_1__2_n_0 ,\counter_reg[16]_i_1__2_n_1 ,\counter_reg[16]_i_1__2_n_2 ,\counter_reg[16]_i_1__2_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\counter_reg[16]_i_1__2_n_4 ,\counter_reg[16]_i_1__2_n_5 ,\counter_reg[16]_i_1__2_n_6 ,\counter_reg[16]_i_1__2_n_7 }),
        .S(counter_reg[19:16]));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[17] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[16]_i_1__2_n_6 ),
        .Q(counter_reg[17]),
        .R(counter));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[18] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[16]_i_1__2_n_5 ),
        .Q(counter_reg[18]),
        .R(counter));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[19] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[16]_i_1__2_n_4 ),
        .Q(counter_reg[19]),
        .R(counter));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[1] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[0]_i_2__2_n_6 ),
        .Q(counter_reg[1]),
        .R(counter));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[20] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[20]_i_1__2_n_7 ),
        .Q(counter_reg[20]),
        .R(counter));
  CARRY4 \counter_reg[20]_i_1__2 
       (.CI(\counter_reg[16]_i_1__2_n_0 ),
        .CO({\counter_reg[20]_i_1__2_n_0 ,\counter_reg[20]_i_1__2_n_1 ,\counter_reg[20]_i_1__2_n_2 ,\counter_reg[20]_i_1__2_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\counter_reg[20]_i_1__2_n_4 ,\counter_reg[20]_i_1__2_n_5 ,\counter_reg[20]_i_1__2_n_6 ,\counter_reg[20]_i_1__2_n_7 }),
        .S(counter_reg[23:20]));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[21] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[20]_i_1__2_n_6 ),
        .Q(counter_reg[21]),
        .R(counter));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[22] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[20]_i_1__2_n_5 ),
        .Q(counter_reg[22]),
        .R(counter));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[23] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[20]_i_1__2_n_4 ),
        .Q(counter_reg[23]),
        .R(counter));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[24] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[24]_i_1__2_n_7 ),
        .Q(counter_reg[24]),
        .R(counter));
  CARRY4 \counter_reg[24]_i_1__2 
       (.CI(\counter_reg[20]_i_1__2_n_0 ),
        .CO({\counter_reg[24]_i_1__2_n_0 ,\counter_reg[24]_i_1__2_n_1 ,\counter_reg[24]_i_1__2_n_2 ,\counter_reg[24]_i_1__2_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\counter_reg[24]_i_1__2_n_4 ,\counter_reg[24]_i_1__2_n_5 ,\counter_reg[24]_i_1__2_n_6 ,\counter_reg[24]_i_1__2_n_7 }),
        .S(counter_reg[27:24]));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[25] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[24]_i_1__2_n_6 ),
        .Q(counter_reg[25]),
        .R(counter));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[26] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[24]_i_1__2_n_5 ),
        .Q(counter_reg[26]),
        .R(counter));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[27] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[24]_i_1__2_n_4 ),
        .Q(counter_reg[27]),
        .R(counter));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[28] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[28]_i_1__2_n_7 ),
        .Q(counter_reg[28]),
        .R(counter));
  CARRY4 \counter_reg[28]_i_1__2 
       (.CI(\counter_reg[24]_i_1__2_n_0 ),
        .CO({\NLW_counter_reg[28]_i_1__2_CO_UNCONNECTED [3],\counter_reg[28]_i_1__2_n_1 ,\counter_reg[28]_i_1__2_n_2 ,\counter_reg[28]_i_1__2_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\counter_reg[28]_i_1__2_n_4 ,\counter_reg[28]_i_1__2_n_5 ,\counter_reg[28]_i_1__2_n_6 ,\counter_reg[28]_i_1__2_n_7 }),
        .S(counter_reg[31:28]));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[29] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[28]_i_1__2_n_6 ),
        .Q(counter_reg[29]),
        .R(counter));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[2] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[0]_i_2__2_n_5 ),
        .Q(counter_reg[2]),
        .R(counter));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[30] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[28]_i_1__2_n_5 ),
        .Q(counter_reg[30]),
        .R(counter));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[31] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[28]_i_1__2_n_4 ),
        .Q(counter_reg[31]),
        .R(counter));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[3] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[0]_i_2__2_n_4 ),
        .Q(counter_reg[3]),
        .R(counter));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[4] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[4]_i_1__2_n_7 ),
        .Q(counter_reg[4]),
        .R(counter));
  CARRY4 \counter_reg[4]_i_1__2 
       (.CI(\counter_reg[0]_i_2__2_n_0 ),
        .CO({\counter_reg[4]_i_1__2_n_0 ,\counter_reg[4]_i_1__2_n_1 ,\counter_reg[4]_i_1__2_n_2 ,\counter_reg[4]_i_1__2_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\counter_reg[4]_i_1__2_n_4 ,\counter_reg[4]_i_1__2_n_5 ,\counter_reg[4]_i_1__2_n_6 ,\counter_reg[4]_i_1__2_n_7 }),
        .S(counter_reg[7:4]));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[5] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[4]_i_1__2_n_6 ),
        .Q(counter_reg[5]),
        .R(counter));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[6] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[4]_i_1__2_n_5 ),
        .Q(counter_reg[6]),
        .R(counter));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[7] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[4]_i_1__2_n_4 ),
        .Q(counter_reg[7]),
        .R(counter));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[8] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[8]_i_1__2_n_7 ),
        .Q(counter_reg[8]),
        .R(counter));
  CARRY4 \counter_reg[8]_i_1__2 
       (.CI(\counter_reg[4]_i_1__2_n_0 ),
        .CO({\counter_reg[8]_i_1__2_n_0 ,\counter_reg[8]_i_1__2_n_1 ,\counter_reg[8]_i_1__2_n_2 ,\counter_reg[8]_i_1__2_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\counter_reg[8]_i_1__2_n_4 ,\counter_reg[8]_i_1__2_n_5 ,\counter_reg[8]_i_1__2_n_6 ,\counter_reg[8]_i_1__2_n_7 }),
        .S(counter_reg[11:8]));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[9] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[8]_i_1__2_n_6 ),
        .Q(counter_reg[9]),
        .R(counter));
  LUT6 #(
    .INIT(64'h0000000000000001)) 
    o_press_i_1__2
       (.I0(o_press_i_2__2_n_0),
        .I1(o_press_i_3__2_n_0),
        .I2(counter_reg[30]),
        .I3(counter_reg[31]),
        .I4(o_press_i_4__2_n_0),
        .I5(o_press_i_5__2_n_0),
        .O(o_press_i_1__2_n_0));
  LUT5 #(
    .INIT(32'hFFFFFFFE)) 
    o_press_i_2__2
       (.I0(counter_reg[21]),
        .I1(counter_reg[20]),
        .I2(counter_reg[23]),
        .I3(counter_reg[22]),
        .I4(o_press_i_6__2_n_0),
        .O(o_press_i_2__2_n_0));
  LUT2 #(
    .INIT(4'hE)) 
    o_press_i_3__2
       (.I0(counter_reg[29]),
        .I1(counter_reg[28]),
        .O(o_press_i_3__2_n_0));
  LUT4 #(
    .INIT(16'hFFFE)) 
    o_press_i_4__2
       (.I0(counter_reg[26]),
        .I1(counter_reg[27]),
        .I2(counter_reg[24]),
        .I3(counter_reg[25]),
        .O(o_press_i_4__2_n_0));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFFFFE)) 
    o_press_i_5__2
       (.I0(o_press_i_7__2_n_0),
        .I1(counter_reg[3]),
        .I2(counter_reg[15]),
        .I3(counter_reg[12]),
        .I4(counter_reg[13]),
        .I5(o_press_i_8__2_n_0),
        .O(o_press_i_5__2_n_0));
  LUT4 #(
    .INIT(16'hFFFE)) 
    o_press_i_6__2
       (.I0(counter_reg[0]),
        .I1(counter_reg[5]),
        .I2(counter_reg[2]),
        .I3(counter_reg[1]),
        .O(o_press_i_6__2_n_0));
  LUT4 #(
    .INIT(16'hFFFE)) 
    o_press_i_7__2
       (.I0(counter_reg[10]),
        .I1(counter_reg[11]),
        .I2(counter_reg[8]),
        .I3(counter_reg[4]),
        .O(o_press_i_7__2_n_0));
  LUT5 #(
    .INIT(32'hFFFFF7FF)) 
    o_press_i_8__2
       (.I0(counter_reg[6]),
        .I1(counter_reg[9]),
        .I2(counter_reg[7]),
        .I3(counter_reg[19]),
        .I4(o_press_i_9__2_n_0),
        .O(o_press_i_8__2_n_0));
  LUT4 #(
    .INIT(16'h7FFF)) 
    o_press_i_9__2
       (.I0(counter_reg[16]),
        .I1(counter_reg[14]),
        .I2(counter_reg[18]),
        .I3(counter_reg[17]),
        .O(o_press_i_9__2_n_0));
  FDRE o_press_reg
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(o_press_i_1__2_n_0),
        .Q(button_down),
        .R(1'b0));
endmodule

(* ORIG_REF_NAME = "debounce" *) 
module decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_debounce_0
   (clear,
    s00_axi_aclk,
    CO,
    i_button_left);
  output clear;
  input s00_axi_aclk;
  input [0:0]CO;
  input i_button_left;

  wire [0:0]CO;
  wire button_Left;
  wire clear;
  wire counter;
  wire counter1_carry__0_i_1__3_n_0;
  wire counter1_carry__0_i_2__3_n_0;
  wire counter1_carry__0_i_3__3_n_0;
  wire counter1_carry__0_i_4_n_0;
  wire counter1_carry__0_i_5_n_0;
  wire counter1_carry__0_i_6_n_0;
  wire counter1_carry__0_i_7_n_0;
  wire counter1_carry__0_n_0;
  wire counter1_carry__0_n_1;
  wire counter1_carry__0_n_2;
  wire counter1_carry__0_n_3;
  wire counter1_carry__1_i_1_n_0;
  wire counter1_carry__1_i_2_n_0;
  wire counter1_carry__1_i_3_n_0;
  wire counter1_carry__1_i_4_n_0;
  wire counter1_carry__1_n_0;
  wire counter1_carry__1_n_1;
  wire counter1_carry__1_n_2;
  wire counter1_carry__1_n_3;
  wire counter1_carry__2_i_1_n_0;
  wire counter1_carry__2_n_3;
  wire counter1_carry_i_1__3_n_0;
  wire counter1_carry_i_2__3_n_0;
  wire counter1_carry_i_3_n_0;
  wire counter1_carry_i_4_n_0;
  wire counter1_carry_i_5_n_0;
  wire counter1_carry_i_6_n_0;
  wire counter1_carry_n_0;
  wire counter1_carry_n_1;
  wire counter1_carry_n_2;
  wire counter1_carry_n_3;
  wire \counter[0]_i_3_n_0 ;
  wire [31:0]counter_reg;
  wire \counter_reg[0]_i_2_n_0 ;
  wire \counter_reg[0]_i_2_n_1 ;
  wire \counter_reg[0]_i_2_n_2 ;
  wire \counter_reg[0]_i_2_n_3 ;
  wire \counter_reg[0]_i_2_n_4 ;
  wire \counter_reg[0]_i_2_n_5 ;
  wire \counter_reg[0]_i_2_n_6 ;
  wire \counter_reg[0]_i_2_n_7 ;
  wire \counter_reg[12]_i_1_n_0 ;
  wire \counter_reg[12]_i_1_n_1 ;
  wire \counter_reg[12]_i_1_n_2 ;
  wire \counter_reg[12]_i_1_n_3 ;
  wire \counter_reg[12]_i_1_n_4 ;
  wire \counter_reg[12]_i_1_n_5 ;
  wire \counter_reg[12]_i_1_n_6 ;
  wire \counter_reg[12]_i_1_n_7 ;
  wire \counter_reg[16]_i_1_n_0 ;
  wire \counter_reg[16]_i_1_n_1 ;
  wire \counter_reg[16]_i_1_n_2 ;
  wire \counter_reg[16]_i_1_n_3 ;
  wire \counter_reg[16]_i_1_n_4 ;
  wire \counter_reg[16]_i_1_n_5 ;
  wire \counter_reg[16]_i_1_n_6 ;
  wire \counter_reg[16]_i_1_n_7 ;
  wire \counter_reg[20]_i_1_n_0 ;
  wire \counter_reg[20]_i_1_n_1 ;
  wire \counter_reg[20]_i_1_n_2 ;
  wire \counter_reg[20]_i_1_n_3 ;
  wire \counter_reg[20]_i_1_n_4 ;
  wire \counter_reg[20]_i_1_n_5 ;
  wire \counter_reg[20]_i_1_n_6 ;
  wire \counter_reg[20]_i_1_n_7 ;
  wire \counter_reg[24]_i_1_n_0 ;
  wire \counter_reg[24]_i_1_n_1 ;
  wire \counter_reg[24]_i_1_n_2 ;
  wire \counter_reg[24]_i_1_n_3 ;
  wire \counter_reg[24]_i_1_n_4 ;
  wire \counter_reg[24]_i_1_n_5 ;
  wire \counter_reg[24]_i_1_n_6 ;
  wire \counter_reg[24]_i_1_n_7 ;
  wire \counter_reg[28]_i_1_n_1 ;
  wire \counter_reg[28]_i_1_n_2 ;
  wire \counter_reg[28]_i_1_n_3 ;
  wire \counter_reg[28]_i_1_n_4 ;
  wire \counter_reg[28]_i_1_n_5 ;
  wire \counter_reg[28]_i_1_n_6 ;
  wire \counter_reg[28]_i_1_n_7 ;
  wire \counter_reg[4]_i_1_n_0 ;
  wire \counter_reg[4]_i_1_n_1 ;
  wire \counter_reg[4]_i_1_n_2 ;
  wire \counter_reg[4]_i_1_n_3 ;
  wire \counter_reg[4]_i_1_n_4 ;
  wire \counter_reg[4]_i_1_n_5 ;
  wire \counter_reg[4]_i_1_n_6 ;
  wire \counter_reg[4]_i_1_n_7 ;
  wire \counter_reg[8]_i_1_n_0 ;
  wire \counter_reg[8]_i_1_n_1 ;
  wire \counter_reg[8]_i_1_n_2 ;
  wire \counter_reg[8]_i_1_n_3 ;
  wire \counter_reg[8]_i_1_n_4 ;
  wire \counter_reg[8]_i_1_n_5 ;
  wire \counter_reg[8]_i_1_n_6 ;
  wire \counter_reg[8]_i_1_n_7 ;
  wire i_button_left;
  wire o_press_i_1_n_0;
  wire o_press_i_2_n_0;
  wire o_press_i_3_n_0;
  wire o_press_i_4_n_0;
  wire o_press_i_5_n_0;
  wire o_press_i_6_n_0;
  wire o_press_i_7_n_0;
  wire o_press_i_8_n_0;
  wire o_press_i_9_n_0;
  wire s00_axi_aclk;
  wire [3:0]NLW_counter1_carry_O_UNCONNECTED;
  wire [3:0]NLW_counter1_carry__0_O_UNCONNECTED;
  wire [3:0]NLW_counter1_carry__1_O_UNCONNECTED;
  wire [3:1]NLW_counter1_carry__2_CO_UNCONNECTED;
  wire [3:0]NLW_counter1_carry__2_O_UNCONNECTED;
  wire [3:3]\NLW_counter_reg[28]_i_1_CO_UNCONNECTED ;

  CARRY4 counter1_carry
       (.CI(1'b0),
        .CO({counter1_carry_n_0,counter1_carry_n_1,counter1_carry_n_2,counter1_carry_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,counter1_carry_i_1__3_n_0,counter1_carry_i_2__3_n_0}),
        .O(NLW_counter1_carry_O_UNCONNECTED[3:0]),
        .S({counter1_carry_i_3_n_0,counter1_carry_i_4_n_0,counter1_carry_i_5_n_0,counter1_carry_i_6_n_0}));
  CARRY4 counter1_carry__0
       (.CI(counter1_carry_n_0),
        .CO({counter1_carry__0_n_0,counter1_carry__0_n_1,counter1_carry__0_n_2,counter1_carry__0_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,counter1_carry__0_i_1__3_n_0,counter1_carry__0_i_2__3_n_0,counter1_carry__0_i_3__3_n_0}),
        .O(NLW_counter1_carry__0_O_UNCONNECTED[3:0]),
        .S({counter1_carry__0_i_4_n_0,counter1_carry__0_i_5_n_0,counter1_carry__0_i_6_n_0,counter1_carry__0_i_7_n_0}));
  LUT2 #(
    .INIT(4'h7)) 
    counter1_carry__0_i_1__3
       (.I0(counter_reg[18]),
        .I1(counter_reg[19]),
        .O(counter1_carry__0_i_1__3_n_0));
  LUT2 #(
    .INIT(4'h7)) 
    counter1_carry__0_i_2__3
       (.I0(counter_reg[16]),
        .I1(counter_reg[17]),
        .O(counter1_carry__0_i_2__3_n_0));
  LUT2 #(
    .INIT(4'h1)) 
    counter1_carry__0_i_3__3
       (.I0(counter_reg[14]),
        .I1(counter_reg[15]),
        .O(counter1_carry__0_i_3__3_n_0));
  LUT2 #(
    .INIT(4'h1)) 
    counter1_carry__0_i_4
       (.I0(counter_reg[20]),
        .I1(counter_reg[21]),
        .O(counter1_carry__0_i_4_n_0));
  LUT2 #(
    .INIT(4'h8)) 
    counter1_carry__0_i_5
       (.I0(counter_reg[18]),
        .I1(counter_reg[19]),
        .O(counter1_carry__0_i_5_n_0));
  LUT2 #(
    .INIT(4'h8)) 
    counter1_carry__0_i_6
       (.I0(counter_reg[16]),
        .I1(counter_reg[17]),
        .O(counter1_carry__0_i_6_n_0));
  LUT2 #(
    .INIT(4'h2)) 
    counter1_carry__0_i_7
       (.I0(counter_reg[14]),
        .I1(counter_reg[15]),
        .O(counter1_carry__0_i_7_n_0));
  CARRY4 counter1_carry__1
       (.CI(counter1_carry__0_n_0),
        .CO({counter1_carry__1_n_0,counter1_carry__1_n_1,counter1_carry__1_n_2,counter1_carry__1_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(NLW_counter1_carry__1_O_UNCONNECTED[3:0]),
        .S({counter1_carry__1_i_1_n_0,counter1_carry__1_i_2_n_0,counter1_carry__1_i_3_n_0,counter1_carry__1_i_4_n_0}));
  LUT2 #(
    .INIT(4'h1)) 
    counter1_carry__1_i_1
       (.I0(counter_reg[28]),
        .I1(counter_reg[29]),
        .O(counter1_carry__1_i_1_n_0));
  LUT2 #(
    .INIT(4'h1)) 
    counter1_carry__1_i_2
       (.I0(counter_reg[26]),
        .I1(counter_reg[27]),
        .O(counter1_carry__1_i_2_n_0));
  LUT2 #(
    .INIT(4'h1)) 
    counter1_carry__1_i_3
       (.I0(counter_reg[24]),
        .I1(counter_reg[25]),
        .O(counter1_carry__1_i_3_n_0));
  LUT2 #(
    .INIT(4'h1)) 
    counter1_carry__1_i_4
       (.I0(counter_reg[22]),
        .I1(counter_reg[23]),
        .O(counter1_carry__1_i_4_n_0));
  CARRY4 counter1_carry__2
       (.CI(counter1_carry__1_n_0),
        .CO({NLW_counter1_carry__2_CO_UNCONNECTED[3:1],counter1_carry__2_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,counter_reg[31]}),
        .O(NLW_counter1_carry__2_O_UNCONNECTED[3:0]),
        .S({1'b0,1'b0,1'b0,counter1_carry__2_i_1_n_0}));
  LUT2 #(
    .INIT(4'h1)) 
    counter1_carry__2_i_1
       (.I0(counter_reg[31]),
        .I1(counter_reg[30]),
        .O(counter1_carry__2_i_1_n_0));
  LUT1 #(
    .INIT(2'h1)) 
    counter1_carry_i_1__3
       (.I0(counter_reg[9]),
        .O(counter1_carry_i_1__3_n_0));
  LUT2 #(
    .INIT(4'h1)) 
    counter1_carry_i_2__3
       (.I0(counter_reg[6]),
        .I1(counter_reg[7]),
        .O(counter1_carry_i_2__3_n_0));
  LUT2 #(
    .INIT(4'h1)) 
    counter1_carry_i_3
       (.I0(counter_reg[12]),
        .I1(counter_reg[13]),
        .O(counter1_carry_i_3_n_0));
  LUT2 #(
    .INIT(4'h1)) 
    counter1_carry_i_4
       (.I0(counter_reg[10]),
        .I1(counter_reg[11]),
        .O(counter1_carry_i_4_n_0));
  LUT2 #(
    .INIT(4'h2)) 
    counter1_carry_i_5
       (.I0(counter_reg[9]),
        .I1(counter_reg[8]),
        .O(counter1_carry_i_5_n_0));
  LUT2 #(
    .INIT(4'h2)) 
    counter1_carry_i_6
       (.I0(counter_reg[6]),
        .I1(counter_reg[7]),
        .O(counter1_carry_i_6_n_0));
  LUT2 #(
    .INIT(4'h7)) 
    \counter[0]_i_1__0 
       (.I0(button_Left),
        .I1(CO),
        .O(clear));
  LUT1 #(
    .INIT(2'h1)) 
    \counter[0]_i_1__3 
       (.I0(i_button_left),
        .O(counter));
  LUT1 #(
    .INIT(2'h1)) 
    \counter[0]_i_3 
       (.I0(counter_reg[0]),
        .O(\counter[0]_i_3_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[0] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[0]_i_2_n_7 ),
        .Q(counter_reg[0]),
        .R(counter));
  CARRY4 \counter_reg[0]_i_2 
       (.CI(1'b0),
        .CO({\counter_reg[0]_i_2_n_0 ,\counter_reg[0]_i_2_n_1 ,\counter_reg[0]_i_2_n_2 ,\counter_reg[0]_i_2_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b1}),
        .O({\counter_reg[0]_i_2_n_4 ,\counter_reg[0]_i_2_n_5 ,\counter_reg[0]_i_2_n_6 ,\counter_reg[0]_i_2_n_7 }),
        .S({counter_reg[3:1],\counter[0]_i_3_n_0 }));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[10] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[8]_i_1_n_5 ),
        .Q(counter_reg[10]),
        .R(counter));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[11] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[8]_i_1_n_4 ),
        .Q(counter_reg[11]),
        .R(counter));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[12] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[12]_i_1_n_7 ),
        .Q(counter_reg[12]),
        .R(counter));
  CARRY4 \counter_reg[12]_i_1 
       (.CI(\counter_reg[8]_i_1_n_0 ),
        .CO({\counter_reg[12]_i_1_n_0 ,\counter_reg[12]_i_1_n_1 ,\counter_reg[12]_i_1_n_2 ,\counter_reg[12]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\counter_reg[12]_i_1_n_4 ,\counter_reg[12]_i_1_n_5 ,\counter_reg[12]_i_1_n_6 ,\counter_reg[12]_i_1_n_7 }),
        .S(counter_reg[15:12]));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[13] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[12]_i_1_n_6 ),
        .Q(counter_reg[13]),
        .R(counter));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[14] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[12]_i_1_n_5 ),
        .Q(counter_reg[14]),
        .R(counter));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[15] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[12]_i_1_n_4 ),
        .Q(counter_reg[15]),
        .R(counter));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[16] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[16]_i_1_n_7 ),
        .Q(counter_reg[16]),
        .R(counter));
  CARRY4 \counter_reg[16]_i_1 
       (.CI(\counter_reg[12]_i_1_n_0 ),
        .CO({\counter_reg[16]_i_1_n_0 ,\counter_reg[16]_i_1_n_1 ,\counter_reg[16]_i_1_n_2 ,\counter_reg[16]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\counter_reg[16]_i_1_n_4 ,\counter_reg[16]_i_1_n_5 ,\counter_reg[16]_i_1_n_6 ,\counter_reg[16]_i_1_n_7 }),
        .S(counter_reg[19:16]));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[17] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[16]_i_1_n_6 ),
        .Q(counter_reg[17]),
        .R(counter));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[18] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[16]_i_1_n_5 ),
        .Q(counter_reg[18]),
        .R(counter));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[19] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[16]_i_1_n_4 ),
        .Q(counter_reg[19]),
        .R(counter));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[1] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[0]_i_2_n_6 ),
        .Q(counter_reg[1]),
        .R(counter));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[20] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[20]_i_1_n_7 ),
        .Q(counter_reg[20]),
        .R(counter));
  CARRY4 \counter_reg[20]_i_1 
       (.CI(\counter_reg[16]_i_1_n_0 ),
        .CO({\counter_reg[20]_i_1_n_0 ,\counter_reg[20]_i_1_n_1 ,\counter_reg[20]_i_1_n_2 ,\counter_reg[20]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\counter_reg[20]_i_1_n_4 ,\counter_reg[20]_i_1_n_5 ,\counter_reg[20]_i_1_n_6 ,\counter_reg[20]_i_1_n_7 }),
        .S(counter_reg[23:20]));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[21] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[20]_i_1_n_6 ),
        .Q(counter_reg[21]),
        .R(counter));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[22] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[20]_i_1_n_5 ),
        .Q(counter_reg[22]),
        .R(counter));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[23] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[20]_i_1_n_4 ),
        .Q(counter_reg[23]),
        .R(counter));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[24] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[24]_i_1_n_7 ),
        .Q(counter_reg[24]),
        .R(counter));
  CARRY4 \counter_reg[24]_i_1 
       (.CI(\counter_reg[20]_i_1_n_0 ),
        .CO({\counter_reg[24]_i_1_n_0 ,\counter_reg[24]_i_1_n_1 ,\counter_reg[24]_i_1_n_2 ,\counter_reg[24]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\counter_reg[24]_i_1_n_4 ,\counter_reg[24]_i_1_n_5 ,\counter_reg[24]_i_1_n_6 ,\counter_reg[24]_i_1_n_7 }),
        .S(counter_reg[27:24]));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[25] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[24]_i_1_n_6 ),
        .Q(counter_reg[25]),
        .R(counter));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[26] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[24]_i_1_n_5 ),
        .Q(counter_reg[26]),
        .R(counter));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[27] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[24]_i_1_n_4 ),
        .Q(counter_reg[27]),
        .R(counter));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[28] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[28]_i_1_n_7 ),
        .Q(counter_reg[28]),
        .R(counter));
  CARRY4 \counter_reg[28]_i_1 
       (.CI(\counter_reg[24]_i_1_n_0 ),
        .CO({\NLW_counter_reg[28]_i_1_CO_UNCONNECTED [3],\counter_reg[28]_i_1_n_1 ,\counter_reg[28]_i_1_n_2 ,\counter_reg[28]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\counter_reg[28]_i_1_n_4 ,\counter_reg[28]_i_1_n_5 ,\counter_reg[28]_i_1_n_6 ,\counter_reg[28]_i_1_n_7 }),
        .S(counter_reg[31:28]));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[29] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[28]_i_1_n_6 ),
        .Q(counter_reg[29]),
        .R(counter));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[2] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[0]_i_2_n_5 ),
        .Q(counter_reg[2]),
        .R(counter));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[30] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[28]_i_1_n_5 ),
        .Q(counter_reg[30]),
        .R(counter));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[31] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[28]_i_1_n_4 ),
        .Q(counter_reg[31]),
        .R(counter));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[3] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[0]_i_2_n_4 ),
        .Q(counter_reg[3]),
        .R(counter));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[4] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[4]_i_1_n_7 ),
        .Q(counter_reg[4]),
        .R(counter));
  CARRY4 \counter_reg[4]_i_1 
       (.CI(\counter_reg[0]_i_2_n_0 ),
        .CO({\counter_reg[4]_i_1_n_0 ,\counter_reg[4]_i_1_n_1 ,\counter_reg[4]_i_1_n_2 ,\counter_reg[4]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\counter_reg[4]_i_1_n_4 ,\counter_reg[4]_i_1_n_5 ,\counter_reg[4]_i_1_n_6 ,\counter_reg[4]_i_1_n_7 }),
        .S(counter_reg[7:4]));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[5] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[4]_i_1_n_6 ),
        .Q(counter_reg[5]),
        .R(counter));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[6] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[4]_i_1_n_5 ),
        .Q(counter_reg[6]),
        .R(counter));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[7] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[4]_i_1_n_4 ),
        .Q(counter_reg[7]),
        .R(counter));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[8] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[8]_i_1_n_7 ),
        .Q(counter_reg[8]),
        .R(counter));
  CARRY4 \counter_reg[8]_i_1 
       (.CI(\counter_reg[4]_i_1_n_0 ),
        .CO({\counter_reg[8]_i_1_n_0 ,\counter_reg[8]_i_1_n_1 ,\counter_reg[8]_i_1_n_2 ,\counter_reg[8]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\counter_reg[8]_i_1_n_4 ,\counter_reg[8]_i_1_n_5 ,\counter_reg[8]_i_1_n_6 ,\counter_reg[8]_i_1_n_7 }),
        .S(counter_reg[11:8]));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[9] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[8]_i_1_n_6 ),
        .Q(counter_reg[9]),
        .R(counter));
  LUT6 #(
    .INIT(64'h0000000000000001)) 
    o_press_i_1
       (.I0(o_press_i_2_n_0),
        .I1(o_press_i_3_n_0),
        .I2(counter_reg[30]),
        .I3(counter_reg[31]),
        .I4(o_press_i_4_n_0),
        .I5(o_press_i_5_n_0),
        .O(o_press_i_1_n_0));
  LUT5 #(
    .INIT(32'hFFFFFFFE)) 
    o_press_i_2
       (.I0(counter_reg[21]),
        .I1(counter_reg[20]),
        .I2(counter_reg[23]),
        .I3(counter_reg[22]),
        .I4(o_press_i_6_n_0),
        .O(o_press_i_2_n_0));
  LUT2 #(
    .INIT(4'hE)) 
    o_press_i_3
       (.I0(counter_reg[29]),
        .I1(counter_reg[28]),
        .O(o_press_i_3_n_0));
  LUT4 #(
    .INIT(16'hFFFE)) 
    o_press_i_4
       (.I0(counter_reg[26]),
        .I1(counter_reg[27]),
        .I2(counter_reg[24]),
        .I3(counter_reg[25]),
        .O(o_press_i_4_n_0));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFFFFE)) 
    o_press_i_5
       (.I0(o_press_i_7_n_0),
        .I1(counter_reg[3]),
        .I2(counter_reg[15]),
        .I3(counter_reg[12]),
        .I4(counter_reg[13]),
        .I5(o_press_i_8_n_0),
        .O(o_press_i_5_n_0));
  LUT4 #(
    .INIT(16'hFFFE)) 
    o_press_i_6
       (.I0(counter_reg[0]),
        .I1(counter_reg[5]),
        .I2(counter_reg[2]),
        .I3(counter_reg[1]),
        .O(o_press_i_6_n_0));
  LUT4 #(
    .INIT(16'hFFFE)) 
    o_press_i_7
       (.I0(counter_reg[10]),
        .I1(counter_reg[11]),
        .I2(counter_reg[8]),
        .I3(counter_reg[4]),
        .O(o_press_i_7_n_0));
  LUT5 #(
    .INIT(32'hFFFFF7FF)) 
    o_press_i_8
       (.I0(counter_reg[6]),
        .I1(counter_reg[9]),
        .I2(counter_reg[7]),
        .I3(counter_reg[19]),
        .I4(o_press_i_9_n_0),
        .O(o_press_i_8_n_0));
  LUT4 #(
    .INIT(16'h7FFF)) 
    o_press_i_9
       (.I0(counter_reg[16]),
        .I1(counter_reg[14]),
        .I2(counter_reg[18]),
        .I3(counter_reg[17]),
        .O(o_press_i_9_n_0));
  FDRE o_press_reg
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(o_press_i_1_n_0),
        .Q(button_Left),
        .R(1'b0));
endmodule

(* ORIG_REF_NAME = "debounce" *) 
module decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_debounce_1
   (\counter_reg[31]_0 ,
    s00_axi_aclk,
    CO,
    i_button_right);
  output \counter_reg[31]_0 ;
  input s00_axi_aclk;
  input [0:0]CO;
  input i_button_right;

  wire [0:0]CO;
  wire button_Right;
  wire counter;
  wire counter1_carry__0_i_1__2_n_0;
  wire counter1_carry__0_i_2__2_n_0;
  wire counter1_carry__0_i_3__2_n_0;
  wire counter1_carry__0_i_4__0_n_0;
  wire counter1_carry__0_i_5__0_n_0;
  wire counter1_carry__0_i_6__0_n_0;
  wire counter1_carry__0_i_7__0_n_0;
  wire counter1_carry__0_n_0;
  wire counter1_carry__0_n_1;
  wire counter1_carry__0_n_2;
  wire counter1_carry__0_n_3;
  wire counter1_carry__1_i_1__0_n_0;
  wire counter1_carry__1_i_2__0_n_0;
  wire counter1_carry__1_i_3__0_n_0;
  wire counter1_carry__1_i_4__0_n_0;
  wire counter1_carry__1_n_0;
  wire counter1_carry__1_n_1;
  wire counter1_carry__1_n_2;
  wire counter1_carry__1_n_3;
  wire counter1_carry__2_i_1__0_n_0;
  wire counter1_carry__2_n_3;
  wire counter1_carry_i_1__2_n_0;
  wire counter1_carry_i_2__2_n_0;
  wire counter1_carry_i_3__0_n_0;
  wire counter1_carry_i_4__0_n_0;
  wire counter1_carry_i_5__0_n_0;
  wire counter1_carry_i_6__0_n_0;
  wire counter1_carry_n_0;
  wire counter1_carry_n_1;
  wire counter1_carry_n_2;
  wire counter1_carry_n_3;
  wire \counter[0]_i_3__0_n_0 ;
  wire [31:0]counter_reg;
  wire \counter_reg[0]_i_2__0_n_0 ;
  wire \counter_reg[0]_i_2__0_n_1 ;
  wire \counter_reg[0]_i_2__0_n_2 ;
  wire \counter_reg[0]_i_2__0_n_3 ;
  wire \counter_reg[0]_i_2__0_n_4 ;
  wire \counter_reg[0]_i_2__0_n_5 ;
  wire \counter_reg[0]_i_2__0_n_6 ;
  wire \counter_reg[0]_i_2__0_n_7 ;
  wire \counter_reg[12]_i_1__0_n_0 ;
  wire \counter_reg[12]_i_1__0_n_1 ;
  wire \counter_reg[12]_i_1__0_n_2 ;
  wire \counter_reg[12]_i_1__0_n_3 ;
  wire \counter_reg[12]_i_1__0_n_4 ;
  wire \counter_reg[12]_i_1__0_n_5 ;
  wire \counter_reg[12]_i_1__0_n_6 ;
  wire \counter_reg[12]_i_1__0_n_7 ;
  wire \counter_reg[16]_i_1__0_n_0 ;
  wire \counter_reg[16]_i_1__0_n_1 ;
  wire \counter_reg[16]_i_1__0_n_2 ;
  wire \counter_reg[16]_i_1__0_n_3 ;
  wire \counter_reg[16]_i_1__0_n_4 ;
  wire \counter_reg[16]_i_1__0_n_5 ;
  wire \counter_reg[16]_i_1__0_n_6 ;
  wire \counter_reg[16]_i_1__0_n_7 ;
  wire \counter_reg[20]_i_1__0_n_0 ;
  wire \counter_reg[20]_i_1__0_n_1 ;
  wire \counter_reg[20]_i_1__0_n_2 ;
  wire \counter_reg[20]_i_1__0_n_3 ;
  wire \counter_reg[20]_i_1__0_n_4 ;
  wire \counter_reg[20]_i_1__0_n_5 ;
  wire \counter_reg[20]_i_1__0_n_6 ;
  wire \counter_reg[20]_i_1__0_n_7 ;
  wire \counter_reg[24]_i_1__0_n_0 ;
  wire \counter_reg[24]_i_1__0_n_1 ;
  wire \counter_reg[24]_i_1__0_n_2 ;
  wire \counter_reg[24]_i_1__0_n_3 ;
  wire \counter_reg[24]_i_1__0_n_4 ;
  wire \counter_reg[24]_i_1__0_n_5 ;
  wire \counter_reg[24]_i_1__0_n_6 ;
  wire \counter_reg[24]_i_1__0_n_7 ;
  wire \counter_reg[28]_i_1__0_n_1 ;
  wire \counter_reg[28]_i_1__0_n_2 ;
  wire \counter_reg[28]_i_1__0_n_3 ;
  wire \counter_reg[28]_i_1__0_n_4 ;
  wire \counter_reg[28]_i_1__0_n_5 ;
  wire \counter_reg[28]_i_1__0_n_6 ;
  wire \counter_reg[28]_i_1__0_n_7 ;
  wire \counter_reg[31]_0 ;
  wire \counter_reg[4]_i_1__0_n_0 ;
  wire \counter_reg[4]_i_1__0_n_1 ;
  wire \counter_reg[4]_i_1__0_n_2 ;
  wire \counter_reg[4]_i_1__0_n_3 ;
  wire \counter_reg[4]_i_1__0_n_4 ;
  wire \counter_reg[4]_i_1__0_n_5 ;
  wire \counter_reg[4]_i_1__0_n_6 ;
  wire \counter_reg[4]_i_1__0_n_7 ;
  wire \counter_reg[8]_i_1__0_n_0 ;
  wire \counter_reg[8]_i_1__0_n_1 ;
  wire \counter_reg[8]_i_1__0_n_2 ;
  wire \counter_reg[8]_i_1__0_n_3 ;
  wire \counter_reg[8]_i_1__0_n_4 ;
  wire \counter_reg[8]_i_1__0_n_5 ;
  wire \counter_reg[8]_i_1__0_n_6 ;
  wire \counter_reg[8]_i_1__0_n_7 ;
  wire i_button_right;
  wire o_press_i_1__0_n_0;
  wire o_press_i_2__0_n_0;
  wire o_press_i_3__0_n_0;
  wire o_press_i_4__0_n_0;
  wire o_press_i_5__0_n_0;
  wire o_press_i_6__0_n_0;
  wire o_press_i_7__0_n_0;
  wire o_press_i_8__0_n_0;
  wire o_press_i_9__0_n_0;
  wire s00_axi_aclk;
  wire [3:0]NLW_counter1_carry_O_UNCONNECTED;
  wire [3:0]NLW_counter1_carry__0_O_UNCONNECTED;
  wire [3:0]NLW_counter1_carry__1_O_UNCONNECTED;
  wire [3:1]NLW_counter1_carry__2_CO_UNCONNECTED;
  wire [3:0]NLW_counter1_carry__2_O_UNCONNECTED;
  wire [3:3]\NLW_counter_reg[28]_i_1__0_CO_UNCONNECTED ;

  CARRY4 counter1_carry
       (.CI(1'b0),
        .CO({counter1_carry_n_0,counter1_carry_n_1,counter1_carry_n_2,counter1_carry_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,counter1_carry_i_1__2_n_0,counter1_carry_i_2__2_n_0}),
        .O(NLW_counter1_carry_O_UNCONNECTED[3:0]),
        .S({counter1_carry_i_3__0_n_0,counter1_carry_i_4__0_n_0,counter1_carry_i_5__0_n_0,counter1_carry_i_6__0_n_0}));
  CARRY4 counter1_carry__0
       (.CI(counter1_carry_n_0),
        .CO({counter1_carry__0_n_0,counter1_carry__0_n_1,counter1_carry__0_n_2,counter1_carry__0_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,counter1_carry__0_i_1__2_n_0,counter1_carry__0_i_2__2_n_0,counter1_carry__0_i_3__2_n_0}),
        .O(NLW_counter1_carry__0_O_UNCONNECTED[3:0]),
        .S({counter1_carry__0_i_4__0_n_0,counter1_carry__0_i_5__0_n_0,counter1_carry__0_i_6__0_n_0,counter1_carry__0_i_7__0_n_0}));
  LUT2 #(
    .INIT(4'h7)) 
    counter1_carry__0_i_1__2
       (.I0(counter_reg[18]),
        .I1(counter_reg[19]),
        .O(counter1_carry__0_i_1__2_n_0));
  LUT2 #(
    .INIT(4'h7)) 
    counter1_carry__0_i_2__2
       (.I0(counter_reg[16]),
        .I1(counter_reg[17]),
        .O(counter1_carry__0_i_2__2_n_0));
  LUT2 #(
    .INIT(4'h1)) 
    counter1_carry__0_i_3__2
       (.I0(counter_reg[14]),
        .I1(counter_reg[15]),
        .O(counter1_carry__0_i_3__2_n_0));
  LUT2 #(
    .INIT(4'h1)) 
    counter1_carry__0_i_4__0
       (.I0(counter_reg[20]),
        .I1(counter_reg[21]),
        .O(counter1_carry__0_i_4__0_n_0));
  LUT2 #(
    .INIT(4'h8)) 
    counter1_carry__0_i_5__0
       (.I0(counter_reg[18]),
        .I1(counter_reg[19]),
        .O(counter1_carry__0_i_5__0_n_0));
  LUT2 #(
    .INIT(4'h8)) 
    counter1_carry__0_i_6__0
       (.I0(counter_reg[16]),
        .I1(counter_reg[17]),
        .O(counter1_carry__0_i_6__0_n_0));
  LUT2 #(
    .INIT(4'h2)) 
    counter1_carry__0_i_7__0
       (.I0(counter_reg[14]),
        .I1(counter_reg[15]),
        .O(counter1_carry__0_i_7__0_n_0));
  CARRY4 counter1_carry__1
       (.CI(counter1_carry__0_n_0),
        .CO({counter1_carry__1_n_0,counter1_carry__1_n_1,counter1_carry__1_n_2,counter1_carry__1_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(NLW_counter1_carry__1_O_UNCONNECTED[3:0]),
        .S({counter1_carry__1_i_1__0_n_0,counter1_carry__1_i_2__0_n_0,counter1_carry__1_i_3__0_n_0,counter1_carry__1_i_4__0_n_0}));
  LUT2 #(
    .INIT(4'h1)) 
    counter1_carry__1_i_1__0
       (.I0(counter_reg[28]),
        .I1(counter_reg[29]),
        .O(counter1_carry__1_i_1__0_n_0));
  LUT2 #(
    .INIT(4'h1)) 
    counter1_carry__1_i_2__0
       (.I0(counter_reg[26]),
        .I1(counter_reg[27]),
        .O(counter1_carry__1_i_2__0_n_0));
  LUT2 #(
    .INIT(4'h1)) 
    counter1_carry__1_i_3__0
       (.I0(counter_reg[24]),
        .I1(counter_reg[25]),
        .O(counter1_carry__1_i_3__0_n_0));
  LUT2 #(
    .INIT(4'h1)) 
    counter1_carry__1_i_4__0
       (.I0(counter_reg[22]),
        .I1(counter_reg[23]),
        .O(counter1_carry__1_i_4__0_n_0));
  CARRY4 counter1_carry__2
       (.CI(counter1_carry__1_n_0),
        .CO({NLW_counter1_carry__2_CO_UNCONNECTED[3:1],counter1_carry__2_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,counter_reg[31]}),
        .O(NLW_counter1_carry__2_O_UNCONNECTED[3:0]),
        .S({1'b0,1'b0,1'b0,counter1_carry__2_i_1__0_n_0}));
  LUT2 #(
    .INIT(4'h1)) 
    counter1_carry__2_i_1__0
       (.I0(counter_reg[31]),
        .I1(counter_reg[30]),
        .O(counter1_carry__2_i_1__0_n_0));
  LUT1 #(
    .INIT(2'h1)) 
    counter1_carry_i_1__2
       (.I0(counter_reg[9]),
        .O(counter1_carry_i_1__2_n_0));
  LUT2 #(
    .INIT(4'h1)) 
    counter1_carry_i_2__2
       (.I0(counter_reg[6]),
        .I1(counter_reg[7]),
        .O(counter1_carry_i_2__2_n_0));
  LUT2 #(
    .INIT(4'h1)) 
    counter1_carry_i_3__0
       (.I0(counter_reg[12]),
        .I1(counter_reg[13]),
        .O(counter1_carry_i_3__0_n_0));
  LUT2 #(
    .INIT(4'h1)) 
    counter1_carry_i_4__0
       (.I0(counter_reg[10]),
        .I1(counter_reg[11]),
        .O(counter1_carry_i_4__0_n_0));
  LUT2 #(
    .INIT(4'h2)) 
    counter1_carry_i_5__0
       (.I0(counter_reg[9]),
        .I1(counter_reg[8]),
        .O(counter1_carry_i_5__0_n_0));
  LUT2 #(
    .INIT(4'h2)) 
    counter1_carry_i_6__0
       (.I0(counter_reg[6]),
        .I1(counter_reg[7]),
        .O(counter1_carry_i_6__0_n_0));
  LUT2 #(
    .INIT(4'h7)) 
    \counter[0]_i_1 
       (.I0(button_Right),
        .I1(CO),
        .O(\counter_reg[31]_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \counter[0]_i_1__4 
       (.I0(i_button_right),
        .O(counter));
  LUT1 #(
    .INIT(2'h1)) 
    \counter[0]_i_3__0 
       (.I0(counter_reg[0]),
        .O(\counter[0]_i_3__0_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[0] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[0]_i_2__0_n_7 ),
        .Q(counter_reg[0]),
        .R(counter));
  CARRY4 \counter_reg[0]_i_2__0 
       (.CI(1'b0),
        .CO({\counter_reg[0]_i_2__0_n_0 ,\counter_reg[0]_i_2__0_n_1 ,\counter_reg[0]_i_2__0_n_2 ,\counter_reg[0]_i_2__0_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b1}),
        .O({\counter_reg[0]_i_2__0_n_4 ,\counter_reg[0]_i_2__0_n_5 ,\counter_reg[0]_i_2__0_n_6 ,\counter_reg[0]_i_2__0_n_7 }),
        .S({counter_reg[3:1],\counter[0]_i_3__0_n_0 }));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[10] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[8]_i_1__0_n_5 ),
        .Q(counter_reg[10]),
        .R(counter));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[11] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[8]_i_1__0_n_4 ),
        .Q(counter_reg[11]),
        .R(counter));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[12] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[12]_i_1__0_n_7 ),
        .Q(counter_reg[12]),
        .R(counter));
  CARRY4 \counter_reg[12]_i_1__0 
       (.CI(\counter_reg[8]_i_1__0_n_0 ),
        .CO({\counter_reg[12]_i_1__0_n_0 ,\counter_reg[12]_i_1__0_n_1 ,\counter_reg[12]_i_1__0_n_2 ,\counter_reg[12]_i_1__0_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\counter_reg[12]_i_1__0_n_4 ,\counter_reg[12]_i_1__0_n_5 ,\counter_reg[12]_i_1__0_n_6 ,\counter_reg[12]_i_1__0_n_7 }),
        .S(counter_reg[15:12]));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[13] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[12]_i_1__0_n_6 ),
        .Q(counter_reg[13]),
        .R(counter));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[14] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[12]_i_1__0_n_5 ),
        .Q(counter_reg[14]),
        .R(counter));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[15] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[12]_i_1__0_n_4 ),
        .Q(counter_reg[15]),
        .R(counter));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[16] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[16]_i_1__0_n_7 ),
        .Q(counter_reg[16]),
        .R(counter));
  CARRY4 \counter_reg[16]_i_1__0 
       (.CI(\counter_reg[12]_i_1__0_n_0 ),
        .CO({\counter_reg[16]_i_1__0_n_0 ,\counter_reg[16]_i_1__0_n_1 ,\counter_reg[16]_i_1__0_n_2 ,\counter_reg[16]_i_1__0_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\counter_reg[16]_i_1__0_n_4 ,\counter_reg[16]_i_1__0_n_5 ,\counter_reg[16]_i_1__0_n_6 ,\counter_reg[16]_i_1__0_n_7 }),
        .S(counter_reg[19:16]));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[17] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[16]_i_1__0_n_6 ),
        .Q(counter_reg[17]),
        .R(counter));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[18] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[16]_i_1__0_n_5 ),
        .Q(counter_reg[18]),
        .R(counter));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[19] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[16]_i_1__0_n_4 ),
        .Q(counter_reg[19]),
        .R(counter));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[1] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[0]_i_2__0_n_6 ),
        .Q(counter_reg[1]),
        .R(counter));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[20] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[20]_i_1__0_n_7 ),
        .Q(counter_reg[20]),
        .R(counter));
  CARRY4 \counter_reg[20]_i_1__0 
       (.CI(\counter_reg[16]_i_1__0_n_0 ),
        .CO({\counter_reg[20]_i_1__0_n_0 ,\counter_reg[20]_i_1__0_n_1 ,\counter_reg[20]_i_1__0_n_2 ,\counter_reg[20]_i_1__0_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\counter_reg[20]_i_1__0_n_4 ,\counter_reg[20]_i_1__0_n_5 ,\counter_reg[20]_i_1__0_n_6 ,\counter_reg[20]_i_1__0_n_7 }),
        .S(counter_reg[23:20]));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[21] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[20]_i_1__0_n_6 ),
        .Q(counter_reg[21]),
        .R(counter));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[22] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[20]_i_1__0_n_5 ),
        .Q(counter_reg[22]),
        .R(counter));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[23] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[20]_i_1__0_n_4 ),
        .Q(counter_reg[23]),
        .R(counter));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[24] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[24]_i_1__0_n_7 ),
        .Q(counter_reg[24]),
        .R(counter));
  CARRY4 \counter_reg[24]_i_1__0 
       (.CI(\counter_reg[20]_i_1__0_n_0 ),
        .CO({\counter_reg[24]_i_1__0_n_0 ,\counter_reg[24]_i_1__0_n_1 ,\counter_reg[24]_i_1__0_n_2 ,\counter_reg[24]_i_1__0_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\counter_reg[24]_i_1__0_n_4 ,\counter_reg[24]_i_1__0_n_5 ,\counter_reg[24]_i_1__0_n_6 ,\counter_reg[24]_i_1__0_n_7 }),
        .S(counter_reg[27:24]));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[25] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[24]_i_1__0_n_6 ),
        .Q(counter_reg[25]),
        .R(counter));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[26] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[24]_i_1__0_n_5 ),
        .Q(counter_reg[26]),
        .R(counter));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[27] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[24]_i_1__0_n_4 ),
        .Q(counter_reg[27]),
        .R(counter));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[28] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[28]_i_1__0_n_7 ),
        .Q(counter_reg[28]),
        .R(counter));
  CARRY4 \counter_reg[28]_i_1__0 
       (.CI(\counter_reg[24]_i_1__0_n_0 ),
        .CO({\NLW_counter_reg[28]_i_1__0_CO_UNCONNECTED [3],\counter_reg[28]_i_1__0_n_1 ,\counter_reg[28]_i_1__0_n_2 ,\counter_reg[28]_i_1__0_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\counter_reg[28]_i_1__0_n_4 ,\counter_reg[28]_i_1__0_n_5 ,\counter_reg[28]_i_1__0_n_6 ,\counter_reg[28]_i_1__0_n_7 }),
        .S(counter_reg[31:28]));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[29] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[28]_i_1__0_n_6 ),
        .Q(counter_reg[29]),
        .R(counter));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[2] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[0]_i_2__0_n_5 ),
        .Q(counter_reg[2]),
        .R(counter));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[30] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[28]_i_1__0_n_5 ),
        .Q(counter_reg[30]),
        .R(counter));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[31] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[28]_i_1__0_n_4 ),
        .Q(counter_reg[31]),
        .R(counter));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[3] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[0]_i_2__0_n_4 ),
        .Q(counter_reg[3]),
        .R(counter));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[4] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[4]_i_1__0_n_7 ),
        .Q(counter_reg[4]),
        .R(counter));
  CARRY4 \counter_reg[4]_i_1__0 
       (.CI(\counter_reg[0]_i_2__0_n_0 ),
        .CO({\counter_reg[4]_i_1__0_n_0 ,\counter_reg[4]_i_1__0_n_1 ,\counter_reg[4]_i_1__0_n_2 ,\counter_reg[4]_i_1__0_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\counter_reg[4]_i_1__0_n_4 ,\counter_reg[4]_i_1__0_n_5 ,\counter_reg[4]_i_1__0_n_6 ,\counter_reg[4]_i_1__0_n_7 }),
        .S(counter_reg[7:4]));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[5] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[4]_i_1__0_n_6 ),
        .Q(counter_reg[5]),
        .R(counter));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[6] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[4]_i_1__0_n_5 ),
        .Q(counter_reg[6]),
        .R(counter));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[7] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[4]_i_1__0_n_4 ),
        .Q(counter_reg[7]),
        .R(counter));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[8] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[8]_i_1__0_n_7 ),
        .Q(counter_reg[8]),
        .R(counter));
  CARRY4 \counter_reg[8]_i_1__0 
       (.CI(\counter_reg[4]_i_1__0_n_0 ),
        .CO({\counter_reg[8]_i_1__0_n_0 ,\counter_reg[8]_i_1__0_n_1 ,\counter_reg[8]_i_1__0_n_2 ,\counter_reg[8]_i_1__0_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\counter_reg[8]_i_1__0_n_4 ,\counter_reg[8]_i_1__0_n_5 ,\counter_reg[8]_i_1__0_n_6 ,\counter_reg[8]_i_1__0_n_7 }),
        .S(counter_reg[11:8]));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[9] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[8]_i_1__0_n_6 ),
        .Q(counter_reg[9]),
        .R(counter));
  LUT6 #(
    .INIT(64'h0000000000000001)) 
    o_press_i_1__0
       (.I0(o_press_i_2__0_n_0),
        .I1(o_press_i_3__0_n_0),
        .I2(counter_reg[30]),
        .I3(counter_reg[31]),
        .I4(o_press_i_4__0_n_0),
        .I5(o_press_i_5__0_n_0),
        .O(o_press_i_1__0_n_0));
  LUT5 #(
    .INIT(32'hFFFFFFFE)) 
    o_press_i_2__0
       (.I0(counter_reg[21]),
        .I1(counter_reg[20]),
        .I2(counter_reg[23]),
        .I3(counter_reg[22]),
        .I4(o_press_i_6__0_n_0),
        .O(o_press_i_2__0_n_0));
  LUT2 #(
    .INIT(4'hE)) 
    o_press_i_3__0
       (.I0(counter_reg[29]),
        .I1(counter_reg[28]),
        .O(o_press_i_3__0_n_0));
  LUT4 #(
    .INIT(16'hFFFE)) 
    o_press_i_4__0
       (.I0(counter_reg[26]),
        .I1(counter_reg[27]),
        .I2(counter_reg[24]),
        .I3(counter_reg[25]),
        .O(o_press_i_4__0_n_0));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFFFFE)) 
    o_press_i_5__0
       (.I0(o_press_i_7__0_n_0),
        .I1(counter_reg[3]),
        .I2(counter_reg[15]),
        .I3(counter_reg[12]),
        .I4(counter_reg[13]),
        .I5(o_press_i_8__0_n_0),
        .O(o_press_i_5__0_n_0));
  LUT4 #(
    .INIT(16'hFFFE)) 
    o_press_i_6__0
       (.I0(counter_reg[0]),
        .I1(counter_reg[5]),
        .I2(counter_reg[2]),
        .I3(counter_reg[1]),
        .O(o_press_i_6__0_n_0));
  LUT4 #(
    .INIT(16'hFFFE)) 
    o_press_i_7__0
       (.I0(counter_reg[10]),
        .I1(counter_reg[11]),
        .I2(counter_reg[8]),
        .I3(counter_reg[4]),
        .O(o_press_i_7__0_n_0));
  LUT5 #(
    .INIT(32'hFFFFF7FF)) 
    o_press_i_8__0
       (.I0(counter_reg[6]),
        .I1(counter_reg[9]),
        .I2(counter_reg[7]),
        .I3(counter_reg[19]),
        .I4(o_press_i_9__0_n_0),
        .O(o_press_i_8__0_n_0));
  LUT4 #(
    .INIT(16'h7FFF)) 
    o_press_i_9__0
       (.I0(counter_reg[16]),
        .I1(counter_reg[14]),
        .I2(counter_reg[18]),
        .I3(counter_reg[17]),
        .O(o_press_i_9__0_n_0));
  FDRE o_press_reg
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(o_press_i_1__0_n_0),
        .Q(button_Right),
        .R(1'b0));
endmodule

(* ORIG_REF_NAME = "debounce" *) 
module decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_debounce_2
   (\counter_reg[31]_0 ,
    s00_axi_aclk,
    CO,
    i_button_up);
  output \counter_reg[31]_0 ;
  input s00_axi_aclk;
  input [0:0]CO;
  input i_button_up;

  wire [0:0]CO;
  wire button_up;
  wire counter;
  wire counter1_carry__0_i_1__1_n_0;
  wire counter1_carry__0_i_2__1_n_0;
  wire counter1_carry__0_i_3__1_n_0;
  wire counter1_carry__0_i_4__1_n_0;
  wire counter1_carry__0_i_5__1_n_0;
  wire counter1_carry__0_i_6__1_n_0;
  wire counter1_carry__0_i_7__1_n_0;
  wire counter1_carry__0_n_0;
  wire counter1_carry__0_n_1;
  wire counter1_carry__0_n_2;
  wire counter1_carry__0_n_3;
  wire counter1_carry__1_i_1__1_n_0;
  wire counter1_carry__1_i_2__1_n_0;
  wire counter1_carry__1_i_3__1_n_0;
  wire counter1_carry__1_i_4__1_n_0;
  wire counter1_carry__1_n_0;
  wire counter1_carry__1_n_1;
  wire counter1_carry__1_n_2;
  wire counter1_carry__1_n_3;
  wire counter1_carry__2_i_1__1_n_0;
  wire counter1_carry__2_n_3;
  wire counter1_carry_i_1__1_n_0;
  wire counter1_carry_i_2__1_n_0;
  wire counter1_carry_i_3__1_n_0;
  wire counter1_carry_i_4__1_n_0;
  wire counter1_carry_i_5__1_n_0;
  wire counter1_carry_i_6__1_n_0;
  wire counter1_carry_n_0;
  wire counter1_carry_n_1;
  wire counter1_carry_n_2;
  wire counter1_carry_n_3;
  wire \counter[0]_i_3__1_n_0 ;
  wire [31:0]counter_reg;
  wire \counter_reg[0]_i_2__1_n_0 ;
  wire \counter_reg[0]_i_2__1_n_1 ;
  wire \counter_reg[0]_i_2__1_n_2 ;
  wire \counter_reg[0]_i_2__1_n_3 ;
  wire \counter_reg[0]_i_2__1_n_4 ;
  wire \counter_reg[0]_i_2__1_n_5 ;
  wire \counter_reg[0]_i_2__1_n_6 ;
  wire \counter_reg[0]_i_2__1_n_7 ;
  wire \counter_reg[12]_i_1__1_n_0 ;
  wire \counter_reg[12]_i_1__1_n_1 ;
  wire \counter_reg[12]_i_1__1_n_2 ;
  wire \counter_reg[12]_i_1__1_n_3 ;
  wire \counter_reg[12]_i_1__1_n_4 ;
  wire \counter_reg[12]_i_1__1_n_5 ;
  wire \counter_reg[12]_i_1__1_n_6 ;
  wire \counter_reg[12]_i_1__1_n_7 ;
  wire \counter_reg[16]_i_1__1_n_0 ;
  wire \counter_reg[16]_i_1__1_n_1 ;
  wire \counter_reg[16]_i_1__1_n_2 ;
  wire \counter_reg[16]_i_1__1_n_3 ;
  wire \counter_reg[16]_i_1__1_n_4 ;
  wire \counter_reg[16]_i_1__1_n_5 ;
  wire \counter_reg[16]_i_1__1_n_6 ;
  wire \counter_reg[16]_i_1__1_n_7 ;
  wire \counter_reg[20]_i_1__1_n_0 ;
  wire \counter_reg[20]_i_1__1_n_1 ;
  wire \counter_reg[20]_i_1__1_n_2 ;
  wire \counter_reg[20]_i_1__1_n_3 ;
  wire \counter_reg[20]_i_1__1_n_4 ;
  wire \counter_reg[20]_i_1__1_n_5 ;
  wire \counter_reg[20]_i_1__1_n_6 ;
  wire \counter_reg[20]_i_1__1_n_7 ;
  wire \counter_reg[24]_i_1__1_n_0 ;
  wire \counter_reg[24]_i_1__1_n_1 ;
  wire \counter_reg[24]_i_1__1_n_2 ;
  wire \counter_reg[24]_i_1__1_n_3 ;
  wire \counter_reg[24]_i_1__1_n_4 ;
  wire \counter_reg[24]_i_1__1_n_5 ;
  wire \counter_reg[24]_i_1__1_n_6 ;
  wire \counter_reg[24]_i_1__1_n_7 ;
  wire \counter_reg[28]_i_1__1_n_1 ;
  wire \counter_reg[28]_i_1__1_n_2 ;
  wire \counter_reg[28]_i_1__1_n_3 ;
  wire \counter_reg[28]_i_1__1_n_4 ;
  wire \counter_reg[28]_i_1__1_n_5 ;
  wire \counter_reg[28]_i_1__1_n_6 ;
  wire \counter_reg[28]_i_1__1_n_7 ;
  wire \counter_reg[31]_0 ;
  wire \counter_reg[4]_i_1__1_n_0 ;
  wire \counter_reg[4]_i_1__1_n_1 ;
  wire \counter_reg[4]_i_1__1_n_2 ;
  wire \counter_reg[4]_i_1__1_n_3 ;
  wire \counter_reg[4]_i_1__1_n_4 ;
  wire \counter_reg[4]_i_1__1_n_5 ;
  wire \counter_reg[4]_i_1__1_n_6 ;
  wire \counter_reg[4]_i_1__1_n_7 ;
  wire \counter_reg[8]_i_1__1_n_0 ;
  wire \counter_reg[8]_i_1__1_n_1 ;
  wire \counter_reg[8]_i_1__1_n_2 ;
  wire \counter_reg[8]_i_1__1_n_3 ;
  wire \counter_reg[8]_i_1__1_n_4 ;
  wire \counter_reg[8]_i_1__1_n_5 ;
  wire \counter_reg[8]_i_1__1_n_6 ;
  wire \counter_reg[8]_i_1__1_n_7 ;
  wire i_button_up;
  wire o_press_i_1__1_n_0;
  wire o_press_i_2__1_n_0;
  wire o_press_i_3__1_n_0;
  wire o_press_i_4__1_n_0;
  wire o_press_i_5__1_n_0;
  wire o_press_i_6__1_n_0;
  wire o_press_i_7__1_n_0;
  wire o_press_i_8__1_n_0;
  wire o_press_i_9__1_n_0;
  wire s00_axi_aclk;
  wire [3:0]NLW_counter1_carry_O_UNCONNECTED;
  wire [3:0]NLW_counter1_carry__0_O_UNCONNECTED;
  wire [3:0]NLW_counter1_carry__1_O_UNCONNECTED;
  wire [3:1]NLW_counter1_carry__2_CO_UNCONNECTED;
  wire [3:0]NLW_counter1_carry__2_O_UNCONNECTED;
  wire [3:3]\NLW_counter_reg[28]_i_1__1_CO_UNCONNECTED ;

  CARRY4 counter1_carry
       (.CI(1'b0),
        .CO({counter1_carry_n_0,counter1_carry_n_1,counter1_carry_n_2,counter1_carry_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,counter1_carry_i_1__1_n_0,counter1_carry_i_2__1_n_0}),
        .O(NLW_counter1_carry_O_UNCONNECTED[3:0]),
        .S({counter1_carry_i_3__1_n_0,counter1_carry_i_4__1_n_0,counter1_carry_i_5__1_n_0,counter1_carry_i_6__1_n_0}));
  CARRY4 counter1_carry__0
       (.CI(counter1_carry_n_0),
        .CO({counter1_carry__0_n_0,counter1_carry__0_n_1,counter1_carry__0_n_2,counter1_carry__0_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,counter1_carry__0_i_1__1_n_0,counter1_carry__0_i_2__1_n_0,counter1_carry__0_i_3__1_n_0}),
        .O(NLW_counter1_carry__0_O_UNCONNECTED[3:0]),
        .S({counter1_carry__0_i_4__1_n_0,counter1_carry__0_i_5__1_n_0,counter1_carry__0_i_6__1_n_0,counter1_carry__0_i_7__1_n_0}));
  LUT2 #(
    .INIT(4'h7)) 
    counter1_carry__0_i_1__1
       (.I0(counter_reg[18]),
        .I1(counter_reg[19]),
        .O(counter1_carry__0_i_1__1_n_0));
  LUT2 #(
    .INIT(4'h7)) 
    counter1_carry__0_i_2__1
       (.I0(counter_reg[16]),
        .I1(counter_reg[17]),
        .O(counter1_carry__0_i_2__1_n_0));
  LUT2 #(
    .INIT(4'h1)) 
    counter1_carry__0_i_3__1
       (.I0(counter_reg[14]),
        .I1(counter_reg[15]),
        .O(counter1_carry__0_i_3__1_n_0));
  LUT2 #(
    .INIT(4'h1)) 
    counter1_carry__0_i_4__1
       (.I0(counter_reg[20]),
        .I1(counter_reg[21]),
        .O(counter1_carry__0_i_4__1_n_0));
  LUT2 #(
    .INIT(4'h8)) 
    counter1_carry__0_i_5__1
       (.I0(counter_reg[18]),
        .I1(counter_reg[19]),
        .O(counter1_carry__0_i_5__1_n_0));
  LUT2 #(
    .INIT(4'h8)) 
    counter1_carry__0_i_6__1
       (.I0(counter_reg[16]),
        .I1(counter_reg[17]),
        .O(counter1_carry__0_i_6__1_n_0));
  LUT2 #(
    .INIT(4'h2)) 
    counter1_carry__0_i_7__1
       (.I0(counter_reg[14]),
        .I1(counter_reg[15]),
        .O(counter1_carry__0_i_7__1_n_0));
  CARRY4 counter1_carry__1
       (.CI(counter1_carry__0_n_0),
        .CO({counter1_carry__1_n_0,counter1_carry__1_n_1,counter1_carry__1_n_2,counter1_carry__1_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(NLW_counter1_carry__1_O_UNCONNECTED[3:0]),
        .S({counter1_carry__1_i_1__1_n_0,counter1_carry__1_i_2__1_n_0,counter1_carry__1_i_3__1_n_0,counter1_carry__1_i_4__1_n_0}));
  LUT2 #(
    .INIT(4'h1)) 
    counter1_carry__1_i_1__1
       (.I0(counter_reg[28]),
        .I1(counter_reg[29]),
        .O(counter1_carry__1_i_1__1_n_0));
  LUT2 #(
    .INIT(4'h1)) 
    counter1_carry__1_i_2__1
       (.I0(counter_reg[26]),
        .I1(counter_reg[27]),
        .O(counter1_carry__1_i_2__1_n_0));
  LUT2 #(
    .INIT(4'h1)) 
    counter1_carry__1_i_3__1
       (.I0(counter_reg[24]),
        .I1(counter_reg[25]),
        .O(counter1_carry__1_i_3__1_n_0));
  LUT2 #(
    .INIT(4'h1)) 
    counter1_carry__1_i_4__1
       (.I0(counter_reg[22]),
        .I1(counter_reg[23]),
        .O(counter1_carry__1_i_4__1_n_0));
  CARRY4 counter1_carry__2
       (.CI(counter1_carry__1_n_0),
        .CO({NLW_counter1_carry__2_CO_UNCONNECTED[3:1],counter1_carry__2_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,counter_reg[31]}),
        .O(NLW_counter1_carry__2_O_UNCONNECTED[3:0]),
        .S({1'b0,1'b0,1'b0,counter1_carry__2_i_1__1_n_0}));
  LUT2 #(
    .INIT(4'h1)) 
    counter1_carry__2_i_1__1
       (.I0(counter_reg[31]),
        .I1(counter_reg[30]),
        .O(counter1_carry__2_i_1__1_n_0));
  LUT1 #(
    .INIT(2'h1)) 
    counter1_carry_i_1__1
       (.I0(counter_reg[9]),
        .O(counter1_carry_i_1__1_n_0));
  LUT2 #(
    .INIT(4'h1)) 
    counter1_carry_i_2__1
       (.I0(counter_reg[6]),
        .I1(counter_reg[7]),
        .O(counter1_carry_i_2__1_n_0));
  LUT2 #(
    .INIT(4'h1)) 
    counter1_carry_i_3__1
       (.I0(counter_reg[12]),
        .I1(counter_reg[13]),
        .O(counter1_carry_i_3__1_n_0));
  LUT2 #(
    .INIT(4'h1)) 
    counter1_carry_i_4__1
       (.I0(counter_reg[10]),
        .I1(counter_reg[11]),
        .O(counter1_carry_i_4__1_n_0));
  LUT2 #(
    .INIT(4'h2)) 
    counter1_carry_i_5__1
       (.I0(counter_reg[9]),
        .I1(counter_reg[8]),
        .O(counter1_carry_i_5__1_n_0));
  LUT2 #(
    .INIT(4'h2)) 
    counter1_carry_i_6__1
       (.I0(counter_reg[6]),
        .I1(counter_reg[7]),
        .O(counter1_carry_i_6__1_n_0));
  LUT2 #(
    .INIT(4'h7)) 
    \counter[0]_i_1__2 
       (.I0(button_up),
        .I1(CO),
        .O(\counter_reg[31]_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \counter[0]_i_1__5 
       (.I0(i_button_up),
        .O(counter));
  LUT1 #(
    .INIT(2'h1)) 
    \counter[0]_i_3__1 
       (.I0(counter_reg[0]),
        .O(\counter[0]_i_3__1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[0] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[0]_i_2__1_n_7 ),
        .Q(counter_reg[0]),
        .R(counter));
  CARRY4 \counter_reg[0]_i_2__1 
       (.CI(1'b0),
        .CO({\counter_reg[0]_i_2__1_n_0 ,\counter_reg[0]_i_2__1_n_1 ,\counter_reg[0]_i_2__1_n_2 ,\counter_reg[0]_i_2__1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b1}),
        .O({\counter_reg[0]_i_2__1_n_4 ,\counter_reg[0]_i_2__1_n_5 ,\counter_reg[0]_i_2__1_n_6 ,\counter_reg[0]_i_2__1_n_7 }),
        .S({counter_reg[3:1],\counter[0]_i_3__1_n_0 }));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[10] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[8]_i_1__1_n_5 ),
        .Q(counter_reg[10]),
        .R(counter));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[11] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[8]_i_1__1_n_4 ),
        .Q(counter_reg[11]),
        .R(counter));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[12] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[12]_i_1__1_n_7 ),
        .Q(counter_reg[12]),
        .R(counter));
  CARRY4 \counter_reg[12]_i_1__1 
       (.CI(\counter_reg[8]_i_1__1_n_0 ),
        .CO({\counter_reg[12]_i_1__1_n_0 ,\counter_reg[12]_i_1__1_n_1 ,\counter_reg[12]_i_1__1_n_2 ,\counter_reg[12]_i_1__1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\counter_reg[12]_i_1__1_n_4 ,\counter_reg[12]_i_1__1_n_5 ,\counter_reg[12]_i_1__1_n_6 ,\counter_reg[12]_i_1__1_n_7 }),
        .S(counter_reg[15:12]));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[13] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[12]_i_1__1_n_6 ),
        .Q(counter_reg[13]),
        .R(counter));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[14] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[12]_i_1__1_n_5 ),
        .Q(counter_reg[14]),
        .R(counter));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[15] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[12]_i_1__1_n_4 ),
        .Q(counter_reg[15]),
        .R(counter));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[16] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[16]_i_1__1_n_7 ),
        .Q(counter_reg[16]),
        .R(counter));
  CARRY4 \counter_reg[16]_i_1__1 
       (.CI(\counter_reg[12]_i_1__1_n_0 ),
        .CO({\counter_reg[16]_i_1__1_n_0 ,\counter_reg[16]_i_1__1_n_1 ,\counter_reg[16]_i_1__1_n_2 ,\counter_reg[16]_i_1__1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\counter_reg[16]_i_1__1_n_4 ,\counter_reg[16]_i_1__1_n_5 ,\counter_reg[16]_i_1__1_n_6 ,\counter_reg[16]_i_1__1_n_7 }),
        .S(counter_reg[19:16]));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[17] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[16]_i_1__1_n_6 ),
        .Q(counter_reg[17]),
        .R(counter));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[18] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[16]_i_1__1_n_5 ),
        .Q(counter_reg[18]),
        .R(counter));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[19] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[16]_i_1__1_n_4 ),
        .Q(counter_reg[19]),
        .R(counter));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[1] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[0]_i_2__1_n_6 ),
        .Q(counter_reg[1]),
        .R(counter));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[20] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[20]_i_1__1_n_7 ),
        .Q(counter_reg[20]),
        .R(counter));
  CARRY4 \counter_reg[20]_i_1__1 
       (.CI(\counter_reg[16]_i_1__1_n_0 ),
        .CO({\counter_reg[20]_i_1__1_n_0 ,\counter_reg[20]_i_1__1_n_1 ,\counter_reg[20]_i_1__1_n_2 ,\counter_reg[20]_i_1__1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\counter_reg[20]_i_1__1_n_4 ,\counter_reg[20]_i_1__1_n_5 ,\counter_reg[20]_i_1__1_n_6 ,\counter_reg[20]_i_1__1_n_7 }),
        .S(counter_reg[23:20]));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[21] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[20]_i_1__1_n_6 ),
        .Q(counter_reg[21]),
        .R(counter));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[22] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[20]_i_1__1_n_5 ),
        .Q(counter_reg[22]),
        .R(counter));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[23] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[20]_i_1__1_n_4 ),
        .Q(counter_reg[23]),
        .R(counter));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[24] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[24]_i_1__1_n_7 ),
        .Q(counter_reg[24]),
        .R(counter));
  CARRY4 \counter_reg[24]_i_1__1 
       (.CI(\counter_reg[20]_i_1__1_n_0 ),
        .CO({\counter_reg[24]_i_1__1_n_0 ,\counter_reg[24]_i_1__1_n_1 ,\counter_reg[24]_i_1__1_n_2 ,\counter_reg[24]_i_1__1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\counter_reg[24]_i_1__1_n_4 ,\counter_reg[24]_i_1__1_n_5 ,\counter_reg[24]_i_1__1_n_6 ,\counter_reg[24]_i_1__1_n_7 }),
        .S(counter_reg[27:24]));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[25] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[24]_i_1__1_n_6 ),
        .Q(counter_reg[25]),
        .R(counter));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[26] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[24]_i_1__1_n_5 ),
        .Q(counter_reg[26]),
        .R(counter));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[27] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[24]_i_1__1_n_4 ),
        .Q(counter_reg[27]),
        .R(counter));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[28] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[28]_i_1__1_n_7 ),
        .Q(counter_reg[28]),
        .R(counter));
  CARRY4 \counter_reg[28]_i_1__1 
       (.CI(\counter_reg[24]_i_1__1_n_0 ),
        .CO({\NLW_counter_reg[28]_i_1__1_CO_UNCONNECTED [3],\counter_reg[28]_i_1__1_n_1 ,\counter_reg[28]_i_1__1_n_2 ,\counter_reg[28]_i_1__1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\counter_reg[28]_i_1__1_n_4 ,\counter_reg[28]_i_1__1_n_5 ,\counter_reg[28]_i_1__1_n_6 ,\counter_reg[28]_i_1__1_n_7 }),
        .S(counter_reg[31:28]));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[29] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[28]_i_1__1_n_6 ),
        .Q(counter_reg[29]),
        .R(counter));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[2] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[0]_i_2__1_n_5 ),
        .Q(counter_reg[2]),
        .R(counter));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[30] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[28]_i_1__1_n_5 ),
        .Q(counter_reg[30]),
        .R(counter));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[31] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[28]_i_1__1_n_4 ),
        .Q(counter_reg[31]),
        .R(counter));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[3] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[0]_i_2__1_n_4 ),
        .Q(counter_reg[3]),
        .R(counter));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[4] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[4]_i_1__1_n_7 ),
        .Q(counter_reg[4]),
        .R(counter));
  CARRY4 \counter_reg[4]_i_1__1 
       (.CI(\counter_reg[0]_i_2__1_n_0 ),
        .CO({\counter_reg[4]_i_1__1_n_0 ,\counter_reg[4]_i_1__1_n_1 ,\counter_reg[4]_i_1__1_n_2 ,\counter_reg[4]_i_1__1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\counter_reg[4]_i_1__1_n_4 ,\counter_reg[4]_i_1__1_n_5 ,\counter_reg[4]_i_1__1_n_6 ,\counter_reg[4]_i_1__1_n_7 }),
        .S(counter_reg[7:4]));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[5] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[4]_i_1__1_n_6 ),
        .Q(counter_reg[5]),
        .R(counter));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[6] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[4]_i_1__1_n_5 ),
        .Q(counter_reg[6]),
        .R(counter));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[7] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[4]_i_1__1_n_4 ),
        .Q(counter_reg[7]),
        .R(counter));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[8] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[8]_i_1__1_n_7 ),
        .Q(counter_reg[8]),
        .R(counter));
  CARRY4 \counter_reg[8]_i_1__1 
       (.CI(\counter_reg[4]_i_1__1_n_0 ),
        .CO({\counter_reg[8]_i_1__1_n_0 ,\counter_reg[8]_i_1__1_n_1 ,\counter_reg[8]_i_1__1_n_2 ,\counter_reg[8]_i_1__1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\counter_reg[8]_i_1__1_n_4 ,\counter_reg[8]_i_1__1_n_5 ,\counter_reg[8]_i_1__1_n_6 ,\counter_reg[8]_i_1__1_n_7 }),
        .S(counter_reg[11:8]));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[9] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[8]_i_1__1_n_6 ),
        .Q(counter_reg[9]),
        .R(counter));
  LUT6 #(
    .INIT(64'h0000000000000001)) 
    o_press_i_1__1
       (.I0(o_press_i_2__1_n_0),
        .I1(o_press_i_3__1_n_0),
        .I2(counter_reg[30]),
        .I3(counter_reg[31]),
        .I4(o_press_i_4__1_n_0),
        .I5(o_press_i_5__1_n_0),
        .O(o_press_i_1__1_n_0));
  LUT5 #(
    .INIT(32'hFFFFFFFE)) 
    o_press_i_2__1
       (.I0(counter_reg[21]),
        .I1(counter_reg[20]),
        .I2(counter_reg[23]),
        .I3(counter_reg[22]),
        .I4(o_press_i_6__1_n_0),
        .O(o_press_i_2__1_n_0));
  LUT2 #(
    .INIT(4'hE)) 
    o_press_i_3__1
       (.I0(counter_reg[29]),
        .I1(counter_reg[28]),
        .O(o_press_i_3__1_n_0));
  LUT4 #(
    .INIT(16'hFFFE)) 
    o_press_i_4__1
       (.I0(counter_reg[26]),
        .I1(counter_reg[27]),
        .I2(counter_reg[24]),
        .I3(counter_reg[25]),
        .O(o_press_i_4__1_n_0));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFFFFE)) 
    o_press_i_5__1
       (.I0(o_press_i_7__1_n_0),
        .I1(counter_reg[3]),
        .I2(counter_reg[15]),
        .I3(counter_reg[12]),
        .I4(counter_reg[13]),
        .I5(o_press_i_8__1_n_0),
        .O(o_press_i_5__1_n_0));
  LUT4 #(
    .INIT(16'hFFFE)) 
    o_press_i_6__1
       (.I0(counter_reg[0]),
        .I1(counter_reg[5]),
        .I2(counter_reg[2]),
        .I3(counter_reg[1]),
        .O(o_press_i_6__1_n_0));
  LUT4 #(
    .INIT(16'hFFFE)) 
    o_press_i_7__1
       (.I0(counter_reg[10]),
        .I1(counter_reg[11]),
        .I2(counter_reg[8]),
        .I3(counter_reg[4]),
        .O(o_press_i_7__1_n_0));
  LUT5 #(
    .INIT(32'hFFFFF7FF)) 
    o_press_i_8__1
       (.I0(counter_reg[6]),
        .I1(counter_reg[9]),
        .I2(counter_reg[7]),
        .I3(counter_reg[19]),
        .I4(o_press_i_9__1_n_0),
        .O(o_press_i_8__1_n_0));
  LUT4 #(
    .INIT(16'h7FFF)) 
    o_press_i_9__1
       (.I0(counter_reg[16]),
        .I1(counter_reg[14]),
        .I2(counter_reg[18]),
        .I3(counter_reg[17]),
        .O(o_press_i_9__1_n_0));
  FDRE o_press_reg
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(o_press_i_1__1_n_0),
        .Q(button_up),
        .R(1'b0));
endmodule

module decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_mouseTracker
   (\intrStatReg_reg[1] ,
    D,
    s00_axi_aclk,
    Q,
    \maxCoordinateReg_reg[31] ,
    s00_axi_wdata,
    w_button_pulse,
    \axi_awaddr_reg[4] ,
    \intrStatReg_reg[1]_0 ,
    \maxCountReg_reg[31] ,
    \axi_araddr_reg[4] ,
    \axi_araddr_reg[3] ,
    \axi_araddr_reg[5] ,
    \intrEnableReg_reg[31] ,
    \axi_araddr_reg[3]_0 ,
    \intrStatReg_reg[0] ,
    \intrStatReg_reg[2] ,
    \intrStatReg_reg[3] ,
    \intrStatReg_reg[4] ,
    \intrStatReg_reg[5] ,
    \intrStatReg_reg[6] ,
    \intrStatReg_reg[7] ,
    \intrStatReg_reg[8] ,
    \intrStatReg_reg[9] ,
    \intrStatReg_reg[10] ,
    \intrStatReg_reg[11] ,
    \intrStatReg_reg[12] ,
    \intrStatReg_reg[13] ,
    \intrStatReg_reg[14] ,
    \intrStatReg_reg[15] ,
    \intrStatReg_reg[16] ,
    \intrStatReg_reg[17] ,
    \intrStatReg_reg[18] ,
    \intrStatReg_reg[19] ,
    \intrStatReg_reg[20] ,
    \intrStatReg_reg[21] ,
    \intrStatReg_reg[22] ,
    \intrStatReg_reg[23] ,
    \intrStatReg_reg[24] ,
    \intrStatReg_reg[25] ,
    \intrStatReg_reg[26] ,
    \intrStatReg_reg[27] ,
    \intrStatReg_reg[28] ,
    \intrStatReg_reg[29] ,
    \intrStatReg_reg[30] ,
    \intrStatReg_reg[31] ,
    i_button_left,
    i_button_right,
    i_button_up,
    i_button_down);
  output \intrStatReg_reg[1] ;
  output [31:0]D;
  input s00_axi_aclk;
  input [31:0]Q;
  input [31:0]\maxCoordinateReg_reg[31] ;
  input [0:0]s00_axi_wdata;
  input w_button_pulse;
  input \axi_awaddr_reg[4] ;
  input \intrStatReg_reg[1]_0 ;
  input [31:0]\maxCountReg_reg[31] ;
  input \axi_araddr_reg[4] ;
  input \axi_araddr_reg[3] ;
  input \axi_araddr_reg[5] ;
  input [31:0]\intrEnableReg_reg[31] ;
  input [1:0]\axi_araddr_reg[3]_0 ;
  input \intrStatReg_reg[0] ;
  input \intrStatReg_reg[2] ;
  input \intrStatReg_reg[3] ;
  input \intrStatReg_reg[4] ;
  input \intrStatReg_reg[5] ;
  input \intrStatReg_reg[6] ;
  input \intrStatReg_reg[7] ;
  input \intrStatReg_reg[8] ;
  input \intrStatReg_reg[9] ;
  input \intrStatReg_reg[10] ;
  input \intrStatReg_reg[11] ;
  input \intrStatReg_reg[12] ;
  input \intrStatReg_reg[13] ;
  input \intrStatReg_reg[14] ;
  input \intrStatReg_reg[15] ;
  input \intrStatReg_reg[16] ;
  input \intrStatReg_reg[17] ;
  input \intrStatReg_reg[18] ;
  input \intrStatReg_reg[19] ;
  input \intrStatReg_reg[20] ;
  input \intrStatReg_reg[21] ;
  input \intrStatReg_reg[22] ;
  input \intrStatReg_reg[23] ;
  input \intrStatReg_reg[24] ;
  input \intrStatReg_reg[25] ;
  input \intrStatReg_reg[26] ;
  input \intrStatReg_reg[27] ;
  input \intrStatReg_reg[28] ;
  input \intrStatReg_reg[29] ;
  input \intrStatReg_reg[30] ;
  input \intrStatReg_reg[31] ;
  input i_button_left;
  input i_button_right;
  input i_button_up;
  input i_button_down;

  wire [31:0]D;
  wire [31:0]Q;
  wire \axi_araddr_reg[3] ;
  wire [1:0]\axi_araddr_reg[3]_0 ;
  wire \axi_araddr_reg[4] ;
  wire \axi_araddr_reg[5] ;
  wire \axi_awaddr_reg[4] ;
  wire \axi_rdata[0]_i_2_n_0 ;
  wire \axi_rdata[10]_i_2_n_0 ;
  wire \axi_rdata[11]_i_2_n_0 ;
  wire \axi_rdata[12]_i_2_n_0 ;
  wire \axi_rdata[13]_i_2_n_0 ;
  wire \axi_rdata[14]_i_2_n_0 ;
  wire \axi_rdata[15]_i_2_n_0 ;
  wire \axi_rdata[16]_i_2_n_0 ;
  wire \axi_rdata[17]_i_2_n_0 ;
  wire \axi_rdata[18]_i_2_n_0 ;
  wire \axi_rdata[19]_i_2_n_0 ;
  wire \axi_rdata[1]_i_2_n_0 ;
  wire \axi_rdata[20]_i_2_n_0 ;
  wire \axi_rdata[21]_i_2_n_0 ;
  wire \axi_rdata[22]_i_2_n_0 ;
  wire \axi_rdata[23]_i_2_n_0 ;
  wire \axi_rdata[24]_i_2_n_0 ;
  wire \axi_rdata[25]_i_2_n_0 ;
  wire \axi_rdata[26]_i_2_n_0 ;
  wire \axi_rdata[27]_i_2_n_0 ;
  wire \axi_rdata[28]_i_2_n_0 ;
  wire \axi_rdata[29]_i_2_n_0 ;
  wire \axi_rdata[2]_i_2_n_0 ;
  wire \axi_rdata[30]_i_2_n_0 ;
  wire \axi_rdata[31]_i_4_n_0 ;
  wire \axi_rdata[3]_i_2_n_0 ;
  wire \axi_rdata[4]_i_2_n_0 ;
  wire \axi_rdata[5]_i_2_n_0 ;
  wire \axi_rdata[6]_i_2_n_0 ;
  wire \axi_rdata[7]_i_2_n_0 ;
  wire \axi_rdata[8]_i_2_n_0 ;
  wire \axi_rdata[9]_i_2_n_0 ;
  wire clear;
  wire counter2;
  wire dbDown_n_0;
  wire dbRight_n_0;
  wire dbUp_n_0;
  wire i__carry__0_i_1__0_n_0;
  wire i__carry__0_i_1_n_0;
  wire i__carry__0_i_2__0_n_0;
  wire i__carry__0_i_2_n_0;
  wire i__carry__0_i_3__0_n_0;
  wire i__carry__0_i_3_n_0;
  wire i__carry__0_i_4__0_n_0;
  wire i__carry__0_i_4_n_0;
  wire i__carry__0_i_5__0_n_0;
  wire i__carry__0_i_5_n_0;
  wire i__carry__0_i_6__0_n_0;
  wire i__carry__0_i_6_n_0;
  wire i__carry__0_i_7__0_n_0;
  wire i__carry__0_i_7_n_0;
  wire i__carry__0_i_8__0_n_0;
  wire i__carry__0_i_8_n_0;
  wire i__carry_i_1__0_n_0;
  wire i__carry_i_1_n_0;
  wire i__carry_i_2__0_n_0;
  wire i__carry_i_2_n_0;
  wire i__carry_i_3__0_n_0;
  wire i__carry_i_3_n_0;
  wire i__carry_i_4__0_n_0;
  wire i__carry_i_4_n_0;
  wire i__carry_i_5__0_n_0;
  wire i__carry_i_5_n_0;
  wire i__carry_i_6__0_n_0;
  wire i__carry_i_6_n_0;
  wire i__carry_i_7__0_n_0;
  wire i__carry_i_7_n_0;
  wire i__carry_i_8__0_n_0;
  wire i__carry_i_8_n_0;
  wire i_button_down;
  wire i_button_left;
  wire i_button_right;
  wire i_button_up;
  wire [31:0]\intrEnableReg_reg[31] ;
  wire \intrStatReg_reg[0] ;
  wire \intrStatReg_reg[10] ;
  wire \intrStatReg_reg[11] ;
  wire \intrStatReg_reg[12] ;
  wire \intrStatReg_reg[13] ;
  wire \intrStatReg_reg[14] ;
  wire \intrStatReg_reg[15] ;
  wire \intrStatReg_reg[16] ;
  wire \intrStatReg_reg[17] ;
  wire \intrStatReg_reg[18] ;
  wire \intrStatReg_reg[19] ;
  wire \intrStatReg_reg[1] ;
  wire \intrStatReg_reg[1]_0 ;
  wire \intrStatReg_reg[20] ;
  wire \intrStatReg_reg[21] ;
  wire \intrStatReg_reg[22] ;
  wire \intrStatReg_reg[23] ;
  wire \intrStatReg_reg[24] ;
  wire \intrStatReg_reg[25] ;
  wire \intrStatReg_reg[26] ;
  wire \intrStatReg_reg[27] ;
  wire \intrStatReg_reg[28] ;
  wire \intrStatReg_reg[29] ;
  wire \intrStatReg_reg[2] ;
  wire \intrStatReg_reg[30] ;
  wire \intrStatReg_reg[31] ;
  wire \intrStatReg_reg[3] ;
  wire \intrStatReg_reg[4] ;
  wire \intrStatReg_reg[5] ;
  wire \intrStatReg_reg[6] ;
  wire \intrStatReg_reg[7] ;
  wire \intrStatReg_reg[8] ;
  wire \intrStatReg_reg[9] ;
  wire [31:0]\maxCoordinateReg_reg[31] ;
  wire [31:0]\maxCountReg_reg[31] ;
  wire o_intr1_out;
  wire o_intr_i_10_n_0;
  wire o_intr_i_4_n_0;
  wire o_intr_i_5_n_0;
  wire o_intr_i_6_n_0;
  wire o_intr_i_7_n_0;
  wire o_intr_i_8_n_0;
  wire o_intr_i_9_n_0;
  wire o_pulse;
  wire \o_x_pos0_inferred__1/i__carry__0_n_1 ;
  wire \o_x_pos0_inferred__1/i__carry__0_n_2 ;
  wire \o_x_pos0_inferred__1/i__carry__0_n_3 ;
  wire \o_x_pos0_inferred__1/i__carry_n_0 ;
  wire \o_x_pos0_inferred__1/i__carry_n_1 ;
  wire \o_x_pos0_inferred__1/i__carry_n_2 ;
  wire \o_x_pos0_inferred__1/i__carry_n_3 ;
  wire \o_x_pos[0]_i_10_n_0 ;
  wire \o_x_pos[0]_i_6_n_0 ;
  wire \o_y_pos0_inferred__1/i__carry__0_n_1 ;
  wire \o_y_pos0_inferred__1/i__carry__0_n_2 ;
  wire \o_y_pos0_inferred__1/i__carry__0_n_3 ;
  wire \o_y_pos0_inferred__1/i__carry_n_0 ;
  wire \o_y_pos0_inferred__1/i__carry_n_1 ;
  wire \o_y_pos0_inferred__1/i__carry_n_2 ;
  wire \o_y_pos0_inferred__1/i__carry_n_3 ;
  wire \o_y_pos[0]_i_10_n_0 ;
  wire \o_y_pos[0]_i_6_n_0 ;
  wire pGDown_n_0;
  wire pGDown_n_1;
  wire pGDown_n_10;
  wire pGDown_n_11;
  wire pGDown_n_12;
  wire pGDown_n_13;
  wire pGDown_n_14;
  wire pGDown_n_15;
  wire pGDown_n_16;
  wire pGDown_n_17;
  wire pGDown_n_2;
  wire pGDown_n_3;
  wire pGDown_n_4;
  wire pGDown_n_5;
  wire pGDown_n_6;
  wire pGDown_n_7;
  wire pGDown_n_8;
  wire pGDown_n_9;
  wire pGRight_n_0;
  wire pGRight_n_10;
  wire pGRight_n_11;
  wire pGRight_n_12;
  wire pGRight_n_13;
  wire pGRight_n_14;
  wire pGRight_n_15;
  wire pGRight_n_16;
  wire pGRight_n_17;
  wire pGRight_n_18;
  wire pGRight_n_3;
  wire pGRight_n_4;
  wire pGRight_n_5;
  wire pGRight_n_6;
  wire pGRight_n_7;
  wire pGRight_n_8;
  wire pGRight_n_9;
  wire pGUp_n_0;
  wire pGUp_n_1;
  wire pGUp_n_2;
  wire p_0_in;
  wire p_1_in;
  wire p_2_in;
  wire [31:0]posReg;
  wire s00_axi_aclk;
  wire [0:0]s00_axi_wdata;
  wire sel;
  wire w_button_pulse;
  wire w_mousemove;
  wire [3:0]\NLW_o_x_pos0_inferred__1/i__carry_O_UNCONNECTED ;
  wire [3:0]\NLW_o_x_pos0_inferred__1/i__carry__0_O_UNCONNECTED ;
  wire [3:0]\NLW_o_y_pos0_inferred__1/i__carry_O_UNCONNECTED ;
  wire [3:0]\NLW_o_y_pos0_inferred__1/i__carry__0_O_UNCONNECTED ;

  LUT6 #(
    .INIT(64'h00000000CCE200E2)) 
    \axi_rdata[0]_i_1 
       (.I0(\maxCountReg_reg[31] [0]),
        .I1(\axi_araddr_reg[4] ),
        .I2(\maxCoordinateReg_reg[31] [0]),
        .I3(\axi_araddr_reg[3] ),
        .I4(\axi_rdata[0]_i_2_n_0 ),
        .I5(\axi_araddr_reg[5] ),
        .O(D[0]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \axi_rdata[0]_i_2 
       (.I0(posReg[0]),
        .I1(\intrEnableReg_reg[31] [0]),
        .I2(\axi_araddr_reg[3]_0 [1]),
        .I3(\intrStatReg_reg[0] ),
        .I4(\axi_araddr_reg[3]_0 [0]),
        .I5(Q[0]),
        .O(\axi_rdata[0]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h00000000CCE200E2)) 
    \axi_rdata[10]_i_1 
       (.I0(\maxCountReg_reg[31] [10]),
        .I1(\axi_araddr_reg[4] ),
        .I2(\maxCoordinateReg_reg[31] [10]),
        .I3(\axi_araddr_reg[3] ),
        .I4(\axi_rdata[10]_i_2_n_0 ),
        .I5(\axi_araddr_reg[5] ),
        .O(D[10]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \axi_rdata[10]_i_2 
       (.I0(posReg[10]),
        .I1(\intrEnableReg_reg[31] [10]),
        .I2(\axi_araddr_reg[3]_0 [1]),
        .I3(\intrStatReg_reg[10] ),
        .I4(\axi_araddr_reg[3]_0 [0]),
        .I5(Q[10]),
        .O(\axi_rdata[10]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h00000000CCE200E2)) 
    \axi_rdata[11]_i_1 
       (.I0(\maxCountReg_reg[31] [11]),
        .I1(\axi_araddr_reg[4] ),
        .I2(\maxCoordinateReg_reg[31] [11]),
        .I3(\axi_araddr_reg[3] ),
        .I4(\axi_rdata[11]_i_2_n_0 ),
        .I5(\axi_araddr_reg[5] ),
        .O(D[11]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \axi_rdata[11]_i_2 
       (.I0(posReg[11]),
        .I1(\intrEnableReg_reg[31] [11]),
        .I2(\axi_araddr_reg[3]_0 [1]),
        .I3(\intrStatReg_reg[11] ),
        .I4(\axi_araddr_reg[3]_0 [0]),
        .I5(Q[11]),
        .O(\axi_rdata[11]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h00000000CCE200E2)) 
    \axi_rdata[12]_i_1 
       (.I0(\maxCountReg_reg[31] [12]),
        .I1(\axi_araddr_reg[4] ),
        .I2(\maxCoordinateReg_reg[31] [12]),
        .I3(\axi_araddr_reg[3] ),
        .I4(\axi_rdata[12]_i_2_n_0 ),
        .I5(\axi_araddr_reg[5] ),
        .O(D[12]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \axi_rdata[12]_i_2 
       (.I0(posReg[12]),
        .I1(\intrEnableReg_reg[31] [12]),
        .I2(\axi_araddr_reg[3]_0 [1]),
        .I3(\intrStatReg_reg[12] ),
        .I4(\axi_araddr_reg[3]_0 [0]),
        .I5(Q[12]),
        .O(\axi_rdata[12]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h00000000CCE200E2)) 
    \axi_rdata[13]_i_1 
       (.I0(\maxCountReg_reg[31] [13]),
        .I1(\axi_araddr_reg[4] ),
        .I2(\maxCoordinateReg_reg[31] [13]),
        .I3(\axi_araddr_reg[3] ),
        .I4(\axi_rdata[13]_i_2_n_0 ),
        .I5(\axi_araddr_reg[5] ),
        .O(D[13]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \axi_rdata[13]_i_2 
       (.I0(posReg[13]),
        .I1(\intrEnableReg_reg[31] [13]),
        .I2(\axi_araddr_reg[3]_0 [1]),
        .I3(\intrStatReg_reg[13] ),
        .I4(\axi_araddr_reg[3]_0 [0]),
        .I5(Q[13]),
        .O(\axi_rdata[13]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h00000000CCE200E2)) 
    \axi_rdata[14]_i_1 
       (.I0(\maxCountReg_reg[31] [14]),
        .I1(\axi_araddr_reg[4] ),
        .I2(\maxCoordinateReg_reg[31] [14]),
        .I3(\axi_araddr_reg[3] ),
        .I4(\axi_rdata[14]_i_2_n_0 ),
        .I5(\axi_araddr_reg[5] ),
        .O(D[14]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \axi_rdata[14]_i_2 
       (.I0(posReg[14]),
        .I1(\intrEnableReg_reg[31] [14]),
        .I2(\axi_araddr_reg[3]_0 [1]),
        .I3(\intrStatReg_reg[14] ),
        .I4(\axi_araddr_reg[3]_0 [0]),
        .I5(Q[14]),
        .O(\axi_rdata[14]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h00000000CCE200E2)) 
    \axi_rdata[15]_i_1 
       (.I0(\maxCountReg_reg[31] [15]),
        .I1(\axi_araddr_reg[4] ),
        .I2(\maxCoordinateReg_reg[31] [15]),
        .I3(\axi_araddr_reg[3] ),
        .I4(\axi_rdata[15]_i_2_n_0 ),
        .I5(\axi_araddr_reg[5] ),
        .O(D[15]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \axi_rdata[15]_i_2 
       (.I0(posReg[15]),
        .I1(\intrEnableReg_reg[31] [15]),
        .I2(\axi_araddr_reg[3]_0 [1]),
        .I3(\intrStatReg_reg[15] ),
        .I4(\axi_araddr_reg[3]_0 [0]),
        .I5(Q[15]),
        .O(\axi_rdata[15]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h00000000CCE200E2)) 
    \axi_rdata[16]_i_1 
       (.I0(\maxCountReg_reg[31] [16]),
        .I1(\axi_araddr_reg[4] ),
        .I2(\maxCoordinateReg_reg[31] [16]),
        .I3(\axi_araddr_reg[3] ),
        .I4(\axi_rdata[16]_i_2_n_0 ),
        .I5(\axi_araddr_reg[5] ),
        .O(D[16]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \axi_rdata[16]_i_2 
       (.I0(posReg[16]),
        .I1(\intrEnableReg_reg[31] [16]),
        .I2(\axi_araddr_reg[3]_0 [1]),
        .I3(\intrStatReg_reg[16] ),
        .I4(\axi_araddr_reg[3]_0 [0]),
        .I5(Q[16]),
        .O(\axi_rdata[16]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h00000000CCE200E2)) 
    \axi_rdata[17]_i_1 
       (.I0(\maxCountReg_reg[31] [17]),
        .I1(\axi_araddr_reg[4] ),
        .I2(\maxCoordinateReg_reg[31] [17]),
        .I3(\axi_araddr_reg[3] ),
        .I4(\axi_rdata[17]_i_2_n_0 ),
        .I5(\axi_araddr_reg[5] ),
        .O(D[17]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \axi_rdata[17]_i_2 
       (.I0(posReg[17]),
        .I1(\intrEnableReg_reg[31] [17]),
        .I2(\axi_araddr_reg[3]_0 [1]),
        .I3(\intrStatReg_reg[17] ),
        .I4(\axi_araddr_reg[3]_0 [0]),
        .I5(Q[17]),
        .O(\axi_rdata[17]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h00000000CCE200E2)) 
    \axi_rdata[18]_i_1 
       (.I0(\maxCountReg_reg[31] [18]),
        .I1(\axi_araddr_reg[4] ),
        .I2(\maxCoordinateReg_reg[31] [18]),
        .I3(\axi_araddr_reg[3] ),
        .I4(\axi_rdata[18]_i_2_n_0 ),
        .I5(\axi_araddr_reg[5] ),
        .O(D[18]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \axi_rdata[18]_i_2 
       (.I0(posReg[18]),
        .I1(\intrEnableReg_reg[31] [18]),
        .I2(\axi_araddr_reg[3]_0 [1]),
        .I3(\intrStatReg_reg[18] ),
        .I4(\axi_araddr_reg[3]_0 [0]),
        .I5(Q[18]),
        .O(\axi_rdata[18]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h00000000CCE200E2)) 
    \axi_rdata[19]_i_1 
       (.I0(\maxCountReg_reg[31] [19]),
        .I1(\axi_araddr_reg[4] ),
        .I2(\maxCoordinateReg_reg[31] [19]),
        .I3(\axi_araddr_reg[3] ),
        .I4(\axi_rdata[19]_i_2_n_0 ),
        .I5(\axi_araddr_reg[5] ),
        .O(D[19]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \axi_rdata[19]_i_2 
       (.I0(posReg[19]),
        .I1(\intrEnableReg_reg[31] [19]),
        .I2(\axi_araddr_reg[3]_0 [1]),
        .I3(\intrStatReg_reg[19] ),
        .I4(\axi_araddr_reg[3]_0 [0]),
        .I5(Q[19]),
        .O(\axi_rdata[19]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h00000000CCE200E2)) 
    \axi_rdata[1]_i_1 
       (.I0(\maxCountReg_reg[31] [1]),
        .I1(\axi_araddr_reg[4] ),
        .I2(\maxCoordinateReg_reg[31] [1]),
        .I3(\axi_araddr_reg[3] ),
        .I4(\axi_rdata[1]_i_2_n_0 ),
        .I5(\axi_araddr_reg[5] ),
        .O(D[1]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \axi_rdata[1]_i_2 
       (.I0(posReg[1]),
        .I1(\intrEnableReg_reg[31] [1]),
        .I2(\axi_araddr_reg[3]_0 [1]),
        .I3(\intrStatReg_reg[1]_0 ),
        .I4(\axi_araddr_reg[3]_0 [0]),
        .I5(Q[1]),
        .O(\axi_rdata[1]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h00000000CCE200E2)) 
    \axi_rdata[20]_i_1 
       (.I0(\maxCountReg_reg[31] [20]),
        .I1(\axi_araddr_reg[4] ),
        .I2(\maxCoordinateReg_reg[31] [20]),
        .I3(\axi_araddr_reg[3] ),
        .I4(\axi_rdata[20]_i_2_n_0 ),
        .I5(\axi_araddr_reg[5] ),
        .O(D[20]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \axi_rdata[20]_i_2 
       (.I0(posReg[20]),
        .I1(\intrEnableReg_reg[31] [20]),
        .I2(\axi_araddr_reg[3]_0 [1]),
        .I3(\intrStatReg_reg[20] ),
        .I4(\axi_araddr_reg[3]_0 [0]),
        .I5(Q[20]),
        .O(\axi_rdata[20]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h00000000CCE200E2)) 
    \axi_rdata[21]_i_1 
       (.I0(\maxCountReg_reg[31] [21]),
        .I1(\axi_araddr_reg[4] ),
        .I2(\maxCoordinateReg_reg[31] [21]),
        .I3(\axi_araddr_reg[3] ),
        .I4(\axi_rdata[21]_i_2_n_0 ),
        .I5(\axi_araddr_reg[5] ),
        .O(D[21]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \axi_rdata[21]_i_2 
       (.I0(posReg[21]),
        .I1(\intrEnableReg_reg[31] [21]),
        .I2(\axi_araddr_reg[3]_0 [1]),
        .I3(\intrStatReg_reg[21] ),
        .I4(\axi_araddr_reg[3]_0 [0]),
        .I5(Q[21]),
        .O(\axi_rdata[21]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h00000000CCE200E2)) 
    \axi_rdata[22]_i_1 
       (.I0(\maxCountReg_reg[31] [22]),
        .I1(\axi_araddr_reg[4] ),
        .I2(\maxCoordinateReg_reg[31] [22]),
        .I3(\axi_araddr_reg[3] ),
        .I4(\axi_rdata[22]_i_2_n_0 ),
        .I5(\axi_araddr_reg[5] ),
        .O(D[22]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \axi_rdata[22]_i_2 
       (.I0(posReg[22]),
        .I1(\intrEnableReg_reg[31] [22]),
        .I2(\axi_araddr_reg[3]_0 [1]),
        .I3(\intrStatReg_reg[22] ),
        .I4(\axi_araddr_reg[3]_0 [0]),
        .I5(Q[22]),
        .O(\axi_rdata[22]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h00000000CCE200E2)) 
    \axi_rdata[23]_i_1 
       (.I0(\maxCountReg_reg[31] [23]),
        .I1(\axi_araddr_reg[4] ),
        .I2(\maxCoordinateReg_reg[31] [23]),
        .I3(\axi_araddr_reg[3] ),
        .I4(\axi_rdata[23]_i_2_n_0 ),
        .I5(\axi_araddr_reg[5] ),
        .O(D[23]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \axi_rdata[23]_i_2 
       (.I0(posReg[23]),
        .I1(\intrEnableReg_reg[31] [23]),
        .I2(\axi_araddr_reg[3]_0 [1]),
        .I3(\intrStatReg_reg[23] ),
        .I4(\axi_araddr_reg[3]_0 [0]),
        .I5(Q[23]),
        .O(\axi_rdata[23]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h00000000CCE200E2)) 
    \axi_rdata[24]_i_1 
       (.I0(\maxCountReg_reg[31] [24]),
        .I1(\axi_araddr_reg[4] ),
        .I2(\maxCoordinateReg_reg[31] [24]),
        .I3(\axi_araddr_reg[3] ),
        .I4(\axi_rdata[24]_i_2_n_0 ),
        .I5(\axi_araddr_reg[5] ),
        .O(D[24]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \axi_rdata[24]_i_2 
       (.I0(posReg[24]),
        .I1(\intrEnableReg_reg[31] [24]),
        .I2(\axi_araddr_reg[3]_0 [1]),
        .I3(\intrStatReg_reg[24] ),
        .I4(\axi_araddr_reg[3]_0 [0]),
        .I5(Q[24]),
        .O(\axi_rdata[24]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h00000000CCE200E2)) 
    \axi_rdata[25]_i_1 
       (.I0(\maxCountReg_reg[31] [25]),
        .I1(\axi_araddr_reg[4] ),
        .I2(\maxCoordinateReg_reg[31] [25]),
        .I3(\axi_araddr_reg[3] ),
        .I4(\axi_rdata[25]_i_2_n_0 ),
        .I5(\axi_araddr_reg[5] ),
        .O(D[25]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \axi_rdata[25]_i_2 
       (.I0(posReg[25]),
        .I1(\intrEnableReg_reg[31] [25]),
        .I2(\axi_araddr_reg[3]_0 [1]),
        .I3(\intrStatReg_reg[25] ),
        .I4(\axi_araddr_reg[3]_0 [0]),
        .I5(Q[25]),
        .O(\axi_rdata[25]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h00000000CCE200E2)) 
    \axi_rdata[26]_i_1 
       (.I0(\maxCountReg_reg[31] [26]),
        .I1(\axi_araddr_reg[4] ),
        .I2(\maxCoordinateReg_reg[31] [26]),
        .I3(\axi_araddr_reg[3] ),
        .I4(\axi_rdata[26]_i_2_n_0 ),
        .I5(\axi_araddr_reg[5] ),
        .O(D[26]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \axi_rdata[26]_i_2 
       (.I0(posReg[26]),
        .I1(\intrEnableReg_reg[31] [26]),
        .I2(\axi_araddr_reg[3]_0 [1]),
        .I3(\intrStatReg_reg[26] ),
        .I4(\axi_araddr_reg[3]_0 [0]),
        .I5(Q[26]),
        .O(\axi_rdata[26]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h00000000CCE200E2)) 
    \axi_rdata[27]_i_1 
       (.I0(\maxCountReg_reg[31] [27]),
        .I1(\axi_araddr_reg[4] ),
        .I2(\maxCoordinateReg_reg[31] [27]),
        .I3(\axi_araddr_reg[3] ),
        .I4(\axi_rdata[27]_i_2_n_0 ),
        .I5(\axi_araddr_reg[5] ),
        .O(D[27]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \axi_rdata[27]_i_2 
       (.I0(posReg[27]),
        .I1(\intrEnableReg_reg[31] [27]),
        .I2(\axi_araddr_reg[3]_0 [1]),
        .I3(\intrStatReg_reg[27] ),
        .I4(\axi_araddr_reg[3]_0 [0]),
        .I5(Q[27]),
        .O(\axi_rdata[27]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h00000000CCE200E2)) 
    \axi_rdata[28]_i_1 
       (.I0(\maxCountReg_reg[31] [28]),
        .I1(\axi_araddr_reg[4] ),
        .I2(\maxCoordinateReg_reg[31] [28]),
        .I3(\axi_araddr_reg[3] ),
        .I4(\axi_rdata[28]_i_2_n_0 ),
        .I5(\axi_araddr_reg[5] ),
        .O(D[28]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \axi_rdata[28]_i_2 
       (.I0(posReg[28]),
        .I1(\intrEnableReg_reg[31] [28]),
        .I2(\axi_araddr_reg[3]_0 [1]),
        .I3(\intrStatReg_reg[28] ),
        .I4(\axi_araddr_reg[3]_0 [0]),
        .I5(Q[28]),
        .O(\axi_rdata[28]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h00000000CCE200E2)) 
    \axi_rdata[29]_i_1 
       (.I0(\maxCountReg_reg[31] [29]),
        .I1(\axi_araddr_reg[4] ),
        .I2(\maxCoordinateReg_reg[31] [29]),
        .I3(\axi_araddr_reg[3] ),
        .I4(\axi_rdata[29]_i_2_n_0 ),
        .I5(\axi_araddr_reg[5] ),
        .O(D[29]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \axi_rdata[29]_i_2 
       (.I0(posReg[29]),
        .I1(\intrEnableReg_reg[31] [29]),
        .I2(\axi_araddr_reg[3]_0 [1]),
        .I3(\intrStatReg_reg[29] ),
        .I4(\axi_araddr_reg[3]_0 [0]),
        .I5(Q[29]),
        .O(\axi_rdata[29]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h00000000CCE200E2)) 
    \axi_rdata[2]_i_1 
       (.I0(\maxCountReg_reg[31] [2]),
        .I1(\axi_araddr_reg[4] ),
        .I2(\maxCoordinateReg_reg[31] [2]),
        .I3(\axi_araddr_reg[3] ),
        .I4(\axi_rdata[2]_i_2_n_0 ),
        .I5(\axi_araddr_reg[5] ),
        .O(D[2]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \axi_rdata[2]_i_2 
       (.I0(posReg[2]),
        .I1(\intrEnableReg_reg[31] [2]),
        .I2(\axi_araddr_reg[3]_0 [1]),
        .I3(\intrStatReg_reg[2] ),
        .I4(\axi_araddr_reg[3]_0 [0]),
        .I5(Q[2]),
        .O(\axi_rdata[2]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h00000000CCE200E2)) 
    \axi_rdata[30]_i_1 
       (.I0(\maxCountReg_reg[31] [30]),
        .I1(\axi_araddr_reg[4] ),
        .I2(\maxCoordinateReg_reg[31] [30]),
        .I3(\axi_araddr_reg[3] ),
        .I4(\axi_rdata[30]_i_2_n_0 ),
        .I5(\axi_araddr_reg[5] ),
        .O(D[30]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \axi_rdata[30]_i_2 
       (.I0(posReg[30]),
        .I1(\intrEnableReg_reg[31] [30]),
        .I2(\axi_araddr_reg[3]_0 [1]),
        .I3(\intrStatReg_reg[30] ),
        .I4(\axi_araddr_reg[3]_0 [0]),
        .I5(Q[30]),
        .O(\axi_rdata[30]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h00000000CCE200E2)) 
    \axi_rdata[31]_i_1 
       (.I0(\maxCountReg_reg[31] [31]),
        .I1(\axi_araddr_reg[4] ),
        .I2(\maxCoordinateReg_reg[31] [31]),
        .I3(\axi_araddr_reg[3] ),
        .I4(\axi_rdata[31]_i_4_n_0 ),
        .I5(\axi_araddr_reg[5] ),
        .O(D[31]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \axi_rdata[31]_i_4 
       (.I0(posReg[31]),
        .I1(\intrEnableReg_reg[31] [31]),
        .I2(\axi_araddr_reg[3]_0 [1]),
        .I3(\intrStatReg_reg[31] ),
        .I4(\axi_araddr_reg[3]_0 [0]),
        .I5(Q[31]),
        .O(\axi_rdata[31]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h00000000CCE200E2)) 
    \axi_rdata[3]_i_1 
       (.I0(\maxCountReg_reg[31] [3]),
        .I1(\axi_araddr_reg[4] ),
        .I2(\maxCoordinateReg_reg[31] [3]),
        .I3(\axi_araddr_reg[3] ),
        .I4(\axi_rdata[3]_i_2_n_0 ),
        .I5(\axi_araddr_reg[5] ),
        .O(D[3]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \axi_rdata[3]_i_2 
       (.I0(posReg[3]),
        .I1(\intrEnableReg_reg[31] [3]),
        .I2(\axi_araddr_reg[3]_0 [1]),
        .I3(\intrStatReg_reg[3] ),
        .I4(\axi_araddr_reg[3]_0 [0]),
        .I5(Q[3]),
        .O(\axi_rdata[3]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h00000000CCE200E2)) 
    \axi_rdata[4]_i_1 
       (.I0(\maxCountReg_reg[31] [4]),
        .I1(\axi_araddr_reg[4] ),
        .I2(\maxCoordinateReg_reg[31] [4]),
        .I3(\axi_araddr_reg[3] ),
        .I4(\axi_rdata[4]_i_2_n_0 ),
        .I5(\axi_araddr_reg[5] ),
        .O(D[4]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \axi_rdata[4]_i_2 
       (.I0(posReg[4]),
        .I1(\intrEnableReg_reg[31] [4]),
        .I2(\axi_araddr_reg[3]_0 [1]),
        .I3(\intrStatReg_reg[4] ),
        .I4(\axi_araddr_reg[3]_0 [0]),
        .I5(Q[4]),
        .O(\axi_rdata[4]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h00000000CCE200E2)) 
    \axi_rdata[5]_i_1 
       (.I0(\maxCountReg_reg[31] [5]),
        .I1(\axi_araddr_reg[4] ),
        .I2(\maxCoordinateReg_reg[31] [5]),
        .I3(\axi_araddr_reg[3] ),
        .I4(\axi_rdata[5]_i_2_n_0 ),
        .I5(\axi_araddr_reg[5] ),
        .O(D[5]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \axi_rdata[5]_i_2 
       (.I0(posReg[5]),
        .I1(\intrEnableReg_reg[31] [5]),
        .I2(\axi_araddr_reg[3]_0 [1]),
        .I3(\intrStatReg_reg[5] ),
        .I4(\axi_araddr_reg[3]_0 [0]),
        .I5(Q[5]),
        .O(\axi_rdata[5]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h00000000CCE200E2)) 
    \axi_rdata[6]_i_1 
       (.I0(\maxCountReg_reg[31] [6]),
        .I1(\axi_araddr_reg[4] ),
        .I2(\maxCoordinateReg_reg[31] [6]),
        .I3(\axi_araddr_reg[3] ),
        .I4(\axi_rdata[6]_i_2_n_0 ),
        .I5(\axi_araddr_reg[5] ),
        .O(D[6]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \axi_rdata[6]_i_2 
       (.I0(posReg[6]),
        .I1(\intrEnableReg_reg[31] [6]),
        .I2(\axi_araddr_reg[3]_0 [1]),
        .I3(\intrStatReg_reg[6] ),
        .I4(\axi_araddr_reg[3]_0 [0]),
        .I5(Q[6]),
        .O(\axi_rdata[6]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h00000000CCE200E2)) 
    \axi_rdata[7]_i_1 
       (.I0(\maxCountReg_reg[31] [7]),
        .I1(\axi_araddr_reg[4] ),
        .I2(\maxCoordinateReg_reg[31] [7]),
        .I3(\axi_araddr_reg[3] ),
        .I4(\axi_rdata[7]_i_2_n_0 ),
        .I5(\axi_araddr_reg[5] ),
        .O(D[7]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \axi_rdata[7]_i_2 
       (.I0(posReg[7]),
        .I1(\intrEnableReg_reg[31] [7]),
        .I2(\axi_araddr_reg[3]_0 [1]),
        .I3(\intrStatReg_reg[7] ),
        .I4(\axi_araddr_reg[3]_0 [0]),
        .I5(Q[7]),
        .O(\axi_rdata[7]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h00000000CCE200E2)) 
    \axi_rdata[8]_i_1 
       (.I0(\maxCountReg_reg[31] [8]),
        .I1(\axi_araddr_reg[4] ),
        .I2(\maxCoordinateReg_reg[31] [8]),
        .I3(\axi_araddr_reg[3] ),
        .I4(\axi_rdata[8]_i_2_n_0 ),
        .I5(\axi_araddr_reg[5] ),
        .O(D[8]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \axi_rdata[8]_i_2 
       (.I0(posReg[8]),
        .I1(\intrEnableReg_reg[31] [8]),
        .I2(\axi_araddr_reg[3]_0 [1]),
        .I3(\intrStatReg_reg[8] ),
        .I4(\axi_araddr_reg[3]_0 [0]),
        .I5(Q[8]),
        .O(\axi_rdata[8]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h00000000CCE200E2)) 
    \axi_rdata[9]_i_1 
       (.I0(\maxCountReg_reg[31] [9]),
        .I1(\axi_araddr_reg[4] ),
        .I2(\maxCoordinateReg_reg[31] [9]),
        .I3(\axi_araddr_reg[3] ),
        .I4(\axi_rdata[9]_i_2_n_0 ),
        .I5(\axi_araddr_reg[5] ),
        .O(D[9]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \axi_rdata[9]_i_2 
       (.I0(posReg[9]),
        .I1(\intrEnableReg_reg[31] [9]),
        .I2(\axi_araddr_reg[3]_0 [1]),
        .I3(\intrStatReg_reg[9] ),
        .I4(\axi_araddr_reg[3]_0 [0]),
        .I5(Q[9]),
        .O(\axi_rdata[9]_i_2_n_0 ));
  decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_debounce dbDown
       (.CO(pGDown_n_1),
        .\counter_reg[31]_0 (dbDown_n_0),
        .i_button_down(i_button_down),
        .s00_axi_aclk(s00_axi_aclk));
  decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_debounce_0 dbLeft
       (.CO(counter2),
        .clear(clear),
        .i_button_left(i_button_left),
        .s00_axi_aclk(s00_axi_aclk));
  decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_debounce_1 dbRight
       (.CO(pGRight_n_0),
        .\counter_reg[31]_0 (dbRight_n_0),
        .i_button_right(i_button_right),
        .s00_axi_aclk(s00_axi_aclk));
  decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_debounce_2 dbUp
       (.CO(pGUp_n_1),
        .\counter_reg[31]_0 (dbUp_n_0),
        .i_button_up(i_button_up),
        .s00_axi_aclk(s00_axi_aclk));
  LUT4 #(
    .INIT(16'h2F02)) 
    i__carry__0_i_1
       (.I0(\maxCoordinateReg_reg[31] [14]),
        .I1(posReg[14]),
        .I2(posReg[15]),
        .I3(\maxCoordinateReg_reg[31] [15]),
        .O(i__carry__0_i_1_n_0));
  LUT4 #(
    .INIT(16'h2F02)) 
    i__carry__0_i_1__0
       (.I0(\maxCoordinateReg_reg[31] [30]),
        .I1(posReg[30]),
        .I2(posReg[31]),
        .I3(\maxCoordinateReg_reg[31] [31]),
        .O(i__carry__0_i_1__0_n_0));
  LUT4 #(
    .INIT(16'h2F02)) 
    i__carry__0_i_2
       (.I0(\maxCoordinateReg_reg[31] [12]),
        .I1(posReg[12]),
        .I2(posReg[13]),
        .I3(\maxCoordinateReg_reg[31] [13]),
        .O(i__carry__0_i_2_n_0));
  LUT4 #(
    .INIT(16'h2F02)) 
    i__carry__0_i_2__0
       (.I0(\maxCoordinateReg_reg[31] [28]),
        .I1(posReg[28]),
        .I2(posReg[29]),
        .I3(\maxCoordinateReg_reg[31] [29]),
        .O(i__carry__0_i_2__0_n_0));
  LUT4 #(
    .INIT(16'h2F02)) 
    i__carry__0_i_3
       (.I0(\maxCoordinateReg_reg[31] [10]),
        .I1(posReg[10]),
        .I2(posReg[11]),
        .I3(\maxCoordinateReg_reg[31] [11]),
        .O(i__carry__0_i_3_n_0));
  LUT4 #(
    .INIT(16'h2F02)) 
    i__carry__0_i_3__0
       (.I0(\maxCoordinateReg_reg[31] [26]),
        .I1(posReg[26]),
        .I2(posReg[27]),
        .I3(\maxCoordinateReg_reg[31] [27]),
        .O(i__carry__0_i_3__0_n_0));
  LUT4 #(
    .INIT(16'h2F02)) 
    i__carry__0_i_4
       (.I0(\maxCoordinateReg_reg[31] [8]),
        .I1(posReg[8]),
        .I2(posReg[9]),
        .I3(\maxCoordinateReg_reg[31] [9]),
        .O(i__carry__0_i_4_n_0));
  LUT4 #(
    .INIT(16'h2F02)) 
    i__carry__0_i_4__0
       (.I0(\maxCoordinateReg_reg[31] [24]),
        .I1(posReg[24]),
        .I2(posReg[25]),
        .I3(\maxCoordinateReg_reg[31] [25]),
        .O(i__carry__0_i_4__0_n_0));
  LUT4 #(
    .INIT(16'h9009)) 
    i__carry__0_i_5
       (.I0(\maxCoordinateReg_reg[31] [14]),
        .I1(posReg[14]),
        .I2(\maxCoordinateReg_reg[31] [15]),
        .I3(posReg[15]),
        .O(i__carry__0_i_5_n_0));
  LUT4 #(
    .INIT(16'h9009)) 
    i__carry__0_i_5__0
       (.I0(\maxCoordinateReg_reg[31] [30]),
        .I1(posReg[30]),
        .I2(\maxCoordinateReg_reg[31] [31]),
        .I3(posReg[31]),
        .O(i__carry__0_i_5__0_n_0));
  LUT4 #(
    .INIT(16'h9009)) 
    i__carry__0_i_6
       (.I0(\maxCoordinateReg_reg[31] [12]),
        .I1(posReg[12]),
        .I2(\maxCoordinateReg_reg[31] [13]),
        .I3(posReg[13]),
        .O(i__carry__0_i_6_n_0));
  LUT4 #(
    .INIT(16'h9009)) 
    i__carry__0_i_6__0
       (.I0(\maxCoordinateReg_reg[31] [28]),
        .I1(posReg[28]),
        .I2(\maxCoordinateReg_reg[31] [29]),
        .I3(posReg[29]),
        .O(i__carry__0_i_6__0_n_0));
  LUT4 #(
    .INIT(16'h9009)) 
    i__carry__0_i_7
       (.I0(\maxCoordinateReg_reg[31] [10]),
        .I1(posReg[10]),
        .I2(\maxCoordinateReg_reg[31] [11]),
        .I3(posReg[11]),
        .O(i__carry__0_i_7_n_0));
  LUT4 #(
    .INIT(16'h9009)) 
    i__carry__0_i_7__0
       (.I0(\maxCoordinateReg_reg[31] [26]),
        .I1(posReg[26]),
        .I2(\maxCoordinateReg_reg[31] [27]),
        .I3(posReg[27]),
        .O(i__carry__0_i_7__0_n_0));
  LUT4 #(
    .INIT(16'h9009)) 
    i__carry__0_i_8
       (.I0(\maxCoordinateReg_reg[31] [8]),
        .I1(posReg[8]),
        .I2(\maxCoordinateReg_reg[31] [9]),
        .I3(posReg[9]),
        .O(i__carry__0_i_8_n_0));
  LUT4 #(
    .INIT(16'h9009)) 
    i__carry__0_i_8__0
       (.I0(\maxCoordinateReg_reg[31] [24]),
        .I1(posReg[24]),
        .I2(\maxCoordinateReg_reg[31] [25]),
        .I3(posReg[25]),
        .O(i__carry__0_i_8__0_n_0));
  LUT4 #(
    .INIT(16'h2F02)) 
    i__carry_i_1
       (.I0(\maxCoordinateReg_reg[31] [6]),
        .I1(posReg[6]),
        .I2(posReg[7]),
        .I3(\maxCoordinateReg_reg[31] [7]),
        .O(i__carry_i_1_n_0));
  LUT4 #(
    .INIT(16'h2F02)) 
    i__carry_i_1__0
       (.I0(\maxCoordinateReg_reg[31] [22]),
        .I1(posReg[22]),
        .I2(posReg[23]),
        .I3(\maxCoordinateReg_reg[31] [23]),
        .O(i__carry_i_1__0_n_0));
  LUT4 #(
    .INIT(16'h2F02)) 
    i__carry_i_2
       (.I0(\maxCoordinateReg_reg[31] [4]),
        .I1(posReg[4]),
        .I2(posReg[5]),
        .I3(\maxCoordinateReg_reg[31] [5]),
        .O(i__carry_i_2_n_0));
  LUT4 #(
    .INIT(16'h2F02)) 
    i__carry_i_2__0
       (.I0(\maxCoordinateReg_reg[31] [20]),
        .I1(posReg[20]),
        .I2(posReg[21]),
        .I3(\maxCoordinateReg_reg[31] [21]),
        .O(i__carry_i_2__0_n_0));
  LUT4 #(
    .INIT(16'h2F02)) 
    i__carry_i_3
       (.I0(\maxCoordinateReg_reg[31] [2]),
        .I1(posReg[2]),
        .I2(posReg[3]),
        .I3(\maxCoordinateReg_reg[31] [3]),
        .O(i__carry_i_3_n_0));
  LUT4 #(
    .INIT(16'h2F02)) 
    i__carry_i_3__0
       (.I0(\maxCoordinateReg_reg[31] [18]),
        .I1(posReg[18]),
        .I2(posReg[19]),
        .I3(\maxCoordinateReg_reg[31] [19]),
        .O(i__carry_i_3__0_n_0));
  LUT4 #(
    .INIT(16'h2F02)) 
    i__carry_i_4
       (.I0(\maxCoordinateReg_reg[31] [0]),
        .I1(posReg[0]),
        .I2(posReg[1]),
        .I3(\maxCoordinateReg_reg[31] [1]),
        .O(i__carry_i_4_n_0));
  LUT4 #(
    .INIT(16'h2F02)) 
    i__carry_i_4__0
       (.I0(\maxCoordinateReg_reg[31] [16]),
        .I1(posReg[16]),
        .I2(posReg[17]),
        .I3(\maxCoordinateReg_reg[31] [17]),
        .O(i__carry_i_4__0_n_0));
  LUT4 #(
    .INIT(16'h9009)) 
    i__carry_i_5
       (.I0(\maxCoordinateReg_reg[31] [6]),
        .I1(posReg[6]),
        .I2(\maxCoordinateReg_reg[31] [7]),
        .I3(posReg[7]),
        .O(i__carry_i_5_n_0));
  LUT4 #(
    .INIT(16'h9009)) 
    i__carry_i_5__0
       (.I0(\maxCoordinateReg_reg[31] [22]),
        .I1(posReg[22]),
        .I2(\maxCoordinateReg_reg[31] [23]),
        .I3(posReg[23]),
        .O(i__carry_i_5__0_n_0));
  LUT4 #(
    .INIT(16'h9009)) 
    i__carry_i_6
       (.I0(\maxCoordinateReg_reg[31] [4]),
        .I1(posReg[4]),
        .I2(\maxCoordinateReg_reg[31] [5]),
        .I3(posReg[5]),
        .O(i__carry_i_6_n_0));
  LUT4 #(
    .INIT(16'h9009)) 
    i__carry_i_6__0
       (.I0(\maxCoordinateReg_reg[31] [20]),
        .I1(posReg[20]),
        .I2(\maxCoordinateReg_reg[31] [21]),
        .I3(posReg[21]),
        .O(i__carry_i_6__0_n_0));
  LUT4 #(
    .INIT(16'h9009)) 
    i__carry_i_7
       (.I0(\maxCoordinateReg_reg[31] [2]),
        .I1(posReg[2]),
        .I2(\maxCoordinateReg_reg[31] [3]),
        .I3(posReg[3]),
        .O(i__carry_i_7_n_0));
  LUT4 #(
    .INIT(16'h9009)) 
    i__carry_i_7__0
       (.I0(\maxCoordinateReg_reg[31] [18]),
        .I1(posReg[18]),
        .I2(\maxCoordinateReg_reg[31] [19]),
        .I3(posReg[19]),
        .O(i__carry_i_7__0_n_0));
  LUT4 #(
    .INIT(16'h9009)) 
    i__carry_i_8
       (.I0(\maxCoordinateReg_reg[31] [0]),
        .I1(posReg[0]),
        .I2(\maxCoordinateReg_reg[31] [1]),
        .I3(posReg[1]),
        .O(i__carry_i_8_n_0));
  LUT4 #(
    .INIT(16'h9009)) 
    i__carry_i_8__0
       (.I0(\maxCoordinateReg_reg[31] [16]),
        .I1(posReg[16]),
        .I2(\maxCoordinateReg_reg[31] [17]),
        .I3(posReg[17]),
        .O(i__carry_i_8__0_n_0));
  LUT5 #(
    .INIT(32'hFF550CAA)) 
    \intrStatReg[1]_i_1 
       (.I0(s00_axi_wdata),
        .I1(w_mousemove),
        .I2(w_button_pulse),
        .I3(\axi_awaddr_reg[4] ),
        .I4(\intrStatReg_reg[1]_0 ),
        .O(\intrStatReg_reg[1] ));
  LUT4 #(
    .INIT(16'hFFFE)) 
    o_intr_i_10
       (.I0(posReg[25]),
        .I1(posReg[24]),
        .I2(posReg[27]),
        .I3(posReg[26]),
        .O(o_intr_i_10_n_0));
  LUT6 #(
    .INIT(64'hFFFFFFFEFFFFFFFF)) 
    o_intr_i_3
       (.I0(o_intr_i_6_n_0),
        .I1(posReg[23]),
        .I2(posReg[22]),
        .I3(posReg[21]),
        .I4(posReg[20]),
        .I5(o_intr_i_7_n_0),
        .O(p_1_in));
  LUT5 #(
    .INIT(32'h00000001)) 
    o_intr_i_4
       (.I0(posReg[12]),
        .I1(posReg[13]),
        .I2(posReg[15]),
        .I3(posReg[14]),
        .I4(o_intr_i_8_n_0),
        .O(o_intr_i_4_n_0));
  LUT5 #(
    .INIT(32'h00000001)) 
    o_intr_i_5
       (.I0(posReg[4]),
        .I1(posReg[5]),
        .I2(posReg[6]),
        .I3(posReg[7]),
        .I4(o_intr_i_9_n_0),
        .O(o_intr_i_5_n_0));
  LUT4 #(
    .INIT(16'hFFFE)) 
    o_intr_i_6
       (.I0(posReg[17]),
        .I1(posReg[16]),
        .I2(posReg[19]),
        .I3(posReg[18]),
        .O(o_intr_i_6_n_0));
  LUT5 #(
    .INIT(32'h00000001)) 
    o_intr_i_7
       (.I0(posReg[28]),
        .I1(posReg[29]),
        .I2(posReg[31]),
        .I3(posReg[30]),
        .I4(o_intr_i_10_n_0),
        .O(o_intr_i_7_n_0));
  LUT4 #(
    .INIT(16'hFFFE)) 
    o_intr_i_8
       (.I0(posReg[9]),
        .I1(posReg[8]),
        .I2(posReg[11]),
        .I3(posReg[10]),
        .O(o_intr_i_8_n_0));
  LUT4 #(
    .INIT(16'hFFFE)) 
    o_intr_i_9
       (.I0(posReg[1]),
        .I1(posReg[0]),
        .I2(posReg[3]),
        .I3(posReg[2]),
        .O(o_intr_i_9_n_0));
  FDRE o_intr_reg
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(o_intr1_out),
        .Q(w_mousemove),
        .R(1'b0));
  CARRY4 \o_x_pos0_inferred__1/i__carry 
       (.CI(1'b0),
        .CO({\o_x_pos0_inferred__1/i__carry_n_0 ,\o_x_pos0_inferred__1/i__carry_n_1 ,\o_x_pos0_inferred__1/i__carry_n_2 ,\o_x_pos0_inferred__1/i__carry_n_3 }),
        .CYINIT(1'b0),
        .DI({i__carry_i_1_n_0,i__carry_i_2_n_0,i__carry_i_3_n_0,i__carry_i_4_n_0}),
        .O(\NLW_o_x_pos0_inferred__1/i__carry_O_UNCONNECTED [3:0]),
        .S({i__carry_i_5_n_0,i__carry_i_6_n_0,i__carry_i_7_n_0,i__carry_i_8_n_0}));
  CARRY4 \o_x_pos0_inferred__1/i__carry__0 
       (.CI(\o_x_pos0_inferred__1/i__carry_n_0 ),
        .CO({p_0_in,\o_x_pos0_inferred__1/i__carry__0_n_1 ,\o_x_pos0_inferred__1/i__carry__0_n_2 ,\o_x_pos0_inferred__1/i__carry__0_n_3 }),
        .CYINIT(1'b0),
        .DI({i__carry__0_i_1_n_0,i__carry__0_i_2_n_0,i__carry__0_i_3_n_0,i__carry__0_i_4_n_0}),
        .O(\NLW_o_x_pos0_inferred__1/i__carry__0_O_UNCONNECTED [3:0]),
        .S({i__carry__0_i_5_n_0,i__carry__0_i_6_n_0,i__carry__0_i_7_n_0,i__carry__0_i_8_n_0}));
  LUT3 #(
    .INIT(8'hD1)) 
    \o_x_pos[0]_i_10 
       (.I0(posReg[0]),
        .I1(Q[0]),
        .I2(\maxCoordinateReg_reg[31] [1]),
        .O(\o_x_pos[0]_i_10_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \o_x_pos[0]_i_6 
       (.I0(Q[0]),
        .O(\o_x_pos[0]_i_6_n_0 ));
  FDRE \o_x_pos_reg[0] 
       (.C(s00_axi_aclk),
        .CE(sel),
        .D(pGRight_n_6),
        .Q(posReg[0]),
        .R(1'b0));
  FDRE \o_x_pos_reg[10] 
       (.C(s00_axi_aclk),
        .CE(sel),
        .D(pGRight_n_12),
        .Q(posReg[10]),
        .R(1'b0));
  FDRE \o_x_pos_reg[11] 
       (.C(s00_axi_aclk),
        .CE(sel),
        .D(pGRight_n_11),
        .Q(posReg[11]),
        .R(1'b0));
  FDRE \o_x_pos_reg[12] 
       (.C(s00_axi_aclk),
        .CE(sel),
        .D(pGRight_n_18),
        .Q(posReg[12]),
        .R(1'b0));
  FDRE \o_x_pos_reg[13] 
       (.C(s00_axi_aclk),
        .CE(sel),
        .D(pGRight_n_17),
        .Q(posReg[13]),
        .R(1'b0));
  FDRE \o_x_pos_reg[14] 
       (.C(s00_axi_aclk),
        .CE(sel),
        .D(pGRight_n_16),
        .Q(posReg[14]),
        .R(1'b0));
  FDRE \o_x_pos_reg[15] 
       (.C(s00_axi_aclk),
        .CE(sel),
        .D(pGRight_n_15),
        .Q(posReg[15]),
        .R(1'b0));
  FDRE \o_x_pos_reg[1] 
       (.C(s00_axi_aclk),
        .CE(sel),
        .D(pGRight_n_5),
        .Q(posReg[1]),
        .R(1'b0));
  FDRE \o_x_pos_reg[2] 
       (.C(s00_axi_aclk),
        .CE(sel),
        .D(pGRight_n_4),
        .Q(posReg[2]),
        .R(1'b0));
  FDRE \o_x_pos_reg[3] 
       (.C(s00_axi_aclk),
        .CE(sel),
        .D(pGRight_n_3),
        .Q(posReg[3]),
        .R(1'b0));
  FDRE \o_x_pos_reg[4] 
       (.C(s00_axi_aclk),
        .CE(sel),
        .D(pGRight_n_10),
        .Q(posReg[4]),
        .R(1'b0));
  FDRE \o_x_pos_reg[5] 
       (.C(s00_axi_aclk),
        .CE(sel),
        .D(pGRight_n_9),
        .Q(posReg[5]),
        .R(1'b0));
  FDRE \o_x_pos_reg[6] 
       (.C(s00_axi_aclk),
        .CE(sel),
        .D(pGRight_n_8),
        .Q(posReg[6]),
        .R(1'b0));
  FDRE \o_x_pos_reg[7] 
       (.C(s00_axi_aclk),
        .CE(sel),
        .D(pGRight_n_7),
        .Q(posReg[7]),
        .R(1'b0));
  FDRE \o_x_pos_reg[8] 
       (.C(s00_axi_aclk),
        .CE(sel),
        .D(pGRight_n_14),
        .Q(posReg[8]),
        .R(1'b0));
  FDRE \o_x_pos_reg[9] 
       (.C(s00_axi_aclk),
        .CE(sel),
        .D(pGRight_n_13),
        .Q(posReg[9]),
        .R(1'b0));
  CARRY4 \o_y_pos0_inferred__1/i__carry 
       (.CI(1'b0),
        .CO({\o_y_pos0_inferred__1/i__carry_n_0 ,\o_y_pos0_inferred__1/i__carry_n_1 ,\o_y_pos0_inferred__1/i__carry_n_2 ,\o_y_pos0_inferred__1/i__carry_n_3 }),
        .CYINIT(1'b0),
        .DI({i__carry_i_1__0_n_0,i__carry_i_2__0_n_0,i__carry_i_3__0_n_0,i__carry_i_4__0_n_0}),
        .O(\NLW_o_y_pos0_inferred__1/i__carry_O_UNCONNECTED [3:0]),
        .S({i__carry_i_5__0_n_0,i__carry_i_6__0_n_0,i__carry_i_7__0_n_0,i__carry_i_8__0_n_0}));
  CARRY4 \o_y_pos0_inferred__1/i__carry__0 
       (.CI(\o_y_pos0_inferred__1/i__carry_n_0 ),
        .CO({p_2_in,\o_y_pos0_inferred__1/i__carry__0_n_1 ,\o_y_pos0_inferred__1/i__carry__0_n_2 ,\o_y_pos0_inferred__1/i__carry__0_n_3 }),
        .CYINIT(1'b0),
        .DI({i__carry__0_i_1__0_n_0,i__carry__0_i_2__0_n_0,i__carry__0_i_3__0_n_0,i__carry__0_i_4__0_n_0}),
        .O(\NLW_o_y_pos0_inferred__1/i__carry__0_O_UNCONNECTED [3:0]),
        .S({i__carry__0_i_5__0_n_0,i__carry__0_i_6__0_n_0,i__carry__0_i_7__0_n_0,i__carry__0_i_8__0_n_0}));
  LUT3 #(
    .INIT(8'hD1)) 
    \o_y_pos[0]_i_10 
       (.I0(posReg[16]),
        .I1(Q[0]),
        .I2(\maxCoordinateReg_reg[31] [17]),
        .O(\o_y_pos[0]_i_10_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \o_y_pos[0]_i_6 
       (.I0(Q[0]),
        .O(\o_y_pos[0]_i_6_n_0 ));
  FDRE \o_y_pos_reg[0] 
       (.C(s00_axi_aclk),
        .CE(pGUp_n_2),
        .D(pGDown_n_5),
        .Q(posReg[16]),
        .R(1'b0));
  FDRE \o_y_pos_reg[10] 
       (.C(s00_axi_aclk),
        .CE(pGUp_n_2),
        .D(pGDown_n_11),
        .Q(posReg[26]),
        .R(1'b0));
  FDRE \o_y_pos_reg[11] 
       (.C(s00_axi_aclk),
        .CE(pGUp_n_2),
        .D(pGDown_n_10),
        .Q(posReg[27]),
        .R(1'b0));
  FDRE \o_y_pos_reg[12] 
       (.C(s00_axi_aclk),
        .CE(pGUp_n_2),
        .D(pGDown_n_17),
        .Q(posReg[28]),
        .R(1'b0));
  FDRE \o_y_pos_reg[13] 
       (.C(s00_axi_aclk),
        .CE(pGUp_n_2),
        .D(pGDown_n_16),
        .Q(posReg[29]),
        .R(1'b0));
  FDRE \o_y_pos_reg[14] 
       (.C(s00_axi_aclk),
        .CE(pGUp_n_2),
        .D(pGDown_n_15),
        .Q(posReg[30]),
        .R(1'b0));
  FDRE \o_y_pos_reg[15] 
       (.C(s00_axi_aclk),
        .CE(pGUp_n_2),
        .D(pGDown_n_14),
        .Q(posReg[31]),
        .R(1'b0));
  FDRE \o_y_pos_reg[1] 
       (.C(s00_axi_aclk),
        .CE(pGUp_n_2),
        .D(pGDown_n_4),
        .Q(posReg[17]),
        .R(1'b0));
  FDRE \o_y_pos_reg[2] 
       (.C(s00_axi_aclk),
        .CE(pGUp_n_2),
        .D(pGDown_n_3),
        .Q(posReg[18]),
        .R(1'b0));
  FDRE \o_y_pos_reg[3] 
       (.C(s00_axi_aclk),
        .CE(pGUp_n_2),
        .D(pGDown_n_2),
        .Q(posReg[19]),
        .R(1'b0));
  FDRE \o_y_pos_reg[4] 
       (.C(s00_axi_aclk),
        .CE(pGUp_n_2),
        .D(pGDown_n_9),
        .Q(posReg[20]),
        .R(1'b0));
  FDRE \o_y_pos_reg[5] 
       (.C(s00_axi_aclk),
        .CE(pGUp_n_2),
        .D(pGDown_n_8),
        .Q(posReg[21]),
        .R(1'b0));
  FDRE \o_y_pos_reg[6] 
       (.C(s00_axi_aclk),
        .CE(pGUp_n_2),
        .D(pGDown_n_7),
        .Q(posReg[22]),
        .R(1'b0));
  FDRE \o_y_pos_reg[7] 
       (.C(s00_axi_aclk),
        .CE(pGUp_n_2),
        .D(pGDown_n_6),
        .Q(posReg[23]),
        .R(1'b0));
  FDRE \o_y_pos_reg[8] 
       (.C(s00_axi_aclk),
        .CE(pGUp_n_2),
        .D(pGDown_n_13),
        .Q(posReg[24]),
        .R(1'b0));
  FDRE \o_y_pos_reg[9] 
       (.C(s00_axi_aclk),
        .CE(pGUp_n_2),
        .D(pGDown_n_12),
        .Q(posReg[25]),
        .R(1'b0));
  decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_pulseGen pGDown
       (.CO(pGDown_n_1),
        .DI(\o_y_pos[0]_i_6_n_0 ),
        .O({pGDown_n_2,pGDown_n_3,pGDown_n_4,pGDown_n_5}),
        .Q(Q[0]),
        .S(\o_y_pos[0]_i_10_n_0 ),
        .\maxCoordinateReg_reg[31] (\maxCoordinateReg_reg[31] [31:18]),
        .\maxCountReg_reg[31] (\maxCountReg_reg[31] ),
        .o_press_reg(dbDown_n_0),
        .\o_y_pos_reg[0] (pGDown_n_0),
        .\o_y_pos_reg[11] ({pGDown_n_10,pGDown_n_11,pGDown_n_12,pGDown_n_13}),
        .\o_y_pos_reg[15] ({pGDown_n_14,pGDown_n_15,pGDown_n_16,pGDown_n_17}),
        .\o_y_pos_reg[7] ({pGDown_n_6,pGDown_n_7,pGDown_n_8,pGDown_n_9}),
        .posReg(posReg[31:17]),
        .s00_axi_aclk(s00_axi_aclk));
  decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_pulseGen_3 pGLeft
       (.CO(counter2),
        .clear(clear),
        .\maxCountReg_reg[31] (\maxCountReg_reg[31] ),
        .o_pulse(o_pulse),
        .s00_axi_aclk(s00_axi_aclk));
  decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_pulseGen_4 pGRight
       (.CO(pGRight_n_0),
        .DI(\o_x_pos[0]_i_6_n_0 ),
        .O({pGRight_n_3,pGRight_n_4,pGRight_n_5,pGRight_n_6}),
        .Q(Q[0]),
        .S(\o_x_pos[0]_i_10_n_0 ),
        .\maxCoordinateReg_reg[14] (p_0_in),
        .\maxCoordinateReg_reg[15] (\maxCoordinateReg_reg[31] [15:2]),
        .\maxCoordinateReg_reg[30] (p_2_in),
        .\maxCountReg_reg[31] (\maxCountReg_reg[31] ),
        .o_intr1_out(o_intr1_out),
        .o_press_reg(dbRight_n_0),
        .o_pulse(o_pulse),
        .o_pulse_reg_0(pGUp_n_0),
        .o_pulse_reg_1(pGDown_n_0),
        .\o_x_pos_reg[11] ({pGRight_n_11,pGRight_n_12,pGRight_n_13,pGRight_n_14}),
        .\o_x_pos_reg[12] (o_intr_i_4_n_0),
        .\o_x_pos_reg[15] ({pGRight_n_15,pGRight_n_16,pGRight_n_17,pGRight_n_18}),
        .\o_x_pos_reg[4] (o_intr_i_5_n_0),
        .\o_x_pos_reg[7] ({pGRight_n_7,pGRight_n_8,pGRight_n_9,pGRight_n_10}),
        .p_1_in(p_1_in),
        .posReg(posReg[15:1]),
        .s00_axi_aclk(s00_axi_aclk),
        .sel(sel));
  decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_pulseGen_5 pGUp
       (.CO(pGUp_n_1),
        .Q(Q[0]),
        .\maxCoordinateReg_reg[30] (p_2_in),
        .\maxCountReg_reg[31] (\maxCountReg_reg[31] ),
        .o_press_reg(dbUp_n_0),
        .o_pulse_reg_0(pGDown_n_0),
        .\o_y_pos_reg[0] (pGUp_n_0),
        .\o_y_pos_reg[0]_0 (pGUp_n_2),
        .p_1_in(p_1_in),
        .s00_axi_aclk(s00_axi_aclk));
endmodule

module decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_pulseGen
   (\o_y_pos_reg[0] ,
    CO,
    O,
    \o_y_pos_reg[7] ,
    \o_y_pos_reg[11] ,
    \o_y_pos_reg[15] ,
    s00_axi_aclk,
    Q,
    \maxCountReg_reg[31] ,
    posReg,
    DI,
    S,
    \maxCoordinateReg_reg[31] ,
    o_press_reg);
  output \o_y_pos_reg[0] ;
  output [0:0]CO;
  output [3:0]O;
  output [3:0]\o_y_pos_reg[7] ;
  output [3:0]\o_y_pos_reg[11] ;
  output [3:0]\o_y_pos_reg[15] ;
  input s00_axi_aclk;
  input [0:0]Q;
  input [31:0]\maxCountReg_reg[31] ;
  input [14:0]posReg;
  input [0:0]DI;
  input [0:0]S;
  input [13:0]\maxCoordinateReg_reg[31] ;
  input o_press_reg;

  wire [0:0]CO;
  wire [0:0]DI;
  wire [3:0]O;
  wire [0:0]Q;
  wire [0:0]S;
  wire counter2_carry__0_i_1__1_n_0;
  wire counter2_carry__0_i_2__1_n_0;
  wire counter2_carry__0_i_3__1_n_0;
  wire counter2_carry__0_i_4__1_n_0;
  wire counter2_carry__0_i_5__1_n_0;
  wire counter2_carry__0_i_6__1_n_0;
  wire counter2_carry__0_i_7__1_n_0;
  wire counter2_carry__0_i_8__1_n_0;
  wire counter2_carry__0_n_0;
  wire counter2_carry__0_n_1;
  wire counter2_carry__0_n_2;
  wire counter2_carry__0_n_3;
  wire counter2_carry__1_i_1__1_n_0;
  wire counter2_carry__1_i_2__1_n_0;
  wire counter2_carry__1_i_3__1_n_0;
  wire counter2_carry__1_i_4__1_n_0;
  wire counter2_carry__1_i_5__1_n_0;
  wire counter2_carry__1_i_6__1_n_0;
  wire counter2_carry__1_i_7__1_n_0;
  wire counter2_carry__1_i_8__1_n_0;
  wire counter2_carry__1_n_0;
  wire counter2_carry__1_n_1;
  wire counter2_carry__1_n_2;
  wire counter2_carry__1_n_3;
  wire counter2_carry__2_i_1__1_n_0;
  wire counter2_carry__2_i_2__1_n_0;
  wire counter2_carry__2_i_3__1_n_0;
  wire counter2_carry__2_i_4__1_n_0;
  wire counter2_carry__2_i_5__1_n_0;
  wire counter2_carry__2_i_6__1_n_0;
  wire counter2_carry__2_i_7__1_n_0;
  wire counter2_carry__2_i_8__1_n_0;
  wire counter2_carry__2_n_1;
  wire counter2_carry__2_n_2;
  wire counter2_carry__2_n_3;
  wire counter2_carry_i_1__1_n_0;
  wire counter2_carry_i_2__1_n_0;
  wire counter2_carry_i_3__1_n_0;
  wire counter2_carry_i_4__1_n_0;
  wire counter2_carry_i_5__1_n_0;
  wire counter2_carry_i_6__1_n_0;
  wire counter2_carry_i_7__1_n_0;
  wire counter2_carry_i_8__1_n_0;
  wire counter2_carry_n_0;
  wire counter2_carry_n_1;
  wire counter2_carry_n_2;
  wire counter2_carry_n_3;
  wire \counter[0]_i_3__4_n_0 ;
  wire [31:0]counter_reg;
  wire \counter_reg[0]_i_2__5_n_0 ;
  wire \counter_reg[0]_i_2__5_n_1 ;
  wire \counter_reg[0]_i_2__5_n_2 ;
  wire \counter_reg[0]_i_2__5_n_3 ;
  wire \counter_reg[0]_i_2__5_n_4 ;
  wire \counter_reg[0]_i_2__5_n_5 ;
  wire \counter_reg[0]_i_2__5_n_6 ;
  wire \counter_reg[0]_i_2__5_n_7 ;
  wire \counter_reg[12]_i_1__5_n_0 ;
  wire \counter_reg[12]_i_1__5_n_1 ;
  wire \counter_reg[12]_i_1__5_n_2 ;
  wire \counter_reg[12]_i_1__5_n_3 ;
  wire \counter_reg[12]_i_1__5_n_4 ;
  wire \counter_reg[12]_i_1__5_n_5 ;
  wire \counter_reg[12]_i_1__5_n_6 ;
  wire \counter_reg[12]_i_1__5_n_7 ;
  wire \counter_reg[16]_i_1__5_n_0 ;
  wire \counter_reg[16]_i_1__5_n_1 ;
  wire \counter_reg[16]_i_1__5_n_2 ;
  wire \counter_reg[16]_i_1__5_n_3 ;
  wire \counter_reg[16]_i_1__5_n_4 ;
  wire \counter_reg[16]_i_1__5_n_5 ;
  wire \counter_reg[16]_i_1__5_n_6 ;
  wire \counter_reg[16]_i_1__5_n_7 ;
  wire \counter_reg[20]_i_1__5_n_0 ;
  wire \counter_reg[20]_i_1__5_n_1 ;
  wire \counter_reg[20]_i_1__5_n_2 ;
  wire \counter_reg[20]_i_1__5_n_3 ;
  wire \counter_reg[20]_i_1__5_n_4 ;
  wire \counter_reg[20]_i_1__5_n_5 ;
  wire \counter_reg[20]_i_1__5_n_6 ;
  wire \counter_reg[20]_i_1__5_n_7 ;
  wire \counter_reg[24]_i_1__5_n_0 ;
  wire \counter_reg[24]_i_1__5_n_1 ;
  wire \counter_reg[24]_i_1__5_n_2 ;
  wire \counter_reg[24]_i_1__5_n_3 ;
  wire \counter_reg[24]_i_1__5_n_4 ;
  wire \counter_reg[24]_i_1__5_n_5 ;
  wire \counter_reg[24]_i_1__5_n_6 ;
  wire \counter_reg[24]_i_1__5_n_7 ;
  wire \counter_reg[28]_i_1__5_n_1 ;
  wire \counter_reg[28]_i_1__5_n_2 ;
  wire \counter_reg[28]_i_1__5_n_3 ;
  wire \counter_reg[28]_i_1__5_n_4 ;
  wire \counter_reg[28]_i_1__5_n_5 ;
  wire \counter_reg[28]_i_1__5_n_6 ;
  wire \counter_reg[28]_i_1__5_n_7 ;
  wire \counter_reg[4]_i_1__5_n_0 ;
  wire \counter_reg[4]_i_1__5_n_1 ;
  wire \counter_reg[4]_i_1__5_n_2 ;
  wire \counter_reg[4]_i_1__5_n_3 ;
  wire \counter_reg[4]_i_1__5_n_4 ;
  wire \counter_reg[4]_i_1__5_n_5 ;
  wire \counter_reg[4]_i_1__5_n_6 ;
  wire \counter_reg[4]_i_1__5_n_7 ;
  wire \counter_reg[8]_i_1__5_n_0 ;
  wire \counter_reg[8]_i_1__5_n_1 ;
  wire \counter_reg[8]_i_1__5_n_2 ;
  wire \counter_reg[8]_i_1__5_n_3 ;
  wire \counter_reg[8]_i_1__5_n_4 ;
  wire \counter_reg[8]_i_1__5_n_5 ;
  wire \counter_reg[8]_i_1__5_n_6 ;
  wire \counter_reg[8]_i_1__5_n_7 ;
  wire [13:0]\maxCoordinateReg_reg[31] ;
  wire [31:0]\maxCountReg_reg[31] ;
  wire o_press_reg;
  wire o_pulse0_carry__0_i_1__1_n_0;
  wire o_pulse0_carry__0_i_2__1_n_0;
  wire o_pulse0_carry__0_i_3__1_n_0;
  wire o_pulse0_carry__0_i_4__1_n_0;
  wire o_pulse0_carry__0_n_0;
  wire o_pulse0_carry__0_n_1;
  wire o_pulse0_carry__0_n_2;
  wire o_pulse0_carry__0_n_3;
  wire o_pulse0_carry__1_i_1__1_n_0;
  wire o_pulse0_carry__1_i_2__1_n_0;
  wire o_pulse0_carry__1_i_3__1_n_0;
  wire o_pulse0_carry__1_n_1;
  wire o_pulse0_carry__1_n_2;
  wire o_pulse0_carry__1_n_3;
  wire o_pulse0_carry_i_1__1_n_0;
  wire o_pulse0_carry_i_2__1_n_0;
  wire o_pulse0_carry_i_3__1_n_0;
  wire o_pulse0_carry_i_4__1_n_0;
  wire o_pulse0_carry_n_0;
  wire o_pulse0_carry_n_1;
  wire o_pulse0_carry_n_2;
  wire o_pulse0_carry_n_3;
  wire \o_y_pos[0]_i_3_n_0 ;
  wire \o_y_pos[0]_i_4_n_0 ;
  wire \o_y_pos[0]_i_5_n_0 ;
  wire \o_y_pos[0]_i_7_n_0 ;
  wire \o_y_pos[0]_i_8_n_0 ;
  wire \o_y_pos[0]_i_9_n_0 ;
  wire \o_y_pos[12]_i_2_n_0 ;
  wire \o_y_pos[12]_i_3_n_0 ;
  wire \o_y_pos[12]_i_4_n_0 ;
  wire \o_y_pos[12]_i_5_n_0 ;
  wire \o_y_pos[12]_i_6_n_0 ;
  wire \o_y_pos[12]_i_7_n_0 ;
  wire \o_y_pos[12]_i_8_n_0 ;
  wire \o_y_pos[4]_i_2_n_0 ;
  wire \o_y_pos[4]_i_3_n_0 ;
  wire \o_y_pos[4]_i_4_n_0 ;
  wire \o_y_pos[4]_i_5_n_0 ;
  wire \o_y_pos[4]_i_6_n_0 ;
  wire \o_y_pos[4]_i_7_n_0 ;
  wire \o_y_pos[4]_i_8_n_0 ;
  wire \o_y_pos[4]_i_9_n_0 ;
  wire \o_y_pos[8]_i_2_n_0 ;
  wire \o_y_pos[8]_i_3_n_0 ;
  wire \o_y_pos[8]_i_4_n_0 ;
  wire \o_y_pos[8]_i_5_n_0 ;
  wire \o_y_pos[8]_i_6_n_0 ;
  wire \o_y_pos[8]_i_7_n_0 ;
  wire \o_y_pos[8]_i_8_n_0 ;
  wire \o_y_pos[8]_i_9_n_0 ;
  wire \o_y_pos_reg[0] ;
  wire \o_y_pos_reg[0]_i_2_n_0 ;
  wire \o_y_pos_reg[0]_i_2_n_1 ;
  wire \o_y_pos_reg[0]_i_2_n_2 ;
  wire \o_y_pos_reg[0]_i_2_n_3 ;
  wire [3:0]\o_y_pos_reg[11] ;
  wire \o_y_pos_reg[12]_i_1_n_1 ;
  wire \o_y_pos_reg[12]_i_1_n_2 ;
  wire \o_y_pos_reg[12]_i_1_n_3 ;
  wire [3:0]\o_y_pos_reg[15] ;
  wire \o_y_pos_reg[4]_i_1_n_0 ;
  wire \o_y_pos_reg[4]_i_1_n_1 ;
  wire \o_y_pos_reg[4]_i_1_n_2 ;
  wire \o_y_pos_reg[4]_i_1_n_3 ;
  wire [3:0]\o_y_pos_reg[7] ;
  wire \o_y_pos_reg[8]_i_1_n_0 ;
  wire \o_y_pos_reg[8]_i_1_n_1 ;
  wire \o_y_pos_reg[8]_i_1_n_2 ;
  wire \o_y_pos_reg[8]_i_1_n_3 ;
  wire [14:0]posReg;
  wire s00_axi_aclk;
  wire [3:0]NLW_counter2_carry_O_UNCONNECTED;
  wire [3:0]NLW_counter2_carry__0_O_UNCONNECTED;
  wire [3:0]NLW_counter2_carry__1_O_UNCONNECTED;
  wire [3:0]NLW_counter2_carry__2_O_UNCONNECTED;
  wire [3:3]\NLW_counter_reg[28]_i_1__5_CO_UNCONNECTED ;
  wire [3:0]NLW_o_pulse0_carry_O_UNCONNECTED;
  wire [3:0]NLW_o_pulse0_carry__0_O_UNCONNECTED;
  wire [3:3]NLW_o_pulse0_carry__1_CO_UNCONNECTED;
  wire [3:0]NLW_o_pulse0_carry__1_O_UNCONNECTED;
  wire [3:3]\NLW_o_y_pos_reg[12]_i_1_CO_UNCONNECTED ;

  CARRY4 counter2_carry
       (.CI(1'b0),
        .CO({counter2_carry_n_0,counter2_carry_n_1,counter2_carry_n_2,counter2_carry_n_3}),
        .CYINIT(1'b0),
        .DI({counter2_carry_i_1__1_n_0,counter2_carry_i_2__1_n_0,counter2_carry_i_3__1_n_0,counter2_carry_i_4__1_n_0}),
        .O(NLW_counter2_carry_O_UNCONNECTED[3:0]),
        .S({counter2_carry_i_5__1_n_0,counter2_carry_i_6__1_n_0,counter2_carry_i_7__1_n_0,counter2_carry_i_8__1_n_0}));
  CARRY4 counter2_carry__0
       (.CI(counter2_carry_n_0),
        .CO({counter2_carry__0_n_0,counter2_carry__0_n_1,counter2_carry__0_n_2,counter2_carry__0_n_3}),
        .CYINIT(1'b0),
        .DI({counter2_carry__0_i_1__1_n_0,counter2_carry__0_i_2__1_n_0,counter2_carry__0_i_3__1_n_0,counter2_carry__0_i_4__1_n_0}),
        .O(NLW_counter2_carry__0_O_UNCONNECTED[3:0]),
        .S({counter2_carry__0_i_5__1_n_0,counter2_carry__0_i_6__1_n_0,counter2_carry__0_i_7__1_n_0,counter2_carry__0_i_8__1_n_0}));
  LUT4 #(
    .INIT(16'h2F02)) 
    counter2_carry__0_i_1__1
       (.I0(\maxCountReg_reg[31] [14]),
        .I1(counter_reg[14]),
        .I2(counter_reg[15]),
        .I3(\maxCountReg_reg[31] [15]),
        .O(counter2_carry__0_i_1__1_n_0));
  LUT4 #(
    .INIT(16'h2F02)) 
    counter2_carry__0_i_2__1
       (.I0(\maxCountReg_reg[31] [12]),
        .I1(counter_reg[12]),
        .I2(counter_reg[13]),
        .I3(\maxCountReg_reg[31] [13]),
        .O(counter2_carry__0_i_2__1_n_0));
  LUT4 #(
    .INIT(16'h2F02)) 
    counter2_carry__0_i_3__1
       (.I0(\maxCountReg_reg[31] [10]),
        .I1(counter_reg[10]),
        .I2(counter_reg[11]),
        .I3(\maxCountReg_reg[31] [11]),
        .O(counter2_carry__0_i_3__1_n_0));
  LUT4 #(
    .INIT(16'h2F02)) 
    counter2_carry__0_i_4__1
       (.I0(\maxCountReg_reg[31] [8]),
        .I1(counter_reg[8]),
        .I2(counter_reg[9]),
        .I3(\maxCountReg_reg[31] [9]),
        .O(counter2_carry__0_i_4__1_n_0));
  LUT4 #(
    .INIT(16'h9009)) 
    counter2_carry__0_i_5__1
       (.I0(\maxCountReg_reg[31] [14]),
        .I1(counter_reg[14]),
        .I2(\maxCountReg_reg[31] [15]),
        .I3(counter_reg[15]),
        .O(counter2_carry__0_i_5__1_n_0));
  LUT4 #(
    .INIT(16'h9009)) 
    counter2_carry__0_i_6__1
       (.I0(\maxCountReg_reg[31] [12]),
        .I1(counter_reg[12]),
        .I2(\maxCountReg_reg[31] [13]),
        .I3(counter_reg[13]),
        .O(counter2_carry__0_i_6__1_n_0));
  LUT4 #(
    .INIT(16'h9009)) 
    counter2_carry__0_i_7__1
       (.I0(\maxCountReg_reg[31] [10]),
        .I1(counter_reg[10]),
        .I2(\maxCountReg_reg[31] [11]),
        .I3(counter_reg[11]),
        .O(counter2_carry__0_i_7__1_n_0));
  LUT4 #(
    .INIT(16'h9009)) 
    counter2_carry__0_i_8__1
       (.I0(\maxCountReg_reg[31] [8]),
        .I1(counter_reg[8]),
        .I2(\maxCountReg_reg[31] [9]),
        .I3(counter_reg[9]),
        .O(counter2_carry__0_i_8__1_n_0));
  CARRY4 counter2_carry__1
       (.CI(counter2_carry__0_n_0),
        .CO({counter2_carry__1_n_0,counter2_carry__1_n_1,counter2_carry__1_n_2,counter2_carry__1_n_3}),
        .CYINIT(1'b0),
        .DI({counter2_carry__1_i_1__1_n_0,counter2_carry__1_i_2__1_n_0,counter2_carry__1_i_3__1_n_0,counter2_carry__1_i_4__1_n_0}),
        .O(NLW_counter2_carry__1_O_UNCONNECTED[3:0]),
        .S({counter2_carry__1_i_5__1_n_0,counter2_carry__1_i_6__1_n_0,counter2_carry__1_i_7__1_n_0,counter2_carry__1_i_8__1_n_0}));
  LUT4 #(
    .INIT(16'h2F02)) 
    counter2_carry__1_i_1__1
       (.I0(\maxCountReg_reg[31] [22]),
        .I1(counter_reg[22]),
        .I2(counter_reg[23]),
        .I3(\maxCountReg_reg[31] [23]),
        .O(counter2_carry__1_i_1__1_n_0));
  LUT4 #(
    .INIT(16'h2F02)) 
    counter2_carry__1_i_2__1
       (.I0(\maxCountReg_reg[31] [20]),
        .I1(counter_reg[20]),
        .I2(counter_reg[21]),
        .I3(\maxCountReg_reg[31] [21]),
        .O(counter2_carry__1_i_2__1_n_0));
  LUT4 #(
    .INIT(16'h2F02)) 
    counter2_carry__1_i_3__1
       (.I0(\maxCountReg_reg[31] [18]),
        .I1(counter_reg[18]),
        .I2(counter_reg[19]),
        .I3(\maxCountReg_reg[31] [19]),
        .O(counter2_carry__1_i_3__1_n_0));
  LUT4 #(
    .INIT(16'h2F02)) 
    counter2_carry__1_i_4__1
       (.I0(\maxCountReg_reg[31] [16]),
        .I1(counter_reg[16]),
        .I2(counter_reg[17]),
        .I3(\maxCountReg_reg[31] [17]),
        .O(counter2_carry__1_i_4__1_n_0));
  LUT4 #(
    .INIT(16'h9009)) 
    counter2_carry__1_i_5__1
       (.I0(\maxCountReg_reg[31] [22]),
        .I1(counter_reg[22]),
        .I2(\maxCountReg_reg[31] [23]),
        .I3(counter_reg[23]),
        .O(counter2_carry__1_i_5__1_n_0));
  LUT4 #(
    .INIT(16'h9009)) 
    counter2_carry__1_i_6__1
       (.I0(\maxCountReg_reg[31] [20]),
        .I1(counter_reg[20]),
        .I2(\maxCountReg_reg[31] [21]),
        .I3(counter_reg[21]),
        .O(counter2_carry__1_i_6__1_n_0));
  LUT4 #(
    .INIT(16'h9009)) 
    counter2_carry__1_i_7__1
       (.I0(\maxCountReg_reg[31] [18]),
        .I1(counter_reg[18]),
        .I2(\maxCountReg_reg[31] [19]),
        .I3(counter_reg[19]),
        .O(counter2_carry__1_i_7__1_n_0));
  LUT4 #(
    .INIT(16'h9009)) 
    counter2_carry__1_i_8__1
       (.I0(\maxCountReg_reg[31] [16]),
        .I1(counter_reg[16]),
        .I2(\maxCountReg_reg[31] [17]),
        .I3(counter_reg[17]),
        .O(counter2_carry__1_i_8__1_n_0));
  CARRY4 counter2_carry__2
       (.CI(counter2_carry__1_n_0),
        .CO({CO,counter2_carry__2_n_1,counter2_carry__2_n_2,counter2_carry__2_n_3}),
        .CYINIT(1'b0),
        .DI({counter2_carry__2_i_1__1_n_0,counter2_carry__2_i_2__1_n_0,counter2_carry__2_i_3__1_n_0,counter2_carry__2_i_4__1_n_0}),
        .O(NLW_counter2_carry__2_O_UNCONNECTED[3:0]),
        .S({counter2_carry__2_i_5__1_n_0,counter2_carry__2_i_6__1_n_0,counter2_carry__2_i_7__1_n_0,counter2_carry__2_i_8__1_n_0}));
  LUT4 #(
    .INIT(16'h2F02)) 
    counter2_carry__2_i_1__1
       (.I0(\maxCountReg_reg[31] [30]),
        .I1(counter_reg[30]),
        .I2(counter_reg[31]),
        .I3(\maxCountReg_reg[31] [31]),
        .O(counter2_carry__2_i_1__1_n_0));
  LUT4 #(
    .INIT(16'h2F02)) 
    counter2_carry__2_i_2__1
       (.I0(\maxCountReg_reg[31] [28]),
        .I1(counter_reg[28]),
        .I2(counter_reg[29]),
        .I3(\maxCountReg_reg[31] [29]),
        .O(counter2_carry__2_i_2__1_n_0));
  LUT4 #(
    .INIT(16'h2F02)) 
    counter2_carry__2_i_3__1
       (.I0(\maxCountReg_reg[31] [26]),
        .I1(counter_reg[26]),
        .I2(counter_reg[27]),
        .I3(\maxCountReg_reg[31] [27]),
        .O(counter2_carry__2_i_3__1_n_0));
  LUT4 #(
    .INIT(16'h2F02)) 
    counter2_carry__2_i_4__1
       (.I0(\maxCountReg_reg[31] [24]),
        .I1(counter_reg[24]),
        .I2(counter_reg[25]),
        .I3(\maxCountReg_reg[31] [25]),
        .O(counter2_carry__2_i_4__1_n_0));
  LUT4 #(
    .INIT(16'h9009)) 
    counter2_carry__2_i_5__1
       (.I0(\maxCountReg_reg[31] [30]),
        .I1(counter_reg[30]),
        .I2(\maxCountReg_reg[31] [31]),
        .I3(counter_reg[31]),
        .O(counter2_carry__2_i_5__1_n_0));
  LUT4 #(
    .INIT(16'h9009)) 
    counter2_carry__2_i_6__1
       (.I0(\maxCountReg_reg[31] [28]),
        .I1(counter_reg[28]),
        .I2(\maxCountReg_reg[31] [29]),
        .I3(counter_reg[29]),
        .O(counter2_carry__2_i_6__1_n_0));
  LUT4 #(
    .INIT(16'h9009)) 
    counter2_carry__2_i_7__1
       (.I0(\maxCountReg_reg[31] [26]),
        .I1(counter_reg[26]),
        .I2(\maxCountReg_reg[31] [27]),
        .I3(counter_reg[27]),
        .O(counter2_carry__2_i_7__1_n_0));
  LUT4 #(
    .INIT(16'h9009)) 
    counter2_carry__2_i_8__1
       (.I0(\maxCountReg_reg[31] [24]),
        .I1(counter_reg[24]),
        .I2(\maxCountReg_reg[31] [25]),
        .I3(counter_reg[25]),
        .O(counter2_carry__2_i_8__1_n_0));
  LUT4 #(
    .INIT(16'h2F02)) 
    counter2_carry_i_1__1
       (.I0(\maxCountReg_reg[31] [6]),
        .I1(counter_reg[6]),
        .I2(counter_reg[7]),
        .I3(\maxCountReg_reg[31] [7]),
        .O(counter2_carry_i_1__1_n_0));
  LUT4 #(
    .INIT(16'h2F02)) 
    counter2_carry_i_2__1
       (.I0(\maxCountReg_reg[31] [4]),
        .I1(counter_reg[4]),
        .I2(counter_reg[5]),
        .I3(\maxCountReg_reg[31] [5]),
        .O(counter2_carry_i_2__1_n_0));
  LUT4 #(
    .INIT(16'h2F02)) 
    counter2_carry_i_3__1
       (.I0(\maxCountReg_reg[31] [2]),
        .I1(counter_reg[2]),
        .I2(counter_reg[3]),
        .I3(\maxCountReg_reg[31] [3]),
        .O(counter2_carry_i_3__1_n_0));
  LUT4 #(
    .INIT(16'h2F02)) 
    counter2_carry_i_4__1
       (.I0(\maxCountReg_reg[31] [0]),
        .I1(counter_reg[0]),
        .I2(counter_reg[1]),
        .I3(\maxCountReg_reg[31] [1]),
        .O(counter2_carry_i_4__1_n_0));
  LUT4 #(
    .INIT(16'h9009)) 
    counter2_carry_i_5__1
       (.I0(\maxCountReg_reg[31] [6]),
        .I1(counter_reg[6]),
        .I2(\maxCountReg_reg[31] [7]),
        .I3(counter_reg[7]),
        .O(counter2_carry_i_5__1_n_0));
  LUT4 #(
    .INIT(16'h9009)) 
    counter2_carry_i_6__1
       (.I0(\maxCountReg_reg[31] [4]),
        .I1(counter_reg[4]),
        .I2(\maxCountReg_reg[31] [5]),
        .I3(counter_reg[5]),
        .O(counter2_carry_i_6__1_n_0));
  LUT4 #(
    .INIT(16'h9009)) 
    counter2_carry_i_7__1
       (.I0(\maxCountReg_reg[31] [2]),
        .I1(counter_reg[2]),
        .I2(\maxCountReg_reg[31] [3]),
        .I3(counter_reg[3]),
        .O(counter2_carry_i_7__1_n_0));
  LUT4 #(
    .INIT(16'h9009)) 
    counter2_carry_i_8__1
       (.I0(\maxCountReg_reg[31] [0]),
        .I1(counter_reg[0]),
        .I2(\maxCountReg_reg[31] [1]),
        .I3(counter_reg[1]),
        .O(counter2_carry_i_8__1_n_0));
  LUT1 #(
    .INIT(2'h1)) 
    \counter[0]_i_3__4 
       (.I0(counter_reg[0]),
        .O(\counter[0]_i_3__4_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[0] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[0]_i_2__5_n_7 ),
        .Q(counter_reg[0]),
        .R(o_press_reg));
  CARRY4 \counter_reg[0]_i_2__5 
       (.CI(1'b0),
        .CO({\counter_reg[0]_i_2__5_n_0 ,\counter_reg[0]_i_2__5_n_1 ,\counter_reg[0]_i_2__5_n_2 ,\counter_reg[0]_i_2__5_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b1}),
        .O({\counter_reg[0]_i_2__5_n_4 ,\counter_reg[0]_i_2__5_n_5 ,\counter_reg[0]_i_2__5_n_6 ,\counter_reg[0]_i_2__5_n_7 }),
        .S({counter_reg[3:1],\counter[0]_i_3__4_n_0 }));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[10] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[8]_i_1__5_n_5 ),
        .Q(counter_reg[10]),
        .R(o_press_reg));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[11] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[8]_i_1__5_n_4 ),
        .Q(counter_reg[11]),
        .R(o_press_reg));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[12] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[12]_i_1__5_n_7 ),
        .Q(counter_reg[12]),
        .R(o_press_reg));
  CARRY4 \counter_reg[12]_i_1__5 
       (.CI(\counter_reg[8]_i_1__5_n_0 ),
        .CO({\counter_reg[12]_i_1__5_n_0 ,\counter_reg[12]_i_1__5_n_1 ,\counter_reg[12]_i_1__5_n_2 ,\counter_reg[12]_i_1__5_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\counter_reg[12]_i_1__5_n_4 ,\counter_reg[12]_i_1__5_n_5 ,\counter_reg[12]_i_1__5_n_6 ,\counter_reg[12]_i_1__5_n_7 }),
        .S(counter_reg[15:12]));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[13] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[12]_i_1__5_n_6 ),
        .Q(counter_reg[13]),
        .R(o_press_reg));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[14] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[12]_i_1__5_n_5 ),
        .Q(counter_reg[14]),
        .R(o_press_reg));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[15] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[12]_i_1__5_n_4 ),
        .Q(counter_reg[15]),
        .R(o_press_reg));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[16] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[16]_i_1__5_n_7 ),
        .Q(counter_reg[16]),
        .R(o_press_reg));
  CARRY4 \counter_reg[16]_i_1__5 
       (.CI(\counter_reg[12]_i_1__5_n_0 ),
        .CO({\counter_reg[16]_i_1__5_n_0 ,\counter_reg[16]_i_1__5_n_1 ,\counter_reg[16]_i_1__5_n_2 ,\counter_reg[16]_i_1__5_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\counter_reg[16]_i_1__5_n_4 ,\counter_reg[16]_i_1__5_n_5 ,\counter_reg[16]_i_1__5_n_6 ,\counter_reg[16]_i_1__5_n_7 }),
        .S(counter_reg[19:16]));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[17] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[16]_i_1__5_n_6 ),
        .Q(counter_reg[17]),
        .R(o_press_reg));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[18] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[16]_i_1__5_n_5 ),
        .Q(counter_reg[18]),
        .R(o_press_reg));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[19] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[16]_i_1__5_n_4 ),
        .Q(counter_reg[19]),
        .R(o_press_reg));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[1] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[0]_i_2__5_n_6 ),
        .Q(counter_reg[1]),
        .R(o_press_reg));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[20] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[20]_i_1__5_n_7 ),
        .Q(counter_reg[20]),
        .R(o_press_reg));
  CARRY4 \counter_reg[20]_i_1__5 
       (.CI(\counter_reg[16]_i_1__5_n_0 ),
        .CO({\counter_reg[20]_i_1__5_n_0 ,\counter_reg[20]_i_1__5_n_1 ,\counter_reg[20]_i_1__5_n_2 ,\counter_reg[20]_i_1__5_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\counter_reg[20]_i_1__5_n_4 ,\counter_reg[20]_i_1__5_n_5 ,\counter_reg[20]_i_1__5_n_6 ,\counter_reg[20]_i_1__5_n_7 }),
        .S(counter_reg[23:20]));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[21] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[20]_i_1__5_n_6 ),
        .Q(counter_reg[21]),
        .R(o_press_reg));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[22] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[20]_i_1__5_n_5 ),
        .Q(counter_reg[22]),
        .R(o_press_reg));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[23] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[20]_i_1__5_n_4 ),
        .Q(counter_reg[23]),
        .R(o_press_reg));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[24] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[24]_i_1__5_n_7 ),
        .Q(counter_reg[24]),
        .R(o_press_reg));
  CARRY4 \counter_reg[24]_i_1__5 
       (.CI(\counter_reg[20]_i_1__5_n_0 ),
        .CO({\counter_reg[24]_i_1__5_n_0 ,\counter_reg[24]_i_1__5_n_1 ,\counter_reg[24]_i_1__5_n_2 ,\counter_reg[24]_i_1__5_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\counter_reg[24]_i_1__5_n_4 ,\counter_reg[24]_i_1__5_n_5 ,\counter_reg[24]_i_1__5_n_6 ,\counter_reg[24]_i_1__5_n_7 }),
        .S(counter_reg[27:24]));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[25] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[24]_i_1__5_n_6 ),
        .Q(counter_reg[25]),
        .R(o_press_reg));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[26] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[24]_i_1__5_n_5 ),
        .Q(counter_reg[26]),
        .R(o_press_reg));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[27] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[24]_i_1__5_n_4 ),
        .Q(counter_reg[27]),
        .R(o_press_reg));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[28] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[28]_i_1__5_n_7 ),
        .Q(counter_reg[28]),
        .R(o_press_reg));
  CARRY4 \counter_reg[28]_i_1__5 
       (.CI(\counter_reg[24]_i_1__5_n_0 ),
        .CO({\NLW_counter_reg[28]_i_1__5_CO_UNCONNECTED [3],\counter_reg[28]_i_1__5_n_1 ,\counter_reg[28]_i_1__5_n_2 ,\counter_reg[28]_i_1__5_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\counter_reg[28]_i_1__5_n_4 ,\counter_reg[28]_i_1__5_n_5 ,\counter_reg[28]_i_1__5_n_6 ,\counter_reg[28]_i_1__5_n_7 }),
        .S(counter_reg[31:28]));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[29] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[28]_i_1__5_n_6 ),
        .Q(counter_reg[29]),
        .R(o_press_reg));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[2] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[0]_i_2__5_n_5 ),
        .Q(counter_reg[2]),
        .R(o_press_reg));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[30] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[28]_i_1__5_n_5 ),
        .Q(counter_reg[30]),
        .R(o_press_reg));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[31] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[28]_i_1__5_n_4 ),
        .Q(counter_reg[31]),
        .R(o_press_reg));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[3] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[0]_i_2__5_n_4 ),
        .Q(counter_reg[3]),
        .R(o_press_reg));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[4] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[4]_i_1__5_n_7 ),
        .Q(counter_reg[4]),
        .R(o_press_reg));
  CARRY4 \counter_reg[4]_i_1__5 
       (.CI(\counter_reg[0]_i_2__5_n_0 ),
        .CO({\counter_reg[4]_i_1__5_n_0 ,\counter_reg[4]_i_1__5_n_1 ,\counter_reg[4]_i_1__5_n_2 ,\counter_reg[4]_i_1__5_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\counter_reg[4]_i_1__5_n_4 ,\counter_reg[4]_i_1__5_n_5 ,\counter_reg[4]_i_1__5_n_6 ,\counter_reg[4]_i_1__5_n_7 }),
        .S(counter_reg[7:4]));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[5] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[4]_i_1__5_n_6 ),
        .Q(counter_reg[5]),
        .R(o_press_reg));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[6] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[4]_i_1__5_n_5 ),
        .Q(counter_reg[6]),
        .R(o_press_reg));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[7] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[4]_i_1__5_n_4 ),
        .Q(counter_reg[7]),
        .R(o_press_reg));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[8] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[8]_i_1__5_n_7 ),
        .Q(counter_reg[8]),
        .R(o_press_reg));
  CARRY4 \counter_reg[8]_i_1__5 
       (.CI(\counter_reg[4]_i_1__5_n_0 ),
        .CO({\counter_reg[8]_i_1__5_n_0 ,\counter_reg[8]_i_1__5_n_1 ,\counter_reg[8]_i_1__5_n_2 ,\counter_reg[8]_i_1__5_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\counter_reg[8]_i_1__5_n_4 ,\counter_reg[8]_i_1__5_n_5 ,\counter_reg[8]_i_1__5_n_6 ,\counter_reg[8]_i_1__5_n_7 }),
        .S(counter_reg[11:8]));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[9] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[8]_i_1__5_n_6 ),
        .Q(counter_reg[9]),
        .R(o_press_reg));
  CARRY4 o_pulse0_carry
       (.CI(1'b0),
        .CO({o_pulse0_carry_n_0,o_pulse0_carry_n_1,o_pulse0_carry_n_2,o_pulse0_carry_n_3}),
        .CYINIT(1'b1),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(NLW_o_pulse0_carry_O_UNCONNECTED[3:0]),
        .S({o_pulse0_carry_i_1__1_n_0,o_pulse0_carry_i_2__1_n_0,o_pulse0_carry_i_3__1_n_0,o_pulse0_carry_i_4__1_n_0}));
  CARRY4 o_pulse0_carry__0
       (.CI(o_pulse0_carry_n_0),
        .CO({o_pulse0_carry__0_n_0,o_pulse0_carry__0_n_1,o_pulse0_carry__0_n_2,o_pulse0_carry__0_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(NLW_o_pulse0_carry__0_O_UNCONNECTED[3:0]),
        .S({o_pulse0_carry__0_i_1__1_n_0,o_pulse0_carry__0_i_2__1_n_0,o_pulse0_carry__0_i_3__1_n_0,o_pulse0_carry__0_i_4__1_n_0}));
  LUT6 #(
    .INIT(64'h9009000000009009)) 
    o_pulse0_carry__0_i_1__1
       (.I0(counter_reg[21]),
        .I1(\maxCountReg_reg[31] [21]),
        .I2(\maxCountReg_reg[31] [23]),
        .I3(counter_reg[23]),
        .I4(\maxCountReg_reg[31] [22]),
        .I5(counter_reg[22]),
        .O(o_pulse0_carry__0_i_1__1_n_0));
  LUT6 #(
    .INIT(64'h9009000000009009)) 
    o_pulse0_carry__0_i_2__1
       (.I0(counter_reg[18]),
        .I1(\maxCountReg_reg[31] [18]),
        .I2(\maxCountReg_reg[31] [20]),
        .I3(counter_reg[20]),
        .I4(\maxCountReg_reg[31] [19]),
        .I5(counter_reg[19]),
        .O(o_pulse0_carry__0_i_2__1_n_0));
  LUT6 #(
    .INIT(64'h9009000000009009)) 
    o_pulse0_carry__0_i_3__1
       (.I0(counter_reg[15]),
        .I1(\maxCountReg_reg[31] [15]),
        .I2(\maxCountReg_reg[31] [17]),
        .I3(counter_reg[17]),
        .I4(\maxCountReg_reg[31] [16]),
        .I5(counter_reg[16]),
        .O(o_pulse0_carry__0_i_3__1_n_0));
  LUT6 #(
    .INIT(64'h9009000000009009)) 
    o_pulse0_carry__0_i_4__1
       (.I0(counter_reg[12]),
        .I1(\maxCountReg_reg[31] [12]),
        .I2(\maxCountReg_reg[31] [14]),
        .I3(counter_reg[14]),
        .I4(\maxCountReg_reg[31] [13]),
        .I5(counter_reg[13]),
        .O(o_pulse0_carry__0_i_4__1_n_0));
  CARRY4 o_pulse0_carry__1
       (.CI(o_pulse0_carry__0_n_0),
        .CO({NLW_o_pulse0_carry__1_CO_UNCONNECTED[3],o_pulse0_carry__1_n_1,o_pulse0_carry__1_n_2,o_pulse0_carry__1_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(NLW_o_pulse0_carry__1_O_UNCONNECTED[3:0]),
        .S({1'b0,o_pulse0_carry__1_i_1__1_n_0,o_pulse0_carry__1_i_2__1_n_0,o_pulse0_carry__1_i_3__1_n_0}));
  LUT4 #(
    .INIT(16'h9009)) 
    o_pulse0_carry__1_i_1__1
       (.I0(counter_reg[30]),
        .I1(\maxCountReg_reg[31] [30]),
        .I2(counter_reg[31]),
        .I3(\maxCountReg_reg[31] [31]),
        .O(o_pulse0_carry__1_i_1__1_n_0));
  LUT6 #(
    .INIT(64'h9009000000009009)) 
    o_pulse0_carry__1_i_2__1
       (.I0(counter_reg[27]),
        .I1(\maxCountReg_reg[31] [27]),
        .I2(\maxCountReg_reg[31] [29]),
        .I3(counter_reg[29]),
        .I4(\maxCountReg_reg[31] [28]),
        .I5(counter_reg[28]),
        .O(o_pulse0_carry__1_i_2__1_n_0));
  LUT6 #(
    .INIT(64'h9009000000009009)) 
    o_pulse0_carry__1_i_3__1
       (.I0(counter_reg[24]),
        .I1(\maxCountReg_reg[31] [24]),
        .I2(\maxCountReg_reg[31] [26]),
        .I3(counter_reg[26]),
        .I4(\maxCountReg_reg[31] [25]),
        .I5(counter_reg[25]),
        .O(o_pulse0_carry__1_i_3__1_n_0));
  LUT6 #(
    .INIT(64'h9009000000009009)) 
    o_pulse0_carry_i_1__1
       (.I0(counter_reg[9]),
        .I1(\maxCountReg_reg[31] [9]),
        .I2(\maxCountReg_reg[31] [11]),
        .I3(counter_reg[11]),
        .I4(\maxCountReg_reg[31] [10]),
        .I5(counter_reg[10]),
        .O(o_pulse0_carry_i_1__1_n_0));
  LUT6 #(
    .INIT(64'h9009000000009009)) 
    o_pulse0_carry_i_2__1
       (.I0(counter_reg[6]),
        .I1(\maxCountReg_reg[31] [6]),
        .I2(\maxCountReg_reg[31] [8]),
        .I3(counter_reg[8]),
        .I4(\maxCountReg_reg[31] [7]),
        .I5(counter_reg[7]),
        .O(o_pulse0_carry_i_2__1_n_0));
  LUT6 #(
    .INIT(64'h9009000000009009)) 
    o_pulse0_carry_i_3__1
       (.I0(counter_reg[3]),
        .I1(\maxCountReg_reg[31] [3]),
        .I2(\maxCountReg_reg[31] [5]),
        .I3(counter_reg[5]),
        .I4(\maxCountReg_reg[31] [4]),
        .I5(counter_reg[4]),
        .O(o_pulse0_carry_i_3__1_n_0));
  LUT6 #(
    .INIT(64'h9009000000009009)) 
    o_pulse0_carry_i_4__1
       (.I0(counter_reg[0]),
        .I1(\maxCountReg_reg[31] [0]),
        .I2(\maxCountReg_reg[31] [2]),
        .I3(counter_reg[2]),
        .I4(\maxCountReg_reg[31] [1]),
        .I5(counter_reg[1]),
        .O(o_pulse0_carry_i_4__1_n_0));
  FDRE o_pulse_reg
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(o_pulse0_carry__1_n_1),
        .Q(\o_y_pos_reg[0] ),
        .R(1'b0));
  LUT2 #(
    .INIT(4'h1)) 
    \o_y_pos[0]_i_3 
       (.I0(\o_y_pos_reg[0] ),
        .I1(Q),
        .O(\o_y_pos[0]_i_3_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \o_y_pos[0]_i_4 
       (.I0(\o_y_pos_reg[0] ),
        .I1(Q),
        .O(\o_y_pos[0]_i_4_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \o_y_pos[0]_i_5 
       (.I0(\o_y_pos_reg[0] ),
        .I1(Q),
        .O(\o_y_pos[0]_i_5_n_0 ));
  LUT4 #(
    .INIT(16'hF909)) 
    \o_y_pos[0]_i_7 
       (.I0(\o_y_pos_reg[0] ),
        .I1(posReg[2]),
        .I2(Q),
        .I3(\maxCoordinateReg_reg[31] [2]),
        .O(\o_y_pos[0]_i_7_n_0 ));
  LUT4 #(
    .INIT(16'hF909)) 
    \o_y_pos[0]_i_8 
       (.I0(\o_y_pos_reg[0] ),
        .I1(posReg[1]),
        .I2(Q),
        .I3(\maxCoordinateReg_reg[31] [1]),
        .O(\o_y_pos[0]_i_8_n_0 ));
  LUT4 #(
    .INIT(16'hF909)) 
    \o_y_pos[0]_i_9 
       (.I0(\o_y_pos_reg[0] ),
        .I1(posReg[0]),
        .I2(Q),
        .I3(\maxCoordinateReg_reg[31] [0]),
        .O(\o_y_pos[0]_i_9_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \o_y_pos[12]_i_2 
       (.I0(\o_y_pos_reg[0] ),
        .I1(Q),
        .O(\o_y_pos[12]_i_2_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \o_y_pos[12]_i_3 
       (.I0(\o_y_pos_reg[0] ),
        .I1(Q),
        .O(\o_y_pos[12]_i_3_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \o_y_pos[12]_i_4 
       (.I0(\o_y_pos_reg[0] ),
        .I1(Q),
        .O(\o_y_pos[12]_i_4_n_0 ));
  LUT3 #(
    .INIT(8'h21)) 
    \o_y_pos[12]_i_5 
       (.I0(\o_y_pos_reg[0] ),
        .I1(Q),
        .I2(posReg[14]),
        .O(\o_y_pos[12]_i_5_n_0 ));
  LUT4 #(
    .INIT(16'hF909)) 
    \o_y_pos[12]_i_6 
       (.I0(\o_y_pos_reg[0] ),
        .I1(posReg[13]),
        .I2(Q),
        .I3(\maxCoordinateReg_reg[31] [13]),
        .O(\o_y_pos[12]_i_6_n_0 ));
  LUT4 #(
    .INIT(16'hF909)) 
    \o_y_pos[12]_i_7 
       (.I0(\o_y_pos_reg[0] ),
        .I1(posReg[12]),
        .I2(Q),
        .I3(\maxCoordinateReg_reg[31] [12]),
        .O(\o_y_pos[12]_i_7_n_0 ));
  LUT4 #(
    .INIT(16'hF909)) 
    \o_y_pos[12]_i_8 
       (.I0(\o_y_pos_reg[0] ),
        .I1(posReg[11]),
        .I2(Q),
        .I3(\maxCoordinateReg_reg[31] [11]),
        .O(\o_y_pos[12]_i_8_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \o_y_pos[4]_i_2 
       (.I0(\o_y_pos_reg[0] ),
        .I1(Q),
        .O(\o_y_pos[4]_i_2_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \o_y_pos[4]_i_3 
       (.I0(\o_y_pos_reg[0] ),
        .I1(Q),
        .O(\o_y_pos[4]_i_3_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \o_y_pos[4]_i_4 
       (.I0(\o_y_pos_reg[0] ),
        .I1(Q),
        .O(\o_y_pos[4]_i_4_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \o_y_pos[4]_i_5 
       (.I0(\o_y_pos_reg[0] ),
        .I1(Q),
        .O(\o_y_pos[4]_i_5_n_0 ));
  LUT4 #(
    .INIT(16'hF909)) 
    \o_y_pos[4]_i_6 
       (.I0(\o_y_pos_reg[0] ),
        .I1(posReg[6]),
        .I2(Q),
        .I3(\maxCoordinateReg_reg[31] [6]),
        .O(\o_y_pos[4]_i_6_n_0 ));
  LUT4 #(
    .INIT(16'hF909)) 
    \o_y_pos[4]_i_7 
       (.I0(\o_y_pos_reg[0] ),
        .I1(posReg[5]),
        .I2(Q),
        .I3(\maxCoordinateReg_reg[31] [5]),
        .O(\o_y_pos[4]_i_7_n_0 ));
  LUT4 #(
    .INIT(16'hF909)) 
    \o_y_pos[4]_i_8 
       (.I0(\o_y_pos_reg[0] ),
        .I1(posReg[4]),
        .I2(Q),
        .I3(\maxCoordinateReg_reg[31] [4]),
        .O(\o_y_pos[4]_i_8_n_0 ));
  LUT4 #(
    .INIT(16'hF909)) 
    \o_y_pos[4]_i_9 
       (.I0(\o_y_pos_reg[0] ),
        .I1(posReg[3]),
        .I2(Q),
        .I3(\maxCoordinateReg_reg[31] [3]),
        .O(\o_y_pos[4]_i_9_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \o_y_pos[8]_i_2 
       (.I0(\o_y_pos_reg[0] ),
        .I1(Q),
        .O(\o_y_pos[8]_i_2_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \o_y_pos[8]_i_3 
       (.I0(\o_y_pos_reg[0] ),
        .I1(Q),
        .O(\o_y_pos[8]_i_3_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \o_y_pos[8]_i_4 
       (.I0(\o_y_pos_reg[0] ),
        .I1(Q),
        .O(\o_y_pos[8]_i_4_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \o_y_pos[8]_i_5 
       (.I0(\o_y_pos_reg[0] ),
        .I1(Q),
        .O(\o_y_pos[8]_i_5_n_0 ));
  LUT4 #(
    .INIT(16'hF909)) 
    \o_y_pos[8]_i_6 
       (.I0(\o_y_pos_reg[0] ),
        .I1(posReg[10]),
        .I2(Q),
        .I3(\maxCoordinateReg_reg[31] [10]),
        .O(\o_y_pos[8]_i_6_n_0 ));
  LUT4 #(
    .INIT(16'hF909)) 
    \o_y_pos[8]_i_7 
       (.I0(\o_y_pos_reg[0] ),
        .I1(posReg[9]),
        .I2(Q),
        .I3(\maxCoordinateReg_reg[31] [9]),
        .O(\o_y_pos[8]_i_7_n_0 ));
  LUT4 #(
    .INIT(16'hF909)) 
    \o_y_pos[8]_i_8 
       (.I0(\o_y_pos_reg[0] ),
        .I1(posReg[8]),
        .I2(Q),
        .I3(\maxCoordinateReg_reg[31] [8]),
        .O(\o_y_pos[8]_i_8_n_0 ));
  LUT4 #(
    .INIT(16'hF909)) 
    \o_y_pos[8]_i_9 
       (.I0(\o_y_pos_reg[0] ),
        .I1(posReg[7]),
        .I2(Q),
        .I3(\maxCoordinateReg_reg[31] [7]),
        .O(\o_y_pos[8]_i_9_n_0 ));
  CARRY4 \o_y_pos_reg[0]_i_2 
       (.CI(1'b0),
        .CO({\o_y_pos_reg[0]_i_2_n_0 ,\o_y_pos_reg[0]_i_2_n_1 ,\o_y_pos_reg[0]_i_2_n_2 ,\o_y_pos_reg[0]_i_2_n_3 }),
        .CYINIT(1'b0),
        .DI({\o_y_pos[0]_i_3_n_0 ,\o_y_pos[0]_i_4_n_0 ,\o_y_pos[0]_i_5_n_0 ,DI}),
        .O(O),
        .S({\o_y_pos[0]_i_7_n_0 ,\o_y_pos[0]_i_8_n_0 ,\o_y_pos[0]_i_9_n_0 ,S}));
  CARRY4 \o_y_pos_reg[12]_i_1 
       (.CI(\o_y_pos_reg[8]_i_1_n_0 ),
        .CO({\NLW_o_y_pos_reg[12]_i_1_CO_UNCONNECTED [3],\o_y_pos_reg[12]_i_1_n_1 ,\o_y_pos_reg[12]_i_1_n_2 ,\o_y_pos_reg[12]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,\o_y_pos[12]_i_2_n_0 ,\o_y_pos[12]_i_3_n_0 ,\o_y_pos[12]_i_4_n_0 }),
        .O(\o_y_pos_reg[15] ),
        .S({\o_y_pos[12]_i_5_n_0 ,\o_y_pos[12]_i_6_n_0 ,\o_y_pos[12]_i_7_n_0 ,\o_y_pos[12]_i_8_n_0 }));
  CARRY4 \o_y_pos_reg[4]_i_1 
       (.CI(\o_y_pos_reg[0]_i_2_n_0 ),
        .CO({\o_y_pos_reg[4]_i_1_n_0 ,\o_y_pos_reg[4]_i_1_n_1 ,\o_y_pos_reg[4]_i_1_n_2 ,\o_y_pos_reg[4]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({\o_y_pos[4]_i_2_n_0 ,\o_y_pos[4]_i_3_n_0 ,\o_y_pos[4]_i_4_n_0 ,\o_y_pos[4]_i_5_n_0 }),
        .O(\o_y_pos_reg[7] ),
        .S({\o_y_pos[4]_i_6_n_0 ,\o_y_pos[4]_i_7_n_0 ,\o_y_pos[4]_i_8_n_0 ,\o_y_pos[4]_i_9_n_0 }));
  CARRY4 \o_y_pos_reg[8]_i_1 
       (.CI(\o_y_pos_reg[4]_i_1_n_0 ),
        .CO({\o_y_pos_reg[8]_i_1_n_0 ,\o_y_pos_reg[8]_i_1_n_1 ,\o_y_pos_reg[8]_i_1_n_2 ,\o_y_pos_reg[8]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({\o_y_pos[8]_i_2_n_0 ,\o_y_pos[8]_i_3_n_0 ,\o_y_pos[8]_i_4_n_0 ,\o_y_pos[8]_i_5_n_0 }),
        .O(\o_y_pos_reg[11] ),
        .S({\o_y_pos[8]_i_6_n_0 ,\o_y_pos[8]_i_7_n_0 ,\o_y_pos[8]_i_8_n_0 ,\o_y_pos[8]_i_9_n_0 }));
endmodule

(* ORIG_REF_NAME = "pulseGen" *) 
module decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_pulseGen_3
   (o_pulse,
    CO,
    s00_axi_aclk,
    \maxCountReg_reg[31] ,
    clear);
  output o_pulse;
  output [0:0]CO;
  input s00_axi_aclk;
  input [31:0]\maxCountReg_reg[31] ;
  input clear;

  wire [0:0]CO;
  wire clear;
  wire counter2_carry__0_i_1__0_n_0;
  wire counter2_carry__0_i_2__0_n_0;
  wire counter2_carry__0_i_3__0_n_0;
  wire counter2_carry__0_i_4__0_n_0;
  wire counter2_carry__0_i_5__0_n_0;
  wire counter2_carry__0_i_6__0_n_0;
  wire counter2_carry__0_i_7__0_n_0;
  wire counter2_carry__0_i_8__0_n_0;
  wire counter2_carry__0_n_0;
  wire counter2_carry__0_n_1;
  wire counter2_carry__0_n_2;
  wire counter2_carry__0_n_3;
  wire counter2_carry__1_i_1__0_n_0;
  wire counter2_carry__1_i_2__0_n_0;
  wire counter2_carry__1_i_3__0_n_0;
  wire counter2_carry__1_i_4__0_n_0;
  wire counter2_carry__1_i_5__0_n_0;
  wire counter2_carry__1_i_6__0_n_0;
  wire counter2_carry__1_i_7__0_n_0;
  wire counter2_carry__1_i_8__0_n_0;
  wire counter2_carry__1_n_0;
  wire counter2_carry__1_n_1;
  wire counter2_carry__1_n_2;
  wire counter2_carry__1_n_3;
  wire counter2_carry__2_i_1__0_n_0;
  wire counter2_carry__2_i_2__0_n_0;
  wire counter2_carry__2_i_3__0_n_0;
  wire counter2_carry__2_i_4__0_n_0;
  wire counter2_carry__2_i_5__0_n_0;
  wire counter2_carry__2_i_6__0_n_0;
  wire counter2_carry__2_i_7__0_n_0;
  wire counter2_carry__2_i_8__0_n_0;
  wire counter2_carry__2_n_1;
  wire counter2_carry__2_n_2;
  wire counter2_carry__2_n_3;
  wire counter2_carry_i_1__0_n_0;
  wire counter2_carry_i_2__0_n_0;
  wire counter2_carry_i_3__0_n_0;
  wire counter2_carry_i_4__0_n_0;
  wire counter2_carry_i_5__0_n_0;
  wire counter2_carry_i_6__0_n_0;
  wire counter2_carry_i_7__0_n_0;
  wire counter2_carry_i_8__0_n_0;
  wire counter2_carry_n_0;
  wire counter2_carry_n_1;
  wire counter2_carry_n_2;
  wire counter2_carry_n_3;
  wire \counter[0]_i_3__7_n_0 ;
  wire [31:0]counter_reg;
  wire \counter_reg[0]_i_2__4_n_0 ;
  wire \counter_reg[0]_i_2__4_n_1 ;
  wire \counter_reg[0]_i_2__4_n_2 ;
  wire \counter_reg[0]_i_2__4_n_3 ;
  wire \counter_reg[0]_i_2__4_n_4 ;
  wire \counter_reg[0]_i_2__4_n_5 ;
  wire \counter_reg[0]_i_2__4_n_6 ;
  wire \counter_reg[0]_i_2__4_n_7 ;
  wire \counter_reg[12]_i_1__4_n_0 ;
  wire \counter_reg[12]_i_1__4_n_1 ;
  wire \counter_reg[12]_i_1__4_n_2 ;
  wire \counter_reg[12]_i_1__4_n_3 ;
  wire \counter_reg[12]_i_1__4_n_4 ;
  wire \counter_reg[12]_i_1__4_n_5 ;
  wire \counter_reg[12]_i_1__4_n_6 ;
  wire \counter_reg[12]_i_1__4_n_7 ;
  wire \counter_reg[16]_i_1__4_n_0 ;
  wire \counter_reg[16]_i_1__4_n_1 ;
  wire \counter_reg[16]_i_1__4_n_2 ;
  wire \counter_reg[16]_i_1__4_n_3 ;
  wire \counter_reg[16]_i_1__4_n_4 ;
  wire \counter_reg[16]_i_1__4_n_5 ;
  wire \counter_reg[16]_i_1__4_n_6 ;
  wire \counter_reg[16]_i_1__4_n_7 ;
  wire \counter_reg[20]_i_1__4_n_0 ;
  wire \counter_reg[20]_i_1__4_n_1 ;
  wire \counter_reg[20]_i_1__4_n_2 ;
  wire \counter_reg[20]_i_1__4_n_3 ;
  wire \counter_reg[20]_i_1__4_n_4 ;
  wire \counter_reg[20]_i_1__4_n_5 ;
  wire \counter_reg[20]_i_1__4_n_6 ;
  wire \counter_reg[20]_i_1__4_n_7 ;
  wire \counter_reg[24]_i_1__4_n_0 ;
  wire \counter_reg[24]_i_1__4_n_1 ;
  wire \counter_reg[24]_i_1__4_n_2 ;
  wire \counter_reg[24]_i_1__4_n_3 ;
  wire \counter_reg[24]_i_1__4_n_4 ;
  wire \counter_reg[24]_i_1__4_n_5 ;
  wire \counter_reg[24]_i_1__4_n_6 ;
  wire \counter_reg[24]_i_1__4_n_7 ;
  wire \counter_reg[28]_i_1__4_n_1 ;
  wire \counter_reg[28]_i_1__4_n_2 ;
  wire \counter_reg[28]_i_1__4_n_3 ;
  wire \counter_reg[28]_i_1__4_n_4 ;
  wire \counter_reg[28]_i_1__4_n_5 ;
  wire \counter_reg[28]_i_1__4_n_6 ;
  wire \counter_reg[28]_i_1__4_n_7 ;
  wire \counter_reg[4]_i_1__4_n_0 ;
  wire \counter_reg[4]_i_1__4_n_1 ;
  wire \counter_reg[4]_i_1__4_n_2 ;
  wire \counter_reg[4]_i_1__4_n_3 ;
  wire \counter_reg[4]_i_1__4_n_4 ;
  wire \counter_reg[4]_i_1__4_n_5 ;
  wire \counter_reg[4]_i_1__4_n_6 ;
  wire \counter_reg[4]_i_1__4_n_7 ;
  wire \counter_reg[8]_i_1__4_n_0 ;
  wire \counter_reg[8]_i_1__4_n_1 ;
  wire \counter_reg[8]_i_1__4_n_2 ;
  wire \counter_reg[8]_i_1__4_n_3 ;
  wire \counter_reg[8]_i_1__4_n_4 ;
  wire \counter_reg[8]_i_1__4_n_5 ;
  wire \counter_reg[8]_i_1__4_n_6 ;
  wire \counter_reg[8]_i_1__4_n_7 ;
  wire [31:0]\maxCountReg_reg[31] ;
  wire o_pulse;
  wire o_pulse0_carry__0_i_1__0_n_0;
  wire o_pulse0_carry__0_i_2__0_n_0;
  wire o_pulse0_carry__0_i_3__0_n_0;
  wire o_pulse0_carry__0_i_4__0_n_0;
  wire o_pulse0_carry__0_n_0;
  wire o_pulse0_carry__0_n_1;
  wire o_pulse0_carry__0_n_2;
  wire o_pulse0_carry__0_n_3;
  wire o_pulse0_carry__1_i_1__0_n_0;
  wire o_pulse0_carry__1_i_2__0_n_0;
  wire o_pulse0_carry__1_i_3__0_n_0;
  wire o_pulse0_carry__1_n_1;
  wire o_pulse0_carry__1_n_2;
  wire o_pulse0_carry__1_n_3;
  wire o_pulse0_carry_i_1__0_n_0;
  wire o_pulse0_carry_i_2__0_n_0;
  wire o_pulse0_carry_i_3__0_n_0;
  wire o_pulse0_carry_i_4__0_n_0;
  wire o_pulse0_carry_n_0;
  wire o_pulse0_carry_n_1;
  wire o_pulse0_carry_n_2;
  wire o_pulse0_carry_n_3;
  wire s00_axi_aclk;
  wire [3:0]NLW_counter2_carry_O_UNCONNECTED;
  wire [3:0]NLW_counter2_carry__0_O_UNCONNECTED;
  wire [3:0]NLW_counter2_carry__1_O_UNCONNECTED;
  wire [3:0]NLW_counter2_carry__2_O_UNCONNECTED;
  wire [3:3]\NLW_counter_reg[28]_i_1__4_CO_UNCONNECTED ;
  wire [3:0]NLW_o_pulse0_carry_O_UNCONNECTED;
  wire [3:0]NLW_o_pulse0_carry__0_O_UNCONNECTED;
  wire [3:3]NLW_o_pulse0_carry__1_CO_UNCONNECTED;
  wire [3:0]NLW_o_pulse0_carry__1_O_UNCONNECTED;

  CARRY4 counter2_carry
       (.CI(1'b0),
        .CO({counter2_carry_n_0,counter2_carry_n_1,counter2_carry_n_2,counter2_carry_n_3}),
        .CYINIT(1'b0),
        .DI({counter2_carry_i_1__0_n_0,counter2_carry_i_2__0_n_0,counter2_carry_i_3__0_n_0,counter2_carry_i_4__0_n_0}),
        .O(NLW_counter2_carry_O_UNCONNECTED[3:0]),
        .S({counter2_carry_i_5__0_n_0,counter2_carry_i_6__0_n_0,counter2_carry_i_7__0_n_0,counter2_carry_i_8__0_n_0}));
  CARRY4 counter2_carry__0
       (.CI(counter2_carry_n_0),
        .CO({counter2_carry__0_n_0,counter2_carry__0_n_1,counter2_carry__0_n_2,counter2_carry__0_n_3}),
        .CYINIT(1'b0),
        .DI({counter2_carry__0_i_1__0_n_0,counter2_carry__0_i_2__0_n_0,counter2_carry__0_i_3__0_n_0,counter2_carry__0_i_4__0_n_0}),
        .O(NLW_counter2_carry__0_O_UNCONNECTED[3:0]),
        .S({counter2_carry__0_i_5__0_n_0,counter2_carry__0_i_6__0_n_0,counter2_carry__0_i_7__0_n_0,counter2_carry__0_i_8__0_n_0}));
  LUT4 #(
    .INIT(16'h2F02)) 
    counter2_carry__0_i_1__0
       (.I0(\maxCountReg_reg[31] [14]),
        .I1(counter_reg[14]),
        .I2(counter_reg[15]),
        .I3(\maxCountReg_reg[31] [15]),
        .O(counter2_carry__0_i_1__0_n_0));
  LUT4 #(
    .INIT(16'h2F02)) 
    counter2_carry__0_i_2__0
       (.I0(\maxCountReg_reg[31] [12]),
        .I1(counter_reg[12]),
        .I2(counter_reg[13]),
        .I3(\maxCountReg_reg[31] [13]),
        .O(counter2_carry__0_i_2__0_n_0));
  LUT4 #(
    .INIT(16'h2F02)) 
    counter2_carry__0_i_3__0
       (.I0(\maxCountReg_reg[31] [10]),
        .I1(counter_reg[10]),
        .I2(counter_reg[11]),
        .I3(\maxCountReg_reg[31] [11]),
        .O(counter2_carry__0_i_3__0_n_0));
  LUT4 #(
    .INIT(16'h2F02)) 
    counter2_carry__0_i_4__0
       (.I0(\maxCountReg_reg[31] [8]),
        .I1(counter_reg[8]),
        .I2(counter_reg[9]),
        .I3(\maxCountReg_reg[31] [9]),
        .O(counter2_carry__0_i_4__0_n_0));
  LUT4 #(
    .INIT(16'h9009)) 
    counter2_carry__0_i_5__0
       (.I0(\maxCountReg_reg[31] [14]),
        .I1(counter_reg[14]),
        .I2(\maxCountReg_reg[31] [15]),
        .I3(counter_reg[15]),
        .O(counter2_carry__0_i_5__0_n_0));
  LUT4 #(
    .INIT(16'h9009)) 
    counter2_carry__0_i_6__0
       (.I0(\maxCountReg_reg[31] [12]),
        .I1(counter_reg[12]),
        .I2(\maxCountReg_reg[31] [13]),
        .I3(counter_reg[13]),
        .O(counter2_carry__0_i_6__0_n_0));
  LUT4 #(
    .INIT(16'h9009)) 
    counter2_carry__0_i_7__0
       (.I0(\maxCountReg_reg[31] [10]),
        .I1(counter_reg[10]),
        .I2(\maxCountReg_reg[31] [11]),
        .I3(counter_reg[11]),
        .O(counter2_carry__0_i_7__0_n_0));
  LUT4 #(
    .INIT(16'h9009)) 
    counter2_carry__0_i_8__0
       (.I0(\maxCountReg_reg[31] [8]),
        .I1(counter_reg[8]),
        .I2(\maxCountReg_reg[31] [9]),
        .I3(counter_reg[9]),
        .O(counter2_carry__0_i_8__0_n_0));
  CARRY4 counter2_carry__1
       (.CI(counter2_carry__0_n_0),
        .CO({counter2_carry__1_n_0,counter2_carry__1_n_1,counter2_carry__1_n_2,counter2_carry__1_n_3}),
        .CYINIT(1'b0),
        .DI({counter2_carry__1_i_1__0_n_0,counter2_carry__1_i_2__0_n_0,counter2_carry__1_i_3__0_n_0,counter2_carry__1_i_4__0_n_0}),
        .O(NLW_counter2_carry__1_O_UNCONNECTED[3:0]),
        .S({counter2_carry__1_i_5__0_n_0,counter2_carry__1_i_6__0_n_0,counter2_carry__1_i_7__0_n_0,counter2_carry__1_i_8__0_n_0}));
  LUT4 #(
    .INIT(16'h2F02)) 
    counter2_carry__1_i_1__0
       (.I0(\maxCountReg_reg[31] [22]),
        .I1(counter_reg[22]),
        .I2(counter_reg[23]),
        .I3(\maxCountReg_reg[31] [23]),
        .O(counter2_carry__1_i_1__0_n_0));
  LUT4 #(
    .INIT(16'h2F02)) 
    counter2_carry__1_i_2__0
       (.I0(\maxCountReg_reg[31] [20]),
        .I1(counter_reg[20]),
        .I2(counter_reg[21]),
        .I3(\maxCountReg_reg[31] [21]),
        .O(counter2_carry__1_i_2__0_n_0));
  LUT4 #(
    .INIT(16'h2F02)) 
    counter2_carry__1_i_3__0
       (.I0(\maxCountReg_reg[31] [18]),
        .I1(counter_reg[18]),
        .I2(counter_reg[19]),
        .I3(\maxCountReg_reg[31] [19]),
        .O(counter2_carry__1_i_3__0_n_0));
  LUT4 #(
    .INIT(16'h2F02)) 
    counter2_carry__1_i_4__0
       (.I0(\maxCountReg_reg[31] [16]),
        .I1(counter_reg[16]),
        .I2(counter_reg[17]),
        .I3(\maxCountReg_reg[31] [17]),
        .O(counter2_carry__1_i_4__0_n_0));
  LUT4 #(
    .INIT(16'h9009)) 
    counter2_carry__1_i_5__0
       (.I0(\maxCountReg_reg[31] [22]),
        .I1(counter_reg[22]),
        .I2(\maxCountReg_reg[31] [23]),
        .I3(counter_reg[23]),
        .O(counter2_carry__1_i_5__0_n_0));
  LUT4 #(
    .INIT(16'h9009)) 
    counter2_carry__1_i_6__0
       (.I0(\maxCountReg_reg[31] [20]),
        .I1(counter_reg[20]),
        .I2(\maxCountReg_reg[31] [21]),
        .I3(counter_reg[21]),
        .O(counter2_carry__1_i_6__0_n_0));
  LUT4 #(
    .INIT(16'h9009)) 
    counter2_carry__1_i_7__0
       (.I0(\maxCountReg_reg[31] [18]),
        .I1(counter_reg[18]),
        .I2(\maxCountReg_reg[31] [19]),
        .I3(counter_reg[19]),
        .O(counter2_carry__1_i_7__0_n_0));
  LUT4 #(
    .INIT(16'h9009)) 
    counter2_carry__1_i_8__0
       (.I0(\maxCountReg_reg[31] [16]),
        .I1(counter_reg[16]),
        .I2(\maxCountReg_reg[31] [17]),
        .I3(counter_reg[17]),
        .O(counter2_carry__1_i_8__0_n_0));
  CARRY4 counter2_carry__2
       (.CI(counter2_carry__1_n_0),
        .CO({CO,counter2_carry__2_n_1,counter2_carry__2_n_2,counter2_carry__2_n_3}),
        .CYINIT(1'b0),
        .DI({counter2_carry__2_i_1__0_n_0,counter2_carry__2_i_2__0_n_0,counter2_carry__2_i_3__0_n_0,counter2_carry__2_i_4__0_n_0}),
        .O(NLW_counter2_carry__2_O_UNCONNECTED[3:0]),
        .S({counter2_carry__2_i_5__0_n_0,counter2_carry__2_i_6__0_n_0,counter2_carry__2_i_7__0_n_0,counter2_carry__2_i_8__0_n_0}));
  LUT4 #(
    .INIT(16'h2F02)) 
    counter2_carry__2_i_1__0
       (.I0(\maxCountReg_reg[31] [30]),
        .I1(counter_reg[30]),
        .I2(counter_reg[31]),
        .I3(\maxCountReg_reg[31] [31]),
        .O(counter2_carry__2_i_1__0_n_0));
  LUT4 #(
    .INIT(16'h2F02)) 
    counter2_carry__2_i_2__0
       (.I0(\maxCountReg_reg[31] [28]),
        .I1(counter_reg[28]),
        .I2(counter_reg[29]),
        .I3(\maxCountReg_reg[31] [29]),
        .O(counter2_carry__2_i_2__0_n_0));
  LUT4 #(
    .INIT(16'h2F02)) 
    counter2_carry__2_i_3__0
       (.I0(\maxCountReg_reg[31] [26]),
        .I1(counter_reg[26]),
        .I2(counter_reg[27]),
        .I3(\maxCountReg_reg[31] [27]),
        .O(counter2_carry__2_i_3__0_n_0));
  LUT4 #(
    .INIT(16'h2F02)) 
    counter2_carry__2_i_4__0
       (.I0(\maxCountReg_reg[31] [24]),
        .I1(counter_reg[24]),
        .I2(counter_reg[25]),
        .I3(\maxCountReg_reg[31] [25]),
        .O(counter2_carry__2_i_4__0_n_0));
  LUT4 #(
    .INIT(16'h9009)) 
    counter2_carry__2_i_5__0
       (.I0(\maxCountReg_reg[31] [30]),
        .I1(counter_reg[30]),
        .I2(\maxCountReg_reg[31] [31]),
        .I3(counter_reg[31]),
        .O(counter2_carry__2_i_5__0_n_0));
  LUT4 #(
    .INIT(16'h9009)) 
    counter2_carry__2_i_6__0
       (.I0(\maxCountReg_reg[31] [28]),
        .I1(counter_reg[28]),
        .I2(\maxCountReg_reg[31] [29]),
        .I3(counter_reg[29]),
        .O(counter2_carry__2_i_6__0_n_0));
  LUT4 #(
    .INIT(16'h9009)) 
    counter2_carry__2_i_7__0
       (.I0(\maxCountReg_reg[31] [26]),
        .I1(counter_reg[26]),
        .I2(\maxCountReg_reg[31] [27]),
        .I3(counter_reg[27]),
        .O(counter2_carry__2_i_7__0_n_0));
  LUT4 #(
    .INIT(16'h9009)) 
    counter2_carry__2_i_8__0
       (.I0(\maxCountReg_reg[31] [24]),
        .I1(counter_reg[24]),
        .I2(\maxCountReg_reg[31] [25]),
        .I3(counter_reg[25]),
        .O(counter2_carry__2_i_8__0_n_0));
  LUT4 #(
    .INIT(16'h2F02)) 
    counter2_carry_i_1__0
       (.I0(\maxCountReg_reg[31] [6]),
        .I1(counter_reg[6]),
        .I2(counter_reg[7]),
        .I3(\maxCountReg_reg[31] [7]),
        .O(counter2_carry_i_1__0_n_0));
  LUT4 #(
    .INIT(16'h2F02)) 
    counter2_carry_i_2__0
       (.I0(\maxCountReg_reg[31] [4]),
        .I1(counter_reg[4]),
        .I2(counter_reg[5]),
        .I3(\maxCountReg_reg[31] [5]),
        .O(counter2_carry_i_2__0_n_0));
  LUT4 #(
    .INIT(16'h2F02)) 
    counter2_carry_i_3__0
       (.I0(\maxCountReg_reg[31] [2]),
        .I1(counter_reg[2]),
        .I2(counter_reg[3]),
        .I3(\maxCountReg_reg[31] [3]),
        .O(counter2_carry_i_3__0_n_0));
  LUT4 #(
    .INIT(16'h2F02)) 
    counter2_carry_i_4__0
       (.I0(\maxCountReg_reg[31] [0]),
        .I1(counter_reg[0]),
        .I2(counter_reg[1]),
        .I3(\maxCountReg_reg[31] [1]),
        .O(counter2_carry_i_4__0_n_0));
  LUT4 #(
    .INIT(16'h9009)) 
    counter2_carry_i_5__0
       (.I0(\maxCountReg_reg[31] [6]),
        .I1(counter_reg[6]),
        .I2(\maxCountReg_reg[31] [7]),
        .I3(counter_reg[7]),
        .O(counter2_carry_i_5__0_n_0));
  LUT4 #(
    .INIT(16'h9009)) 
    counter2_carry_i_6__0
       (.I0(\maxCountReg_reg[31] [4]),
        .I1(counter_reg[4]),
        .I2(\maxCountReg_reg[31] [5]),
        .I3(counter_reg[5]),
        .O(counter2_carry_i_6__0_n_0));
  LUT4 #(
    .INIT(16'h9009)) 
    counter2_carry_i_7__0
       (.I0(\maxCountReg_reg[31] [2]),
        .I1(counter_reg[2]),
        .I2(\maxCountReg_reg[31] [3]),
        .I3(counter_reg[3]),
        .O(counter2_carry_i_7__0_n_0));
  LUT4 #(
    .INIT(16'h9009)) 
    counter2_carry_i_8__0
       (.I0(\maxCountReg_reg[31] [0]),
        .I1(counter_reg[0]),
        .I2(\maxCountReg_reg[31] [1]),
        .I3(counter_reg[1]),
        .O(counter2_carry_i_8__0_n_0));
  LUT1 #(
    .INIT(2'h1)) 
    \counter[0]_i_3__7 
       (.I0(counter_reg[0]),
        .O(\counter[0]_i_3__7_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[0] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[0]_i_2__4_n_7 ),
        .Q(counter_reg[0]),
        .R(clear));
  CARRY4 \counter_reg[0]_i_2__4 
       (.CI(1'b0),
        .CO({\counter_reg[0]_i_2__4_n_0 ,\counter_reg[0]_i_2__4_n_1 ,\counter_reg[0]_i_2__4_n_2 ,\counter_reg[0]_i_2__4_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b1}),
        .O({\counter_reg[0]_i_2__4_n_4 ,\counter_reg[0]_i_2__4_n_5 ,\counter_reg[0]_i_2__4_n_6 ,\counter_reg[0]_i_2__4_n_7 }),
        .S({counter_reg[3:1],\counter[0]_i_3__7_n_0 }));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[10] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[8]_i_1__4_n_5 ),
        .Q(counter_reg[10]),
        .R(clear));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[11] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[8]_i_1__4_n_4 ),
        .Q(counter_reg[11]),
        .R(clear));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[12] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[12]_i_1__4_n_7 ),
        .Q(counter_reg[12]),
        .R(clear));
  CARRY4 \counter_reg[12]_i_1__4 
       (.CI(\counter_reg[8]_i_1__4_n_0 ),
        .CO({\counter_reg[12]_i_1__4_n_0 ,\counter_reg[12]_i_1__4_n_1 ,\counter_reg[12]_i_1__4_n_2 ,\counter_reg[12]_i_1__4_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\counter_reg[12]_i_1__4_n_4 ,\counter_reg[12]_i_1__4_n_5 ,\counter_reg[12]_i_1__4_n_6 ,\counter_reg[12]_i_1__4_n_7 }),
        .S(counter_reg[15:12]));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[13] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[12]_i_1__4_n_6 ),
        .Q(counter_reg[13]),
        .R(clear));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[14] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[12]_i_1__4_n_5 ),
        .Q(counter_reg[14]),
        .R(clear));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[15] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[12]_i_1__4_n_4 ),
        .Q(counter_reg[15]),
        .R(clear));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[16] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[16]_i_1__4_n_7 ),
        .Q(counter_reg[16]),
        .R(clear));
  CARRY4 \counter_reg[16]_i_1__4 
       (.CI(\counter_reg[12]_i_1__4_n_0 ),
        .CO({\counter_reg[16]_i_1__4_n_0 ,\counter_reg[16]_i_1__4_n_1 ,\counter_reg[16]_i_1__4_n_2 ,\counter_reg[16]_i_1__4_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\counter_reg[16]_i_1__4_n_4 ,\counter_reg[16]_i_1__4_n_5 ,\counter_reg[16]_i_1__4_n_6 ,\counter_reg[16]_i_1__4_n_7 }),
        .S(counter_reg[19:16]));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[17] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[16]_i_1__4_n_6 ),
        .Q(counter_reg[17]),
        .R(clear));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[18] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[16]_i_1__4_n_5 ),
        .Q(counter_reg[18]),
        .R(clear));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[19] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[16]_i_1__4_n_4 ),
        .Q(counter_reg[19]),
        .R(clear));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[1] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[0]_i_2__4_n_6 ),
        .Q(counter_reg[1]),
        .R(clear));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[20] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[20]_i_1__4_n_7 ),
        .Q(counter_reg[20]),
        .R(clear));
  CARRY4 \counter_reg[20]_i_1__4 
       (.CI(\counter_reg[16]_i_1__4_n_0 ),
        .CO({\counter_reg[20]_i_1__4_n_0 ,\counter_reg[20]_i_1__4_n_1 ,\counter_reg[20]_i_1__4_n_2 ,\counter_reg[20]_i_1__4_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\counter_reg[20]_i_1__4_n_4 ,\counter_reg[20]_i_1__4_n_5 ,\counter_reg[20]_i_1__4_n_6 ,\counter_reg[20]_i_1__4_n_7 }),
        .S(counter_reg[23:20]));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[21] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[20]_i_1__4_n_6 ),
        .Q(counter_reg[21]),
        .R(clear));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[22] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[20]_i_1__4_n_5 ),
        .Q(counter_reg[22]),
        .R(clear));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[23] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[20]_i_1__4_n_4 ),
        .Q(counter_reg[23]),
        .R(clear));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[24] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[24]_i_1__4_n_7 ),
        .Q(counter_reg[24]),
        .R(clear));
  CARRY4 \counter_reg[24]_i_1__4 
       (.CI(\counter_reg[20]_i_1__4_n_0 ),
        .CO({\counter_reg[24]_i_1__4_n_0 ,\counter_reg[24]_i_1__4_n_1 ,\counter_reg[24]_i_1__4_n_2 ,\counter_reg[24]_i_1__4_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\counter_reg[24]_i_1__4_n_4 ,\counter_reg[24]_i_1__4_n_5 ,\counter_reg[24]_i_1__4_n_6 ,\counter_reg[24]_i_1__4_n_7 }),
        .S(counter_reg[27:24]));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[25] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[24]_i_1__4_n_6 ),
        .Q(counter_reg[25]),
        .R(clear));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[26] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[24]_i_1__4_n_5 ),
        .Q(counter_reg[26]),
        .R(clear));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[27] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[24]_i_1__4_n_4 ),
        .Q(counter_reg[27]),
        .R(clear));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[28] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[28]_i_1__4_n_7 ),
        .Q(counter_reg[28]),
        .R(clear));
  CARRY4 \counter_reg[28]_i_1__4 
       (.CI(\counter_reg[24]_i_1__4_n_0 ),
        .CO({\NLW_counter_reg[28]_i_1__4_CO_UNCONNECTED [3],\counter_reg[28]_i_1__4_n_1 ,\counter_reg[28]_i_1__4_n_2 ,\counter_reg[28]_i_1__4_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\counter_reg[28]_i_1__4_n_4 ,\counter_reg[28]_i_1__4_n_5 ,\counter_reg[28]_i_1__4_n_6 ,\counter_reg[28]_i_1__4_n_7 }),
        .S(counter_reg[31:28]));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[29] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[28]_i_1__4_n_6 ),
        .Q(counter_reg[29]),
        .R(clear));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[2] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[0]_i_2__4_n_5 ),
        .Q(counter_reg[2]),
        .R(clear));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[30] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[28]_i_1__4_n_5 ),
        .Q(counter_reg[30]),
        .R(clear));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[31] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[28]_i_1__4_n_4 ),
        .Q(counter_reg[31]),
        .R(clear));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[3] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[0]_i_2__4_n_4 ),
        .Q(counter_reg[3]),
        .R(clear));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[4] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[4]_i_1__4_n_7 ),
        .Q(counter_reg[4]),
        .R(clear));
  CARRY4 \counter_reg[4]_i_1__4 
       (.CI(\counter_reg[0]_i_2__4_n_0 ),
        .CO({\counter_reg[4]_i_1__4_n_0 ,\counter_reg[4]_i_1__4_n_1 ,\counter_reg[4]_i_1__4_n_2 ,\counter_reg[4]_i_1__4_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\counter_reg[4]_i_1__4_n_4 ,\counter_reg[4]_i_1__4_n_5 ,\counter_reg[4]_i_1__4_n_6 ,\counter_reg[4]_i_1__4_n_7 }),
        .S(counter_reg[7:4]));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[5] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[4]_i_1__4_n_6 ),
        .Q(counter_reg[5]),
        .R(clear));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[6] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[4]_i_1__4_n_5 ),
        .Q(counter_reg[6]),
        .R(clear));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[7] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[4]_i_1__4_n_4 ),
        .Q(counter_reg[7]),
        .R(clear));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[8] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[8]_i_1__4_n_7 ),
        .Q(counter_reg[8]),
        .R(clear));
  CARRY4 \counter_reg[8]_i_1__4 
       (.CI(\counter_reg[4]_i_1__4_n_0 ),
        .CO({\counter_reg[8]_i_1__4_n_0 ,\counter_reg[8]_i_1__4_n_1 ,\counter_reg[8]_i_1__4_n_2 ,\counter_reg[8]_i_1__4_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\counter_reg[8]_i_1__4_n_4 ,\counter_reg[8]_i_1__4_n_5 ,\counter_reg[8]_i_1__4_n_6 ,\counter_reg[8]_i_1__4_n_7 }),
        .S(counter_reg[11:8]));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[9] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[8]_i_1__4_n_6 ),
        .Q(counter_reg[9]),
        .R(clear));
  CARRY4 o_pulse0_carry
       (.CI(1'b0),
        .CO({o_pulse0_carry_n_0,o_pulse0_carry_n_1,o_pulse0_carry_n_2,o_pulse0_carry_n_3}),
        .CYINIT(1'b1),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(NLW_o_pulse0_carry_O_UNCONNECTED[3:0]),
        .S({o_pulse0_carry_i_1__0_n_0,o_pulse0_carry_i_2__0_n_0,o_pulse0_carry_i_3__0_n_0,o_pulse0_carry_i_4__0_n_0}));
  CARRY4 o_pulse0_carry__0
       (.CI(o_pulse0_carry_n_0),
        .CO({o_pulse0_carry__0_n_0,o_pulse0_carry__0_n_1,o_pulse0_carry__0_n_2,o_pulse0_carry__0_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(NLW_o_pulse0_carry__0_O_UNCONNECTED[3:0]),
        .S({o_pulse0_carry__0_i_1__0_n_0,o_pulse0_carry__0_i_2__0_n_0,o_pulse0_carry__0_i_3__0_n_0,o_pulse0_carry__0_i_4__0_n_0}));
  LUT6 #(
    .INIT(64'h9009000000009009)) 
    o_pulse0_carry__0_i_1__0
       (.I0(counter_reg[21]),
        .I1(\maxCountReg_reg[31] [21]),
        .I2(\maxCountReg_reg[31] [23]),
        .I3(counter_reg[23]),
        .I4(\maxCountReg_reg[31] [22]),
        .I5(counter_reg[22]),
        .O(o_pulse0_carry__0_i_1__0_n_0));
  LUT6 #(
    .INIT(64'h9009000000009009)) 
    o_pulse0_carry__0_i_2__0
       (.I0(counter_reg[18]),
        .I1(\maxCountReg_reg[31] [18]),
        .I2(\maxCountReg_reg[31] [20]),
        .I3(counter_reg[20]),
        .I4(\maxCountReg_reg[31] [19]),
        .I5(counter_reg[19]),
        .O(o_pulse0_carry__0_i_2__0_n_0));
  LUT6 #(
    .INIT(64'h9009000000009009)) 
    o_pulse0_carry__0_i_3__0
       (.I0(counter_reg[15]),
        .I1(\maxCountReg_reg[31] [15]),
        .I2(\maxCountReg_reg[31] [17]),
        .I3(counter_reg[17]),
        .I4(\maxCountReg_reg[31] [16]),
        .I5(counter_reg[16]),
        .O(o_pulse0_carry__0_i_3__0_n_0));
  LUT6 #(
    .INIT(64'h9009000000009009)) 
    o_pulse0_carry__0_i_4__0
       (.I0(counter_reg[12]),
        .I1(\maxCountReg_reg[31] [12]),
        .I2(\maxCountReg_reg[31] [14]),
        .I3(counter_reg[14]),
        .I4(\maxCountReg_reg[31] [13]),
        .I5(counter_reg[13]),
        .O(o_pulse0_carry__0_i_4__0_n_0));
  CARRY4 o_pulse0_carry__1
       (.CI(o_pulse0_carry__0_n_0),
        .CO({NLW_o_pulse0_carry__1_CO_UNCONNECTED[3],o_pulse0_carry__1_n_1,o_pulse0_carry__1_n_2,o_pulse0_carry__1_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(NLW_o_pulse0_carry__1_O_UNCONNECTED[3:0]),
        .S({1'b0,o_pulse0_carry__1_i_1__0_n_0,o_pulse0_carry__1_i_2__0_n_0,o_pulse0_carry__1_i_3__0_n_0}));
  LUT4 #(
    .INIT(16'h9009)) 
    o_pulse0_carry__1_i_1__0
       (.I0(counter_reg[30]),
        .I1(\maxCountReg_reg[31] [30]),
        .I2(counter_reg[31]),
        .I3(\maxCountReg_reg[31] [31]),
        .O(o_pulse0_carry__1_i_1__0_n_0));
  LUT6 #(
    .INIT(64'h9009000000009009)) 
    o_pulse0_carry__1_i_2__0
       (.I0(counter_reg[27]),
        .I1(\maxCountReg_reg[31] [27]),
        .I2(\maxCountReg_reg[31] [29]),
        .I3(counter_reg[29]),
        .I4(\maxCountReg_reg[31] [28]),
        .I5(counter_reg[28]),
        .O(o_pulse0_carry__1_i_2__0_n_0));
  LUT6 #(
    .INIT(64'h9009000000009009)) 
    o_pulse0_carry__1_i_3__0
       (.I0(counter_reg[24]),
        .I1(\maxCountReg_reg[31] [24]),
        .I2(\maxCountReg_reg[31] [26]),
        .I3(counter_reg[26]),
        .I4(\maxCountReg_reg[31] [25]),
        .I5(counter_reg[25]),
        .O(o_pulse0_carry__1_i_3__0_n_0));
  LUT6 #(
    .INIT(64'h9009000000009009)) 
    o_pulse0_carry_i_1__0
       (.I0(counter_reg[9]),
        .I1(\maxCountReg_reg[31] [9]),
        .I2(\maxCountReg_reg[31] [11]),
        .I3(counter_reg[11]),
        .I4(\maxCountReg_reg[31] [10]),
        .I5(counter_reg[10]),
        .O(o_pulse0_carry_i_1__0_n_0));
  LUT6 #(
    .INIT(64'h9009000000009009)) 
    o_pulse0_carry_i_2__0
       (.I0(counter_reg[6]),
        .I1(\maxCountReg_reg[31] [6]),
        .I2(\maxCountReg_reg[31] [8]),
        .I3(counter_reg[8]),
        .I4(\maxCountReg_reg[31] [7]),
        .I5(counter_reg[7]),
        .O(o_pulse0_carry_i_2__0_n_0));
  LUT6 #(
    .INIT(64'h9009000000009009)) 
    o_pulse0_carry_i_3__0
       (.I0(counter_reg[3]),
        .I1(\maxCountReg_reg[31] [3]),
        .I2(\maxCountReg_reg[31] [5]),
        .I3(counter_reg[5]),
        .I4(\maxCountReg_reg[31] [4]),
        .I5(counter_reg[4]),
        .O(o_pulse0_carry_i_3__0_n_0));
  LUT6 #(
    .INIT(64'h9009000000009009)) 
    o_pulse0_carry_i_4__0
       (.I0(counter_reg[0]),
        .I1(\maxCountReg_reg[31] [0]),
        .I2(\maxCountReg_reg[31] [2]),
        .I3(counter_reg[2]),
        .I4(\maxCountReg_reg[31] [1]),
        .I5(counter_reg[1]),
        .O(o_pulse0_carry_i_4__0_n_0));
  FDRE o_pulse_reg
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(o_pulse0_carry__1_n_1),
        .Q(o_pulse),
        .R(1'b0));
endmodule

(* ORIG_REF_NAME = "pulseGen" *) 
module decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_pulseGen_4
   (CO,
    o_intr1_out,
    sel,
    O,
    \o_x_pos_reg[7] ,
    \o_x_pos_reg[11] ,
    \o_x_pos_reg[15] ,
    s00_axi_aclk,
    Q,
    o_pulse_reg_0,
    p_1_in,
    o_pulse_reg_1,
    \maxCoordinateReg_reg[30] ,
    \maxCountReg_reg[31] ,
    posReg,
    \maxCoordinateReg_reg[14] ,
    o_pulse,
    \o_x_pos_reg[12] ,
    \o_x_pos_reg[4] ,
    DI,
    S,
    \maxCoordinateReg_reg[15] ,
    o_press_reg);
  output [0:0]CO;
  output o_intr1_out;
  output sel;
  output [3:0]O;
  output [3:0]\o_x_pos_reg[7] ;
  output [3:0]\o_x_pos_reg[11] ;
  output [3:0]\o_x_pos_reg[15] ;
  input s00_axi_aclk;
  input [0:0]Q;
  input o_pulse_reg_0;
  input p_1_in;
  input o_pulse_reg_1;
  input [0:0]\maxCoordinateReg_reg[30] ;
  input [31:0]\maxCountReg_reg[31] ;
  input [14:0]posReg;
  input [0:0]\maxCoordinateReg_reg[14] ;
  input o_pulse;
  input \o_x_pos_reg[12] ;
  input \o_x_pos_reg[4] ;
  input [0:0]DI;
  input [0:0]S;
  input [13:0]\maxCoordinateReg_reg[15] ;
  input o_press_reg;

  wire [0:0]CO;
  wire [0:0]DI;
  wire [3:0]O;
  wire [0:0]Q;
  wire [0:0]S;
  wire counter2_carry__0_i_1_n_0;
  wire counter2_carry__0_i_2_n_0;
  wire counter2_carry__0_i_3_n_0;
  wire counter2_carry__0_i_4_n_0;
  wire counter2_carry__0_i_5_n_0;
  wire counter2_carry__0_i_6_n_0;
  wire counter2_carry__0_i_7_n_0;
  wire counter2_carry__0_i_8_n_0;
  wire counter2_carry__0_n_0;
  wire counter2_carry__0_n_1;
  wire counter2_carry__0_n_2;
  wire counter2_carry__0_n_3;
  wire counter2_carry__1_i_1_n_0;
  wire counter2_carry__1_i_2_n_0;
  wire counter2_carry__1_i_3_n_0;
  wire counter2_carry__1_i_4_n_0;
  wire counter2_carry__1_i_5_n_0;
  wire counter2_carry__1_i_6_n_0;
  wire counter2_carry__1_i_7_n_0;
  wire counter2_carry__1_i_8_n_0;
  wire counter2_carry__1_n_0;
  wire counter2_carry__1_n_1;
  wire counter2_carry__1_n_2;
  wire counter2_carry__1_n_3;
  wire counter2_carry__2_i_1_n_0;
  wire counter2_carry__2_i_2_n_0;
  wire counter2_carry__2_i_3_n_0;
  wire counter2_carry__2_i_4_n_0;
  wire counter2_carry__2_i_5_n_0;
  wire counter2_carry__2_i_6_n_0;
  wire counter2_carry__2_i_7_n_0;
  wire counter2_carry__2_i_8_n_0;
  wire counter2_carry__2_n_1;
  wire counter2_carry__2_n_2;
  wire counter2_carry__2_n_3;
  wire counter2_carry_i_1_n_0;
  wire counter2_carry_i_2_n_0;
  wire counter2_carry_i_3_n_0;
  wire counter2_carry_i_4_n_0;
  wire counter2_carry_i_5_n_0;
  wire counter2_carry_i_6_n_0;
  wire counter2_carry_i_7_n_0;
  wire counter2_carry_i_8_n_0;
  wire counter2_carry_n_0;
  wire counter2_carry_n_1;
  wire counter2_carry_n_2;
  wire counter2_carry_n_3;
  wire \counter[0]_i_3__6_n_0 ;
  wire [31:0]counter_reg;
  wire \counter_reg[0]_i_2__3_n_0 ;
  wire \counter_reg[0]_i_2__3_n_1 ;
  wire \counter_reg[0]_i_2__3_n_2 ;
  wire \counter_reg[0]_i_2__3_n_3 ;
  wire \counter_reg[0]_i_2__3_n_4 ;
  wire \counter_reg[0]_i_2__3_n_5 ;
  wire \counter_reg[0]_i_2__3_n_6 ;
  wire \counter_reg[0]_i_2__3_n_7 ;
  wire \counter_reg[12]_i_1__3_n_0 ;
  wire \counter_reg[12]_i_1__3_n_1 ;
  wire \counter_reg[12]_i_1__3_n_2 ;
  wire \counter_reg[12]_i_1__3_n_3 ;
  wire \counter_reg[12]_i_1__3_n_4 ;
  wire \counter_reg[12]_i_1__3_n_5 ;
  wire \counter_reg[12]_i_1__3_n_6 ;
  wire \counter_reg[12]_i_1__3_n_7 ;
  wire \counter_reg[16]_i_1__3_n_0 ;
  wire \counter_reg[16]_i_1__3_n_1 ;
  wire \counter_reg[16]_i_1__3_n_2 ;
  wire \counter_reg[16]_i_1__3_n_3 ;
  wire \counter_reg[16]_i_1__3_n_4 ;
  wire \counter_reg[16]_i_1__3_n_5 ;
  wire \counter_reg[16]_i_1__3_n_6 ;
  wire \counter_reg[16]_i_1__3_n_7 ;
  wire \counter_reg[20]_i_1__3_n_0 ;
  wire \counter_reg[20]_i_1__3_n_1 ;
  wire \counter_reg[20]_i_1__3_n_2 ;
  wire \counter_reg[20]_i_1__3_n_3 ;
  wire \counter_reg[20]_i_1__3_n_4 ;
  wire \counter_reg[20]_i_1__3_n_5 ;
  wire \counter_reg[20]_i_1__3_n_6 ;
  wire \counter_reg[20]_i_1__3_n_7 ;
  wire \counter_reg[24]_i_1__3_n_0 ;
  wire \counter_reg[24]_i_1__3_n_1 ;
  wire \counter_reg[24]_i_1__3_n_2 ;
  wire \counter_reg[24]_i_1__3_n_3 ;
  wire \counter_reg[24]_i_1__3_n_4 ;
  wire \counter_reg[24]_i_1__3_n_5 ;
  wire \counter_reg[24]_i_1__3_n_6 ;
  wire \counter_reg[24]_i_1__3_n_7 ;
  wire \counter_reg[28]_i_1__3_n_1 ;
  wire \counter_reg[28]_i_1__3_n_2 ;
  wire \counter_reg[28]_i_1__3_n_3 ;
  wire \counter_reg[28]_i_1__3_n_4 ;
  wire \counter_reg[28]_i_1__3_n_5 ;
  wire \counter_reg[28]_i_1__3_n_6 ;
  wire \counter_reg[28]_i_1__3_n_7 ;
  wire \counter_reg[4]_i_1__3_n_0 ;
  wire \counter_reg[4]_i_1__3_n_1 ;
  wire \counter_reg[4]_i_1__3_n_2 ;
  wire \counter_reg[4]_i_1__3_n_3 ;
  wire \counter_reg[4]_i_1__3_n_4 ;
  wire \counter_reg[4]_i_1__3_n_5 ;
  wire \counter_reg[4]_i_1__3_n_6 ;
  wire \counter_reg[4]_i_1__3_n_7 ;
  wire \counter_reg[8]_i_1__3_n_0 ;
  wire \counter_reg[8]_i_1__3_n_1 ;
  wire \counter_reg[8]_i_1__3_n_2 ;
  wire \counter_reg[8]_i_1__3_n_3 ;
  wire \counter_reg[8]_i_1__3_n_4 ;
  wire \counter_reg[8]_i_1__3_n_5 ;
  wire \counter_reg[8]_i_1__3_n_6 ;
  wire \counter_reg[8]_i_1__3_n_7 ;
  wire [0:0]\maxCoordinateReg_reg[14] ;
  wire [13:0]\maxCoordinateReg_reg[15] ;
  wire [0:0]\maxCoordinateReg_reg[30] ;
  wire [31:0]\maxCountReg_reg[31] ;
  wire o_intr1_out;
  wire o_intr_i_2_n_0;
  wire o_press_reg;
  wire o_pulse;
  wire o_pulse0_carry__0_i_1_n_0;
  wire o_pulse0_carry__0_i_2_n_0;
  wire o_pulse0_carry__0_i_3_n_0;
  wire o_pulse0_carry__0_i_4_n_0;
  wire o_pulse0_carry__0_n_0;
  wire o_pulse0_carry__0_n_1;
  wire o_pulse0_carry__0_n_2;
  wire o_pulse0_carry__0_n_3;
  wire o_pulse0_carry__1_i_1_n_0;
  wire o_pulse0_carry__1_i_2_n_0;
  wire o_pulse0_carry__1_i_3_n_0;
  wire o_pulse0_carry__1_n_1;
  wire o_pulse0_carry__1_n_2;
  wire o_pulse0_carry__1_n_3;
  wire o_pulse0_carry_i_1_n_0;
  wire o_pulse0_carry_i_2_n_0;
  wire o_pulse0_carry_i_3_n_0;
  wire o_pulse0_carry_i_4_n_0;
  wire o_pulse0_carry_n_0;
  wire o_pulse0_carry_n_1;
  wire o_pulse0_carry_n_2;
  wire o_pulse0_carry_n_3;
  wire o_pulse_reg_0;
  wire o_pulse_reg_1;
  wire o_pulse_reg_n_0;
  wire \o_x_pos[0]_i_3_n_0 ;
  wire \o_x_pos[0]_i_4_n_0 ;
  wire \o_x_pos[0]_i_5_n_0 ;
  wire \o_x_pos[0]_i_7_n_0 ;
  wire \o_x_pos[0]_i_8_n_0 ;
  wire \o_x_pos[0]_i_9_n_0 ;
  wire \o_x_pos[12]_i_2_n_0 ;
  wire \o_x_pos[12]_i_3_n_0 ;
  wire \o_x_pos[12]_i_4_n_0 ;
  wire \o_x_pos[12]_i_5_n_0 ;
  wire \o_x_pos[12]_i_6_n_0 ;
  wire \o_x_pos[12]_i_7_n_0 ;
  wire \o_x_pos[12]_i_8_n_0 ;
  wire \o_x_pos[4]_i_2_n_0 ;
  wire \o_x_pos[4]_i_3_n_0 ;
  wire \o_x_pos[4]_i_4_n_0 ;
  wire \o_x_pos[4]_i_5_n_0 ;
  wire \o_x_pos[4]_i_6_n_0 ;
  wire \o_x_pos[4]_i_7_n_0 ;
  wire \o_x_pos[4]_i_8_n_0 ;
  wire \o_x_pos[4]_i_9_n_0 ;
  wire \o_x_pos[8]_i_2_n_0 ;
  wire \o_x_pos[8]_i_3_n_0 ;
  wire \o_x_pos[8]_i_4_n_0 ;
  wire \o_x_pos[8]_i_5_n_0 ;
  wire \o_x_pos[8]_i_6_n_0 ;
  wire \o_x_pos[8]_i_7_n_0 ;
  wire \o_x_pos[8]_i_8_n_0 ;
  wire \o_x_pos[8]_i_9_n_0 ;
  wire \o_x_pos_reg[0]_i_2_n_0 ;
  wire \o_x_pos_reg[0]_i_2_n_1 ;
  wire \o_x_pos_reg[0]_i_2_n_2 ;
  wire \o_x_pos_reg[0]_i_2_n_3 ;
  wire [3:0]\o_x_pos_reg[11] ;
  wire \o_x_pos_reg[12] ;
  wire \o_x_pos_reg[12]_i_1_n_1 ;
  wire \o_x_pos_reg[12]_i_1_n_2 ;
  wire \o_x_pos_reg[12]_i_1_n_3 ;
  wire [3:0]\o_x_pos_reg[15] ;
  wire \o_x_pos_reg[4] ;
  wire \o_x_pos_reg[4]_i_1_n_0 ;
  wire \o_x_pos_reg[4]_i_1_n_1 ;
  wire \o_x_pos_reg[4]_i_1_n_2 ;
  wire \o_x_pos_reg[4]_i_1_n_3 ;
  wire [3:0]\o_x_pos_reg[7] ;
  wire \o_x_pos_reg[8]_i_1_n_0 ;
  wire \o_x_pos_reg[8]_i_1_n_1 ;
  wire \o_x_pos_reg[8]_i_1_n_2 ;
  wire \o_x_pos_reg[8]_i_1_n_3 ;
  wire p_1_in;
  wire [14:0]posReg;
  wire s00_axi_aclk;
  wire sel;
  wire [3:0]NLW_counter2_carry_O_UNCONNECTED;
  wire [3:0]NLW_counter2_carry__0_O_UNCONNECTED;
  wire [3:0]NLW_counter2_carry__1_O_UNCONNECTED;
  wire [3:0]NLW_counter2_carry__2_O_UNCONNECTED;
  wire [3:3]\NLW_counter_reg[28]_i_1__3_CO_UNCONNECTED ;
  wire [3:0]NLW_o_pulse0_carry_O_UNCONNECTED;
  wire [3:0]NLW_o_pulse0_carry__0_O_UNCONNECTED;
  wire [3:3]NLW_o_pulse0_carry__1_CO_UNCONNECTED;
  wire [3:0]NLW_o_pulse0_carry__1_O_UNCONNECTED;
  wire [3:3]\NLW_o_x_pos_reg[12]_i_1_CO_UNCONNECTED ;

  CARRY4 counter2_carry
       (.CI(1'b0),
        .CO({counter2_carry_n_0,counter2_carry_n_1,counter2_carry_n_2,counter2_carry_n_3}),
        .CYINIT(1'b0),
        .DI({counter2_carry_i_1_n_0,counter2_carry_i_2_n_0,counter2_carry_i_3_n_0,counter2_carry_i_4_n_0}),
        .O(NLW_counter2_carry_O_UNCONNECTED[3:0]),
        .S({counter2_carry_i_5_n_0,counter2_carry_i_6_n_0,counter2_carry_i_7_n_0,counter2_carry_i_8_n_0}));
  CARRY4 counter2_carry__0
       (.CI(counter2_carry_n_0),
        .CO({counter2_carry__0_n_0,counter2_carry__0_n_1,counter2_carry__0_n_2,counter2_carry__0_n_3}),
        .CYINIT(1'b0),
        .DI({counter2_carry__0_i_1_n_0,counter2_carry__0_i_2_n_0,counter2_carry__0_i_3_n_0,counter2_carry__0_i_4_n_0}),
        .O(NLW_counter2_carry__0_O_UNCONNECTED[3:0]),
        .S({counter2_carry__0_i_5_n_0,counter2_carry__0_i_6_n_0,counter2_carry__0_i_7_n_0,counter2_carry__0_i_8_n_0}));
  LUT4 #(
    .INIT(16'h2F02)) 
    counter2_carry__0_i_1
       (.I0(\maxCountReg_reg[31] [14]),
        .I1(counter_reg[14]),
        .I2(counter_reg[15]),
        .I3(\maxCountReg_reg[31] [15]),
        .O(counter2_carry__0_i_1_n_0));
  LUT4 #(
    .INIT(16'h2F02)) 
    counter2_carry__0_i_2
       (.I0(\maxCountReg_reg[31] [12]),
        .I1(counter_reg[12]),
        .I2(counter_reg[13]),
        .I3(\maxCountReg_reg[31] [13]),
        .O(counter2_carry__0_i_2_n_0));
  LUT4 #(
    .INIT(16'h2F02)) 
    counter2_carry__0_i_3
       (.I0(\maxCountReg_reg[31] [10]),
        .I1(counter_reg[10]),
        .I2(counter_reg[11]),
        .I3(\maxCountReg_reg[31] [11]),
        .O(counter2_carry__0_i_3_n_0));
  LUT4 #(
    .INIT(16'h2F02)) 
    counter2_carry__0_i_4
       (.I0(\maxCountReg_reg[31] [8]),
        .I1(counter_reg[8]),
        .I2(counter_reg[9]),
        .I3(\maxCountReg_reg[31] [9]),
        .O(counter2_carry__0_i_4_n_0));
  LUT4 #(
    .INIT(16'h9009)) 
    counter2_carry__0_i_5
       (.I0(\maxCountReg_reg[31] [14]),
        .I1(counter_reg[14]),
        .I2(\maxCountReg_reg[31] [15]),
        .I3(counter_reg[15]),
        .O(counter2_carry__0_i_5_n_0));
  LUT4 #(
    .INIT(16'h9009)) 
    counter2_carry__0_i_6
       (.I0(\maxCountReg_reg[31] [12]),
        .I1(counter_reg[12]),
        .I2(\maxCountReg_reg[31] [13]),
        .I3(counter_reg[13]),
        .O(counter2_carry__0_i_6_n_0));
  LUT4 #(
    .INIT(16'h9009)) 
    counter2_carry__0_i_7
       (.I0(\maxCountReg_reg[31] [10]),
        .I1(counter_reg[10]),
        .I2(\maxCountReg_reg[31] [11]),
        .I3(counter_reg[11]),
        .O(counter2_carry__0_i_7_n_0));
  LUT4 #(
    .INIT(16'h9009)) 
    counter2_carry__0_i_8
       (.I0(\maxCountReg_reg[31] [8]),
        .I1(counter_reg[8]),
        .I2(\maxCountReg_reg[31] [9]),
        .I3(counter_reg[9]),
        .O(counter2_carry__0_i_8_n_0));
  CARRY4 counter2_carry__1
       (.CI(counter2_carry__0_n_0),
        .CO({counter2_carry__1_n_0,counter2_carry__1_n_1,counter2_carry__1_n_2,counter2_carry__1_n_3}),
        .CYINIT(1'b0),
        .DI({counter2_carry__1_i_1_n_0,counter2_carry__1_i_2_n_0,counter2_carry__1_i_3_n_0,counter2_carry__1_i_4_n_0}),
        .O(NLW_counter2_carry__1_O_UNCONNECTED[3:0]),
        .S({counter2_carry__1_i_5_n_0,counter2_carry__1_i_6_n_0,counter2_carry__1_i_7_n_0,counter2_carry__1_i_8_n_0}));
  LUT4 #(
    .INIT(16'h2F02)) 
    counter2_carry__1_i_1
       (.I0(\maxCountReg_reg[31] [22]),
        .I1(counter_reg[22]),
        .I2(counter_reg[23]),
        .I3(\maxCountReg_reg[31] [23]),
        .O(counter2_carry__1_i_1_n_0));
  LUT4 #(
    .INIT(16'h2F02)) 
    counter2_carry__1_i_2
       (.I0(\maxCountReg_reg[31] [20]),
        .I1(counter_reg[20]),
        .I2(counter_reg[21]),
        .I3(\maxCountReg_reg[31] [21]),
        .O(counter2_carry__1_i_2_n_0));
  LUT4 #(
    .INIT(16'h2F02)) 
    counter2_carry__1_i_3
       (.I0(\maxCountReg_reg[31] [18]),
        .I1(counter_reg[18]),
        .I2(counter_reg[19]),
        .I3(\maxCountReg_reg[31] [19]),
        .O(counter2_carry__1_i_3_n_0));
  LUT4 #(
    .INIT(16'h2F02)) 
    counter2_carry__1_i_4
       (.I0(\maxCountReg_reg[31] [16]),
        .I1(counter_reg[16]),
        .I2(counter_reg[17]),
        .I3(\maxCountReg_reg[31] [17]),
        .O(counter2_carry__1_i_4_n_0));
  LUT4 #(
    .INIT(16'h9009)) 
    counter2_carry__1_i_5
       (.I0(\maxCountReg_reg[31] [22]),
        .I1(counter_reg[22]),
        .I2(\maxCountReg_reg[31] [23]),
        .I3(counter_reg[23]),
        .O(counter2_carry__1_i_5_n_0));
  LUT4 #(
    .INIT(16'h9009)) 
    counter2_carry__1_i_6
       (.I0(\maxCountReg_reg[31] [20]),
        .I1(counter_reg[20]),
        .I2(\maxCountReg_reg[31] [21]),
        .I3(counter_reg[21]),
        .O(counter2_carry__1_i_6_n_0));
  LUT4 #(
    .INIT(16'h9009)) 
    counter2_carry__1_i_7
       (.I0(\maxCountReg_reg[31] [18]),
        .I1(counter_reg[18]),
        .I2(\maxCountReg_reg[31] [19]),
        .I3(counter_reg[19]),
        .O(counter2_carry__1_i_7_n_0));
  LUT4 #(
    .INIT(16'h9009)) 
    counter2_carry__1_i_8
       (.I0(\maxCountReg_reg[31] [16]),
        .I1(counter_reg[16]),
        .I2(\maxCountReg_reg[31] [17]),
        .I3(counter_reg[17]),
        .O(counter2_carry__1_i_8_n_0));
  CARRY4 counter2_carry__2
       (.CI(counter2_carry__1_n_0),
        .CO({CO,counter2_carry__2_n_1,counter2_carry__2_n_2,counter2_carry__2_n_3}),
        .CYINIT(1'b0),
        .DI({counter2_carry__2_i_1_n_0,counter2_carry__2_i_2_n_0,counter2_carry__2_i_3_n_0,counter2_carry__2_i_4_n_0}),
        .O(NLW_counter2_carry__2_O_UNCONNECTED[3:0]),
        .S({counter2_carry__2_i_5_n_0,counter2_carry__2_i_6_n_0,counter2_carry__2_i_7_n_0,counter2_carry__2_i_8_n_0}));
  LUT4 #(
    .INIT(16'h2F02)) 
    counter2_carry__2_i_1
       (.I0(\maxCountReg_reg[31] [30]),
        .I1(counter_reg[30]),
        .I2(counter_reg[31]),
        .I3(\maxCountReg_reg[31] [31]),
        .O(counter2_carry__2_i_1_n_0));
  LUT4 #(
    .INIT(16'h2F02)) 
    counter2_carry__2_i_2
       (.I0(\maxCountReg_reg[31] [28]),
        .I1(counter_reg[28]),
        .I2(counter_reg[29]),
        .I3(\maxCountReg_reg[31] [29]),
        .O(counter2_carry__2_i_2_n_0));
  LUT4 #(
    .INIT(16'h2F02)) 
    counter2_carry__2_i_3
       (.I0(\maxCountReg_reg[31] [26]),
        .I1(counter_reg[26]),
        .I2(counter_reg[27]),
        .I3(\maxCountReg_reg[31] [27]),
        .O(counter2_carry__2_i_3_n_0));
  LUT4 #(
    .INIT(16'h2F02)) 
    counter2_carry__2_i_4
       (.I0(\maxCountReg_reg[31] [24]),
        .I1(counter_reg[24]),
        .I2(counter_reg[25]),
        .I3(\maxCountReg_reg[31] [25]),
        .O(counter2_carry__2_i_4_n_0));
  LUT4 #(
    .INIT(16'h9009)) 
    counter2_carry__2_i_5
       (.I0(\maxCountReg_reg[31] [30]),
        .I1(counter_reg[30]),
        .I2(\maxCountReg_reg[31] [31]),
        .I3(counter_reg[31]),
        .O(counter2_carry__2_i_5_n_0));
  LUT4 #(
    .INIT(16'h9009)) 
    counter2_carry__2_i_6
       (.I0(\maxCountReg_reg[31] [28]),
        .I1(counter_reg[28]),
        .I2(\maxCountReg_reg[31] [29]),
        .I3(counter_reg[29]),
        .O(counter2_carry__2_i_6_n_0));
  LUT4 #(
    .INIT(16'h9009)) 
    counter2_carry__2_i_7
       (.I0(\maxCountReg_reg[31] [26]),
        .I1(counter_reg[26]),
        .I2(\maxCountReg_reg[31] [27]),
        .I3(counter_reg[27]),
        .O(counter2_carry__2_i_7_n_0));
  LUT4 #(
    .INIT(16'h9009)) 
    counter2_carry__2_i_8
       (.I0(\maxCountReg_reg[31] [24]),
        .I1(counter_reg[24]),
        .I2(\maxCountReg_reg[31] [25]),
        .I3(counter_reg[25]),
        .O(counter2_carry__2_i_8_n_0));
  LUT4 #(
    .INIT(16'h2F02)) 
    counter2_carry_i_1
       (.I0(\maxCountReg_reg[31] [6]),
        .I1(counter_reg[6]),
        .I2(counter_reg[7]),
        .I3(\maxCountReg_reg[31] [7]),
        .O(counter2_carry_i_1_n_0));
  LUT4 #(
    .INIT(16'h2F02)) 
    counter2_carry_i_2
       (.I0(\maxCountReg_reg[31] [4]),
        .I1(counter_reg[4]),
        .I2(counter_reg[5]),
        .I3(\maxCountReg_reg[31] [5]),
        .O(counter2_carry_i_2_n_0));
  LUT4 #(
    .INIT(16'h2F02)) 
    counter2_carry_i_3
       (.I0(\maxCountReg_reg[31] [2]),
        .I1(counter_reg[2]),
        .I2(counter_reg[3]),
        .I3(\maxCountReg_reg[31] [3]),
        .O(counter2_carry_i_3_n_0));
  LUT4 #(
    .INIT(16'h2F02)) 
    counter2_carry_i_4
       (.I0(\maxCountReg_reg[31] [0]),
        .I1(counter_reg[0]),
        .I2(counter_reg[1]),
        .I3(\maxCountReg_reg[31] [1]),
        .O(counter2_carry_i_4_n_0));
  LUT4 #(
    .INIT(16'h9009)) 
    counter2_carry_i_5
       (.I0(\maxCountReg_reg[31] [6]),
        .I1(counter_reg[6]),
        .I2(\maxCountReg_reg[31] [7]),
        .I3(counter_reg[7]),
        .O(counter2_carry_i_5_n_0));
  LUT4 #(
    .INIT(16'h9009)) 
    counter2_carry_i_6
       (.I0(\maxCountReg_reg[31] [4]),
        .I1(counter_reg[4]),
        .I2(\maxCountReg_reg[31] [5]),
        .I3(counter_reg[5]),
        .O(counter2_carry_i_6_n_0));
  LUT4 #(
    .INIT(16'h9009)) 
    counter2_carry_i_7
       (.I0(\maxCountReg_reg[31] [2]),
        .I1(counter_reg[2]),
        .I2(\maxCountReg_reg[31] [3]),
        .I3(counter_reg[3]),
        .O(counter2_carry_i_7_n_0));
  LUT4 #(
    .INIT(16'h9009)) 
    counter2_carry_i_8
       (.I0(\maxCountReg_reg[31] [0]),
        .I1(counter_reg[0]),
        .I2(\maxCountReg_reg[31] [1]),
        .I3(counter_reg[1]),
        .O(counter2_carry_i_8_n_0));
  LUT1 #(
    .INIT(2'h1)) 
    \counter[0]_i_3__6 
       (.I0(counter_reg[0]),
        .O(\counter[0]_i_3__6_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[0] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[0]_i_2__3_n_7 ),
        .Q(counter_reg[0]),
        .R(o_press_reg));
  CARRY4 \counter_reg[0]_i_2__3 
       (.CI(1'b0),
        .CO({\counter_reg[0]_i_2__3_n_0 ,\counter_reg[0]_i_2__3_n_1 ,\counter_reg[0]_i_2__3_n_2 ,\counter_reg[0]_i_2__3_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b1}),
        .O({\counter_reg[0]_i_2__3_n_4 ,\counter_reg[0]_i_2__3_n_5 ,\counter_reg[0]_i_2__3_n_6 ,\counter_reg[0]_i_2__3_n_7 }),
        .S({counter_reg[3:1],\counter[0]_i_3__6_n_0 }));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[10] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[8]_i_1__3_n_5 ),
        .Q(counter_reg[10]),
        .R(o_press_reg));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[11] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[8]_i_1__3_n_4 ),
        .Q(counter_reg[11]),
        .R(o_press_reg));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[12] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[12]_i_1__3_n_7 ),
        .Q(counter_reg[12]),
        .R(o_press_reg));
  CARRY4 \counter_reg[12]_i_1__3 
       (.CI(\counter_reg[8]_i_1__3_n_0 ),
        .CO({\counter_reg[12]_i_1__3_n_0 ,\counter_reg[12]_i_1__3_n_1 ,\counter_reg[12]_i_1__3_n_2 ,\counter_reg[12]_i_1__3_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\counter_reg[12]_i_1__3_n_4 ,\counter_reg[12]_i_1__3_n_5 ,\counter_reg[12]_i_1__3_n_6 ,\counter_reg[12]_i_1__3_n_7 }),
        .S(counter_reg[15:12]));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[13] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[12]_i_1__3_n_6 ),
        .Q(counter_reg[13]),
        .R(o_press_reg));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[14] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[12]_i_1__3_n_5 ),
        .Q(counter_reg[14]),
        .R(o_press_reg));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[15] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[12]_i_1__3_n_4 ),
        .Q(counter_reg[15]),
        .R(o_press_reg));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[16] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[16]_i_1__3_n_7 ),
        .Q(counter_reg[16]),
        .R(o_press_reg));
  CARRY4 \counter_reg[16]_i_1__3 
       (.CI(\counter_reg[12]_i_1__3_n_0 ),
        .CO({\counter_reg[16]_i_1__3_n_0 ,\counter_reg[16]_i_1__3_n_1 ,\counter_reg[16]_i_1__3_n_2 ,\counter_reg[16]_i_1__3_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\counter_reg[16]_i_1__3_n_4 ,\counter_reg[16]_i_1__3_n_5 ,\counter_reg[16]_i_1__3_n_6 ,\counter_reg[16]_i_1__3_n_7 }),
        .S(counter_reg[19:16]));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[17] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[16]_i_1__3_n_6 ),
        .Q(counter_reg[17]),
        .R(o_press_reg));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[18] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[16]_i_1__3_n_5 ),
        .Q(counter_reg[18]),
        .R(o_press_reg));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[19] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[16]_i_1__3_n_4 ),
        .Q(counter_reg[19]),
        .R(o_press_reg));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[1] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[0]_i_2__3_n_6 ),
        .Q(counter_reg[1]),
        .R(o_press_reg));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[20] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[20]_i_1__3_n_7 ),
        .Q(counter_reg[20]),
        .R(o_press_reg));
  CARRY4 \counter_reg[20]_i_1__3 
       (.CI(\counter_reg[16]_i_1__3_n_0 ),
        .CO({\counter_reg[20]_i_1__3_n_0 ,\counter_reg[20]_i_1__3_n_1 ,\counter_reg[20]_i_1__3_n_2 ,\counter_reg[20]_i_1__3_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\counter_reg[20]_i_1__3_n_4 ,\counter_reg[20]_i_1__3_n_5 ,\counter_reg[20]_i_1__3_n_6 ,\counter_reg[20]_i_1__3_n_7 }),
        .S(counter_reg[23:20]));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[21] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[20]_i_1__3_n_6 ),
        .Q(counter_reg[21]),
        .R(o_press_reg));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[22] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[20]_i_1__3_n_5 ),
        .Q(counter_reg[22]),
        .R(o_press_reg));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[23] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[20]_i_1__3_n_4 ),
        .Q(counter_reg[23]),
        .R(o_press_reg));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[24] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[24]_i_1__3_n_7 ),
        .Q(counter_reg[24]),
        .R(o_press_reg));
  CARRY4 \counter_reg[24]_i_1__3 
       (.CI(\counter_reg[20]_i_1__3_n_0 ),
        .CO({\counter_reg[24]_i_1__3_n_0 ,\counter_reg[24]_i_1__3_n_1 ,\counter_reg[24]_i_1__3_n_2 ,\counter_reg[24]_i_1__3_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\counter_reg[24]_i_1__3_n_4 ,\counter_reg[24]_i_1__3_n_5 ,\counter_reg[24]_i_1__3_n_6 ,\counter_reg[24]_i_1__3_n_7 }),
        .S(counter_reg[27:24]));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[25] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[24]_i_1__3_n_6 ),
        .Q(counter_reg[25]),
        .R(o_press_reg));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[26] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[24]_i_1__3_n_5 ),
        .Q(counter_reg[26]),
        .R(o_press_reg));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[27] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[24]_i_1__3_n_4 ),
        .Q(counter_reg[27]),
        .R(o_press_reg));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[28] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[28]_i_1__3_n_7 ),
        .Q(counter_reg[28]),
        .R(o_press_reg));
  CARRY4 \counter_reg[28]_i_1__3 
       (.CI(\counter_reg[24]_i_1__3_n_0 ),
        .CO({\NLW_counter_reg[28]_i_1__3_CO_UNCONNECTED [3],\counter_reg[28]_i_1__3_n_1 ,\counter_reg[28]_i_1__3_n_2 ,\counter_reg[28]_i_1__3_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\counter_reg[28]_i_1__3_n_4 ,\counter_reg[28]_i_1__3_n_5 ,\counter_reg[28]_i_1__3_n_6 ,\counter_reg[28]_i_1__3_n_7 }),
        .S(counter_reg[31:28]));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[29] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[28]_i_1__3_n_6 ),
        .Q(counter_reg[29]),
        .R(o_press_reg));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[2] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[0]_i_2__3_n_5 ),
        .Q(counter_reg[2]),
        .R(o_press_reg));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[30] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[28]_i_1__3_n_5 ),
        .Q(counter_reg[30]),
        .R(o_press_reg));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[31] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[28]_i_1__3_n_4 ),
        .Q(counter_reg[31]),
        .R(o_press_reg));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[3] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[0]_i_2__3_n_4 ),
        .Q(counter_reg[3]),
        .R(o_press_reg));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[4] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[4]_i_1__3_n_7 ),
        .Q(counter_reg[4]),
        .R(o_press_reg));
  CARRY4 \counter_reg[4]_i_1__3 
       (.CI(\counter_reg[0]_i_2__3_n_0 ),
        .CO({\counter_reg[4]_i_1__3_n_0 ,\counter_reg[4]_i_1__3_n_1 ,\counter_reg[4]_i_1__3_n_2 ,\counter_reg[4]_i_1__3_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\counter_reg[4]_i_1__3_n_4 ,\counter_reg[4]_i_1__3_n_5 ,\counter_reg[4]_i_1__3_n_6 ,\counter_reg[4]_i_1__3_n_7 }),
        .S(counter_reg[7:4]));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[5] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[4]_i_1__3_n_6 ),
        .Q(counter_reg[5]),
        .R(o_press_reg));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[6] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[4]_i_1__3_n_5 ),
        .Q(counter_reg[6]),
        .R(o_press_reg));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[7] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[4]_i_1__3_n_4 ),
        .Q(counter_reg[7]),
        .R(o_press_reg));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[8] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[8]_i_1__3_n_7 ),
        .Q(counter_reg[8]),
        .R(o_press_reg));
  CARRY4 \counter_reg[8]_i_1__3 
       (.CI(\counter_reg[4]_i_1__3_n_0 ),
        .CO({\counter_reg[8]_i_1__3_n_0 ,\counter_reg[8]_i_1__3_n_1 ,\counter_reg[8]_i_1__3_n_2 ,\counter_reg[8]_i_1__3_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\counter_reg[8]_i_1__3_n_4 ,\counter_reg[8]_i_1__3_n_5 ,\counter_reg[8]_i_1__3_n_6 ,\counter_reg[8]_i_1__3_n_7 }),
        .S(counter_reg[11:8]));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[9] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[8]_i_1__3_n_6 ),
        .Q(counter_reg[9]),
        .R(o_press_reg));
  LUT6 #(
    .INIT(64'h00000000FFEAAAEA)) 
    o_intr_i_1
       (.I0(o_intr_i_2_n_0),
        .I1(o_pulse_reg_0),
        .I2(p_1_in),
        .I3(o_pulse_reg_1),
        .I4(\maxCoordinateReg_reg[30] ),
        .I5(Q),
        .O(o_intr1_out));
  LUT5 #(
    .INIT(32'h88B8B8B8)) 
    o_intr_i_2
       (.I0(\maxCoordinateReg_reg[14] ),
        .I1(o_pulse_reg_n_0),
        .I2(o_pulse),
        .I3(\o_x_pos_reg[12] ),
        .I4(\o_x_pos_reg[4] ),
        .O(o_intr_i_2_n_0));
  CARRY4 o_pulse0_carry
       (.CI(1'b0),
        .CO({o_pulse0_carry_n_0,o_pulse0_carry_n_1,o_pulse0_carry_n_2,o_pulse0_carry_n_3}),
        .CYINIT(1'b1),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(NLW_o_pulse0_carry_O_UNCONNECTED[3:0]),
        .S({o_pulse0_carry_i_1_n_0,o_pulse0_carry_i_2_n_0,o_pulse0_carry_i_3_n_0,o_pulse0_carry_i_4_n_0}));
  CARRY4 o_pulse0_carry__0
       (.CI(o_pulse0_carry_n_0),
        .CO({o_pulse0_carry__0_n_0,o_pulse0_carry__0_n_1,o_pulse0_carry__0_n_2,o_pulse0_carry__0_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(NLW_o_pulse0_carry__0_O_UNCONNECTED[3:0]),
        .S({o_pulse0_carry__0_i_1_n_0,o_pulse0_carry__0_i_2_n_0,o_pulse0_carry__0_i_3_n_0,o_pulse0_carry__0_i_4_n_0}));
  LUT6 #(
    .INIT(64'h9009000000009009)) 
    o_pulse0_carry__0_i_1
       (.I0(counter_reg[21]),
        .I1(\maxCountReg_reg[31] [21]),
        .I2(\maxCountReg_reg[31] [23]),
        .I3(counter_reg[23]),
        .I4(\maxCountReg_reg[31] [22]),
        .I5(counter_reg[22]),
        .O(o_pulse0_carry__0_i_1_n_0));
  LUT6 #(
    .INIT(64'h9009000000009009)) 
    o_pulse0_carry__0_i_2
       (.I0(counter_reg[18]),
        .I1(\maxCountReg_reg[31] [18]),
        .I2(\maxCountReg_reg[31] [20]),
        .I3(counter_reg[20]),
        .I4(\maxCountReg_reg[31] [19]),
        .I5(counter_reg[19]),
        .O(o_pulse0_carry__0_i_2_n_0));
  LUT6 #(
    .INIT(64'h9009000000009009)) 
    o_pulse0_carry__0_i_3
       (.I0(counter_reg[15]),
        .I1(\maxCountReg_reg[31] [15]),
        .I2(\maxCountReg_reg[31] [17]),
        .I3(counter_reg[17]),
        .I4(\maxCountReg_reg[31] [16]),
        .I5(counter_reg[16]),
        .O(o_pulse0_carry__0_i_3_n_0));
  LUT6 #(
    .INIT(64'h9009000000009009)) 
    o_pulse0_carry__0_i_4
       (.I0(counter_reg[12]),
        .I1(\maxCountReg_reg[31] [12]),
        .I2(\maxCountReg_reg[31] [14]),
        .I3(counter_reg[14]),
        .I4(\maxCountReg_reg[31] [13]),
        .I5(counter_reg[13]),
        .O(o_pulse0_carry__0_i_4_n_0));
  CARRY4 o_pulse0_carry__1
       (.CI(o_pulse0_carry__0_n_0),
        .CO({NLW_o_pulse0_carry__1_CO_UNCONNECTED[3],o_pulse0_carry__1_n_1,o_pulse0_carry__1_n_2,o_pulse0_carry__1_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(NLW_o_pulse0_carry__1_O_UNCONNECTED[3:0]),
        .S({1'b0,o_pulse0_carry__1_i_1_n_0,o_pulse0_carry__1_i_2_n_0,o_pulse0_carry__1_i_3_n_0}));
  LUT4 #(
    .INIT(16'h9009)) 
    o_pulse0_carry__1_i_1
       (.I0(counter_reg[30]),
        .I1(\maxCountReg_reg[31] [30]),
        .I2(counter_reg[31]),
        .I3(\maxCountReg_reg[31] [31]),
        .O(o_pulse0_carry__1_i_1_n_0));
  LUT6 #(
    .INIT(64'h9009000000009009)) 
    o_pulse0_carry__1_i_2
       (.I0(counter_reg[27]),
        .I1(\maxCountReg_reg[31] [27]),
        .I2(\maxCountReg_reg[31] [29]),
        .I3(counter_reg[29]),
        .I4(\maxCountReg_reg[31] [28]),
        .I5(counter_reg[28]),
        .O(o_pulse0_carry__1_i_2_n_0));
  LUT6 #(
    .INIT(64'h9009000000009009)) 
    o_pulse0_carry__1_i_3
       (.I0(counter_reg[24]),
        .I1(\maxCountReg_reg[31] [24]),
        .I2(\maxCountReg_reg[31] [26]),
        .I3(counter_reg[26]),
        .I4(\maxCountReg_reg[31] [25]),
        .I5(counter_reg[25]),
        .O(o_pulse0_carry__1_i_3_n_0));
  LUT6 #(
    .INIT(64'h9009000000009009)) 
    o_pulse0_carry_i_1
       (.I0(counter_reg[9]),
        .I1(\maxCountReg_reg[31] [9]),
        .I2(\maxCountReg_reg[31] [11]),
        .I3(counter_reg[11]),
        .I4(\maxCountReg_reg[31] [10]),
        .I5(counter_reg[10]),
        .O(o_pulse0_carry_i_1_n_0));
  LUT6 #(
    .INIT(64'h9009000000009009)) 
    o_pulse0_carry_i_2
       (.I0(counter_reg[6]),
        .I1(\maxCountReg_reg[31] [6]),
        .I2(\maxCountReg_reg[31] [8]),
        .I3(counter_reg[8]),
        .I4(\maxCountReg_reg[31] [7]),
        .I5(counter_reg[7]),
        .O(o_pulse0_carry_i_2_n_0));
  LUT6 #(
    .INIT(64'h9009000000009009)) 
    o_pulse0_carry_i_3
       (.I0(counter_reg[3]),
        .I1(\maxCountReg_reg[31] [3]),
        .I2(\maxCountReg_reg[31] [5]),
        .I3(counter_reg[5]),
        .I4(\maxCountReg_reg[31] [4]),
        .I5(counter_reg[4]),
        .O(o_pulse0_carry_i_3_n_0));
  LUT6 #(
    .INIT(64'h9009000000009009)) 
    o_pulse0_carry_i_4
       (.I0(counter_reg[0]),
        .I1(\maxCountReg_reg[31] [0]),
        .I2(\maxCountReg_reg[31] [2]),
        .I3(counter_reg[2]),
        .I4(\maxCountReg_reg[31] [1]),
        .I5(counter_reg[1]),
        .O(o_pulse0_carry_i_4_n_0));
  FDRE o_pulse_reg
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(o_pulse0_carry__1_n_1),
        .Q(o_pulse_reg_n_0),
        .R(1'b0));
  LUT2 #(
    .INIT(4'hE)) 
    \o_x_pos[0]_i_1 
       (.I0(Q),
        .I1(o_intr_i_2_n_0),
        .O(sel));
  LUT2 #(
    .INIT(4'h1)) 
    \o_x_pos[0]_i_3 
       (.I0(o_pulse_reg_n_0),
        .I1(Q),
        .O(\o_x_pos[0]_i_3_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \o_x_pos[0]_i_4 
       (.I0(o_pulse_reg_n_0),
        .I1(Q),
        .O(\o_x_pos[0]_i_4_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \o_x_pos[0]_i_5 
       (.I0(o_pulse_reg_n_0),
        .I1(Q),
        .O(\o_x_pos[0]_i_5_n_0 ));
  LUT4 #(
    .INIT(16'hF909)) 
    \o_x_pos[0]_i_7 
       (.I0(o_pulse_reg_n_0),
        .I1(posReg[2]),
        .I2(Q),
        .I3(\maxCoordinateReg_reg[15] [2]),
        .O(\o_x_pos[0]_i_7_n_0 ));
  LUT4 #(
    .INIT(16'hF909)) 
    \o_x_pos[0]_i_8 
       (.I0(o_pulse_reg_n_0),
        .I1(posReg[1]),
        .I2(Q),
        .I3(\maxCoordinateReg_reg[15] [1]),
        .O(\o_x_pos[0]_i_8_n_0 ));
  LUT4 #(
    .INIT(16'hF909)) 
    \o_x_pos[0]_i_9 
       (.I0(o_pulse_reg_n_0),
        .I1(posReg[0]),
        .I2(Q),
        .I3(\maxCoordinateReg_reg[15] [0]),
        .O(\o_x_pos[0]_i_9_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \o_x_pos[12]_i_2 
       (.I0(o_pulse_reg_n_0),
        .I1(Q),
        .O(\o_x_pos[12]_i_2_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \o_x_pos[12]_i_3 
       (.I0(o_pulse_reg_n_0),
        .I1(Q),
        .O(\o_x_pos[12]_i_3_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \o_x_pos[12]_i_4 
       (.I0(o_pulse_reg_n_0),
        .I1(Q),
        .O(\o_x_pos[12]_i_4_n_0 ));
  LUT3 #(
    .INIT(8'h21)) 
    \o_x_pos[12]_i_5 
       (.I0(o_pulse_reg_n_0),
        .I1(Q),
        .I2(posReg[14]),
        .O(\o_x_pos[12]_i_5_n_0 ));
  LUT4 #(
    .INIT(16'hF909)) 
    \o_x_pos[12]_i_6 
       (.I0(o_pulse_reg_n_0),
        .I1(posReg[13]),
        .I2(Q),
        .I3(\maxCoordinateReg_reg[15] [13]),
        .O(\o_x_pos[12]_i_6_n_0 ));
  LUT4 #(
    .INIT(16'hF909)) 
    \o_x_pos[12]_i_7 
       (.I0(o_pulse_reg_n_0),
        .I1(posReg[12]),
        .I2(Q),
        .I3(\maxCoordinateReg_reg[15] [12]),
        .O(\o_x_pos[12]_i_7_n_0 ));
  LUT4 #(
    .INIT(16'hF909)) 
    \o_x_pos[12]_i_8 
       (.I0(o_pulse_reg_n_0),
        .I1(posReg[11]),
        .I2(Q),
        .I3(\maxCoordinateReg_reg[15] [11]),
        .O(\o_x_pos[12]_i_8_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \o_x_pos[4]_i_2 
       (.I0(o_pulse_reg_n_0),
        .I1(Q),
        .O(\o_x_pos[4]_i_2_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \o_x_pos[4]_i_3 
       (.I0(o_pulse_reg_n_0),
        .I1(Q),
        .O(\o_x_pos[4]_i_3_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \o_x_pos[4]_i_4 
       (.I0(o_pulse_reg_n_0),
        .I1(Q),
        .O(\o_x_pos[4]_i_4_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \o_x_pos[4]_i_5 
       (.I0(o_pulse_reg_n_0),
        .I1(Q),
        .O(\o_x_pos[4]_i_5_n_0 ));
  LUT4 #(
    .INIT(16'hF909)) 
    \o_x_pos[4]_i_6 
       (.I0(o_pulse_reg_n_0),
        .I1(posReg[6]),
        .I2(Q),
        .I3(\maxCoordinateReg_reg[15] [6]),
        .O(\o_x_pos[4]_i_6_n_0 ));
  LUT4 #(
    .INIT(16'hF909)) 
    \o_x_pos[4]_i_7 
       (.I0(o_pulse_reg_n_0),
        .I1(posReg[5]),
        .I2(Q),
        .I3(\maxCoordinateReg_reg[15] [5]),
        .O(\o_x_pos[4]_i_7_n_0 ));
  LUT4 #(
    .INIT(16'hF909)) 
    \o_x_pos[4]_i_8 
       (.I0(o_pulse_reg_n_0),
        .I1(posReg[4]),
        .I2(Q),
        .I3(\maxCoordinateReg_reg[15] [4]),
        .O(\o_x_pos[4]_i_8_n_0 ));
  LUT4 #(
    .INIT(16'hF909)) 
    \o_x_pos[4]_i_9 
       (.I0(o_pulse_reg_n_0),
        .I1(posReg[3]),
        .I2(Q),
        .I3(\maxCoordinateReg_reg[15] [3]),
        .O(\o_x_pos[4]_i_9_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \o_x_pos[8]_i_2 
       (.I0(o_pulse_reg_n_0),
        .I1(Q),
        .O(\o_x_pos[8]_i_2_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \o_x_pos[8]_i_3 
       (.I0(o_pulse_reg_n_0),
        .I1(Q),
        .O(\o_x_pos[8]_i_3_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \o_x_pos[8]_i_4 
       (.I0(o_pulse_reg_n_0),
        .I1(Q),
        .O(\o_x_pos[8]_i_4_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \o_x_pos[8]_i_5 
       (.I0(o_pulse_reg_n_0),
        .I1(Q),
        .O(\o_x_pos[8]_i_5_n_0 ));
  LUT4 #(
    .INIT(16'hF909)) 
    \o_x_pos[8]_i_6 
       (.I0(o_pulse_reg_n_0),
        .I1(posReg[10]),
        .I2(Q),
        .I3(\maxCoordinateReg_reg[15] [10]),
        .O(\o_x_pos[8]_i_6_n_0 ));
  LUT4 #(
    .INIT(16'hF909)) 
    \o_x_pos[8]_i_7 
       (.I0(o_pulse_reg_n_0),
        .I1(posReg[9]),
        .I2(Q),
        .I3(\maxCoordinateReg_reg[15] [9]),
        .O(\o_x_pos[8]_i_7_n_0 ));
  LUT4 #(
    .INIT(16'hF909)) 
    \o_x_pos[8]_i_8 
       (.I0(o_pulse_reg_n_0),
        .I1(posReg[8]),
        .I2(Q),
        .I3(\maxCoordinateReg_reg[15] [8]),
        .O(\o_x_pos[8]_i_8_n_0 ));
  LUT4 #(
    .INIT(16'hF909)) 
    \o_x_pos[8]_i_9 
       (.I0(o_pulse_reg_n_0),
        .I1(posReg[7]),
        .I2(Q),
        .I3(\maxCoordinateReg_reg[15] [7]),
        .O(\o_x_pos[8]_i_9_n_0 ));
  CARRY4 \o_x_pos_reg[0]_i_2 
       (.CI(1'b0),
        .CO({\o_x_pos_reg[0]_i_2_n_0 ,\o_x_pos_reg[0]_i_2_n_1 ,\o_x_pos_reg[0]_i_2_n_2 ,\o_x_pos_reg[0]_i_2_n_3 }),
        .CYINIT(1'b0),
        .DI({\o_x_pos[0]_i_3_n_0 ,\o_x_pos[0]_i_4_n_0 ,\o_x_pos[0]_i_5_n_0 ,DI}),
        .O(O),
        .S({\o_x_pos[0]_i_7_n_0 ,\o_x_pos[0]_i_8_n_0 ,\o_x_pos[0]_i_9_n_0 ,S}));
  CARRY4 \o_x_pos_reg[12]_i_1 
       (.CI(\o_x_pos_reg[8]_i_1_n_0 ),
        .CO({\NLW_o_x_pos_reg[12]_i_1_CO_UNCONNECTED [3],\o_x_pos_reg[12]_i_1_n_1 ,\o_x_pos_reg[12]_i_1_n_2 ,\o_x_pos_reg[12]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,\o_x_pos[12]_i_2_n_0 ,\o_x_pos[12]_i_3_n_0 ,\o_x_pos[12]_i_4_n_0 }),
        .O(\o_x_pos_reg[15] ),
        .S({\o_x_pos[12]_i_5_n_0 ,\o_x_pos[12]_i_6_n_0 ,\o_x_pos[12]_i_7_n_0 ,\o_x_pos[12]_i_8_n_0 }));
  CARRY4 \o_x_pos_reg[4]_i_1 
       (.CI(\o_x_pos_reg[0]_i_2_n_0 ),
        .CO({\o_x_pos_reg[4]_i_1_n_0 ,\o_x_pos_reg[4]_i_1_n_1 ,\o_x_pos_reg[4]_i_1_n_2 ,\o_x_pos_reg[4]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({\o_x_pos[4]_i_2_n_0 ,\o_x_pos[4]_i_3_n_0 ,\o_x_pos[4]_i_4_n_0 ,\o_x_pos[4]_i_5_n_0 }),
        .O(\o_x_pos_reg[7] ),
        .S({\o_x_pos[4]_i_6_n_0 ,\o_x_pos[4]_i_7_n_0 ,\o_x_pos[4]_i_8_n_0 ,\o_x_pos[4]_i_9_n_0 }));
  CARRY4 \o_x_pos_reg[8]_i_1 
       (.CI(\o_x_pos_reg[4]_i_1_n_0 ),
        .CO({\o_x_pos_reg[8]_i_1_n_0 ,\o_x_pos_reg[8]_i_1_n_1 ,\o_x_pos_reg[8]_i_1_n_2 ,\o_x_pos_reg[8]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({\o_x_pos[8]_i_2_n_0 ,\o_x_pos[8]_i_3_n_0 ,\o_x_pos[8]_i_4_n_0 ,\o_x_pos[8]_i_5_n_0 }),
        .O(\o_x_pos_reg[11] ),
        .S({\o_x_pos[8]_i_6_n_0 ,\o_x_pos[8]_i_7_n_0 ,\o_x_pos[8]_i_8_n_0 ,\o_x_pos[8]_i_9_n_0 }));
endmodule

(* ORIG_REF_NAME = "pulseGen" *) 
module decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_pulseGen_5
   (\o_y_pos_reg[0] ,
    CO,
    \o_y_pos_reg[0]_0 ,
    s00_axi_aclk,
    \maxCountReg_reg[31] ,
    Q,
    p_1_in,
    o_pulse_reg_0,
    \maxCoordinateReg_reg[30] ,
    o_press_reg);
  output \o_y_pos_reg[0] ;
  output [0:0]CO;
  output \o_y_pos_reg[0]_0 ;
  input s00_axi_aclk;
  input [31:0]\maxCountReg_reg[31] ;
  input [0:0]Q;
  input p_1_in;
  input o_pulse_reg_0;
  input [0:0]\maxCoordinateReg_reg[30] ;
  input o_press_reg;

  wire [0:0]CO;
  wire [0:0]Q;
  wire counter2_carry__0_i_1__2_n_0;
  wire counter2_carry__0_i_2__2_n_0;
  wire counter2_carry__0_i_3__2_n_0;
  wire counter2_carry__0_i_4__2_n_0;
  wire counter2_carry__0_i_5__2_n_0;
  wire counter2_carry__0_i_6__2_n_0;
  wire counter2_carry__0_i_7__2_n_0;
  wire counter2_carry__0_i_8__2_n_0;
  wire counter2_carry__0_n_0;
  wire counter2_carry__0_n_1;
  wire counter2_carry__0_n_2;
  wire counter2_carry__0_n_3;
  wire counter2_carry__1_i_1__2_n_0;
  wire counter2_carry__1_i_2__2_n_0;
  wire counter2_carry__1_i_3__2_n_0;
  wire counter2_carry__1_i_4__2_n_0;
  wire counter2_carry__1_i_5__2_n_0;
  wire counter2_carry__1_i_6__2_n_0;
  wire counter2_carry__1_i_7__2_n_0;
  wire counter2_carry__1_i_8__2_n_0;
  wire counter2_carry__1_n_0;
  wire counter2_carry__1_n_1;
  wire counter2_carry__1_n_2;
  wire counter2_carry__1_n_3;
  wire counter2_carry__2_i_1__2_n_0;
  wire counter2_carry__2_i_2__2_n_0;
  wire counter2_carry__2_i_3__2_n_0;
  wire counter2_carry__2_i_4__2_n_0;
  wire counter2_carry__2_i_5__2_n_0;
  wire counter2_carry__2_i_6__2_n_0;
  wire counter2_carry__2_i_7__2_n_0;
  wire counter2_carry__2_i_8__2_n_0;
  wire counter2_carry__2_n_1;
  wire counter2_carry__2_n_2;
  wire counter2_carry__2_n_3;
  wire counter2_carry_i_1__2_n_0;
  wire counter2_carry_i_2__2_n_0;
  wire counter2_carry_i_3__2_n_0;
  wire counter2_carry_i_4__2_n_0;
  wire counter2_carry_i_5__2_n_0;
  wire counter2_carry_i_6__2_n_0;
  wire counter2_carry_i_7__2_n_0;
  wire counter2_carry_i_8__2_n_0;
  wire counter2_carry_n_0;
  wire counter2_carry_n_1;
  wire counter2_carry_n_2;
  wire counter2_carry_n_3;
  wire \counter[0]_i_3__5_n_0 ;
  wire [31:0]counter_reg;
  wire \counter_reg[0]_i_2__6_n_0 ;
  wire \counter_reg[0]_i_2__6_n_1 ;
  wire \counter_reg[0]_i_2__6_n_2 ;
  wire \counter_reg[0]_i_2__6_n_3 ;
  wire \counter_reg[0]_i_2__6_n_4 ;
  wire \counter_reg[0]_i_2__6_n_5 ;
  wire \counter_reg[0]_i_2__6_n_6 ;
  wire \counter_reg[0]_i_2__6_n_7 ;
  wire \counter_reg[12]_i_1__6_n_0 ;
  wire \counter_reg[12]_i_1__6_n_1 ;
  wire \counter_reg[12]_i_1__6_n_2 ;
  wire \counter_reg[12]_i_1__6_n_3 ;
  wire \counter_reg[12]_i_1__6_n_4 ;
  wire \counter_reg[12]_i_1__6_n_5 ;
  wire \counter_reg[12]_i_1__6_n_6 ;
  wire \counter_reg[12]_i_1__6_n_7 ;
  wire \counter_reg[16]_i_1__6_n_0 ;
  wire \counter_reg[16]_i_1__6_n_1 ;
  wire \counter_reg[16]_i_1__6_n_2 ;
  wire \counter_reg[16]_i_1__6_n_3 ;
  wire \counter_reg[16]_i_1__6_n_4 ;
  wire \counter_reg[16]_i_1__6_n_5 ;
  wire \counter_reg[16]_i_1__6_n_6 ;
  wire \counter_reg[16]_i_1__6_n_7 ;
  wire \counter_reg[20]_i_1__6_n_0 ;
  wire \counter_reg[20]_i_1__6_n_1 ;
  wire \counter_reg[20]_i_1__6_n_2 ;
  wire \counter_reg[20]_i_1__6_n_3 ;
  wire \counter_reg[20]_i_1__6_n_4 ;
  wire \counter_reg[20]_i_1__6_n_5 ;
  wire \counter_reg[20]_i_1__6_n_6 ;
  wire \counter_reg[20]_i_1__6_n_7 ;
  wire \counter_reg[24]_i_1__6_n_0 ;
  wire \counter_reg[24]_i_1__6_n_1 ;
  wire \counter_reg[24]_i_1__6_n_2 ;
  wire \counter_reg[24]_i_1__6_n_3 ;
  wire \counter_reg[24]_i_1__6_n_4 ;
  wire \counter_reg[24]_i_1__6_n_5 ;
  wire \counter_reg[24]_i_1__6_n_6 ;
  wire \counter_reg[24]_i_1__6_n_7 ;
  wire \counter_reg[28]_i_1__6_n_1 ;
  wire \counter_reg[28]_i_1__6_n_2 ;
  wire \counter_reg[28]_i_1__6_n_3 ;
  wire \counter_reg[28]_i_1__6_n_4 ;
  wire \counter_reg[28]_i_1__6_n_5 ;
  wire \counter_reg[28]_i_1__6_n_6 ;
  wire \counter_reg[28]_i_1__6_n_7 ;
  wire \counter_reg[4]_i_1__6_n_0 ;
  wire \counter_reg[4]_i_1__6_n_1 ;
  wire \counter_reg[4]_i_1__6_n_2 ;
  wire \counter_reg[4]_i_1__6_n_3 ;
  wire \counter_reg[4]_i_1__6_n_4 ;
  wire \counter_reg[4]_i_1__6_n_5 ;
  wire \counter_reg[4]_i_1__6_n_6 ;
  wire \counter_reg[4]_i_1__6_n_7 ;
  wire \counter_reg[8]_i_1__6_n_0 ;
  wire \counter_reg[8]_i_1__6_n_1 ;
  wire \counter_reg[8]_i_1__6_n_2 ;
  wire \counter_reg[8]_i_1__6_n_3 ;
  wire \counter_reg[8]_i_1__6_n_4 ;
  wire \counter_reg[8]_i_1__6_n_5 ;
  wire \counter_reg[8]_i_1__6_n_6 ;
  wire \counter_reg[8]_i_1__6_n_7 ;
  wire [0:0]\maxCoordinateReg_reg[30] ;
  wire [31:0]\maxCountReg_reg[31] ;
  wire o_press_reg;
  wire o_pulse0_carry__0_i_1__2_n_0;
  wire o_pulse0_carry__0_i_2__2_n_0;
  wire o_pulse0_carry__0_i_3__2_n_0;
  wire o_pulse0_carry__0_i_4__2_n_0;
  wire o_pulse0_carry__0_n_0;
  wire o_pulse0_carry__0_n_1;
  wire o_pulse0_carry__0_n_2;
  wire o_pulse0_carry__0_n_3;
  wire o_pulse0_carry__1_i_1__2_n_0;
  wire o_pulse0_carry__1_i_2__2_n_0;
  wire o_pulse0_carry__1_i_3__2_n_0;
  wire o_pulse0_carry__1_n_1;
  wire o_pulse0_carry__1_n_2;
  wire o_pulse0_carry__1_n_3;
  wire o_pulse0_carry_i_1__2_n_0;
  wire o_pulse0_carry_i_2__2_n_0;
  wire o_pulse0_carry_i_3__2_n_0;
  wire o_pulse0_carry_i_4__2_n_0;
  wire o_pulse0_carry_n_0;
  wire o_pulse0_carry_n_1;
  wire o_pulse0_carry_n_2;
  wire o_pulse0_carry_n_3;
  wire o_pulse_reg_0;
  wire \o_y_pos_reg[0] ;
  wire \o_y_pos_reg[0]_0 ;
  wire p_1_in;
  wire s00_axi_aclk;
  wire [3:0]NLW_counter2_carry_O_UNCONNECTED;
  wire [3:0]NLW_counter2_carry__0_O_UNCONNECTED;
  wire [3:0]NLW_counter2_carry__1_O_UNCONNECTED;
  wire [3:0]NLW_counter2_carry__2_O_UNCONNECTED;
  wire [3:3]\NLW_counter_reg[28]_i_1__6_CO_UNCONNECTED ;
  wire [3:0]NLW_o_pulse0_carry_O_UNCONNECTED;
  wire [3:0]NLW_o_pulse0_carry__0_O_UNCONNECTED;
  wire [3:3]NLW_o_pulse0_carry__1_CO_UNCONNECTED;
  wire [3:0]NLW_o_pulse0_carry__1_O_UNCONNECTED;

  CARRY4 counter2_carry
       (.CI(1'b0),
        .CO({counter2_carry_n_0,counter2_carry_n_1,counter2_carry_n_2,counter2_carry_n_3}),
        .CYINIT(1'b0),
        .DI({counter2_carry_i_1__2_n_0,counter2_carry_i_2__2_n_0,counter2_carry_i_3__2_n_0,counter2_carry_i_4__2_n_0}),
        .O(NLW_counter2_carry_O_UNCONNECTED[3:0]),
        .S({counter2_carry_i_5__2_n_0,counter2_carry_i_6__2_n_0,counter2_carry_i_7__2_n_0,counter2_carry_i_8__2_n_0}));
  CARRY4 counter2_carry__0
       (.CI(counter2_carry_n_0),
        .CO({counter2_carry__0_n_0,counter2_carry__0_n_1,counter2_carry__0_n_2,counter2_carry__0_n_3}),
        .CYINIT(1'b0),
        .DI({counter2_carry__0_i_1__2_n_0,counter2_carry__0_i_2__2_n_0,counter2_carry__0_i_3__2_n_0,counter2_carry__0_i_4__2_n_0}),
        .O(NLW_counter2_carry__0_O_UNCONNECTED[3:0]),
        .S({counter2_carry__0_i_5__2_n_0,counter2_carry__0_i_6__2_n_0,counter2_carry__0_i_7__2_n_0,counter2_carry__0_i_8__2_n_0}));
  LUT4 #(
    .INIT(16'h2F02)) 
    counter2_carry__0_i_1__2
       (.I0(\maxCountReg_reg[31] [14]),
        .I1(counter_reg[14]),
        .I2(counter_reg[15]),
        .I3(\maxCountReg_reg[31] [15]),
        .O(counter2_carry__0_i_1__2_n_0));
  LUT4 #(
    .INIT(16'h2F02)) 
    counter2_carry__0_i_2__2
       (.I0(\maxCountReg_reg[31] [12]),
        .I1(counter_reg[12]),
        .I2(counter_reg[13]),
        .I3(\maxCountReg_reg[31] [13]),
        .O(counter2_carry__0_i_2__2_n_0));
  LUT4 #(
    .INIT(16'h2F02)) 
    counter2_carry__0_i_3__2
       (.I0(\maxCountReg_reg[31] [10]),
        .I1(counter_reg[10]),
        .I2(counter_reg[11]),
        .I3(\maxCountReg_reg[31] [11]),
        .O(counter2_carry__0_i_3__2_n_0));
  LUT4 #(
    .INIT(16'h2F02)) 
    counter2_carry__0_i_4__2
       (.I0(\maxCountReg_reg[31] [8]),
        .I1(counter_reg[8]),
        .I2(counter_reg[9]),
        .I3(\maxCountReg_reg[31] [9]),
        .O(counter2_carry__0_i_4__2_n_0));
  LUT4 #(
    .INIT(16'h9009)) 
    counter2_carry__0_i_5__2
       (.I0(\maxCountReg_reg[31] [14]),
        .I1(counter_reg[14]),
        .I2(\maxCountReg_reg[31] [15]),
        .I3(counter_reg[15]),
        .O(counter2_carry__0_i_5__2_n_0));
  LUT4 #(
    .INIT(16'h9009)) 
    counter2_carry__0_i_6__2
       (.I0(\maxCountReg_reg[31] [12]),
        .I1(counter_reg[12]),
        .I2(\maxCountReg_reg[31] [13]),
        .I3(counter_reg[13]),
        .O(counter2_carry__0_i_6__2_n_0));
  LUT4 #(
    .INIT(16'h9009)) 
    counter2_carry__0_i_7__2
       (.I0(\maxCountReg_reg[31] [10]),
        .I1(counter_reg[10]),
        .I2(\maxCountReg_reg[31] [11]),
        .I3(counter_reg[11]),
        .O(counter2_carry__0_i_7__2_n_0));
  LUT4 #(
    .INIT(16'h9009)) 
    counter2_carry__0_i_8__2
       (.I0(\maxCountReg_reg[31] [8]),
        .I1(counter_reg[8]),
        .I2(\maxCountReg_reg[31] [9]),
        .I3(counter_reg[9]),
        .O(counter2_carry__0_i_8__2_n_0));
  CARRY4 counter2_carry__1
       (.CI(counter2_carry__0_n_0),
        .CO({counter2_carry__1_n_0,counter2_carry__1_n_1,counter2_carry__1_n_2,counter2_carry__1_n_3}),
        .CYINIT(1'b0),
        .DI({counter2_carry__1_i_1__2_n_0,counter2_carry__1_i_2__2_n_0,counter2_carry__1_i_3__2_n_0,counter2_carry__1_i_4__2_n_0}),
        .O(NLW_counter2_carry__1_O_UNCONNECTED[3:0]),
        .S({counter2_carry__1_i_5__2_n_0,counter2_carry__1_i_6__2_n_0,counter2_carry__1_i_7__2_n_0,counter2_carry__1_i_8__2_n_0}));
  LUT4 #(
    .INIT(16'h2F02)) 
    counter2_carry__1_i_1__2
       (.I0(\maxCountReg_reg[31] [22]),
        .I1(counter_reg[22]),
        .I2(counter_reg[23]),
        .I3(\maxCountReg_reg[31] [23]),
        .O(counter2_carry__1_i_1__2_n_0));
  LUT4 #(
    .INIT(16'h2F02)) 
    counter2_carry__1_i_2__2
       (.I0(\maxCountReg_reg[31] [20]),
        .I1(counter_reg[20]),
        .I2(counter_reg[21]),
        .I3(\maxCountReg_reg[31] [21]),
        .O(counter2_carry__1_i_2__2_n_0));
  LUT4 #(
    .INIT(16'h2F02)) 
    counter2_carry__1_i_3__2
       (.I0(\maxCountReg_reg[31] [18]),
        .I1(counter_reg[18]),
        .I2(counter_reg[19]),
        .I3(\maxCountReg_reg[31] [19]),
        .O(counter2_carry__1_i_3__2_n_0));
  LUT4 #(
    .INIT(16'h2F02)) 
    counter2_carry__1_i_4__2
       (.I0(\maxCountReg_reg[31] [16]),
        .I1(counter_reg[16]),
        .I2(counter_reg[17]),
        .I3(\maxCountReg_reg[31] [17]),
        .O(counter2_carry__1_i_4__2_n_0));
  LUT4 #(
    .INIT(16'h9009)) 
    counter2_carry__1_i_5__2
       (.I0(\maxCountReg_reg[31] [22]),
        .I1(counter_reg[22]),
        .I2(\maxCountReg_reg[31] [23]),
        .I3(counter_reg[23]),
        .O(counter2_carry__1_i_5__2_n_0));
  LUT4 #(
    .INIT(16'h9009)) 
    counter2_carry__1_i_6__2
       (.I0(\maxCountReg_reg[31] [20]),
        .I1(counter_reg[20]),
        .I2(\maxCountReg_reg[31] [21]),
        .I3(counter_reg[21]),
        .O(counter2_carry__1_i_6__2_n_0));
  LUT4 #(
    .INIT(16'h9009)) 
    counter2_carry__1_i_7__2
       (.I0(\maxCountReg_reg[31] [18]),
        .I1(counter_reg[18]),
        .I2(\maxCountReg_reg[31] [19]),
        .I3(counter_reg[19]),
        .O(counter2_carry__1_i_7__2_n_0));
  LUT4 #(
    .INIT(16'h9009)) 
    counter2_carry__1_i_8__2
       (.I0(\maxCountReg_reg[31] [16]),
        .I1(counter_reg[16]),
        .I2(\maxCountReg_reg[31] [17]),
        .I3(counter_reg[17]),
        .O(counter2_carry__1_i_8__2_n_0));
  CARRY4 counter2_carry__2
       (.CI(counter2_carry__1_n_0),
        .CO({CO,counter2_carry__2_n_1,counter2_carry__2_n_2,counter2_carry__2_n_3}),
        .CYINIT(1'b0),
        .DI({counter2_carry__2_i_1__2_n_0,counter2_carry__2_i_2__2_n_0,counter2_carry__2_i_3__2_n_0,counter2_carry__2_i_4__2_n_0}),
        .O(NLW_counter2_carry__2_O_UNCONNECTED[3:0]),
        .S({counter2_carry__2_i_5__2_n_0,counter2_carry__2_i_6__2_n_0,counter2_carry__2_i_7__2_n_0,counter2_carry__2_i_8__2_n_0}));
  LUT4 #(
    .INIT(16'h2F02)) 
    counter2_carry__2_i_1__2
       (.I0(\maxCountReg_reg[31] [30]),
        .I1(counter_reg[30]),
        .I2(counter_reg[31]),
        .I3(\maxCountReg_reg[31] [31]),
        .O(counter2_carry__2_i_1__2_n_0));
  LUT4 #(
    .INIT(16'h2F02)) 
    counter2_carry__2_i_2__2
       (.I0(\maxCountReg_reg[31] [28]),
        .I1(counter_reg[28]),
        .I2(counter_reg[29]),
        .I3(\maxCountReg_reg[31] [29]),
        .O(counter2_carry__2_i_2__2_n_0));
  LUT4 #(
    .INIT(16'h2F02)) 
    counter2_carry__2_i_3__2
       (.I0(\maxCountReg_reg[31] [26]),
        .I1(counter_reg[26]),
        .I2(counter_reg[27]),
        .I3(\maxCountReg_reg[31] [27]),
        .O(counter2_carry__2_i_3__2_n_0));
  LUT4 #(
    .INIT(16'h2F02)) 
    counter2_carry__2_i_4__2
       (.I0(\maxCountReg_reg[31] [24]),
        .I1(counter_reg[24]),
        .I2(counter_reg[25]),
        .I3(\maxCountReg_reg[31] [25]),
        .O(counter2_carry__2_i_4__2_n_0));
  LUT4 #(
    .INIT(16'h9009)) 
    counter2_carry__2_i_5__2
       (.I0(\maxCountReg_reg[31] [30]),
        .I1(counter_reg[30]),
        .I2(\maxCountReg_reg[31] [31]),
        .I3(counter_reg[31]),
        .O(counter2_carry__2_i_5__2_n_0));
  LUT4 #(
    .INIT(16'h9009)) 
    counter2_carry__2_i_6__2
       (.I0(\maxCountReg_reg[31] [28]),
        .I1(counter_reg[28]),
        .I2(\maxCountReg_reg[31] [29]),
        .I3(counter_reg[29]),
        .O(counter2_carry__2_i_6__2_n_0));
  LUT4 #(
    .INIT(16'h9009)) 
    counter2_carry__2_i_7__2
       (.I0(\maxCountReg_reg[31] [26]),
        .I1(counter_reg[26]),
        .I2(\maxCountReg_reg[31] [27]),
        .I3(counter_reg[27]),
        .O(counter2_carry__2_i_7__2_n_0));
  LUT4 #(
    .INIT(16'h9009)) 
    counter2_carry__2_i_8__2
       (.I0(\maxCountReg_reg[31] [24]),
        .I1(counter_reg[24]),
        .I2(\maxCountReg_reg[31] [25]),
        .I3(counter_reg[25]),
        .O(counter2_carry__2_i_8__2_n_0));
  LUT4 #(
    .INIT(16'h2F02)) 
    counter2_carry_i_1__2
       (.I0(\maxCountReg_reg[31] [6]),
        .I1(counter_reg[6]),
        .I2(counter_reg[7]),
        .I3(\maxCountReg_reg[31] [7]),
        .O(counter2_carry_i_1__2_n_0));
  LUT4 #(
    .INIT(16'h2F02)) 
    counter2_carry_i_2__2
       (.I0(\maxCountReg_reg[31] [4]),
        .I1(counter_reg[4]),
        .I2(counter_reg[5]),
        .I3(\maxCountReg_reg[31] [5]),
        .O(counter2_carry_i_2__2_n_0));
  LUT4 #(
    .INIT(16'h2F02)) 
    counter2_carry_i_3__2
       (.I0(\maxCountReg_reg[31] [2]),
        .I1(counter_reg[2]),
        .I2(counter_reg[3]),
        .I3(\maxCountReg_reg[31] [3]),
        .O(counter2_carry_i_3__2_n_0));
  LUT4 #(
    .INIT(16'h2F02)) 
    counter2_carry_i_4__2
       (.I0(\maxCountReg_reg[31] [0]),
        .I1(counter_reg[0]),
        .I2(counter_reg[1]),
        .I3(\maxCountReg_reg[31] [1]),
        .O(counter2_carry_i_4__2_n_0));
  LUT4 #(
    .INIT(16'h9009)) 
    counter2_carry_i_5__2
       (.I0(\maxCountReg_reg[31] [6]),
        .I1(counter_reg[6]),
        .I2(\maxCountReg_reg[31] [7]),
        .I3(counter_reg[7]),
        .O(counter2_carry_i_5__2_n_0));
  LUT4 #(
    .INIT(16'h9009)) 
    counter2_carry_i_6__2
       (.I0(\maxCountReg_reg[31] [4]),
        .I1(counter_reg[4]),
        .I2(\maxCountReg_reg[31] [5]),
        .I3(counter_reg[5]),
        .O(counter2_carry_i_6__2_n_0));
  LUT4 #(
    .INIT(16'h9009)) 
    counter2_carry_i_7__2
       (.I0(\maxCountReg_reg[31] [2]),
        .I1(counter_reg[2]),
        .I2(\maxCountReg_reg[31] [3]),
        .I3(counter_reg[3]),
        .O(counter2_carry_i_7__2_n_0));
  LUT4 #(
    .INIT(16'h9009)) 
    counter2_carry_i_8__2
       (.I0(\maxCountReg_reg[31] [0]),
        .I1(counter_reg[0]),
        .I2(\maxCountReg_reg[31] [1]),
        .I3(counter_reg[1]),
        .O(counter2_carry_i_8__2_n_0));
  LUT1 #(
    .INIT(2'h1)) 
    \counter[0]_i_3__5 
       (.I0(counter_reg[0]),
        .O(\counter[0]_i_3__5_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[0] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[0]_i_2__6_n_7 ),
        .Q(counter_reg[0]),
        .R(o_press_reg));
  CARRY4 \counter_reg[0]_i_2__6 
       (.CI(1'b0),
        .CO({\counter_reg[0]_i_2__6_n_0 ,\counter_reg[0]_i_2__6_n_1 ,\counter_reg[0]_i_2__6_n_2 ,\counter_reg[0]_i_2__6_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b1}),
        .O({\counter_reg[0]_i_2__6_n_4 ,\counter_reg[0]_i_2__6_n_5 ,\counter_reg[0]_i_2__6_n_6 ,\counter_reg[0]_i_2__6_n_7 }),
        .S({counter_reg[3:1],\counter[0]_i_3__5_n_0 }));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[10] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[8]_i_1__6_n_5 ),
        .Q(counter_reg[10]),
        .R(o_press_reg));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[11] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[8]_i_1__6_n_4 ),
        .Q(counter_reg[11]),
        .R(o_press_reg));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[12] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[12]_i_1__6_n_7 ),
        .Q(counter_reg[12]),
        .R(o_press_reg));
  CARRY4 \counter_reg[12]_i_1__6 
       (.CI(\counter_reg[8]_i_1__6_n_0 ),
        .CO({\counter_reg[12]_i_1__6_n_0 ,\counter_reg[12]_i_1__6_n_1 ,\counter_reg[12]_i_1__6_n_2 ,\counter_reg[12]_i_1__6_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\counter_reg[12]_i_1__6_n_4 ,\counter_reg[12]_i_1__6_n_5 ,\counter_reg[12]_i_1__6_n_6 ,\counter_reg[12]_i_1__6_n_7 }),
        .S(counter_reg[15:12]));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[13] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[12]_i_1__6_n_6 ),
        .Q(counter_reg[13]),
        .R(o_press_reg));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[14] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[12]_i_1__6_n_5 ),
        .Q(counter_reg[14]),
        .R(o_press_reg));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[15] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[12]_i_1__6_n_4 ),
        .Q(counter_reg[15]),
        .R(o_press_reg));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[16] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[16]_i_1__6_n_7 ),
        .Q(counter_reg[16]),
        .R(o_press_reg));
  CARRY4 \counter_reg[16]_i_1__6 
       (.CI(\counter_reg[12]_i_1__6_n_0 ),
        .CO({\counter_reg[16]_i_1__6_n_0 ,\counter_reg[16]_i_1__6_n_1 ,\counter_reg[16]_i_1__6_n_2 ,\counter_reg[16]_i_1__6_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\counter_reg[16]_i_1__6_n_4 ,\counter_reg[16]_i_1__6_n_5 ,\counter_reg[16]_i_1__6_n_6 ,\counter_reg[16]_i_1__6_n_7 }),
        .S(counter_reg[19:16]));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[17] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[16]_i_1__6_n_6 ),
        .Q(counter_reg[17]),
        .R(o_press_reg));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[18] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[16]_i_1__6_n_5 ),
        .Q(counter_reg[18]),
        .R(o_press_reg));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[19] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[16]_i_1__6_n_4 ),
        .Q(counter_reg[19]),
        .R(o_press_reg));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[1] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[0]_i_2__6_n_6 ),
        .Q(counter_reg[1]),
        .R(o_press_reg));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[20] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[20]_i_1__6_n_7 ),
        .Q(counter_reg[20]),
        .R(o_press_reg));
  CARRY4 \counter_reg[20]_i_1__6 
       (.CI(\counter_reg[16]_i_1__6_n_0 ),
        .CO({\counter_reg[20]_i_1__6_n_0 ,\counter_reg[20]_i_1__6_n_1 ,\counter_reg[20]_i_1__6_n_2 ,\counter_reg[20]_i_1__6_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\counter_reg[20]_i_1__6_n_4 ,\counter_reg[20]_i_1__6_n_5 ,\counter_reg[20]_i_1__6_n_6 ,\counter_reg[20]_i_1__6_n_7 }),
        .S(counter_reg[23:20]));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[21] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[20]_i_1__6_n_6 ),
        .Q(counter_reg[21]),
        .R(o_press_reg));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[22] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[20]_i_1__6_n_5 ),
        .Q(counter_reg[22]),
        .R(o_press_reg));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[23] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[20]_i_1__6_n_4 ),
        .Q(counter_reg[23]),
        .R(o_press_reg));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[24] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[24]_i_1__6_n_7 ),
        .Q(counter_reg[24]),
        .R(o_press_reg));
  CARRY4 \counter_reg[24]_i_1__6 
       (.CI(\counter_reg[20]_i_1__6_n_0 ),
        .CO({\counter_reg[24]_i_1__6_n_0 ,\counter_reg[24]_i_1__6_n_1 ,\counter_reg[24]_i_1__6_n_2 ,\counter_reg[24]_i_1__6_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\counter_reg[24]_i_1__6_n_4 ,\counter_reg[24]_i_1__6_n_5 ,\counter_reg[24]_i_1__6_n_6 ,\counter_reg[24]_i_1__6_n_7 }),
        .S(counter_reg[27:24]));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[25] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[24]_i_1__6_n_6 ),
        .Q(counter_reg[25]),
        .R(o_press_reg));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[26] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[24]_i_1__6_n_5 ),
        .Q(counter_reg[26]),
        .R(o_press_reg));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[27] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[24]_i_1__6_n_4 ),
        .Q(counter_reg[27]),
        .R(o_press_reg));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[28] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[28]_i_1__6_n_7 ),
        .Q(counter_reg[28]),
        .R(o_press_reg));
  CARRY4 \counter_reg[28]_i_1__6 
       (.CI(\counter_reg[24]_i_1__6_n_0 ),
        .CO({\NLW_counter_reg[28]_i_1__6_CO_UNCONNECTED [3],\counter_reg[28]_i_1__6_n_1 ,\counter_reg[28]_i_1__6_n_2 ,\counter_reg[28]_i_1__6_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\counter_reg[28]_i_1__6_n_4 ,\counter_reg[28]_i_1__6_n_5 ,\counter_reg[28]_i_1__6_n_6 ,\counter_reg[28]_i_1__6_n_7 }),
        .S(counter_reg[31:28]));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[29] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[28]_i_1__6_n_6 ),
        .Q(counter_reg[29]),
        .R(o_press_reg));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[2] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[0]_i_2__6_n_5 ),
        .Q(counter_reg[2]),
        .R(o_press_reg));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[30] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[28]_i_1__6_n_5 ),
        .Q(counter_reg[30]),
        .R(o_press_reg));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[31] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[28]_i_1__6_n_4 ),
        .Q(counter_reg[31]),
        .R(o_press_reg));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[3] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[0]_i_2__6_n_4 ),
        .Q(counter_reg[3]),
        .R(o_press_reg));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[4] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[4]_i_1__6_n_7 ),
        .Q(counter_reg[4]),
        .R(o_press_reg));
  CARRY4 \counter_reg[4]_i_1__6 
       (.CI(\counter_reg[0]_i_2__6_n_0 ),
        .CO({\counter_reg[4]_i_1__6_n_0 ,\counter_reg[4]_i_1__6_n_1 ,\counter_reg[4]_i_1__6_n_2 ,\counter_reg[4]_i_1__6_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\counter_reg[4]_i_1__6_n_4 ,\counter_reg[4]_i_1__6_n_5 ,\counter_reg[4]_i_1__6_n_6 ,\counter_reg[4]_i_1__6_n_7 }),
        .S(counter_reg[7:4]));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[5] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[4]_i_1__6_n_6 ),
        .Q(counter_reg[5]),
        .R(o_press_reg));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[6] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[4]_i_1__6_n_5 ),
        .Q(counter_reg[6]),
        .R(o_press_reg));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[7] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[4]_i_1__6_n_4 ),
        .Q(counter_reg[7]),
        .R(o_press_reg));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[8] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[8]_i_1__6_n_7 ),
        .Q(counter_reg[8]),
        .R(o_press_reg));
  CARRY4 \counter_reg[8]_i_1__6 
       (.CI(\counter_reg[4]_i_1__6_n_0 ),
        .CO({\counter_reg[8]_i_1__6_n_0 ,\counter_reg[8]_i_1__6_n_1 ,\counter_reg[8]_i_1__6_n_2 ,\counter_reg[8]_i_1__6_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\counter_reg[8]_i_1__6_n_4 ,\counter_reg[8]_i_1__6_n_5 ,\counter_reg[8]_i_1__6_n_6 ,\counter_reg[8]_i_1__6_n_7 }),
        .S(counter_reg[11:8]));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[9] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\counter_reg[8]_i_1__6_n_6 ),
        .Q(counter_reg[9]),
        .R(o_press_reg));
  CARRY4 o_pulse0_carry
       (.CI(1'b0),
        .CO({o_pulse0_carry_n_0,o_pulse0_carry_n_1,o_pulse0_carry_n_2,o_pulse0_carry_n_3}),
        .CYINIT(1'b1),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(NLW_o_pulse0_carry_O_UNCONNECTED[3:0]),
        .S({o_pulse0_carry_i_1__2_n_0,o_pulse0_carry_i_2__2_n_0,o_pulse0_carry_i_3__2_n_0,o_pulse0_carry_i_4__2_n_0}));
  CARRY4 o_pulse0_carry__0
       (.CI(o_pulse0_carry_n_0),
        .CO({o_pulse0_carry__0_n_0,o_pulse0_carry__0_n_1,o_pulse0_carry__0_n_2,o_pulse0_carry__0_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(NLW_o_pulse0_carry__0_O_UNCONNECTED[3:0]),
        .S({o_pulse0_carry__0_i_1__2_n_0,o_pulse0_carry__0_i_2__2_n_0,o_pulse0_carry__0_i_3__2_n_0,o_pulse0_carry__0_i_4__2_n_0}));
  LUT6 #(
    .INIT(64'h9009000000009009)) 
    o_pulse0_carry__0_i_1__2
       (.I0(counter_reg[21]),
        .I1(\maxCountReg_reg[31] [21]),
        .I2(\maxCountReg_reg[31] [23]),
        .I3(counter_reg[23]),
        .I4(\maxCountReg_reg[31] [22]),
        .I5(counter_reg[22]),
        .O(o_pulse0_carry__0_i_1__2_n_0));
  LUT6 #(
    .INIT(64'h9009000000009009)) 
    o_pulse0_carry__0_i_2__2
       (.I0(counter_reg[18]),
        .I1(\maxCountReg_reg[31] [18]),
        .I2(\maxCountReg_reg[31] [20]),
        .I3(counter_reg[20]),
        .I4(\maxCountReg_reg[31] [19]),
        .I5(counter_reg[19]),
        .O(o_pulse0_carry__0_i_2__2_n_0));
  LUT6 #(
    .INIT(64'h9009000000009009)) 
    o_pulse0_carry__0_i_3__2
       (.I0(counter_reg[15]),
        .I1(\maxCountReg_reg[31] [15]),
        .I2(\maxCountReg_reg[31] [17]),
        .I3(counter_reg[17]),
        .I4(\maxCountReg_reg[31] [16]),
        .I5(counter_reg[16]),
        .O(o_pulse0_carry__0_i_3__2_n_0));
  LUT6 #(
    .INIT(64'h9009000000009009)) 
    o_pulse0_carry__0_i_4__2
       (.I0(counter_reg[12]),
        .I1(\maxCountReg_reg[31] [12]),
        .I2(\maxCountReg_reg[31] [14]),
        .I3(counter_reg[14]),
        .I4(\maxCountReg_reg[31] [13]),
        .I5(counter_reg[13]),
        .O(o_pulse0_carry__0_i_4__2_n_0));
  CARRY4 o_pulse0_carry__1
       (.CI(o_pulse0_carry__0_n_0),
        .CO({NLW_o_pulse0_carry__1_CO_UNCONNECTED[3],o_pulse0_carry__1_n_1,o_pulse0_carry__1_n_2,o_pulse0_carry__1_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(NLW_o_pulse0_carry__1_O_UNCONNECTED[3:0]),
        .S({1'b0,o_pulse0_carry__1_i_1__2_n_0,o_pulse0_carry__1_i_2__2_n_0,o_pulse0_carry__1_i_3__2_n_0}));
  LUT4 #(
    .INIT(16'h9009)) 
    o_pulse0_carry__1_i_1__2
       (.I0(counter_reg[30]),
        .I1(\maxCountReg_reg[31] [30]),
        .I2(counter_reg[31]),
        .I3(\maxCountReg_reg[31] [31]),
        .O(o_pulse0_carry__1_i_1__2_n_0));
  LUT6 #(
    .INIT(64'h9009000000009009)) 
    o_pulse0_carry__1_i_2__2
       (.I0(counter_reg[27]),
        .I1(\maxCountReg_reg[31] [27]),
        .I2(\maxCountReg_reg[31] [29]),
        .I3(counter_reg[29]),
        .I4(\maxCountReg_reg[31] [28]),
        .I5(counter_reg[28]),
        .O(o_pulse0_carry__1_i_2__2_n_0));
  LUT6 #(
    .INIT(64'h9009000000009009)) 
    o_pulse0_carry__1_i_3__2
       (.I0(counter_reg[24]),
        .I1(\maxCountReg_reg[31] [24]),
        .I2(\maxCountReg_reg[31] [26]),
        .I3(counter_reg[26]),
        .I4(\maxCountReg_reg[31] [25]),
        .I5(counter_reg[25]),
        .O(o_pulse0_carry__1_i_3__2_n_0));
  LUT6 #(
    .INIT(64'h9009000000009009)) 
    o_pulse0_carry_i_1__2
       (.I0(counter_reg[9]),
        .I1(\maxCountReg_reg[31] [9]),
        .I2(\maxCountReg_reg[31] [11]),
        .I3(counter_reg[11]),
        .I4(\maxCountReg_reg[31] [10]),
        .I5(counter_reg[10]),
        .O(o_pulse0_carry_i_1__2_n_0));
  LUT6 #(
    .INIT(64'h9009000000009009)) 
    o_pulse0_carry_i_2__2
       (.I0(counter_reg[6]),
        .I1(\maxCountReg_reg[31] [6]),
        .I2(\maxCountReg_reg[31] [8]),
        .I3(counter_reg[8]),
        .I4(\maxCountReg_reg[31] [7]),
        .I5(counter_reg[7]),
        .O(o_pulse0_carry_i_2__2_n_0));
  LUT6 #(
    .INIT(64'h9009000000009009)) 
    o_pulse0_carry_i_3__2
       (.I0(counter_reg[3]),
        .I1(\maxCountReg_reg[31] [3]),
        .I2(\maxCountReg_reg[31] [5]),
        .I3(counter_reg[5]),
        .I4(\maxCountReg_reg[31] [4]),
        .I5(counter_reg[4]),
        .O(o_pulse0_carry_i_3__2_n_0));
  LUT6 #(
    .INIT(64'h9009000000009009)) 
    o_pulse0_carry_i_4__2
       (.I0(counter_reg[0]),
        .I1(\maxCountReg_reg[31] [0]),
        .I2(\maxCountReg_reg[31] [2]),
        .I3(counter_reg[2]),
        .I4(\maxCountReg_reg[31] [1]),
        .I5(counter_reg[1]),
        .O(o_pulse0_carry_i_4__2_n_0));
  FDRE o_pulse_reg
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(o_pulse0_carry__1_n_1),
        .Q(\o_y_pos_reg[0] ),
        .R(1'b0));
  LUT5 #(
    .INIT(32'hFFEAAAEA)) 
    \o_y_pos[0]_i_1 
       (.I0(Q),
        .I1(p_1_in),
        .I2(\o_y_pos_reg[0] ),
        .I3(o_pulse_reg_0),
        .I4(\maxCoordinateReg_reg[30] ),
        .O(\o_y_pos_reg[0]_0 ));
endmodule

module decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_singlePulseDebounce
   (w_button_pulse,
    \intrStatReg_reg[0] ,
    s00_axi_aclk,
    s00_axi_wdata,
    \axi_awaddr_reg[4] ,
    \intrStatReg_reg[0]_0 ,
    i_button_press);
  output w_button_pulse;
  output \intrStatReg_reg[0] ;
  input s00_axi_aclk;
  input [0:0]s00_axi_wdata;
  input \axi_awaddr_reg[4] ;
  input \intrStatReg_reg[0]_0 ;
  input i_button_press;

  wire \axi_awaddr_reg[4] ;
  wire counter;
  wire counter1_carry__0_i_1_n_0;
  wire counter1_carry__0_i_2_n_0;
  wire counter1_carry__0_i_3_n_0;
  wire counter1_carry__0_i_4__3_n_0;
  wire counter1_carry__0_i_5__3_n_0;
  wire counter1_carry__0_i_6__3_n_0;
  wire counter1_carry__0_i_7__3_n_0;
  wire counter1_carry__0_n_0;
  wire counter1_carry__0_n_1;
  wire counter1_carry__0_n_2;
  wire counter1_carry__0_n_3;
  wire counter1_carry__1_i_1__3_n_0;
  wire counter1_carry__1_i_2__3_n_0;
  wire counter1_carry__1_i_3__3_n_0;
  wire counter1_carry__1_i_4__3_n_0;
  wire counter1_carry__1_n_0;
  wire counter1_carry__1_n_1;
  wire counter1_carry__1_n_2;
  wire counter1_carry__1_n_3;
  wire counter1_carry__2_i_1__3_n_0;
  wire counter1_carry__2_n_3;
  wire counter1_carry_i_1_n_0;
  wire counter1_carry_i_2_n_0;
  wire counter1_carry_i_3__3_n_0;
  wire counter1_carry_i_4__3_n_0;
  wire counter1_carry_i_5__3_n_0;
  wire counter1_carry_i_6__3_n_0;
  wire counter1_carry_n_0;
  wire counter1_carry_n_1;
  wire counter1_carry_n_2;
  wire counter1_carry_n_3;
  wire \counter[0]_i_3__3_n_0 ;
  wire [31:0]counter_reg;
  wire \counter_reg[0]_i_2__7_n_0 ;
  wire \counter_reg[0]_i_2__7_n_1 ;
  wire \counter_reg[0]_i_2__7_n_2 ;
  wire \counter_reg[0]_i_2__7_n_3 ;
  wire \counter_reg[0]_i_2__7_n_4 ;
  wire \counter_reg[0]_i_2__7_n_5 ;
  wire \counter_reg[0]_i_2__7_n_6 ;
  wire \counter_reg[0]_i_2__7_n_7 ;
  wire \counter_reg[12]_i_1__7_n_0 ;
  wire \counter_reg[12]_i_1__7_n_1 ;
  wire \counter_reg[12]_i_1__7_n_2 ;
  wire \counter_reg[12]_i_1__7_n_3 ;
  wire \counter_reg[12]_i_1__7_n_4 ;
  wire \counter_reg[12]_i_1__7_n_5 ;
  wire \counter_reg[12]_i_1__7_n_6 ;
  wire \counter_reg[12]_i_1__7_n_7 ;
  wire \counter_reg[16]_i_1__7_n_0 ;
  wire \counter_reg[16]_i_1__7_n_1 ;
  wire \counter_reg[16]_i_1__7_n_2 ;
  wire \counter_reg[16]_i_1__7_n_3 ;
  wire \counter_reg[16]_i_1__7_n_4 ;
  wire \counter_reg[16]_i_1__7_n_5 ;
  wire \counter_reg[16]_i_1__7_n_6 ;
  wire \counter_reg[16]_i_1__7_n_7 ;
  wire \counter_reg[20]_i_1__7_n_0 ;
  wire \counter_reg[20]_i_1__7_n_1 ;
  wire \counter_reg[20]_i_1__7_n_2 ;
  wire \counter_reg[20]_i_1__7_n_3 ;
  wire \counter_reg[20]_i_1__7_n_4 ;
  wire \counter_reg[20]_i_1__7_n_5 ;
  wire \counter_reg[20]_i_1__7_n_6 ;
  wire \counter_reg[20]_i_1__7_n_7 ;
  wire \counter_reg[24]_i_1__7_n_0 ;
  wire \counter_reg[24]_i_1__7_n_1 ;
  wire \counter_reg[24]_i_1__7_n_2 ;
  wire \counter_reg[24]_i_1__7_n_3 ;
  wire \counter_reg[24]_i_1__7_n_4 ;
  wire \counter_reg[24]_i_1__7_n_5 ;
  wire \counter_reg[24]_i_1__7_n_6 ;
  wire \counter_reg[24]_i_1__7_n_7 ;
  wire \counter_reg[28]_i_1__7_n_1 ;
  wire \counter_reg[28]_i_1__7_n_2 ;
  wire \counter_reg[28]_i_1__7_n_3 ;
  wire \counter_reg[28]_i_1__7_n_4 ;
  wire \counter_reg[28]_i_1__7_n_5 ;
  wire \counter_reg[28]_i_1__7_n_6 ;
  wire \counter_reg[28]_i_1__7_n_7 ;
  wire \counter_reg[4]_i_1__7_n_0 ;
  wire \counter_reg[4]_i_1__7_n_1 ;
  wire \counter_reg[4]_i_1__7_n_2 ;
  wire \counter_reg[4]_i_1__7_n_3 ;
  wire \counter_reg[4]_i_1__7_n_4 ;
  wire \counter_reg[4]_i_1__7_n_5 ;
  wire \counter_reg[4]_i_1__7_n_6 ;
  wire \counter_reg[4]_i_1__7_n_7 ;
  wire \counter_reg[8]_i_1__7_n_0 ;
  wire \counter_reg[8]_i_1__7_n_1 ;
  wire \counter_reg[8]_i_1__7_n_2 ;
  wire \counter_reg[8]_i_1__7_n_3 ;
  wire \counter_reg[8]_i_1__7_n_4 ;
  wire \counter_reg[8]_i_1__7_n_5 ;
  wire \counter_reg[8]_i_1__7_n_6 ;
  wire \counter_reg[8]_i_1__7_n_7 ;
  wire i_button_press;
  wire \intrStatReg_reg[0] ;
  wire \intrStatReg_reg[0]_0 ;
  wire o_press_i_1__3_n_0;
  wire o_press_i_2__3_n_0;
  wire o_press_i_3__3_n_0;
  wire o_press_i_4__3_n_0;
  wire o_press_i_5__3_n_0;
  wire o_press_i_6__3_n_0;
  wire o_press_i_7__3_n_0;
  wire o_press_i_8__3_n_0;
  wire o_press_i_9__3_n_0;
  wire s00_axi_aclk;
  wire [0:0]s00_axi_wdata;
  wire w_button_pulse;
  wire [3:0]NLW_counter1_carry_O_UNCONNECTED;
  wire [3:0]NLW_counter1_carry__0_O_UNCONNECTED;
  wire [3:0]NLW_counter1_carry__1_O_UNCONNECTED;
  wire [3:1]NLW_counter1_carry__2_CO_UNCONNECTED;
  wire [3:0]NLW_counter1_carry__2_O_UNCONNECTED;
  wire [3:3]\NLW_counter_reg[28]_i_1__7_CO_UNCONNECTED ;

  CARRY4 counter1_carry
       (.CI(1'b0),
        .CO({counter1_carry_n_0,counter1_carry_n_1,counter1_carry_n_2,counter1_carry_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,counter1_carry_i_1_n_0,counter1_carry_i_2_n_0}),
        .O(NLW_counter1_carry_O_UNCONNECTED[3:0]),
        .S({counter1_carry_i_3__3_n_0,counter1_carry_i_4__3_n_0,counter1_carry_i_5__3_n_0,counter1_carry_i_6__3_n_0}));
  CARRY4 counter1_carry__0
       (.CI(counter1_carry_n_0),
        .CO({counter1_carry__0_n_0,counter1_carry__0_n_1,counter1_carry__0_n_2,counter1_carry__0_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,counter1_carry__0_i_1_n_0,counter1_carry__0_i_2_n_0,counter1_carry__0_i_3_n_0}),
        .O(NLW_counter1_carry__0_O_UNCONNECTED[3:0]),
        .S({counter1_carry__0_i_4__3_n_0,counter1_carry__0_i_5__3_n_0,counter1_carry__0_i_6__3_n_0,counter1_carry__0_i_7__3_n_0}));
  LUT2 #(
    .INIT(4'h7)) 
    counter1_carry__0_i_1
       (.I0(counter_reg[18]),
        .I1(counter_reg[19]),
        .O(counter1_carry__0_i_1_n_0));
  LUT2 #(
    .INIT(4'h7)) 
    counter1_carry__0_i_2
       (.I0(counter_reg[16]),
        .I1(counter_reg[17]),
        .O(counter1_carry__0_i_2_n_0));
  LUT2 #(
    .INIT(4'h1)) 
    counter1_carry__0_i_3
       (.I0(counter_reg[14]),
        .I1(counter_reg[15]),
        .O(counter1_carry__0_i_3_n_0));
  LUT2 #(
    .INIT(4'h1)) 
    counter1_carry__0_i_4__3
       (.I0(counter_reg[20]),
        .I1(counter_reg[21]),
        .O(counter1_carry__0_i_4__3_n_0));
  LUT2 #(
    .INIT(4'h8)) 
    counter1_carry__0_i_5__3
       (.I0(counter_reg[18]),
        .I1(counter_reg[19]),
        .O(counter1_carry__0_i_5__3_n_0));
  LUT2 #(
    .INIT(4'h8)) 
    counter1_carry__0_i_6__3
       (.I0(counter_reg[16]),
        .I1(counter_reg[17]),
        .O(counter1_carry__0_i_6__3_n_0));
  LUT2 #(
    .INIT(4'h2)) 
    counter1_carry__0_i_7__3
       (.I0(counter_reg[14]),
        .I1(counter_reg[15]),
        .O(counter1_carry__0_i_7__3_n_0));
  CARRY4 counter1_carry__1
       (.CI(counter1_carry__0_n_0),
        .CO({counter1_carry__1_n_0,counter1_carry__1_n_1,counter1_carry__1_n_2,counter1_carry__1_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(NLW_counter1_carry__1_O_UNCONNECTED[3:0]),
        .S({counter1_carry__1_i_1__3_n_0,counter1_carry__1_i_2__3_n_0,counter1_carry__1_i_3__3_n_0,counter1_carry__1_i_4__3_n_0}));
  LUT2 #(
    .INIT(4'h1)) 
    counter1_carry__1_i_1__3
       (.I0(counter_reg[28]),
        .I1(counter_reg[29]),
        .O(counter1_carry__1_i_1__3_n_0));
  LUT2 #(
    .INIT(4'h1)) 
    counter1_carry__1_i_2__3
       (.I0(counter_reg[26]),
        .I1(counter_reg[27]),
        .O(counter1_carry__1_i_2__3_n_0));
  LUT2 #(
    .INIT(4'h1)) 
    counter1_carry__1_i_3__3
       (.I0(counter_reg[24]),
        .I1(counter_reg[25]),
        .O(counter1_carry__1_i_3__3_n_0));
  LUT2 #(
    .INIT(4'h1)) 
    counter1_carry__1_i_4__3
       (.I0(counter_reg[22]),
        .I1(counter_reg[23]),
        .O(counter1_carry__1_i_4__3_n_0));
  CARRY4 counter1_carry__2
       (.CI(counter1_carry__1_n_0),
        .CO({NLW_counter1_carry__2_CO_UNCONNECTED[3:1],counter1_carry__2_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,counter_reg[31]}),
        .O(NLW_counter1_carry__2_O_UNCONNECTED[3:0]),
        .S({1'b0,1'b0,1'b0,counter1_carry__2_i_1__3_n_0}));
  LUT2 #(
    .INIT(4'h1)) 
    counter1_carry__2_i_1__3
       (.I0(counter_reg[31]),
        .I1(counter_reg[30]),
        .O(counter1_carry__2_i_1__3_n_0));
  LUT1 #(
    .INIT(2'h1)) 
    counter1_carry_i_1
       (.I0(counter_reg[9]),
        .O(counter1_carry_i_1_n_0));
  LUT2 #(
    .INIT(4'h1)) 
    counter1_carry_i_2
       (.I0(counter_reg[6]),
        .I1(counter_reg[7]),
        .O(counter1_carry_i_2_n_0));
  LUT2 #(
    .INIT(4'h1)) 
    counter1_carry_i_3__3
       (.I0(counter_reg[12]),
        .I1(counter_reg[13]),
        .O(counter1_carry_i_3__3_n_0));
  LUT2 #(
    .INIT(4'h1)) 
    counter1_carry_i_4__3
       (.I0(counter_reg[10]),
        .I1(counter_reg[11]),
        .O(counter1_carry_i_4__3_n_0));
  LUT2 #(
    .INIT(4'h2)) 
    counter1_carry_i_5__3
       (.I0(counter_reg[9]),
        .I1(counter_reg[8]),
        .O(counter1_carry_i_5__3_n_0));
  LUT2 #(
    .INIT(4'h2)) 
    counter1_carry_i_6__3
       (.I0(counter_reg[6]),
        .I1(counter_reg[7]),
        .O(counter1_carry_i_6__3_n_0));
  LUT1 #(
    .INIT(2'h1)) 
    \counter[0]_i_1__7 
       (.I0(i_button_press),
        .O(counter));
  LUT1 #(
    .INIT(2'h1)) 
    \counter[0]_i_3__3 
       (.I0(counter_reg[0]),
        .O(\counter[0]_i_3__3_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[0] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[0]_i_2__7_n_7 ),
        .Q(counter_reg[0]),
        .R(counter));
  CARRY4 \counter_reg[0]_i_2__7 
       (.CI(1'b0),
        .CO({\counter_reg[0]_i_2__7_n_0 ,\counter_reg[0]_i_2__7_n_1 ,\counter_reg[0]_i_2__7_n_2 ,\counter_reg[0]_i_2__7_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b1}),
        .O({\counter_reg[0]_i_2__7_n_4 ,\counter_reg[0]_i_2__7_n_5 ,\counter_reg[0]_i_2__7_n_6 ,\counter_reg[0]_i_2__7_n_7 }),
        .S({counter_reg[3:1],\counter[0]_i_3__3_n_0 }));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[10] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[8]_i_1__7_n_5 ),
        .Q(counter_reg[10]),
        .R(counter));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[11] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[8]_i_1__7_n_4 ),
        .Q(counter_reg[11]),
        .R(counter));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[12] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[12]_i_1__7_n_7 ),
        .Q(counter_reg[12]),
        .R(counter));
  CARRY4 \counter_reg[12]_i_1__7 
       (.CI(\counter_reg[8]_i_1__7_n_0 ),
        .CO({\counter_reg[12]_i_1__7_n_0 ,\counter_reg[12]_i_1__7_n_1 ,\counter_reg[12]_i_1__7_n_2 ,\counter_reg[12]_i_1__7_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\counter_reg[12]_i_1__7_n_4 ,\counter_reg[12]_i_1__7_n_5 ,\counter_reg[12]_i_1__7_n_6 ,\counter_reg[12]_i_1__7_n_7 }),
        .S(counter_reg[15:12]));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[13] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[12]_i_1__7_n_6 ),
        .Q(counter_reg[13]),
        .R(counter));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[14] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[12]_i_1__7_n_5 ),
        .Q(counter_reg[14]),
        .R(counter));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[15] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[12]_i_1__7_n_4 ),
        .Q(counter_reg[15]),
        .R(counter));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[16] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[16]_i_1__7_n_7 ),
        .Q(counter_reg[16]),
        .R(counter));
  CARRY4 \counter_reg[16]_i_1__7 
       (.CI(\counter_reg[12]_i_1__7_n_0 ),
        .CO({\counter_reg[16]_i_1__7_n_0 ,\counter_reg[16]_i_1__7_n_1 ,\counter_reg[16]_i_1__7_n_2 ,\counter_reg[16]_i_1__7_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\counter_reg[16]_i_1__7_n_4 ,\counter_reg[16]_i_1__7_n_5 ,\counter_reg[16]_i_1__7_n_6 ,\counter_reg[16]_i_1__7_n_7 }),
        .S(counter_reg[19:16]));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[17] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[16]_i_1__7_n_6 ),
        .Q(counter_reg[17]),
        .R(counter));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[18] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[16]_i_1__7_n_5 ),
        .Q(counter_reg[18]),
        .R(counter));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[19] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[16]_i_1__7_n_4 ),
        .Q(counter_reg[19]),
        .R(counter));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[1] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[0]_i_2__7_n_6 ),
        .Q(counter_reg[1]),
        .R(counter));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[20] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[20]_i_1__7_n_7 ),
        .Q(counter_reg[20]),
        .R(counter));
  CARRY4 \counter_reg[20]_i_1__7 
       (.CI(\counter_reg[16]_i_1__7_n_0 ),
        .CO({\counter_reg[20]_i_1__7_n_0 ,\counter_reg[20]_i_1__7_n_1 ,\counter_reg[20]_i_1__7_n_2 ,\counter_reg[20]_i_1__7_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\counter_reg[20]_i_1__7_n_4 ,\counter_reg[20]_i_1__7_n_5 ,\counter_reg[20]_i_1__7_n_6 ,\counter_reg[20]_i_1__7_n_7 }),
        .S(counter_reg[23:20]));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[21] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[20]_i_1__7_n_6 ),
        .Q(counter_reg[21]),
        .R(counter));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[22] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[20]_i_1__7_n_5 ),
        .Q(counter_reg[22]),
        .R(counter));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[23] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[20]_i_1__7_n_4 ),
        .Q(counter_reg[23]),
        .R(counter));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[24] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[24]_i_1__7_n_7 ),
        .Q(counter_reg[24]),
        .R(counter));
  CARRY4 \counter_reg[24]_i_1__7 
       (.CI(\counter_reg[20]_i_1__7_n_0 ),
        .CO({\counter_reg[24]_i_1__7_n_0 ,\counter_reg[24]_i_1__7_n_1 ,\counter_reg[24]_i_1__7_n_2 ,\counter_reg[24]_i_1__7_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\counter_reg[24]_i_1__7_n_4 ,\counter_reg[24]_i_1__7_n_5 ,\counter_reg[24]_i_1__7_n_6 ,\counter_reg[24]_i_1__7_n_7 }),
        .S(counter_reg[27:24]));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[25] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[24]_i_1__7_n_6 ),
        .Q(counter_reg[25]),
        .R(counter));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[26] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[24]_i_1__7_n_5 ),
        .Q(counter_reg[26]),
        .R(counter));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[27] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[24]_i_1__7_n_4 ),
        .Q(counter_reg[27]),
        .R(counter));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[28] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[28]_i_1__7_n_7 ),
        .Q(counter_reg[28]),
        .R(counter));
  CARRY4 \counter_reg[28]_i_1__7 
       (.CI(\counter_reg[24]_i_1__7_n_0 ),
        .CO({\NLW_counter_reg[28]_i_1__7_CO_UNCONNECTED [3],\counter_reg[28]_i_1__7_n_1 ,\counter_reg[28]_i_1__7_n_2 ,\counter_reg[28]_i_1__7_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\counter_reg[28]_i_1__7_n_4 ,\counter_reg[28]_i_1__7_n_5 ,\counter_reg[28]_i_1__7_n_6 ,\counter_reg[28]_i_1__7_n_7 }),
        .S(counter_reg[31:28]));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[29] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[28]_i_1__7_n_6 ),
        .Q(counter_reg[29]),
        .R(counter));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[2] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[0]_i_2__7_n_5 ),
        .Q(counter_reg[2]),
        .R(counter));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[30] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[28]_i_1__7_n_5 ),
        .Q(counter_reg[30]),
        .R(counter));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[31] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[28]_i_1__7_n_4 ),
        .Q(counter_reg[31]),
        .R(counter));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[3] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[0]_i_2__7_n_4 ),
        .Q(counter_reg[3]),
        .R(counter));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[4] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[4]_i_1__7_n_7 ),
        .Q(counter_reg[4]),
        .R(counter));
  CARRY4 \counter_reg[4]_i_1__7 
       (.CI(\counter_reg[0]_i_2__7_n_0 ),
        .CO({\counter_reg[4]_i_1__7_n_0 ,\counter_reg[4]_i_1__7_n_1 ,\counter_reg[4]_i_1__7_n_2 ,\counter_reg[4]_i_1__7_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\counter_reg[4]_i_1__7_n_4 ,\counter_reg[4]_i_1__7_n_5 ,\counter_reg[4]_i_1__7_n_6 ,\counter_reg[4]_i_1__7_n_7 }),
        .S(counter_reg[7:4]));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[5] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[4]_i_1__7_n_6 ),
        .Q(counter_reg[5]),
        .R(counter));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[6] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[4]_i_1__7_n_5 ),
        .Q(counter_reg[6]),
        .R(counter));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[7] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[4]_i_1__7_n_4 ),
        .Q(counter_reg[7]),
        .R(counter));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[8] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[8]_i_1__7_n_7 ),
        .Q(counter_reg[8]),
        .R(counter));
  CARRY4 \counter_reg[8]_i_1__7 
       (.CI(\counter_reg[4]_i_1__7_n_0 ),
        .CO({\counter_reg[8]_i_1__7_n_0 ,\counter_reg[8]_i_1__7_n_1 ,\counter_reg[8]_i_1__7_n_2 ,\counter_reg[8]_i_1__7_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\counter_reg[8]_i_1__7_n_4 ,\counter_reg[8]_i_1__7_n_5 ,\counter_reg[8]_i_1__7_n_6 ,\counter_reg[8]_i_1__7_n_7 }),
        .S(counter_reg[11:8]));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[9] 
       (.C(s00_axi_aclk),
        .CE(counter1_carry__2_n_3),
        .D(\counter_reg[8]_i_1__7_n_6 ),
        .Q(counter_reg[9]),
        .R(counter));
  LUT4 #(
    .INIT(16'hF5CA)) 
    \intrStatReg[0]_i_1 
       (.I0(s00_axi_wdata),
        .I1(w_button_pulse),
        .I2(\axi_awaddr_reg[4] ),
        .I3(\intrStatReg_reg[0]_0 ),
        .O(\intrStatReg_reg[0] ));
  LUT6 #(
    .INIT(64'h0000000000000001)) 
    o_press_i_1__3
       (.I0(o_press_i_2__3_n_0),
        .I1(o_press_i_3__3_n_0),
        .I2(counter_reg[30]),
        .I3(counter_reg[31]),
        .I4(o_press_i_4__3_n_0),
        .I5(o_press_i_5__3_n_0),
        .O(o_press_i_1__3_n_0));
  LUT5 #(
    .INIT(32'hFFFFFFFE)) 
    o_press_i_2__3
       (.I0(counter_reg[21]),
        .I1(counter_reg[20]),
        .I2(counter_reg[23]),
        .I3(counter_reg[22]),
        .I4(o_press_i_6__3_n_0),
        .O(o_press_i_2__3_n_0));
  LUT2 #(
    .INIT(4'hE)) 
    o_press_i_3__3
       (.I0(counter_reg[29]),
        .I1(counter_reg[28]),
        .O(o_press_i_3__3_n_0));
  LUT4 #(
    .INIT(16'hFFFE)) 
    o_press_i_4__3
       (.I0(counter_reg[26]),
        .I1(counter_reg[27]),
        .I2(counter_reg[24]),
        .I3(counter_reg[25]),
        .O(o_press_i_4__3_n_0));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFFFFE)) 
    o_press_i_5__3
       (.I0(o_press_i_7__3_n_0),
        .I1(counter_reg[10]),
        .I2(counter_reg[15]),
        .I3(counter_reg[12]),
        .I4(counter_reg[13]),
        .I5(o_press_i_8__3_n_0),
        .O(o_press_i_5__3_n_0));
  LUT4 #(
    .INIT(16'hFFFE)) 
    o_press_i_6__3
       (.I0(counter_reg[6]),
        .I1(counter_reg[11]),
        .I2(counter_reg[8]),
        .I3(counter_reg[7]),
        .O(o_press_i_6__3_n_0));
  LUT4 #(
    .INIT(16'h7FFF)) 
    o_press_i_7__3
       (.I0(counter_reg[14]),
        .I1(counter_reg[19]),
        .I2(counter_reg[16]),
        .I3(counter_reg[9]),
        .O(o_press_i_7__3_n_0));
  LUT5 #(
    .INIT(32'hFFFF7FFF)) 
    o_press_i_8__3
       (.I0(counter_reg[5]),
        .I1(counter_reg[4]),
        .I2(counter_reg[17]),
        .I3(counter_reg[18]),
        .I4(o_press_i_9__3_n_0),
        .O(o_press_i_8__3_n_0));
  LUT4 #(
    .INIT(16'h7FFF)) 
    o_press_i_9__3
       (.I0(counter_reg[2]),
        .I1(counter_reg[3]),
        .I2(counter_reg[0]),
        .I3(counter_reg[1]),
        .O(o_press_i_9__3_n_0));
  FDRE o_press_reg
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(o_press_i_1__3_n_0),
        .Q(w_button_pulse),
        .R(1'b0));
endmodule

(* CHECK_LICENSE_TYPE = "system_zyMouse_0_0,zyMouse_v1_0,{}" *) (* DowngradeIPIdentifiedWarnings = "yes" *) (* X_CORE_INFO = "zyMouse_v1_0,Vivado 2017.4" *) 
(* NotValidForBitStream *)
module decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix
   (s00_axi_awaddr,
    s00_axi_awprot,
    s00_axi_awvalid,
    s00_axi_awready,
    s00_axi_wdata,
    s00_axi_wstrb,
    s00_axi_wvalid,
    s00_axi_wready,
    s00_axi_bresp,
    s00_axi_bvalid,
    s00_axi_bready,
    s00_axi_araddr,
    s00_axi_arprot,
    s00_axi_arvalid,
    s00_axi_arready,
    s00_axi_rdata,
    s00_axi_rresp,
    s00_axi_rvalid,
    s00_axi_rready,
    i_button_left,
    i_button_right,
    i_button_up,
    i_button_down,
    i_button_press,
    o_intr,
    s00_axi_aclk,
    s00_axi_aresetn);
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S00_AXI AWADDR" *) input [7:0]s00_axi_awaddr;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S00_AXI AWPROT" *) input [2:0]s00_axi_awprot;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S00_AXI AWVALID" *) input s00_axi_awvalid;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S00_AXI AWREADY" *) output s00_axi_awready;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S00_AXI WDATA" *) input [31:0]s00_axi_wdata;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S00_AXI WSTRB" *) input [3:0]s00_axi_wstrb;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S00_AXI WVALID" *) input s00_axi_wvalid;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S00_AXI WREADY" *) output s00_axi_wready;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S00_AXI BRESP" *) output [1:0]s00_axi_bresp;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S00_AXI BVALID" *) output s00_axi_bvalid;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S00_AXI BREADY" *) input s00_axi_bready;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S00_AXI ARADDR" *) input [7:0]s00_axi_araddr;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S00_AXI ARPROT" *) input [2:0]s00_axi_arprot;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S00_AXI ARVALID" *) input s00_axi_arvalid;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S00_AXI ARREADY" *) output s00_axi_arready;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S00_AXI RDATA" *) output [31:0]s00_axi_rdata;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S00_AXI RRESP" *) output [1:0]s00_axi_rresp;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S00_AXI RVALID" *) output s00_axi_rvalid;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S00_AXI RREADY" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME S00_AXI, WIZ_DATA_WIDTH 32, WIZ_NUM_REG 4, SUPPORTS_NARROW_BURST 0, DATA_WIDTH 32, PROTOCOL AXI4LITE, FREQ_HZ 99776785, ID_WIDTH 0, ADDR_WIDTH 8, AWUSER_WIDTH 0, ARUSER_WIDTH 0, WUSER_WIDTH 0, RUSER_WIDTH 0, BUSER_WIDTH 0, READ_WRITE_MODE READ_WRITE, HAS_BURST 0, HAS_LOCK 0, HAS_PROT 1, HAS_CACHE 0, HAS_QOS 0, HAS_REGION 0, HAS_WSTRB 1, HAS_BRESP 1, HAS_RRESP 1, NUM_READ_OUTSTANDING 2, NUM_WRITE_OUTSTANDING 2, MAX_BURST_LENGTH 1, PHASE 0.0, CLK_DOMAIN /clk_wiz_0_clk_out1, NUM_READ_THREADS 1, NUM_WRITE_THREADS 1, RUSER_BITS_PER_BYTE 0, WUSER_BITS_PER_BYTE 0" *) input s00_axi_rready;
  input i_button_left;
  input i_button_right;
  input i_button_up;
  input i_button_down;
  input i_button_press;
  (* X_INTERFACE_INFO = "xilinx.com:signal:interrupt:1.0 o_intr INTERRUPT" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME o_intr, SENSITIVITY LEVEL_HIGH, PortWidth 1" *) output o_intr;
  (* X_INTERFACE_INFO = "xilinx.com:signal:clock:1.0 S00_AXI_CLK CLK" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME S00_AXI_CLK, ASSOCIATED_BUSIF S00_AXI, ASSOCIATED_RESET s00_axi_aresetn, FREQ_HZ 99776785, PHASE 0.0, CLK_DOMAIN /clk_wiz_0_clk_out1" *) input s00_axi_aclk;
  (* X_INTERFACE_INFO = "xilinx.com:signal:reset:1.0 S00_AXI_RST RST" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME S00_AXI_RST, POLARITY ACTIVE_LOW" *) input s00_axi_aresetn;

  wire \<const0> ;
  wire i_button_down;
  wire i_button_left;
  wire i_button_press;
  wire i_button_right;
  wire i_button_up;
  wire o_intr;
  wire s00_axi_aclk;
  wire [7:0]s00_axi_araddr;
  wire s00_axi_aresetn;
  wire s00_axi_arready;
  wire s00_axi_arvalid;
  wire [7:0]s00_axi_awaddr;
  wire s00_axi_awready;
  wire s00_axi_awvalid;
  wire s00_axi_bready;
  wire s00_axi_bvalid;
  wire [31:0]s00_axi_rdata;
  wire s00_axi_rready;
  wire s00_axi_rvalid;
  wire [31:0]s00_axi_wdata;
  wire s00_axi_wready;
  wire s00_axi_wvalid;

  assign s00_axi_bresp[1] = \<const0> ;
  assign s00_axi_bresp[0] = \<const0> ;
  assign s00_axi_rresp[1] = \<const0> ;
  assign s00_axi_rresp[0] = \<const0> ;
  GND GND
       (.G(\<const0> ));
  decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_zyMouse_v1_0 inst
       (.S_AXI_ARREADY(s00_axi_arready),
        .S_AXI_AWREADY(s00_axi_awready),
        .S_AXI_WREADY(s00_axi_wready),
        .i_button_down(i_button_down),
        .i_button_left(i_button_left),
        .i_button_press(i_button_press),
        .i_button_right(i_button_right),
        .i_button_up(i_button_up),
        .o_intr(o_intr),
        .s00_axi_aclk(s00_axi_aclk),
        .s00_axi_araddr(s00_axi_araddr[6:2]),
        .s00_axi_aresetn(s00_axi_aresetn),
        .s00_axi_arvalid(s00_axi_arvalid),
        .s00_axi_awaddr(s00_axi_awaddr[6:2]),
        .s00_axi_awvalid(s00_axi_awvalid),
        .s00_axi_bready(s00_axi_bready),
        .s00_axi_bvalid(s00_axi_bvalid),
        .s00_axi_rdata(s00_axi_rdata),
        .s00_axi_rready(s00_axi_rready),
        .s00_axi_rvalid(s00_axi_rvalid),
        .s00_axi_wdata(s00_axi_wdata),
        .s00_axi_wvalid(s00_axi_wvalid));
endmodule

module decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_zyMouse_v1_0
   (S_AXI_ARREADY,
    S_AXI_WREADY,
    S_AXI_AWREADY,
    s00_axi_rdata,
    o_intr,
    s00_axi_rvalid,
    s00_axi_bvalid,
    s00_axi_arvalid,
    s00_axi_aclk,
    s00_axi_awaddr,
    s00_axi_wdata,
    s00_axi_araddr,
    i_button_left,
    i_button_right,
    i_button_up,
    i_button_down,
    i_button_press,
    s00_axi_wvalid,
    s00_axi_awvalid,
    s00_axi_aresetn,
    s00_axi_bready,
    s00_axi_rready);
  output S_AXI_ARREADY;
  output S_AXI_WREADY;
  output S_AXI_AWREADY;
  output [31:0]s00_axi_rdata;
  output o_intr;
  output s00_axi_rvalid;
  output s00_axi_bvalid;
  input s00_axi_arvalid;
  input s00_axi_aclk;
  input [4:0]s00_axi_awaddr;
  input [31:0]s00_axi_wdata;
  input [4:0]s00_axi_araddr;
  input i_button_left;
  input i_button_right;
  input i_button_up;
  input i_button_down;
  input i_button_press;
  input s00_axi_wvalid;
  input s00_axi_awvalid;
  input s00_axi_aresetn;
  input s00_axi_bready;
  input s00_axi_rready;

  wire S_AXI_ARREADY;
  wire S_AXI_AWREADY;
  wire S_AXI_WREADY;
  wire aw_en_i_1_n_0;
  wire axi_awready_i_1_n_0;
  wire axi_bvalid_i_1_n_0;
  wire axi_rvalid_i_1_n_0;
  wire i_button_down;
  wire i_button_left;
  wire i_button_press;
  wire i_button_right;
  wire i_button_up;
  wire o_intr;
  wire s00_axi_aclk;
  wire [4:0]s00_axi_araddr;
  wire s00_axi_aresetn;
  wire s00_axi_arvalid;
  wire [4:0]s00_axi_awaddr;
  wire s00_axi_awvalid;
  wire s00_axi_bready;
  wire s00_axi_bvalid;
  wire [31:0]s00_axi_rdata;
  wire s00_axi_rready;
  wire s00_axi_rvalid;
  wire [31:0]s00_axi_wdata;
  wire s00_axi_wvalid;
  wire zyMouse_v1_0_S00_AXI_inst_n_6;

  LUT6 #(
    .INIT(64'hF0FFFFFF88888888)) 
    aw_en_i_1
       (.I0(s00_axi_bready),
        .I1(s00_axi_bvalid),
        .I2(S_AXI_AWREADY),
        .I3(s00_axi_awvalid),
        .I4(s00_axi_wvalid),
        .I5(zyMouse_v1_0_S00_AXI_inst_n_6),
        .O(aw_en_i_1_n_0));
  LUT1 #(
    .INIT(2'h1)) 
    axi_awready_i_1
       (.I0(s00_axi_aresetn),
        .O(axi_awready_i_1_n_0));
  LUT6 #(
    .INIT(64'h7444444444444444)) 
    axi_bvalid_i_1
       (.I0(s00_axi_bready),
        .I1(s00_axi_bvalid),
        .I2(s00_axi_wvalid),
        .I3(s00_axi_awvalid),
        .I4(S_AXI_AWREADY),
        .I5(S_AXI_WREADY),
        .O(axi_bvalid_i_1_n_0));
  LUT4 #(
    .INIT(16'h08F8)) 
    axi_rvalid_i_1
       (.I0(s00_axi_arvalid),
        .I1(S_AXI_ARREADY),
        .I2(s00_axi_rvalid),
        .I3(s00_axi_rready),
        .O(axi_rvalid_i_1_n_0));
  decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_zyMouse_v1_0_S00_AXI zyMouse_v1_0_S00_AXI_inst
       (.SR(axi_awready_i_1_n_0),
        .axi_arready_reg_0(axi_rvalid_i_1_n_0),
        .axi_bvalid_reg_0(axi_bvalid_i_1_n_0),
        .axi_bvalid_reg_1(aw_en_i_1_n_0),
        .axi_wready_reg_0(zyMouse_v1_0_S00_AXI_inst_n_6),
        .i_button_down(i_button_down),
        .i_button_left(i_button_left),
        .i_button_press(i_button_press),
        .i_button_right(i_button_right),
        .i_button_up(i_button_up),
        .o_intr(o_intr),
        .s00_axi_aclk(s00_axi_aclk),
        .s00_axi_araddr(s00_axi_araddr),
        .s00_axi_arready(S_AXI_ARREADY),
        .s00_axi_arvalid(s00_axi_arvalid),
        .s00_axi_awaddr(s00_axi_awaddr),
        .s00_axi_awready(S_AXI_AWREADY),
        .s00_axi_awvalid(s00_axi_awvalid),
        .s00_axi_bvalid(s00_axi_bvalid),
        .s00_axi_rdata(s00_axi_rdata),
        .s00_axi_rvalid(s00_axi_rvalid),
        .s00_axi_wdata(s00_axi_wdata),
        .s00_axi_wready(S_AXI_WREADY),
        .s00_axi_wvalid(s00_axi_wvalid));
endmodule

module decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_zyMouse_v1_0_S00_AXI
   (s00_axi_wready,
    s00_axi_awready,
    s00_axi_arready,
    o_intr,
    s00_axi_rvalid,
    s00_axi_bvalid,
    axi_wready_reg_0,
    s00_axi_rdata,
    s00_axi_aclk,
    SR,
    s00_axi_arvalid,
    axi_bvalid_reg_0,
    axi_bvalid_reg_1,
    axi_arready_reg_0,
    s00_axi_awaddr,
    s00_axi_wdata,
    s00_axi_araddr,
    s00_axi_wvalid,
    s00_axi_awvalid,
    i_button_left,
    i_button_right,
    i_button_up,
    i_button_down,
    i_button_press);
  output s00_axi_wready;
  output s00_axi_awready;
  output s00_axi_arready;
  output o_intr;
  output s00_axi_rvalid;
  output s00_axi_bvalid;
  output axi_wready_reg_0;
  output [31:0]s00_axi_rdata;
  input s00_axi_aclk;
  input [0:0]SR;
  input s00_axi_arvalid;
  input axi_bvalid_reg_0;
  input axi_bvalid_reg_1;
  input axi_arready_reg_0;
  input [4:0]s00_axi_awaddr;
  input [31:0]s00_axi_wdata;
  input [4:0]s00_axi_araddr;
  input s00_axi_wvalid;
  input s00_axi_awvalid;
  input i_button_left;
  input i_button_right;
  input i_button_up;
  input i_button_down;
  input i_button_press;

  wire [0:0]SR;
  wire \axi_araddr_reg_n_0_[5] ;
  wire \axi_araddr_reg_n_0_[6] ;
  wire axi_arready_i_1_n_0;
  wire axi_arready_reg_0;
  wire axi_awready0;
  wire axi_bvalid_reg_0;
  wire axi_bvalid_reg_1;
  wire \axi_rdata[31]_i_2_n_0 ;
  wire \axi_rdata[31]_i_3_n_0 ;
  wire \axi_rdata[31]_i_5_n_0 ;
  wire axi_wready0;
  wire axi_wready_reg_0;
  wire controlReg;
  wire \controlReg[31]_i_2_n_0 ;
  wire \controlReg_reg_n_0_[0] ;
  wire \controlReg_reg_n_0_[10] ;
  wire \controlReg_reg_n_0_[11] ;
  wire \controlReg_reg_n_0_[12] ;
  wire \controlReg_reg_n_0_[13] ;
  wire \controlReg_reg_n_0_[14] ;
  wire \controlReg_reg_n_0_[15] ;
  wire \controlReg_reg_n_0_[16] ;
  wire \controlReg_reg_n_0_[17] ;
  wire \controlReg_reg_n_0_[18] ;
  wire \controlReg_reg_n_0_[19] ;
  wire \controlReg_reg_n_0_[1] ;
  wire \controlReg_reg_n_0_[20] ;
  wire \controlReg_reg_n_0_[21] ;
  wire \controlReg_reg_n_0_[22] ;
  wire \controlReg_reg_n_0_[23] ;
  wire \controlReg_reg_n_0_[24] ;
  wire \controlReg_reg_n_0_[25] ;
  wire \controlReg_reg_n_0_[26] ;
  wire \controlReg_reg_n_0_[27] ;
  wire \controlReg_reg_n_0_[28] ;
  wire \controlReg_reg_n_0_[29] ;
  wire \controlReg_reg_n_0_[2] ;
  wire \controlReg_reg_n_0_[30] ;
  wire \controlReg_reg_n_0_[31] ;
  wire \controlReg_reg_n_0_[3] ;
  wire \controlReg_reg_n_0_[4] ;
  wire \controlReg_reg_n_0_[5] ;
  wire \controlReg_reg_n_0_[6] ;
  wire \controlReg_reg_n_0_[7] ;
  wire \controlReg_reg_n_0_[8] ;
  wire \controlReg_reg_n_0_[9] ;
  wire i_button_down;
  wire i_button_left;
  wire i_button_press;
  wire i_button_right;
  wire i_button_up;
  wire intrEnableReg;
  wire \intrEnableReg_reg_n_0_[0] ;
  wire \intrEnableReg_reg_n_0_[10] ;
  wire \intrEnableReg_reg_n_0_[11] ;
  wire \intrEnableReg_reg_n_0_[12] ;
  wire \intrEnableReg_reg_n_0_[13] ;
  wire \intrEnableReg_reg_n_0_[14] ;
  wire \intrEnableReg_reg_n_0_[15] ;
  wire \intrEnableReg_reg_n_0_[16] ;
  wire \intrEnableReg_reg_n_0_[17] ;
  wire \intrEnableReg_reg_n_0_[18] ;
  wire \intrEnableReg_reg_n_0_[19] ;
  wire \intrEnableReg_reg_n_0_[1] ;
  wire \intrEnableReg_reg_n_0_[20] ;
  wire \intrEnableReg_reg_n_0_[21] ;
  wire \intrEnableReg_reg_n_0_[22] ;
  wire \intrEnableReg_reg_n_0_[23] ;
  wire \intrEnableReg_reg_n_0_[24] ;
  wire \intrEnableReg_reg_n_0_[25] ;
  wire \intrEnableReg_reg_n_0_[26] ;
  wire \intrEnableReg_reg_n_0_[27] ;
  wire \intrEnableReg_reg_n_0_[28] ;
  wire \intrEnableReg_reg_n_0_[29] ;
  wire \intrEnableReg_reg_n_0_[2] ;
  wire \intrEnableReg_reg_n_0_[30] ;
  wire \intrEnableReg_reg_n_0_[31] ;
  wire \intrEnableReg_reg_n_0_[3] ;
  wire \intrEnableReg_reg_n_0_[4] ;
  wire \intrEnableReg_reg_n_0_[5] ;
  wire \intrEnableReg_reg_n_0_[6] ;
  wire \intrEnableReg_reg_n_0_[7] ;
  wire \intrEnableReg_reg_n_0_[8] ;
  wire \intrEnableReg_reg_n_0_[9] ;
  wire intrStatReg1;
  wire \intrStatReg[10]_i_1_n_0 ;
  wire \intrStatReg[11]_i_1_n_0 ;
  wire \intrStatReg[12]_i_1_n_0 ;
  wire \intrStatReg[13]_i_1_n_0 ;
  wire \intrStatReg[14]_i_1_n_0 ;
  wire \intrStatReg[15]_i_1_n_0 ;
  wire \intrStatReg[16]_i_1_n_0 ;
  wire \intrStatReg[17]_i_1_n_0 ;
  wire \intrStatReg[18]_i_1_n_0 ;
  wire \intrStatReg[19]_i_1_n_0 ;
  wire \intrStatReg[20]_i_1_n_0 ;
  wire \intrStatReg[21]_i_1_n_0 ;
  wire \intrStatReg[22]_i_1_n_0 ;
  wire \intrStatReg[23]_i_1_n_0 ;
  wire \intrStatReg[24]_i_1_n_0 ;
  wire \intrStatReg[25]_i_1_n_0 ;
  wire \intrStatReg[26]_i_1_n_0 ;
  wire \intrStatReg[27]_i_1_n_0 ;
  wire \intrStatReg[28]_i_1_n_0 ;
  wire \intrStatReg[29]_i_1_n_0 ;
  wire \intrStatReg[2]_i_1_n_0 ;
  wire \intrStatReg[30]_i_1_n_0 ;
  wire \intrStatReg[31]_i_2_n_0 ;
  wire \intrStatReg[31]_i_3_n_0 ;
  wire \intrStatReg[3]_i_1_n_0 ;
  wire \intrStatReg[4]_i_1_n_0 ;
  wire \intrStatReg[5]_i_1_n_0 ;
  wire \intrStatReg[6]_i_1_n_0 ;
  wire \intrStatReg[7]_i_1_n_0 ;
  wire \intrStatReg[8]_i_1_n_0 ;
  wire \intrStatReg[9]_i_1_n_0 ;
  wire \intrStatReg_reg_n_0_[0] ;
  wire \intrStatReg_reg_n_0_[10] ;
  wire \intrStatReg_reg_n_0_[11] ;
  wire \intrStatReg_reg_n_0_[12] ;
  wire \intrStatReg_reg_n_0_[13] ;
  wire \intrStatReg_reg_n_0_[14] ;
  wire \intrStatReg_reg_n_0_[15] ;
  wire \intrStatReg_reg_n_0_[16] ;
  wire \intrStatReg_reg_n_0_[17] ;
  wire \intrStatReg_reg_n_0_[18] ;
  wire \intrStatReg_reg_n_0_[19] ;
  wire \intrStatReg_reg_n_0_[1] ;
  wire \intrStatReg_reg_n_0_[20] ;
  wire \intrStatReg_reg_n_0_[21] ;
  wire \intrStatReg_reg_n_0_[22] ;
  wire \intrStatReg_reg_n_0_[23] ;
  wire \intrStatReg_reg_n_0_[24] ;
  wire \intrStatReg_reg_n_0_[25] ;
  wire \intrStatReg_reg_n_0_[26] ;
  wire \intrStatReg_reg_n_0_[27] ;
  wire \intrStatReg_reg_n_0_[28] ;
  wire \intrStatReg_reg_n_0_[29] ;
  wire \intrStatReg_reg_n_0_[2] ;
  wire \intrStatReg_reg_n_0_[30] ;
  wire \intrStatReg_reg_n_0_[31] ;
  wire \intrStatReg_reg_n_0_[3] ;
  wire \intrStatReg_reg_n_0_[4] ;
  wire \intrStatReg_reg_n_0_[5] ;
  wire \intrStatReg_reg_n_0_[6] ;
  wire \intrStatReg_reg_n_0_[7] ;
  wire \intrStatReg_reg_n_0_[8] ;
  wire \intrStatReg_reg_n_0_[9] ;
  wire mT_n_0;
  wire maxCoordinateReg;
  wire \maxCoordinateReg_reg_n_0_[0] ;
  wire \maxCoordinateReg_reg_n_0_[10] ;
  wire \maxCoordinateReg_reg_n_0_[11] ;
  wire \maxCoordinateReg_reg_n_0_[12] ;
  wire \maxCoordinateReg_reg_n_0_[13] ;
  wire \maxCoordinateReg_reg_n_0_[14] ;
  wire \maxCoordinateReg_reg_n_0_[15] ;
  wire \maxCoordinateReg_reg_n_0_[16] ;
  wire \maxCoordinateReg_reg_n_0_[17] ;
  wire \maxCoordinateReg_reg_n_0_[18] ;
  wire \maxCoordinateReg_reg_n_0_[19] ;
  wire \maxCoordinateReg_reg_n_0_[1] ;
  wire \maxCoordinateReg_reg_n_0_[20] ;
  wire \maxCoordinateReg_reg_n_0_[21] ;
  wire \maxCoordinateReg_reg_n_0_[22] ;
  wire \maxCoordinateReg_reg_n_0_[23] ;
  wire \maxCoordinateReg_reg_n_0_[24] ;
  wire \maxCoordinateReg_reg_n_0_[25] ;
  wire \maxCoordinateReg_reg_n_0_[26] ;
  wire \maxCoordinateReg_reg_n_0_[27] ;
  wire \maxCoordinateReg_reg_n_0_[28] ;
  wire \maxCoordinateReg_reg_n_0_[29] ;
  wire \maxCoordinateReg_reg_n_0_[2] ;
  wire \maxCoordinateReg_reg_n_0_[30] ;
  wire \maxCoordinateReg_reg_n_0_[31] ;
  wire \maxCoordinateReg_reg_n_0_[3] ;
  wire \maxCoordinateReg_reg_n_0_[4] ;
  wire \maxCoordinateReg_reg_n_0_[5] ;
  wire \maxCoordinateReg_reg_n_0_[6] ;
  wire \maxCoordinateReg_reg_n_0_[7] ;
  wire \maxCoordinateReg_reg_n_0_[8] ;
  wire \maxCoordinateReg_reg_n_0_[9] ;
  wire maxCountReg;
  wire \maxCountReg_reg_n_0_[0] ;
  wire \maxCountReg_reg_n_0_[10] ;
  wire \maxCountReg_reg_n_0_[11] ;
  wire \maxCountReg_reg_n_0_[12] ;
  wire \maxCountReg_reg_n_0_[13] ;
  wire \maxCountReg_reg_n_0_[14] ;
  wire \maxCountReg_reg_n_0_[15] ;
  wire \maxCountReg_reg_n_0_[16] ;
  wire \maxCountReg_reg_n_0_[17] ;
  wire \maxCountReg_reg_n_0_[18] ;
  wire \maxCountReg_reg_n_0_[19] ;
  wire \maxCountReg_reg_n_0_[1] ;
  wire \maxCountReg_reg_n_0_[20] ;
  wire \maxCountReg_reg_n_0_[21] ;
  wire \maxCountReg_reg_n_0_[22] ;
  wire \maxCountReg_reg_n_0_[23] ;
  wire \maxCountReg_reg_n_0_[24] ;
  wire \maxCountReg_reg_n_0_[25] ;
  wire \maxCountReg_reg_n_0_[26] ;
  wire \maxCountReg_reg_n_0_[27] ;
  wire \maxCountReg_reg_n_0_[28] ;
  wire \maxCountReg_reg_n_0_[29] ;
  wire \maxCountReg_reg_n_0_[2] ;
  wire \maxCountReg_reg_n_0_[30] ;
  wire \maxCountReg_reg_n_0_[31] ;
  wire \maxCountReg_reg_n_0_[3] ;
  wire \maxCountReg_reg_n_0_[4] ;
  wire \maxCountReg_reg_n_0_[5] ;
  wire \maxCountReg_reg_n_0_[6] ;
  wire \maxCountReg_reg_n_0_[7] ;
  wire \maxCountReg_reg_n_0_[8] ;
  wire \maxCountReg_reg_n_0_[9] ;
  wire o_intr;
  wire o_intr_i_10__0_n_0;
  wire o_intr_i_11_n_0;
  wire o_intr_i_12_n_0;
  wire o_intr_i_13_n_0;
  wire o_intr_i_14_n_0;
  wire o_intr_i_15_n_0;
  wire o_intr_i_16_n_0;
  wire o_intr_i_17_n_0;
  wire o_intr_i_1__0_n_0;
  wire o_intr_i_2__0_n_0;
  wire o_intr_i_3__0_n_0;
  wire o_intr_i_4__0_n_0;
  wire o_intr_i_5__0_n_0;
  wire o_intr_i_6__0_n_0;
  wire o_intr_i_7__0_n_0;
  wire o_intr_i_8__0_n_0;
  wire o_intr_i_9__0_n_0;
  wire [4:0]p_0_in;
  wire [31:0]p_1_in;
  wire s00_axi_aclk;
  wire [4:0]s00_axi_araddr;
  wire s00_axi_arready;
  wire s00_axi_arvalid;
  wire [4:0]s00_axi_awaddr;
  wire s00_axi_awready;
  wire s00_axi_awvalid;
  wire s00_axi_bvalid;
  wire [31:0]s00_axi_rdata;
  wire s00_axi_rvalid;
  wire [31:0]s00_axi_wdata;
  wire s00_axi_wready;
  wire s00_axi_wvalid;
  wire [2:0]sel0;
  wire slv_reg_rden__0;
  wire spDebounce_n_1;
  wire w_button_pulse;

  FDSE aw_en_reg
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(axi_bvalid_reg_1),
        .Q(axi_wready_reg_0),
        .S(SR));
  FDRE \axi_araddr_reg[2] 
       (.C(s00_axi_aclk),
        .CE(axi_arready_i_1_n_0),
        .D(s00_axi_araddr[0]),
        .Q(sel0[0]),
        .R(SR));
  FDRE \axi_araddr_reg[3] 
       (.C(s00_axi_aclk),
        .CE(axi_arready_i_1_n_0),
        .D(s00_axi_araddr[1]),
        .Q(sel0[1]),
        .R(SR));
  FDRE \axi_araddr_reg[4] 
       (.C(s00_axi_aclk),
        .CE(axi_arready_i_1_n_0),
        .D(s00_axi_araddr[2]),
        .Q(sel0[2]),
        .R(SR));
  FDRE \axi_araddr_reg[5] 
       (.C(s00_axi_aclk),
        .CE(axi_arready_i_1_n_0),
        .D(s00_axi_araddr[3]),
        .Q(\axi_araddr_reg_n_0_[5] ),
        .R(SR));
  FDRE \axi_araddr_reg[6] 
       (.C(s00_axi_aclk),
        .CE(axi_arready_i_1_n_0),
        .D(s00_axi_araddr[4]),
        .Q(\axi_araddr_reg_n_0_[6] ),
        .R(SR));
  LUT2 #(
    .INIT(4'h2)) 
    axi_arready_i_1
       (.I0(s00_axi_arvalid),
        .I1(s00_axi_arready),
        .O(axi_arready_i_1_n_0));
  FDRE axi_arready_reg
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(axi_arready_i_1_n_0),
        .Q(s00_axi_arready),
        .R(SR));
  FDRE \axi_awaddr_reg[2] 
       (.C(s00_axi_aclk),
        .CE(axi_awready0),
        .D(s00_axi_awaddr[0]),
        .Q(p_0_in[0]),
        .R(SR));
  FDRE \axi_awaddr_reg[3] 
       (.C(s00_axi_aclk),
        .CE(axi_awready0),
        .D(s00_axi_awaddr[1]),
        .Q(p_0_in[1]),
        .R(SR));
  FDRE \axi_awaddr_reg[4] 
       (.C(s00_axi_aclk),
        .CE(axi_awready0),
        .D(s00_axi_awaddr[2]),
        .Q(p_0_in[2]),
        .R(SR));
  FDRE \axi_awaddr_reg[5] 
       (.C(s00_axi_aclk),
        .CE(axi_awready0),
        .D(s00_axi_awaddr[3]),
        .Q(p_0_in[3]),
        .R(SR));
  FDRE \axi_awaddr_reg[6] 
       (.C(s00_axi_aclk),
        .CE(axi_awready0),
        .D(s00_axi_awaddr[4]),
        .Q(p_0_in[4]),
        .R(SR));
  LUT4 #(
    .INIT(16'h4000)) 
    axi_awready_i_2
       (.I0(s00_axi_awready),
        .I1(s00_axi_awvalid),
        .I2(s00_axi_wvalid),
        .I3(axi_wready_reg_0),
        .O(axi_awready0));
  FDRE axi_awready_reg
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(axi_awready0),
        .Q(s00_axi_awready),
        .R(SR));
  FDRE axi_bvalid_reg
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(axi_bvalid_reg_0),
        .Q(s00_axi_bvalid),
        .R(SR));
  (* SOFT_HLUTNM = "soft_lutpair8" *) 
  LUT3 #(
    .INIT(8'h5D)) 
    \axi_rdata[31]_i_2 
       (.I0(sel0[2]),
        .I1(sel0[0]),
        .I2(sel0[1]),
        .O(\axi_rdata[31]_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair8" *) 
  LUT2 #(
    .INIT(4'hB)) 
    \axi_rdata[31]_i_3 
       (.I0(sel0[1]),
        .I1(sel0[2]),
        .O(\axi_rdata[31]_i_3_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \axi_rdata[31]_i_5 
       (.I0(\axi_araddr_reg_n_0_[5] ),
        .I1(\axi_araddr_reg_n_0_[6] ),
        .O(\axi_rdata[31]_i_5_n_0 ));
  FDRE \axi_rdata_reg[0] 
       (.C(s00_axi_aclk),
        .CE(slv_reg_rden__0),
        .D(p_1_in[0]),
        .Q(s00_axi_rdata[0]),
        .R(SR));
  FDRE \axi_rdata_reg[10] 
       (.C(s00_axi_aclk),
        .CE(slv_reg_rden__0),
        .D(p_1_in[10]),
        .Q(s00_axi_rdata[10]),
        .R(SR));
  FDRE \axi_rdata_reg[11] 
       (.C(s00_axi_aclk),
        .CE(slv_reg_rden__0),
        .D(p_1_in[11]),
        .Q(s00_axi_rdata[11]),
        .R(SR));
  FDRE \axi_rdata_reg[12] 
       (.C(s00_axi_aclk),
        .CE(slv_reg_rden__0),
        .D(p_1_in[12]),
        .Q(s00_axi_rdata[12]),
        .R(SR));
  FDRE \axi_rdata_reg[13] 
       (.C(s00_axi_aclk),
        .CE(slv_reg_rden__0),
        .D(p_1_in[13]),
        .Q(s00_axi_rdata[13]),
        .R(SR));
  FDRE \axi_rdata_reg[14] 
       (.C(s00_axi_aclk),
        .CE(slv_reg_rden__0),
        .D(p_1_in[14]),
        .Q(s00_axi_rdata[14]),
        .R(SR));
  FDRE \axi_rdata_reg[15] 
       (.C(s00_axi_aclk),
        .CE(slv_reg_rden__0),
        .D(p_1_in[15]),
        .Q(s00_axi_rdata[15]),
        .R(SR));
  FDRE \axi_rdata_reg[16] 
       (.C(s00_axi_aclk),
        .CE(slv_reg_rden__0),
        .D(p_1_in[16]),
        .Q(s00_axi_rdata[16]),
        .R(SR));
  FDRE \axi_rdata_reg[17] 
       (.C(s00_axi_aclk),
        .CE(slv_reg_rden__0),
        .D(p_1_in[17]),
        .Q(s00_axi_rdata[17]),
        .R(SR));
  FDRE \axi_rdata_reg[18] 
       (.C(s00_axi_aclk),
        .CE(slv_reg_rden__0),
        .D(p_1_in[18]),
        .Q(s00_axi_rdata[18]),
        .R(SR));
  FDRE \axi_rdata_reg[19] 
       (.C(s00_axi_aclk),
        .CE(slv_reg_rden__0),
        .D(p_1_in[19]),
        .Q(s00_axi_rdata[19]),
        .R(SR));
  FDRE \axi_rdata_reg[1] 
       (.C(s00_axi_aclk),
        .CE(slv_reg_rden__0),
        .D(p_1_in[1]),
        .Q(s00_axi_rdata[1]),
        .R(SR));
  FDRE \axi_rdata_reg[20] 
       (.C(s00_axi_aclk),
        .CE(slv_reg_rden__0),
        .D(p_1_in[20]),
        .Q(s00_axi_rdata[20]),
        .R(SR));
  FDRE \axi_rdata_reg[21] 
       (.C(s00_axi_aclk),
        .CE(slv_reg_rden__0),
        .D(p_1_in[21]),
        .Q(s00_axi_rdata[21]),
        .R(SR));
  FDRE \axi_rdata_reg[22] 
       (.C(s00_axi_aclk),
        .CE(slv_reg_rden__0),
        .D(p_1_in[22]),
        .Q(s00_axi_rdata[22]),
        .R(SR));
  FDRE \axi_rdata_reg[23] 
       (.C(s00_axi_aclk),
        .CE(slv_reg_rden__0),
        .D(p_1_in[23]),
        .Q(s00_axi_rdata[23]),
        .R(SR));
  FDRE \axi_rdata_reg[24] 
       (.C(s00_axi_aclk),
        .CE(slv_reg_rden__0),
        .D(p_1_in[24]),
        .Q(s00_axi_rdata[24]),
        .R(SR));
  FDRE \axi_rdata_reg[25] 
       (.C(s00_axi_aclk),
        .CE(slv_reg_rden__0),
        .D(p_1_in[25]),
        .Q(s00_axi_rdata[25]),
        .R(SR));
  FDRE \axi_rdata_reg[26] 
       (.C(s00_axi_aclk),
        .CE(slv_reg_rden__0),
        .D(p_1_in[26]),
        .Q(s00_axi_rdata[26]),
        .R(SR));
  FDRE \axi_rdata_reg[27] 
       (.C(s00_axi_aclk),
        .CE(slv_reg_rden__0),
        .D(p_1_in[27]),
        .Q(s00_axi_rdata[27]),
        .R(SR));
  FDRE \axi_rdata_reg[28] 
       (.C(s00_axi_aclk),
        .CE(slv_reg_rden__0),
        .D(p_1_in[28]),
        .Q(s00_axi_rdata[28]),
        .R(SR));
  FDRE \axi_rdata_reg[29] 
       (.C(s00_axi_aclk),
        .CE(slv_reg_rden__0),
        .D(p_1_in[29]),
        .Q(s00_axi_rdata[29]),
        .R(SR));
  FDRE \axi_rdata_reg[2] 
       (.C(s00_axi_aclk),
        .CE(slv_reg_rden__0),
        .D(p_1_in[2]),
        .Q(s00_axi_rdata[2]),
        .R(SR));
  FDRE \axi_rdata_reg[30] 
       (.C(s00_axi_aclk),
        .CE(slv_reg_rden__0),
        .D(p_1_in[30]),
        .Q(s00_axi_rdata[30]),
        .R(SR));
  FDRE \axi_rdata_reg[31] 
       (.C(s00_axi_aclk),
        .CE(slv_reg_rden__0),
        .D(p_1_in[31]),
        .Q(s00_axi_rdata[31]),
        .R(SR));
  FDRE \axi_rdata_reg[3] 
       (.C(s00_axi_aclk),
        .CE(slv_reg_rden__0),
        .D(p_1_in[3]),
        .Q(s00_axi_rdata[3]),
        .R(SR));
  FDRE \axi_rdata_reg[4] 
       (.C(s00_axi_aclk),
        .CE(slv_reg_rden__0),
        .D(p_1_in[4]),
        .Q(s00_axi_rdata[4]),
        .R(SR));
  FDRE \axi_rdata_reg[5] 
       (.C(s00_axi_aclk),
        .CE(slv_reg_rden__0),
        .D(p_1_in[5]),
        .Q(s00_axi_rdata[5]),
        .R(SR));
  FDRE \axi_rdata_reg[6] 
       (.C(s00_axi_aclk),
        .CE(slv_reg_rden__0),
        .D(p_1_in[6]),
        .Q(s00_axi_rdata[6]),
        .R(SR));
  FDRE \axi_rdata_reg[7] 
       (.C(s00_axi_aclk),
        .CE(slv_reg_rden__0),
        .D(p_1_in[7]),
        .Q(s00_axi_rdata[7]),
        .R(SR));
  FDRE \axi_rdata_reg[8] 
       (.C(s00_axi_aclk),
        .CE(slv_reg_rden__0),
        .D(p_1_in[8]),
        .Q(s00_axi_rdata[8]),
        .R(SR));
  FDRE \axi_rdata_reg[9] 
       (.C(s00_axi_aclk),
        .CE(slv_reg_rden__0),
        .D(p_1_in[9]),
        .Q(s00_axi_rdata[9]),
        .R(SR));
  FDRE axi_rvalid_reg
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(axi_arready_reg_0),
        .Q(s00_axi_rvalid),
        .R(SR));
  (* SOFT_HLUTNM = "soft_lutpair2" *) 
  LUT4 #(
    .INIT(16'h0080)) 
    axi_wready_i_1
       (.I0(axi_wready_reg_0),
        .I1(s00_axi_wvalid),
        .I2(s00_axi_awvalid),
        .I3(s00_axi_wready),
        .O(axi_wready0));
  FDRE axi_wready_reg
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(axi_wready0),
        .Q(s00_axi_wready),
        .R(SR));
  LUT6 #(
    .INIT(64'h0000000000000001)) 
    \controlReg[31]_i_1 
       (.I0(p_0_in[2]),
        .I1(\controlReg[31]_i_2_n_0 ),
        .I2(p_0_in[3]),
        .I3(p_0_in[4]),
        .I4(p_0_in[1]),
        .I5(p_0_in[0]),
        .O(controlReg));
  (* SOFT_HLUTNM = "soft_lutpair2" *) 
  LUT4 #(
    .INIT(16'h7FFF)) 
    \controlReg[31]_i_2 
       (.I0(s00_axi_wready),
        .I1(s00_axi_awready),
        .I2(s00_axi_awvalid),
        .I3(s00_axi_wvalid),
        .O(\controlReg[31]_i_2_n_0 ));
  FDRE \controlReg_reg[0] 
       (.C(s00_axi_aclk),
        .CE(controlReg),
        .D(s00_axi_wdata[0]),
        .Q(\controlReg_reg_n_0_[0] ),
        .R(SR));
  FDRE \controlReg_reg[10] 
       (.C(s00_axi_aclk),
        .CE(controlReg),
        .D(s00_axi_wdata[10]),
        .Q(\controlReg_reg_n_0_[10] ),
        .R(SR));
  FDRE \controlReg_reg[11] 
       (.C(s00_axi_aclk),
        .CE(controlReg),
        .D(s00_axi_wdata[11]),
        .Q(\controlReg_reg_n_0_[11] ),
        .R(SR));
  FDRE \controlReg_reg[12] 
       (.C(s00_axi_aclk),
        .CE(controlReg),
        .D(s00_axi_wdata[12]),
        .Q(\controlReg_reg_n_0_[12] ),
        .R(SR));
  FDRE \controlReg_reg[13] 
       (.C(s00_axi_aclk),
        .CE(controlReg),
        .D(s00_axi_wdata[13]),
        .Q(\controlReg_reg_n_0_[13] ),
        .R(SR));
  FDRE \controlReg_reg[14] 
       (.C(s00_axi_aclk),
        .CE(controlReg),
        .D(s00_axi_wdata[14]),
        .Q(\controlReg_reg_n_0_[14] ),
        .R(SR));
  FDRE \controlReg_reg[15] 
       (.C(s00_axi_aclk),
        .CE(controlReg),
        .D(s00_axi_wdata[15]),
        .Q(\controlReg_reg_n_0_[15] ),
        .R(SR));
  FDRE \controlReg_reg[16] 
       (.C(s00_axi_aclk),
        .CE(controlReg),
        .D(s00_axi_wdata[16]),
        .Q(\controlReg_reg_n_0_[16] ),
        .R(SR));
  FDRE \controlReg_reg[17] 
       (.C(s00_axi_aclk),
        .CE(controlReg),
        .D(s00_axi_wdata[17]),
        .Q(\controlReg_reg_n_0_[17] ),
        .R(SR));
  FDRE \controlReg_reg[18] 
       (.C(s00_axi_aclk),
        .CE(controlReg),
        .D(s00_axi_wdata[18]),
        .Q(\controlReg_reg_n_0_[18] ),
        .R(SR));
  FDRE \controlReg_reg[19] 
       (.C(s00_axi_aclk),
        .CE(controlReg),
        .D(s00_axi_wdata[19]),
        .Q(\controlReg_reg_n_0_[19] ),
        .R(SR));
  FDRE \controlReg_reg[1] 
       (.C(s00_axi_aclk),
        .CE(controlReg),
        .D(s00_axi_wdata[1]),
        .Q(\controlReg_reg_n_0_[1] ),
        .R(SR));
  FDRE \controlReg_reg[20] 
       (.C(s00_axi_aclk),
        .CE(controlReg),
        .D(s00_axi_wdata[20]),
        .Q(\controlReg_reg_n_0_[20] ),
        .R(SR));
  FDRE \controlReg_reg[21] 
       (.C(s00_axi_aclk),
        .CE(controlReg),
        .D(s00_axi_wdata[21]),
        .Q(\controlReg_reg_n_0_[21] ),
        .R(SR));
  FDRE \controlReg_reg[22] 
       (.C(s00_axi_aclk),
        .CE(controlReg),
        .D(s00_axi_wdata[22]),
        .Q(\controlReg_reg_n_0_[22] ),
        .R(SR));
  FDRE \controlReg_reg[23] 
       (.C(s00_axi_aclk),
        .CE(controlReg),
        .D(s00_axi_wdata[23]),
        .Q(\controlReg_reg_n_0_[23] ),
        .R(SR));
  FDRE \controlReg_reg[24] 
       (.C(s00_axi_aclk),
        .CE(controlReg),
        .D(s00_axi_wdata[24]),
        .Q(\controlReg_reg_n_0_[24] ),
        .R(SR));
  FDRE \controlReg_reg[25] 
       (.C(s00_axi_aclk),
        .CE(controlReg),
        .D(s00_axi_wdata[25]),
        .Q(\controlReg_reg_n_0_[25] ),
        .R(SR));
  FDRE \controlReg_reg[26] 
       (.C(s00_axi_aclk),
        .CE(controlReg),
        .D(s00_axi_wdata[26]),
        .Q(\controlReg_reg_n_0_[26] ),
        .R(SR));
  FDRE \controlReg_reg[27] 
       (.C(s00_axi_aclk),
        .CE(controlReg),
        .D(s00_axi_wdata[27]),
        .Q(\controlReg_reg_n_0_[27] ),
        .R(SR));
  FDRE \controlReg_reg[28] 
       (.C(s00_axi_aclk),
        .CE(controlReg),
        .D(s00_axi_wdata[28]),
        .Q(\controlReg_reg_n_0_[28] ),
        .R(SR));
  FDRE \controlReg_reg[29] 
       (.C(s00_axi_aclk),
        .CE(controlReg),
        .D(s00_axi_wdata[29]),
        .Q(\controlReg_reg_n_0_[29] ),
        .R(SR));
  FDRE \controlReg_reg[2] 
       (.C(s00_axi_aclk),
        .CE(controlReg),
        .D(s00_axi_wdata[2]),
        .Q(\controlReg_reg_n_0_[2] ),
        .R(SR));
  FDRE \controlReg_reg[30] 
       (.C(s00_axi_aclk),
        .CE(controlReg),
        .D(s00_axi_wdata[30]),
        .Q(\controlReg_reg_n_0_[30] ),
        .R(SR));
  FDRE \controlReg_reg[31] 
       (.C(s00_axi_aclk),
        .CE(controlReg),
        .D(s00_axi_wdata[31]),
        .Q(\controlReg_reg_n_0_[31] ),
        .R(SR));
  FDRE \controlReg_reg[3] 
       (.C(s00_axi_aclk),
        .CE(controlReg),
        .D(s00_axi_wdata[3]),
        .Q(\controlReg_reg_n_0_[3] ),
        .R(SR));
  FDRE \controlReg_reg[4] 
       (.C(s00_axi_aclk),
        .CE(controlReg),
        .D(s00_axi_wdata[4]),
        .Q(\controlReg_reg_n_0_[4] ),
        .R(SR));
  FDRE \controlReg_reg[5] 
       (.C(s00_axi_aclk),
        .CE(controlReg),
        .D(s00_axi_wdata[5]),
        .Q(\controlReg_reg_n_0_[5] ),
        .R(SR));
  FDRE \controlReg_reg[6] 
       (.C(s00_axi_aclk),
        .CE(controlReg),
        .D(s00_axi_wdata[6]),
        .Q(\controlReg_reg_n_0_[6] ),
        .R(SR));
  FDRE \controlReg_reg[7] 
       (.C(s00_axi_aclk),
        .CE(controlReg),
        .D(s00_axi_wdata[7]),
        .Q(\controlReg_reg_n_0_[7] ),
        .R(SR));
  FDRE \controlReg_reg[8] 
       (.C(s00_axi_aclk),
        .CE(controlReg),
        .D(s00_axi_wdata[8]),
        .Q(\controlReg_reg_n_0_[8] ),
        .R(SR));
  FDRE \controlReg_reg[9] 
       (.C(s00_axi_aclk),
        .CE(controlReg),
        .D(s00_axi_wdata[9]),
        .Q(\controlReg_reg_n_0_[9] ),
        .R(SR));
  LUT6 #(
    .INIT(64'h0000000000000004)) 
    \intrEnableReg[31]_i_1 
       (.I0(p_0_in[0]),
        .I1(p_0_in[1]),
        .I2(p_0_in[2]),
        .I3(\controlReg[31]_i_2_n_0 ),
        .I4(p_0_in[3]),
        .I5(p_0_in[4]),
        .O(intrEnableReg));
  FDRE #(
    .INIT(1'b0)) 
    \intrEnableReg_reg[0] 
       (.C(s00_axi_aclk),
        .CE(intrEnableReg),
        .D(s00_axi_wdata[0]),
        .Q(\intrEnableReg_reg_n_0_[0] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \intrEnableReg_reg[10] 
       (.C(s00_axi_aclk),
        .CE(intrEnableReg),
        .D(s00_axi_wdata[10]),
        .Q(\intrEnableReg_reg_n_0_[10] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \intrEnableReg_reg[11] 
       (.C(s00_axi_aclk),
        .CE(intrEnableReg),
        .D(s00_axi_wdata[11]),
        .Q(\intrEnableReg_reg_n_0_[11] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \intrEnableReg_reg[12] 
       (.C(s00_axi_aclk),
        .CE(intrEnableReg),
        .D(s00_axi_wdata[12]),
        .Q(\intrEnableReg_reg_n_0_[12] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \intrEnableReg_reg[13] 
       (.C(s00_axi_aclk),
        .CE(intrEnableReg),
        .D(s00_axi_wdata[13]),
        .Q(\intrEnableReg_reg_n_0_[13] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \intrEnableReg_reg[14] 
       (.C(s00_axi_aclk),
        .CE(intrEnableReg),
        .D(s00_axi_wdata[14]),
        .Q(\intrEnableReg_reg_n_0_[14] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \intrEnableReg_reg[15] 
       (.C(s00_axi_aclk),
        .CE(intrEnableReg),
        .D(s00_axi_wdata[15]),
        .Q(\intrEnableReg_reg_n_0_[15] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \intrEnableReg_reg[16] 
       (.C(s00_axi_aclk),
        .CE(intrEnableReg),
        .D(s00_axi_wdata[16]),
        .Q(\intrEnableReg_reg_n_0_[16] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \intrEnableReg_reg[17] 
       (.C(s00_axi_aclk),
        .CE(intrEnableReg),
        .D(s00_axi_wdata[17]),
        .Q(\intrEnableReg_reg_n_0_[17] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \intrEnableReg_reg[18] 
       (.C(s00_axi_aclk),
        .CE(intrEnableReg),
        .D(s00_axi_wdata[18]),
        .Q(\intrEnableReg_reg_n_0_[18] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \intrEnableReg_reg[19] 
       (.C(s00_axi_aclk),
        .CE(intrEnableReg),
        .D(s00_axi_wdata[19]),
        .Q(\intrEnableReg_reg_n_0_[19] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \intrEnableReg_reg[1] 
       (.C(s00_axi_aclk),
        .CE(intrEnableReg),
        .D(s00_axi_wdata[1]),
        .Q(\intrEnableReg_reg_n_0_[1] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \intrEnableReg_reg[20] 
       (.C(s00_axi_aclk),
        .CE(intrEnableReg),
        .D(s00_axi_wdata[20]),
        .Q(\intrEnableReg_reg_n_0_[20] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \intrEnableReg_reg[21] 
       (.C(s00_axi_aclk),
        .CE(intrEnableReg),
        .D(s00_axi_wdata[21]),
        .Q(\intrEnableReg_reg_n_0_[21] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \intrEnableReg_reg[22] 
       (.C(s00_axi_aclk),
        .CE(intrEnableReg),
        .D(s00_axi_wdata[22]),
        .Q(\intrEnableReg_reg_n_0_[22] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \intrEnableReg_reg[23] 
       (.C(s00_axi_aclk),
        .CE(intrEnableReg),
        .D(s00_axi_wdata[23]),
        .Q(\intrEnableReg_reg_n_0_[23] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \intrEnableReg_reg[24] 
       (.C(s00_axi_aclk),
        .CE(intrEnableReg),
        .D(s00_axi_wdata[24]),
        .Q(\intrEnableReg_reg_n_0_[24] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \intrEnableReg_reg[25] 
       (.C(s00_axi_aclk),
        .CE(intrEnableReg),
        .D(s00_axi_wdata[25]),
        .Q(\intrEnableReg_reg_n_0_[25] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \intrEnableReg_reg[26] 
       (.C(s00_axi_aclk),
        .CE(intrEnableReg),
        .D(s00_axi_wdata[26]),
        .Q(\intrEnableReg_reg_n_0_[26] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \intrEnableReg_reg[27] 
       (.C(s00_axi_aclk),
        .CE(intrEnableReg),
        .D(s00_axi_wdata[27]),
        .Q(\intrEnableReg_reg_n_0_[27] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \intrEnableReg_reg[28] 
       (.C(s00_axi_aclk),
        .CE(intrEnableReg),
        .D(s00_axi_wdata[28]),
        .Q(\intrEnableReg_reg_n_0_[28] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \intrEnableReg_reg[29] 
       (.C(s00_axi_aclk),
        .CE(intrEnableReg),
        .D(s00_axi_wdata[29]),
        .Q(\intrEnableReg_reg_n_0_[29] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \intrEnableReg_reg[2] 
       (.C(s00_axi_aclk),
        .CE(intrEnableReg),
        .D(s00_axi_wdata[2]),
        .Q(\intrEnableReg_reg_n_0_[2] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \intrEnableReg_reg[30] 
       (.C(s00_axi_aclk),
        .CE(intrEnableReg),
        .D(s00_axi_wdata[30]),
        .Q(\intrEnableReg_reg_n_0_[30] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \intrEnableReg_reg[31] 
       (.C(s00_axi_aclk),
        .CE(intrEnableReg),
        .D(s00_axi_wdata[31]),
        .Q(\intrEnableReg_reg_n_0_[31] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \intrEnableReg_reg[3] 
       (.C(s00_axi_aclk),
        .CE(intrEnableReg),
        .D(s00_axi_wdata[3]),
        .Q(\intrEnableReg_reg_n_0_[3] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \intrEnableReg_reg[4] 
       (.C(s00_axi_aclk),
        .CE(intrEnableReg),
        .D(s00_axi_wdata[4]),
        .Q(\intrEnableReg_reg_n_0_[4] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \intrEnableReg_reg[5] 
       (.C(s00_axi_aclk),
        .CE(intrEnableReg),
        .D(s00_axi_wdata[5]),
        .Q(\intrEnableReg_reg_n_0_[5] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \intrEnableReg_reg[6] 
       (.C(s00_axi_aclk),
        .CE(intrEnableReg),
        .D(s00_axi_wdata[6]),
        .Q(\intrEnableReg_reg_n_0_[6] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \intrEnableReg_reg[7] 
       (.C(s00_axi_aclk),
        .CE(intrEnableReg),
        .D(s00_axi_wdata[7]),
        .Q(\intrEnableReg_reg_n_0_[7] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \intrEnableReg_reg[8] 
       (.C(s00_axi_aclk),
        .CE(intrEnableReg),
        .D(s00_axi_wdata[8]),
        .Q(\intrEnableReg_reg_n_0_[8] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \intrEnableReg_reg[9] 
       (.C(s00_axi_aclk),
        .CE(intrEnableReg),
        .D(s00_axi_wdata[9]),
        .Q(\intrEnableReg_reg_n_0_[9] ),
        .R(SR));
  (* SOFT_HLUTNM = "soft_lutpair3" *) 
  LUT2 #(
    .INIT(4'h6)) 
    \intrStatReg[10]_i_1 
       (.I0(\intrStatReg_reg_n_0_[10] ),
        .I1(s00_axi_wdata[10]),
        .O(\intrStatReg[10]_i_1_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \intrStatReg[11]_i_1 
       (.I0(\intrStatReg_reg_n_0_[11] ),
        .I1(s00_axi_wdata[11]),
        .O(\intrStatReg[11]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair4" *) 
  LUT2 #(
    .INIT(4'h6)) 
    \intrStatReg[12]_i_1 
       (.I0(\intrStatReg_reg_n_0_[12] ),
        .I1(s00_axi_wdata[12]),
        .O(\intrStatReg[12]_i_1_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \intrStatReg[13]_i_1 
       (.I0(\intrStatReg_reg_n_0_[13] ),
        .I1(s00_axi_wdata[13]),
        .O(\intrStatReg[13]_i_1_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \intrStatReg[14]_i_1 
       (.I0(\intrStatReg_reg_n_0_[14] ),
        .I1(s00_axi_wdata[14]),
        .O(\intrStatReg[14]_i_1_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \intrStatReg[15]_i_1 
       (.I0(\intrStatReg_reg_n_0_[15] ),
        .I1(s00_axi_wdata[15]),
        .O(\intrStatReg[15]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair6" *) 
  LUT2 #(
    .INIT(4'h6)) 
    \intrStatReg[16]_i_1 
       (.I0(\intrStatReg_reg_n_0_[16] ),
        .I1(s00_axi_wdata[16]),
        .O(\intrStatReg[16]_i_1_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \intrStatReg[17]_i_1 
       (.I0(\intrStatReg_reg_n_0_[17] ),
        .I1(s00_axi_wdata[17]),
        .O(\intrStatReg[17]_i_1_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \intrStatReg[18]_i_1 
       (.I0(\intrStatReg_reg_n_0_[18] ),
        .I1(s00_axi_wdata[18]),
        .O(\intrStatReg[18]_i_1_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \intrStatReg[19]_i_1 
       (.I0(\intrStatReg_reg_n_0_[19] ),
        .I1(s00_axi_wdata[19]),
        .O(\intrStatReg[19]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT2 #(
    .INIT(4'h6)) 
    \intrStatReg[20]_i_1 
       (.I0(\intrStatReg_reg_n_0_[20] ),
        .I1(s00_axi_wdata[20]),
        .O(\intrStatReg[20]_i_1_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \intrStatReg[21]_i_1 
       (.I0(\intrStatReg_reg_n_0_[21] ),
        .I1(s00_axi_wdata[21]),
        .O(\intrStatReg[21]_i_1_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \intrStatReg[22]_i_1 
       (.I0(\intrStatReg_reg_n_0_[22] ),
        .I1(s00_axi_wdata[22]),
        .O(\intrStatReg[22]_i_1_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \intrStatReg[23]_i_1 
       (.I0(\intrStatReg_reg_n_0_[23] ),
        .I1(s00_axi_wdata[23]),
        .O(\intrStatReg[23]_i_1_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \intrStatReg[24]_i_1 
       (.I0(\intrStatReg_reg_n_0_[24] ),
        .I1(s00_axi_wdata[24]),
        .O(\intrStatReg[24]_i_1_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \intrStatReg[25]_i_1 
       (.I0(\intrStatReg_reg_n_0_[25] ),
        .I1(s00_axi_wdata[25]),
        .O(\intrStatReg[25]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT2 #(
    .INIT(4'h6)) 
    \intrStatReg[26]_i_1 
       (.I0(\intrStatReg_reg_n_0_[26] ),
        .I1(s00_axi_wdata[26]),
        .O(\intrStatReg[26]_i_1_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \intrStatReg[27]_i_1 
       (.I0(\intrStatReg_reg_n_0_[27] ),
        .I1(s00_axi_wdata[27]),
        .O(\intrStatReg[27]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair7" *) 
  LUT2 #(
    .INIT(4'h6)) 
    \intrStatReg[28]_i_1 
       (.I0(\intrStatReg_reg_n_0_[28] ),
        .I1(s00_axi_wdata[28]),
        .O(\intrStatReg[28]_i_1_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \intrStatReg[29]_i_1 
       (.I0(\intrStatReg_reg_n_0_[29] ),
        .I1(s00_axi_wdata[29]),
        .O(\intrStatReg[29]_i_1_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \intrStatReg[2]_i_1 
       (.I0(\intrStatReg_reg_n_0_[2] ),
        .I1(s00_axi_wdata[2]),
        .O(\intrStatReg[2]_i_1_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \intrStatReg[30]_i_1 
       (.I0(\intrStatReg_reg_n_0_[30] ),
        .I1(s00_axi_wdata[30]),
        .O(\intrStatReg[30]_i_1_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \intrStatReg[31]_i_1 
       (.I0(\intrStatReg[31]_i_3_n_0 ),
        .O(intrStatReg1));
  LUT2 #(
    .INIT(4'h6)) 
    \intrStatReg[31]_i_2 
       (.I0(\intrStatReg_reg_n_0_[31] ),
        .I1(s00_axi_wdata[31]),
        .O(\intrStatReg[31]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFEFFFFFFFF)) 
    \intrStatReg[31]_i_3 
       (.I0(p_0_in[2]),
        .I1(\controlReg[31]_i_2_n_0 ),
        .I2(p_0_in[3]),
        .I3(p_0_in[4]),
        .I4(p_0_in[1]),
        .I5(p_0_in[0]),
        .O(\intrStatReg[31]_i_3_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \intrStatReg[3]_i_1 
       (.I0(\intrStatReg_reg_n_0_[3] ),
        .I1(s00_axi_wdata[3]),
        .O(\intrStatReg[3]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair5" *) 
  LUT2 #(
    .INIT(4'h6)) 
    \intrStatReg[4]_i_1 
       (.I0(\intrStatReg_reg_n_0_[4] ),
        .I1(s00_axi_wdata[4]),
        .O(\intrStatReg[4]_i_1_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \intrStatReg[5]_i_1 
       (.I0(\intrStatReg_reg_n_0_[5] ),
        .I1(s00_axi_wdata[5]),
        .O(\intrStatReg[5]_i_1_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \intrStatReg[6]_i_1 
       (.I0(\intrStatReg_reg_n_0_[6] ),
        .I1(s00_axi_wdata[6]),
        .O(\intrStatReg[6]_i_1_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \intrStatReg[7]_i_1 
       (.I0(\intrStatReg_reg_n_0_[7] ),
        .I1(s00_axi_wdata[7]),
        .O(\intrStatReg[7]_i_1_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \intrStatReg[8]_i_1 
       (.I0(\intrStatReg_reg_n_0_[8] ),
        .I1(s00_axi_wdata[8]),
        .O(\intrStatReg[8]_i_1_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \intrStatReg[9]_i_1 
       (.I0(\intrStatReg_reg_n_0_[9] ),
        .I1(s00_axi_wdata[9]),
        .O(\intrStatReg[9]_i_1_n_0 ));
  FDRE \intrStatReg_reg[0] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(spDebounce_n_1),
        .Q(\intrStatReg_reg_n_0_[0] ),
        .R(SR));
  FDRE \intrStatReg_reg[10] 
       (.C(s00_axi_aclk),
        .CE(intrStatReg1),
        .D(\intrStatReg[10]_i_1_n_0 ),
        .Q(\intrStatReg_reg_n_0_[10] ),
        .R(SR));
  FDRE \intrStatReg_reg[11] 
       (.C(s00_axi_aclk),
        .CE(intrStatReg1),
        .D(\intrStatReg[11]_i_1_n_0 ),
        .Q(\intrStatReg_reg_n_0_[11] ),
        .R(SR));
  FDRE \intrStatReg_reg[12] 
       (.C(s00_axi_aclk),
        .CE(intrStatReg1),
        .D(\intrStatReg[12]_i_1_n_0 ),
        .Q(\intrStatReg_reg_n_0_[12] ),
        .R(SR));
  FDRE \intrStatReg_reg[13] 
       (.C(s00_axi_aclk),
        .CE(intrStatReg1),
        .D(\intrStatReg[13]_i_1_n_0 ),
        .Q(\intrStatReg_reg_n_0_[13] ),
        .R(SR));
  FDRE \intrStatReg_reg[14] 
       (.C(s00_axi_aclk),
        .CE(intrStatReg1),
        .D(\intrStatReg[14]_i_1_n_0 ),
        .Q(\intrStatReg_reg_n_0_[14] ),
        .R(SR));
  FDRE \intrStatReg_reg[15] 
       (.C(s00_axi_aclk),
        .CE(intrStatReg1),
        .D(\intrStatReg[15]_i_1_n_0 ),
        .Q(\intrStatReg_reg_n_0_[15] ),
        .R(SR));
  FDRE \intrStatReg_reg[16] 
       (.C(s00_axi_aclk),
        .CE(intrStatReg1),
        .D(\intrStatReg[16]_i_1_n_0 ),
        .Q(\intrStatReg_reg_n_0_[16] ),
        .R(SR));
  FDRE \intrStatReg_reg[17] 
       (.C(s00_axi_aclk),
        .CE(intrStatReg1),
        .D(\intrStatReg[17]_i_1_n_0 ),
        .Q(\intrStatReg_reg_n_0_[17] ),
        .R(SR));
  FDRE \intrStatReg_reg[18] 
       (.C(s00_axi_aclk),
        .CE(intrStatReg1),
        .D(\intrStatReg[18]_i_1_n_0 ),
        .Q(\intrStatReg_reg_n_0_[18] ),
        .R(SR));
  FDRE \intrStatReg_reg[19] 
       (.C(s00_axi_aclk),
        .CE(intrStatReg1),
        .D(\intrStatReg[19]_i_1_n_0 ),
        .Q(\intrStatReg_reg_n_0_[19] ),
        .R(SR));
  FDRE \intrStatReg_reg[1] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(mT_n_0),
        .Q(\intrStatReg_reg_n_0_[1] ),
        .R(SR));
  FDRE \intrStatReg_reg[20] 
       (.C(s00_axi_aclk),
        .CE(intrStatReg1),
        .D(\intrStatReg[20]_i_1_n_0 ),
        .Q(\intrStatReg_reg_n_0_[20] ),
        .R(SR));
  FDRE \intrStatReg_reg[21] 
       (.C(s00_axi_aclk),
        .CE(intrStatReg1),
        .D(\intrStatReg[21]_i_1_n_0 ),
        .Q(\intrStatReg_reg_n_0_[21] ),
        .R(SR));
  FDRE \intrStatReg_reg[22] 
       (.C(s00_axi_aclk),
        .CE(intrStatReg1),
        .D(\intrStatReg[22]_i_1_n_0 ),
        .Q(\intrStatReg_reg_n_0_[22] ),
        .R(SR));
  FDRE \intrStatReg_reg[23] 
       (.C(s00_axi_aclk),
        .CE(intrStatReg1),
        .D(\intrStatReg[23]_i_1_n_0 ),
        .Q(\intrStatReg_reg_n_0_[23] ),
        .R(SR));
  FDRE \intrStatReg_reg[24] 
       (.C(s00_axi_aclk),
        .CE(intrStatReg1),
        .D(\intrStatReg[24]_i_1_n_0 ),
        .Q(\intrStatReg_reg_n_0_[24] ),
        .R(SR));
  FDRE \intrStatReg_reg[25] 
       (.C(s00_axi_aclk),
        .CE(intrStatReg1),
        .D(\intrStatReg[25]_i_1_n_0 ),
        .Q(\intrStatReg_reg_n_0_[25] ),
        .R(SR));
  FDRE \intrStatReg_reg[26] 
       (.C(s00_axi_aclk),
        .CE(intrStatReg1),
        .D(\intrStatReg[26]_i_1_n_0 ),
        .Q(\intrStatReg_reg_n_0_[26] ),
        .R(SR));
  FDRE \intrStatReg_reg[27] 
       (.C(s00_axi_aclk),
        .CE(intrStatReg1),
        .D(\intrStatReg[27]_i_1_n_0 ),
        .Q(\intrStatReg_reg_n_0_[27] ),
        .R(SR));
  FDRE \intrStatReg_reg[28] 
       (.C(s00_axi_aclk),
        .CE(intrStatReg1),
        .D(\intrStatReg[28]_i_1_n_0 ),
        .Q(\intrStatReg_reg_n_0_[28] ),
        .R(SR));
  FDRE \intrStatReg_reg[29] 
       (.C(s00_axi_aclk),
        .CE(intrStatReg1),
        .D(\intrStatReg[29]_i_1_n_0 ),
        .Q(\intrStatReg_reg_n_0_[29] ),
        .R(SR));
  FDRE \intrStatReg_reg[2] 
       (.C(s00_axi_aclk),
        .CE(intrStatReg1),
        .D(\intrStatReg[2]_i_1_n_0 ),
        .Q(\intrStatReg_reg_n_0_[2] ),
        .R(SR));
  FDRE \intrStatReg_reg[30] 
       (.C(s00_axi_aclk),
        .CE(intrStatReg1),
        .D(\intrStatReg[30]_i_1_n_0 ),
        .Q(\intrStatReg_reg_n_0_[30] ),
        .R(SR));
  FDRE \intrStatReg_reg[31] 
       (.C(s00_axi_aclk),
        .CE(intrStatReg1),
        .D(\intrStatReg[31]_i_2_n_0 ),
        .Q(\intrStatReg_reg_n_0_[31] ),
        .R(SR));
  FDRE \intrStatReg_reg[3] 
       (.C(s00_axi_aclk),
        .CE(intrStatReg1),
        .D(\intrStatReg[3]_i_1_n_0 ),
        .Q(\intrStatReg_reg_n_0_[3] ),
        .R(SR));
  FDRE \intrStatReg_reg[4] 
       (.C(s00_axi_aclk),
        .CE(intrStatReg1),
        .D(\intrStatReg[4]_i_1_n_0 ),
        .Q(\intrStatReg_reg_n_0_[4] ),
        .R(SR));
  FDRE \intrStatReg_reg[5] 
       (.C(s00_axi_aclk),
        .CE(intrStatReg1),
        .D(\intrStatReg[5]_i_1_n_0 ),
        .Q(\intrStatReg_reg_n_0_[5] ),
        .R(SR));
  FDRE \intrStatReg_reg[6] 
       (.C(s00_axi_aclk),
        .CE(intrStatReg1),
        .D(\intrStatReg[6]_i_1_n_0 ),
        .Q(\intrStatReg_reg_n_0_[6] ),
        .R(SR));
  FDRE \intrStatReg_reg[7] 
       (.C(s00_axi_aclk),
        .CE(intrStatReg1),
        .D(\intrStatReg[7]_i_1_n_0 ),
        .Q(\intrStatReg_reg_n_0_[7] ),
        .R(SR));
  FDRE \intrStatReg_reg[8] 
       (.C(s00_axi_aclk),
        .CE(intrStatReg1),
        .D(\intrStatReg[8]_i_1_n_0 ),
        .Q(\intrStatReg_reg_n_0_[8] ),
        .R(SR));
  FDRE \intrStatReg_reg[9] 
       (.C(s00_axi_aclk),
        .CE(intrStatReg1),
        .D(\intrStatReg[9]_i_1_n_0 ),
        .Q(\intrStatReg_reg_n_0_[9] ),
        .R(SR));
  decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_mouseTracker mT
       (.D(p_1_in),
        .Q({\controlReg_reg_n_0_[31] ,\controlReg_reg_n_0_[30] ,\controlReg_reg_n_0_[29] ,\controlReg_reg_n_0_[28] ,\controlReg_reg_n_0_[27] ,\controlReg_reg_n_0_[26] ,\controlReg_reg_n_0_[25] ,\controlReg_reg_n_0_[24] ,\controlReg_reg_n_0_[23] ,\controlReg_reg_n_0_[22] ,\controlReg_reg_n_0_[21] ,\controlReg_reg_n_0_[20] ,\controlReg_reg_n_0_[19] ,\controlReg_reg_n_0_[18] ,\controlReg_reg_n_0_[17] ,\controlReg_reg_n_0_[16] ,\controlReg_reg_n_0_[15] ,\controlReg_reg_n_0_[14] ,\controlReg_reg_n_0_[13] ,\controlReg_reg_n_0_[12] ,\controlReg_reg_n_0_[11] ,\controlReg_reg_n_0_[10] ,\controlReg_reg_n_0_[9] ,\controlReg_reg_n_0_[8] ,\controlReg_reg_n_0_[7] ,\controlReg_reg_n_0_[6] ,\controlReg_reg_n_0_[5] ,\controlReg_reg_n_0_[4] ,\controlReg_reg_n_0_[3] ,\controlReg_reg_n_0_[2] ,\controlReg_reg_n_0_[1] ,\controlReg_reg_n_0_[0] }),
        .\axi_araddr_reg[3] (\axi_rdata[31]_i_3_n_0 ),
        .\axi_araddr_reg[3]_0 (sel0[1:0]),
        .\axi_araddr_reg[4] (\axi_rdata[31]_i_2_n_0 ),
        .\axi_araddr_reg[5] (\axi_rdata[31]_i_5_n_0 ),
        .\axi_awaddr_reg[4] (\intrStatReg[31]_i_3_n_0 ),
        .i_button_down(i_button_down),
        .i_button_left(i_button_left),
        .i_button_right(i_button_right),
        .i_button_up(i_button_up),
        .\intrEnableReg_reg[31] ({\intrEnableReg_reg_n_0_[31] ,\intrEnableReg_reg_n_0_[30] ,\intrEnableReg_reg_n_0_[29] ,\intrEnableReg_reg_n_0_[28] ,\intrEnableReg_reg_n_0_[27] ,\intrEnableReg_reg_n_0_[26] ,\intrEnableReg_reg_n_0_[25] ,\intrEnableReg_reg_n_0_[24] ,\intrEnableReg_reg_n_0_[23] ,\intrEnableReg_reg_n_0_[22] ,\intrEnableReg_reg_n_0_[21] ,\intrEnableReg_reg_n_0_[20] ,\intrEnableReg_reg_n_0_[19] ,\intrEnableReg_reg_n_0_[18] ,\intrEnableReg_reg_n_0_[17] ,\intrEnableReg_reg_n_0_[16] ,\intrEnableReg_reg_n_0_[15] ,\intrEnableReg_reg_n_0_[14] ,\intrEnableReg_reg_n_0_[13] ,\intrEnableReg_reg_n_0_[12] ,\intrEnableReg_reg_n_0_[11] ,\intrEnableReg_reg_n_0_[10] ,\intrEnableReg_reg_n_0_[9] ,\intrEnableReg_reg_n_0_[8] ,\intrEnableReg_reg_n_0_[7] ,\intrEnableReg_reg_n_0_[6] ,\intrEnableReg_reg_n_0_[5] ,\intrEnableReg_reg_n_0_[4] ,\intrEnableReg_reg_n_0_[3] ,\intrEnableReg_reg_n_0_[2] ,\intrEnableReg_reg_n_0_[1] ,\intrEnableReg_reg_n_0_[0] }),
        .\intrStatReg_reg[0] (\intrStatReg_reg_n_0_[0] ),
        .\intrStatReg_reg[10] (\intrStatReg_reg_n_0_[10] ),
        .\intrStatReg_reg[11] (\intrStatReg_reg_n_0_[11] ),
        .\intrStatReg_reg[12] (\intrStatReg_reg_n_0_[12] ),
        .\intrStatReg_reg[13] (\intrStatReg_reg_n_0_[13] ),
        .\intrStatReg_reg[14] (\intrStatReg_reg_n_0_[14] ),
        .\intrStatReg_reg[15] (\intrStatReg_reg_n_0_[15] ),
        .\intrStatReg_reg[16] (\intrStatReg_reg_n_0_[16] ),
        .\intrStatReg_reg[17] (\intrStatReg_reg_n_0_[17] ),
        .\intrStatReg_reg[18] (\intrStatReg_reg_n_0_[18] ),
        .\intrStatReg_reg[19] (\intrStatReg_reg_n_0_[19] ),
        .\intrStatReg_reg[1] (mT_n_0),
        .\intrStatReg_reg[1]_0 (\intrStatReg_reg_n_0_[1] ),
        .\intrStatReg_reg[20] (\intrStatReg_reg_n_0_[20] ),
        .\intrStatReg_reg[21] (\intrStatReg_reg_n_0_[21] ),
        .\intrStatReg_reg[22] (\intrStatReg_reg_n_0_[22] ),
        .\intrStatReg_reg[23] (\intrStatReg_reg_n_0_[23] ),
        .\intrStatReg_reg[24] (\intrStatReg_reg_n_0_[24] ),
        .\intrStatReg_reg[25] (\intrStatReg_reg_n_0_[25] ),
        .\intrStatReg_reg[26] (\intrStatReg_reg_n_0_[26] ),
        .\intrStatReg_reg[27] (\intrStatReg_reg_n_0_[27] ),
        .\intrStatReg_reg[28] (\intrStatReg_reg_n_0_[28] ),
        .\intrStatReg_reg[29] (\intrStatReg_reg_n_0_[29] ),
        .\intrStatReg_reg[2] (\intrStatReg_reg_n_0_[2] ),
        .\intrStatReg_reg[30] (\intrStatReg_reg_n_0_[30] ),
        .\intrStatReg_reg[31] (\intrStatReg_reg_n_0_[31] ),
        .\intrStatReg_reg[3] (\intrStatReg_reg_n_0_[3] ),
        .\intrStatReg_reg[4] (\intrStatReg_reg_n_0_[4] ),
        .\intrStatReg_reg[5] (\intrStatReg_reg_n_0_[5] ),
        .\intrStatReg_reg[6] (\intrStatReg_reg_n_0_[6] ),
        .\intrStatReg_reg[7] (\intrStatReg_reg_n_0_[7] ),
        .\intrStatReg_reg[8] (\intrStatReg_reg_n_0_[8] ),
        .\intrStatReg_reg[9] (\intrStatReg_reg_n_0_[9] ),
        .\maxCoordinateReg_reg[31] ({\maxCoordinateReg_reg_n_0_[31] ,\maxCoordinateReg_reg_n_0_[30] ,\maxCoordinateReg_reg_n_0_[29] ,\maxCoordinateReg_reg_n_0_[28] ,\maxCoordinateReg_reg_n_0_[27] ,\maxCoordinateReg_reg_n_0_[26] ,\maxCoordinateReg_reg_n_0_[25] ,\maxCoordinateReg_reg_n_0_[24] ,\maxCoordinateReg_reg_n_0_[23] ,\maxCoordinateReg_reg_n_0_[22] ,\maxCoordinateReg_reg_n_0_[21] ,\maxCoordinateReg_reg_n_0_[20] ,\maxCoordinateReg_reg_n_0_[19] ,\maxCoordinateReg_reg_n_0_[18] ,\maxCoordinateReg_reg_n_0_[17] ,\maxCoordinateReg_reg_n_0_[16] ,\maxCoordinateReg_reg_n_0_[15] ,\maxCoordinateReg_reg_n_0_[14] ,\maxCoordinateReg_reg_n_0_[13] ,\maxCoordinateReg_reg_n_0_[12] ,\maxCoordinateReg_reg_n_0_[11] ,\maxCoordinateReg_reg_n_0_[10] ,\maxCoordinateReg_reg_n_0_[9] ,\maxCoordinateReg_reg_n_0_[8] ,\maxCoordinateReg_reg_n_0_[7] ,\maxCoordinateReg_reg_n_0_[6] ,\maxCoordinateReg_reg_n_0_[5] ,\maxCoordinateReg_reg_n_0_[4] ,\maxCoordinateReg_reg_n_0_[3] ,\maxCoordinateReg_reg_n_0_[2] ,\maxCoordinateReg_reg_n_0_[1] ,\maxCoordinateReg_reg_n_0_[0] }),
        .\maxCountReg_reg[31] ({\maxCountReg_reg_n_0_[31] ,\maxCountReg_reg_n_0_[30] ,\maxCountReg_reg_n_0_[29] ,\maxCountReg_reg_n_0_[28] ,\maxCountReg_reg_n_0_[27] ,\maxCountReg_reg_n_0_[26] ,\maxCountReg_reg_n_0_[25] ,\maxCountReg_reg_n_0_[24] ,\maxCountReg_reg_n_0_[23] ,\maxCountReg_reg_n_0_[22] ,\maxCountReg_reg_n_0_[21] ,\maxCountReg_reg_n_0_[20] ,\maxCountReg_reg_n_0_[19] ,\maxCountReg_reg_n_0_[18] ,\maxCountReg_reg_n_0_[17] ,\maxCountReg_reg_n_0_[16] ,\maxCountReg_reg_n_0_[15] ,\maxCountReg_reg_n_0_[14] ,\maxCountReg_reg_n_0_[13] ,\maxCountReg_reg_n_0_[12] ,\maxCountReg_reg_n_0_[11] ,\maxCountReg_reg_n_0_[10] ,\maxCountReg_reg_n_0_[9] ,\maxCountReg_reg_n_0_[8] ,\maxCountReg_reg_n_0_[7] ,\maxCountReg_reg_n_0_[6] ,\maxCountReg_reg_n_0_[5] ,\maxCountReg_reg_n_0_[4] ,\maxCountReg_reg_n_0_[3] ,\maxCountReg_reg_n_0_[2] ,\maxCountReg_reg_n_0_[1] ,\maxCountReg_reg_n_0_[0] }),
        .s00_axi_aclk(s00_axi_aclk),
        .s00_axi_wdata(s00_axi_wdata[1]),
        .w_button_pulse(w_button_pulse));
  LUT6 #(
    .INIT(64'h0000000000000008)) 
    \maxCoordinateReg[31]_i_1 
       (.I0(p_0_in[2]),
        .I1(p_0_in[0]),
        .I2(p_0_in[1]),
        .I3(p_0_in[4]),
        .I4(p_0_in[3]),
        .I5(\controlReg[31]_i_2_n_0 ),
        .O(maxCoordinateReg));
  FDRE \maxCoordinateReg_reg[0] 
       (.C(s00_axi_aclk),
        .CE(maxCoordinateReg),
        .D(s00_axi_wdata[0]),
        .Q(\maxCoordinateReg_reg_n_0_[0] ),
        .R(SR));
  FDRE \maxCoordinateReg_reg[10] 
       (.C(s00_axi_aclk),
        .CE(maxCoordinateReg),
        .D(s00_axi_wdata[10]),
        .Q(\maxCoordinateReg_reg_n_0_[10] ),
        .R(SR));
  FDRE \maxCoordinateReg_reg[11] 
       (.C(s00_axi_aclk),
        .CE(maxCoordinateReg),
        .D(s00_axi_wdata[11]),
        .Q(\maxCoordinateReg_reg_n_0_[11] ),
        .R(SR));
  FDRE \maxCoordinateReg_reg[12] 
       (.C(s00_axi_aclk),
        .CE(maxCoordinateReg),
        .D(s00_axi_wdata[12]),
        .Q(\maxCoordinateReg_reg_n_0_[12] ),
        .R(SR));
  FDRE \maxCoordinateReg_reg[13] 
       (.C(s00_axi_aclk),
        .CE(maxCoordinateReg),
        .D(s00_axi_wdata[13]),
        .Q(\maxCoordinateReg_reg_n_0_[13] ),
        .R(SR));
  FDRE \maxCoordinateReg_reg[14] 
       (.C(s00_axi_aclk),
        .CE(maxCoordinateReg),
        .D(s00_axi_wdata[14]),
        .Q(\maxCoordinateReg_reg_n_0_[14] ),
        .R(SR));
  FDRE \maxCoordinateReg_reg[15] 
       (.C(s00_axi_aclk),
        .CE(maxCoordinateReg),
        .D(s00_axi_wdata[15]),
        .Q(\maxCoordinateReg_reg_n_0_[15] ),
        .R(SR));
  FDRE \maxCoordinateReg_reg[16] 
       (.C(s00_axi_aclk),
        .CE(maxCoordinateReg),
        .D(s00_axi_wdata[16]),
        .Q(\maxCoordinateReg_reg_n_0_[16] ),
        .R(SR));
  FDRE \maxCoordinateReg_reg[17] 
       (.C(s00_axi_aclk),
        .CE(maxCoordinateReg),
        .D(s00_axi_wdata[17]),
        .Q(\maxCoordinateReg_reg_n_0_[17] ),
        .R(SR));
  FDRE \maxCoordinateReg_reg[18] 
       (.C(s00_axi_aclk),
        .CE(maxCoordinateReg),
        .D(s00_axi_wdata[18]),
        .Q(\maxCoordinateReg_reg_n_0_[18] ),
        .R(SR));
  FDRE \maxCoordinateReg_reg[19] 
       (.C(s00_axi_aclk),
        .CE(maxCoordinateReg),
        .D(s00_axi_wdata[19]),
        .Q(\maxCoordinateReg_reg_n_0_[19] ),
        .R(SR));
  FDRE \maxCoordinateReg_reg[1] 
       (.C(s00_axi_aclk),
        .CE(maxCoordinateReg),
        .D(s00_axi_wdata[1]),
        .Q(\maxCoordinateReg_reg_n_0_[1] ),
        .R(SR));
  FDRE \maxCoordinateReg_reg[20] 
       (.C(s00_axi_aclk),
        .CE(maxCoordinateReg),
        .D(s00_axi_wdata[20]),
        .Q(\maxCoordinateReg_reg_n_0_[20] ),
        .R(SR));
  FDRE \maxCoordinateReg_reg[21] 
       (.C(s00_axi_aclk),
        .CE(maxCoordinateReg),
        .D(s00_axi_wdata[21]),
        .Q(\maxCoordinateReg_reg_n_0_[21] ),
        .R(SR));
  FDRE \maxCoordinateReg_reg[22] 
       (.C(s00_axi_aclk),
        .CE(maxCoordinateReg),
        .D(s00_axi_wdata[22]),
        .Q(\maxCoordinateReg_reg_n_0_[22] ),
        .R(SR));
  FDRE \maxCoordinateReg_reg[23] 
       (.C(s00_axi_aclk),
        .CE(maxCoordinateReg),
        .D(s00_axi_wdata[23]),
        .Q(\maxCoordinateReg_reg_n_0_[23] ),
        .R(SR));
  FDRE \maxCoordinateReg_reg[24] 
       (.C(s00_axi_aclk),
        .CE(maxCoordinateReg),
        .D(s00_axi_wdata[24]),
        .Q(\maxCoordinateReg_reg_n_0_[24] ),
        .R(SR));
  FDRE \maxCoordinateReg_reg[25] 
       (.C(s00_axi_aclk),
        .CE(maxCoordinateReg),
        .D(s00_axi_wdata[25]),
        .Q(\maxCoordinateReg_reg_n_0_[25] ),
        .R(SR));
  FDRE \maxCoordinateReg_reg[26] 
       (.C(s00_axi_aclk),
        .CE(maxCoordinateReg),
        .D(s00_axi_wdata[26]),
        .Q(\maxCoordinateReg_reg_n_0_[26] ),
        .R(SR));
  FDRE \maxCoordinateReg_reg[27] 
       (.C(s00_axi_aclk),
        .CE(maxCoordinateReg),
        .D(s00_axi_wdata[27]),
        .Q(\maxCoordinateReg_reg_n_0_[27] ),
        .R(SR));
  FDRE \maxCoordinateReg_reg[28] 
       (.C(s00_axi_aclk),
        .CE(maxCoordinateReg),
        .D(s00_axi_wdata[28]),
        .Q(\maxCoordinateReg_reg_n_0_[28] ),
        .R(SR));
  FDRE \maxCoordinateReg_reg[29] 
       (.C(s00_axi_aclk),
        .CE(maxCoordinateReg),
        .D(s00_axi_wdata[29]),
        .Q(\maxCoordinateReg_reg_n_0_[29] ),
        .R(SR));
  FDRE \maxCoordinateReg_reg[2] 
       (.C(s00_axi_aclk),
        .CE(maxCoordinateReg),
        .D(s00_axi_wdata[2]),
        .Q(\maxCoordinateReg_reg_n_0_[2] ),
        .R(SR));
  FDRE \maxCoordinateReg_reg[30] 
       (.C(s00_axi_aclk),
        .CE(maxCoordinateReg),
        .D(s00_axi_wdata[30]),
        .Q(\maxCoordinateReg_reg_n_0_[30] ),
        .R(SR));
  FDRE \maxCoordinateReg_reg[31] 
       (.C(s00_axi_aclk),
        .CE(maxCoordinateReg),
        .D(s00_axi_wdata[31]),
        .Q(\maxCoordinateReg_reg_n_0_[31] ),
        .R(SR));
  FDRE \maxCoordinateReg_reg[3] 
       (.C(s00_axi_aclk),
        .CE(maxCoordinateReg),
        .D(s00_axi_wdata[3]),
        .Q(\maxCoordinateReg_reg_n_0_[3] ),
        .R(SR));
  FDRE \maxCoordinateReg_reg[4] 
       (.C(s00_axi_aclk),
        .CE(maxCoordinateReg),
        .D(s00_axi_wdata[4]),
        .Q(\maxCoordinateReg_reg_n_0_[4] ),
        .R(SR));
  FDRE \maxCoordinateReg_reg[5] 
       (.C(s00_axi_aclk),
        .CE(maxCoordinateReg),
        .D(s00_axi_wdata[5]),
        .Q(\maxCoordinateReg_reg_n_0_[5] ),
        .R(SR));
  FDRE \maxCoordinateReg_reg[6] 
       (.C(s00_axi_aclk),
        .CE(maxCoordinateReg),
        .D(s00_axi_wdata[6]),
        .Q(\maxCoordinateReg_reg_n_0_[6] ),
        .R(SR));
  FDRE \maxCoordinateReg_reg[7] 
       (.C(s00_axi_aclk),
        .CE(maxCoordinateReg),
        .D(s00_axi_wdata[7]),
        .Q(\maxCoordinateReg_reg_n_0_[7] ),
        .R(SR));
  FDRE \maxCoordinateReg_reg[8] 
       (.C(s00_axi_aclk),
        .CE(maxCoordinateReg),
        .D(s00_axi_wdata[8]),
        .Q(\maxCoordinateReg_reg_n_0_[8] ),
        .R(SR));
  FDRE \maxCoordinateReg_reg[9] 
       (.C(s00_axi_aclk),
        .CE(maxCoordinateReg),
        .D(s00_axi_wdata[9]),
        .Q(\maxCoordinateReg_reg_n_0_[9] ),
        .R(SR));
  LUT6 #(
    .INIT(64'h0000000000000004)) 
    \maxCountReg[31]_i_1 
       (.I0(p_0_in[0]),
        .I1(p_0_in[2]),
        .I2(p_0_in[1]),
        .I3(p_0_in[4]),
        .I4(p_0_in[3]),
        .I5(\controlReg[31]_i_2_n_0 ),
        .O(maxCountReg));
  FDRE \maxCountReg_reg[0] 
       (.C(s00_axi_aclk),
        .CE(maxCountReg),
        .D(s00_axi_wdata[0]),
        .Q(\maxCountReg_reg_n_0_[0] ),
        .R(SR));
  FDRE \maxCountReg_reg[10] 
       (.C(s00_axi_aclk),
        .CE(maxCountReg),
        .D(s00_axi_wdata[10]),
        .Q(\maxCountReg_reg_n_0_[10] ),
        .R(SR));
  FDRE \maxCountReg_reg[11] 
       (.C(s00_axi_aclk),
        .CE(maxCountReg),
        .D(s00_axi_wdata[11]),
        .Q(\maxCountReg_reg_n_0_[11] ),
        .R(SR));
  FDRE \maxCountReg_reg[12] 
       (.C(s00_axi_aclk),
        .CE(maxCountReg),
        .D(s00_axi_wdata[12]),
        .Q(\maxCountReg_reg_n_0_[12] ),
        .R(SR));
  FDRE \maxCountReg_reg[13] 
       (.C(s00_axi_aclk),
        .CE(maxCountReg),
        .D(s00_axi_wdata[13]),
        .Q(\maxCountReg_reg_n_0_[13] ),
        .R(SR));
  FDRE \maxCountReg_reg[14] 
       (.C(s00_axi_aclk),
        .CE(maxCountReg),
        .D(s00_axi_wdata[14]),
        .Q(\maxCountReg_reg_n_0_[14] ),
        .R(SR));
  FDRE \maxCountReg_reg[15] 
       (.C(s00_axi_aclk),
        .CE(maxCountReg),
        .D(s00_axi_wdata[15]),
        .Q(\maxCountReg_reg_n_0_[15] ),
        .R(SR));
  FDRE \maxCountReg_reg[16] 
       (.C(s00_axi_aclk),
        .CE(maxCountReg),
        .D(s00_axi_wdata[16]),
        .Q(\maxCountReg_reg_n_0_[16] ),
        .R(SR));
  FDRE \maxCountReg_reg[17] 
       (.C(s00_axi_aclk),
        .CE(maxCountReg),
        .D(s00_axi_wdata[17]),
        .Q(\maxCountReg_reg_n_0_[17] ),
        .R(SR));
  FDRE \maxCountReg_reg[18] 
       (.C(s00_axi_aclk),
        .CE(maxCountReg),
        .D(s00_axi_wdata[18]),
        .Q(\maxCountReg_reg_n_0_[18] ),
        .R(SR));
  FDRE \maxCountReg_reg[19] 
       (.C(s00_axi_aclk),
        .CE(maxCountReg),
        .D(s00_axi_wdata[19]),
        .Q(\maxCountReg_reg_n_0_[19] ),
        .R(SR));
  FDRE \maxCountReg_reg[1] 
       (.C(s00_axi_aclk),
        .CE(maxCountReg),
        .D(s00_axi_wdata[1]),
        .Q(\maxCountReg_reg_n_0_[1] ),
        .R(SR));
  FDRE \maxCountReg_reg[20] 
       (.C(s00_axi_aclk),
        .CE(maxCountReg),
        .D(s00_axi_wdata[20]),
        .Q(\maxCountReg_reg_n_0_[20] ),
        .R(SR));
  FDRE \maxCountReg_reg[21] 
       (.C(s00_axi_aclk),
        .CE(maxCountReg),
        .D(s00_axi_wdata[21]),
        .Q(\maxCountReg_reg_n_0_[21] ),
        .R(SR));
  FDRE \maxCountReg_reg[22] 
       (.C(s00_axi_aclk),
        .CE(maxCountReg),
        .D(s00_axi_wdata[22]),
        .Q(\maxCountReg_reg_n_0_[22] ),
        .R(SR));
  FDRE \maxCountReg_reg[23] 
       (.C(s00_axi_aclk),
        .CE(maxCountReg),
        .D(s00_axi_wdata[23]),
        .Q(\maxCountReg_reg_n_0_[23] ),
        .R(SR));
  FDRE \maxCountReg_reg[24] 
       (.C(s00_axi_aclk),
        .CE(maxCountReg),
        .D(s00_axi_wdata[24]),
        .Q(\maxCountReg_reg_n_0_[24] ),
        .R(SR));
  FDRE \maxCountReg_reg[25] 
       (.C(s00_axi_aclk),
        .CE(maxCountReg),
        .D(s00_axi_wdata[25]),
        .Q(\maxCountReg_reg_n_0_[25] ),
        .R(SR));
  FDRE \maxCountReg_reg[26] 
       (.C(s00_axi_aclk),
        .CE(maxCountReg),
        .D(s00_axi_wdata[26]),
        .Q(\maxCountReg_reg_n_0_[26] ),
        .R(SR));
  FDRE \maxCountReg_reg[27] 
       (.C(s00_axi_aclk),
        .CE(maxCountReg),
        .D(s00_axi_wdata[27]),
        .Q(\maxCountReg_reg_n_0_[27] ),
        .R(SR));
  FDRE \maxCountReg_reg[28] 
       (.C(s00_axi_aclk),
        .CE(maxCountReg),
        .D(s00_axi_wdata[28]),
        .Q(\maxCountReg_reg_n_0_[28] ),
        .R(SR));
  FDRE \maxCountReg_reg[29] 
       (.C(s00_axi_aclk),
        .CE(maxCountReg),
        .D(s00_axi_wdata[29]),
        .Q(\maxCountReg_reg_n_0_[29] ),
        .R(SR));
  FDRE \maxCountReg_reg[2] 
       (.C(s00_axi_aclk),
        .CE(maxCountReg),
        .D(s00_axi_wdata[2]),
        .Q(\maxCountReg_reg_n_0_[2] ),
        .R(SR));
  FDRE \maxCountReg_reg[30] 
       (.C(s00_axi_aclk),
        .CE(maxCountReg),
        .D(s00_axi_wdata[30]),
        .Q(\maxCountReg_reg_n_0_[30] ),
        .R(SR));
  FDRE \maxCountReg_reg[31] 
       (.C(s00_axi_aclk),
        .CE(maxCountReg),
        .D(s00_axi_wdata[31]),
        .Q(\maxCountReg_reg_n_0_[31] ),
        .R(SR));
  FDRE \maxCountReg_reg[3] 
       (.C(s00_axi_aclk),
        .CE(maxCountReg),
        .D(s00_axi_wdata[3]),
        .Q(\maxCountReg_reg_n_0_[3] ),
        .R(SR));
  FDRE \maxCountReg_reg[4] 
       (.C(s00_axi_aclk),
        .CE(maxCountReg),
        .D(s00_axi_wdata[4]),
        .Q(\maxCountReg_reg_n_0_[4] ),
        .R(SR));
  FDRE \maxCountReg_reg[5] 
       (.C(s00_axi_aclk),
        .CE(maxCountReg),
        .D(s00_axi_wdata[5]),
        .Q(\maxCountReg_reg_n_0_[5] ),
        .R(SR));
  FDRE \maxCountReg_reg[6] 
       (.C(s00_axi_aclk),
        .CE(maxCountReg),
        .D(s00_axi_wdata[6]),
        .Q(\maxCountReg_reg_n_0_[6] ),
        .R(SR));
  FDRE \maxCountReg_reg[7] 
       (.C(s00_axi_aclk),
        .CE(maxCountReg),
        .D(s00_axi_wdata[7]),
        .Q(\maxCountReg_reg_n_0_[7] ),
        .R(SR));
  FDRE \maxCountReg_reg[8] 
       (.C(s00_axi_aclk),
        .CE(maxCountReg),
        .D(s00_axi_wdata[8]),
        .Q(\maxCountReg_reg_n_0_[8] ),
        .R(SR));
  FDRE \maxCountReg_reg[9] 
       (.C(s00_axi_aclk),
        .CE(maxCountReg),
        .D(s00_axi_wdata[9]),
        .Q(\maxCountReg_reg_n_0_[9] ),
        .R(SR));
  (* SOFT_HLUTNM = "soft_lutpair6" *) 
  LUT4 #(
    .INIT(16'hF888)) 
    o_intr_i_10__0
       (.I0(\intrEnableReg_reg_n_0_[16] ),
        .I1(\intrStatReg_reg_n_0_[16] ),
        .I2(\intrEnableReg_reg_n_0_[17] ),
        .I3(\intrStatReg_reg_n_0_[17] ),
        .O(o_intr_i_10__0_n_0));
  LUT5 #(
    .INIT(32'h00000777)) 
    o_intr_i_11
       (.I0(\intrStatReg_reg_n_0_[23] ),
        .I1(\intrEnableReg_reg_n_0_[23] ),
        .I2(\intrStatReg_reg_n_0_[22] ),
        .I3(\intrEnableReg_reg_n_0_[22] ),
        .I4(o_intr_i_16_n_0),
        .O(o_intr_i_11_n_0));
  (* SOFT_HLUTNM = "soft_lutpair7" *) 
  LUT4 #(
    .INIT(16'hF888)) 
    o_intr_i_12
       (.I0(\intrEnableReg_reg_n_0_[28] ),
        .I1(\intrStatReg_reg_n_0_[28] ),
        .I2(\intrEnableReg_reg_n_0_[29] ),
        .I3(\intrStatReg_reg_n_0_[29] ),
        .O(o_intr_i_12_n_0));
  LUT5 #(
    .INIT(32'hF888FFFF)) 
    o_intr_i_13
       (.I0(\intrStatReg_reg_n_0_[25] ),
        .I1(\intrEnableReg_reg_n_0_[25] ),
        .I2(\intrStatReg_reg_n_0_[24] ),
        .I3(\intrEnableReg_reg_n_0_[24] ),
        .I4(o_intr_i_17_n_0),
        .O(o_intr_i_13_n_0));
  (* SOFT_HLUTNM = "soft_lutpair5" *) 
  LUT4 #(
    .INIT(16'hF888)) 
    o_intr_i_14
       (.I0(\intrEnableReg_reg_n_0_[4] ),
        .I1(\intrStatReg_reg_n_0_[4] ),
        .I2(\intrEnableReg_reg_n_0_[5] ),
        .I3(\intrStatReg_reg_n_0_[5] ),
        .O(o_intr_i_14_n_0));
  (* SOFT_HLUTNM = "soft_lutpair3" *) 
  LUT4 #(
    .INIT(16'h0777)) 
    o_intr_i_15
       (.I0(\intrEnableReg_reg_n_0_[10] ),
        .I1(\intrStatReg_reg_n_0_[10] ),
        .I2(\intrEnableReg_reg_n_0_[11] ),
        .I3(\intrStatReg_reg_n_0_[11] ),
        .O(o_intr_i_15_n_0));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT4 #(
    .INIT(16'hF888)) 
    o_intr_i_16
       (.I0(\intrEnableReg_reg_n_0_[20] ),
        .I1(\intrStatReg_reg_n_0_[20] ),
        .I2(\intrEnableReg_reg_n_0_[21] ),
        .I3(\intrStatReg_reg_n_0_[21] ),
        .O(o_intr_i_16_n_0));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT4 #(
    .INIT(16'h0777)) 
    o_intr_i_17
       (.I0(\intrEnableReg_reg_n_0_[26] ),
        .I1(\intrStatReg_reg_n_0_[26] ),
        .I2(\intrEnableReg_reg_n_0_[27] ),
        .I3(\intrStatReg_reg_n_0_[27] ),
        .O(o_intr_i_17_n_0));
  LUT4 #(
    .INIT(16'hFBFF)) 
    o_intr_i_1__0
       (.I0(o_intr_i_2__0_n_0),
        .I1(o_intr_i_3__0_n_0),
        .I2(o_intr_i_4__0_n_0),
        .I3(o_intr_i_5__0_n_0),
        .O(o_intr_i_1__0_n_0));
  LUT6 #(
    .INIT(64'hFFEAEAEAFFFFFFFF)) 
    o_intr_i_2__0
       (.I0(o_intr_i_6__0_n_0),
        .I1(\intrEnableReg_reg_n_0_[2] ),
        .I2(\intrStatReg_reg_n_0_[2] ),
        .I3(\intrEnableReg_reg_n_0_[3] ),
        .I4(\intrStatReg_reg_n_0_[3] ),
        .I5(o_intr_i_7__0_n_0),
        .O(o_intr_i_2__0_n_0));
  LUT6 #(
    .INIT(64'h0000000000151515)) 
    o_intr_i_3__0
       (.I0(o_intr_i_8__0_n_0),
        .I1(\intrEnableReg_reg_n_0_[14] ),
        .I2(\intrStatReg_reg_n_0_[14] ),
        .I3(\intrEnableReg_reg_n_0_[15] ),
        .I4(\intrStatReg_reg_n_0_[15] ),
        .I5(o_intr_i_9__0_n_0),
        .O(o_intr_i_3__0_n_0));
  LUT6 #(
    .INIT(64'hFFEAEAEAFFFFFFFF)) 
    o_intr_i_4__0
       (.I0(o_intr_i_10__0_n_0),
        .I1(\intrEnableReg_reg_n_0_[18] ),
        .I2(\intrStatReg_reg_n_0_[18] ),
        .I3(\intrEnableReg_reg_n_0_[19] ),
        .I4(\intrStatReg_reg_n_0_[19] ),
        .I5(o_intr_i_11_n_0),
        .O(o_intr_i_4__0_n_0));
  LUT6 #(
    .INIT(64'h0000000000151515)) 
    o_intr_i_5__0
       (.I0(o_intr_i_12_n_0),
        .I1(\intrEnableReg_reg_n_0_[31] ),
        .I2(\intrStatReg_reg_n_0_[31] ),
        .I3(\intrEnableReg_reg_n_0_[30] ),
        .I4(\intrStatReg_reg_n_0_[30] ),
        .I5(o_intr_i_13_n_0),
        .O(o_intr_i_5__0_n_0));
  LUT4 #(
    .INIT(16'hF888)) 
    o_intr_i_6__0
       (.I0(\intrEnableReg_reg_n_0_[0] ),
        .I1(\intrStatReg_reg_n_0_[0] ),
        .I2(\intrEnableReg_reg_n_0_[1] ),
        .I3(\intrStatReg_reg_n_0_[1] ),
        .O(o_intr_i_6__0_n_0));
  LUT5 #(
    .INIT(32'h00000777)) 
    o_intr_i_7__0
       (.I0(\intrStatReg_reg_n_0_[7] ),
        .I1(\intrEnableReg_reg_n_0_[7] ),
        .I2(\intrStatReg_reg_n_0_[6] ),
        .I3(\intrEnableReg_reg_n_0_[6] ),
        .I4(o_intr_i_14_n_0),
        .O(o_intr_i_7__0_n_0));
  (* SOFT_HLUTNM = "soft_lutpair4" *) 
  LUT4 #(
    .INIT(16'hF888)) 
    o_intr_i_8__0
       (.I0(\intrEnableReg_reg_n_0_[12] ),
        .I1(\intrStatReg_reg_n_0_[12] ),
        .I2(\intrEnableReg_reg_n_0_[13] ),
        .I3(\intrStatReg_reg_n_0_[13] ),
        .O(o_intr_i_8__0_n_0));
  LUT5 #(
    .INIT(32'hF888FFFF)) 
    o_intr_i_9__0
       (.I0(\intrStatReg_reg_n_0_[9] ),
        .I1(\intrEnableReg_reg_n_0_[9] ),
        .I2(\intrStatReg_reg_n_0_[8] ),
        .I3(\intrEnableReg_reg_n_0_[8] ),
        .I4(o_intr_i_15_n_0),
        .O(o_intr_i_9__0_n_0));
  FDRE o_intr_reg
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(o_intr_i_1__0_n_0),
        .Q(o_intr),
        .R(1'b0));
  LUT3 #(
    .INIT(8'h40)) 
    slv_reg_rden
       (.I0(s00_axi_rvalid),
        .I1(s00_axi_arready),
        .I2(s00_axi_arvalid),
        .O(slv_reg_rden__0));
  decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_singlePulseDebounce spDebounce
       (.\axi_awaddr_reg[4] (\intrStatReg[31]_i_3_n_0 ),
        .i_button_press(i_button_press),
        .\intrStatReg_reg[0] (spDebounce_n_1),
        .\intrStatReg_reg[0]_0 (\intrStatReg_reg_n_0_[0] ),
        .s00_axi_aclk(s00_axi_aclk),
        .s00_axi_wdata(s00_axi_wdata[0]),
        .w_button_pulse(w_button_pulse));
endmodule
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

endmodule
`endif
