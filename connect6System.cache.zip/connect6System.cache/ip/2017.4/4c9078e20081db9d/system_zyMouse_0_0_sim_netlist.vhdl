-- Copyright 1986-2017 Xilinx, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2017.4 (win64) Build 2086221 Fri Dec 15 20:55:39 MST 2017
-- Date        : Thu Apr  2 23:14:57 2026
-- Host        : DESKTOP-VKRMBR2 running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode funcsim -rename_top decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix -prefix
--               decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_ system_zyMouse_0_0_sim_netlist.vhdl
-- Design      : system_zyMouse_0_0
-- Purpose     : This VHDL netlist is a functional simulation representation of the design and should not be modified or
--               synthesized. This netlist cannot be used for SDF annotated simulation.
-- Device      : xc7z020clg484-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_debounce is
  port (
    \counter_reg[31]_0\ : out STD_LOGIC;
    s00_axi_aclk : in STD_LOGIC;
    CO : in STD_LOGIC_VECTOR ( 0 to 0 );
    i_button_down : in STD_LOGIC
  );
end decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_debounce;

architecture STRUCTURE of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_debounce is
  signal button_down : STD_LOGIC;
  signal counter : STD_LOGIC;
  signal \counter1_carry__0_i_1__0_n_0\ : STD_LOGIC;
  signal \counter1_carry__0_i_2__0_n_0\ : STD_LOGIC;
  signal \counter1_carry__0_i_3__0_n_0\ : STD_LOGIC;
  signal \counter1_carry__0_i_4__2_n_0\ : STD_LOGIC;
  signal \counter1_carry__0_i_5__2_n_0\ : STD_LOGIC;
  signal \counter1_carry__0_i_6__2_n_0\ : STD_LOGIC;
  signal \counter1_carry__0_i_7__2_n_0\ : STD_LOGIC;
  signal \counter1_carry__0_n_0\ : STD_LOGIC;
  signal \counter1_carry__0_n_1\ : STD_LOGIC;
  signal \counter1_carry__0_n_2\ : STD_LOGIC;
  signal \counter1_carry__0_n_3\ : STD_LOGIC;
  signal \counter1_carry__1_i_1__2_n_0\ : STD_LOGIC;
  signal \counter1_carry__1_i_2__2_n_0\ : STD_LOGIC;
  signal \counter1_carry__1_i_3__2_n_0\ : STD_LOGIC;
  signal \counter1_carry__1_i_4__2_n_0\ : STD_LOGIC;
  signal \counter1_carry__1_n_0\ : STD_LOGIC;
  signal \counter1_carry__1_n_1\ : STD_LOGIC;
  signal \counter1_carry__1_n_2\ : STD_LOGIC;
  signal \counter1_carry__1_n_3\ : STD_LOGIC;
  signal \counter1_carry__2_i_1__2_n_0\ : STD_LOGIC;
  signal \counter1_carry__2_n_3\ : STD_LOGIC;
  signal \counter1_carry_i_1__0_n_0\ : STD_LOGIC;
  signal \counter1_carry_i_2__0_n_0\ : STD_LOGIC;
  signal \counter1_carry_i_3__2_n_0\ : STD_LOGIC;
  signal \counter1_carry_i_4__2_n_0\ : STD_LOGIC;
  signal \counter1_carry_i_5__2_n_0\ : STD_LOGIC;
  signal \counter1_carry_i_6__2_n_0\ : STD_LOGIC;
  signal counter1_carry_n_0 : STD_LOGIC;
  signal counter1_carry_n_1 : STD_LOGIC;
  signal counter1_carry_n_2 : STD_LOGIC;
  signal counter1_carry_n_3 : STD_LOGIC;
  signal \counter[0]_i_3__2_n_0\ : STD_LOGIC;
  signal counter_reg : STD_LOGIC_VECTOR ( 31 downto 0 );
  signal \counter_reg[0]_i_2__2_n_0\ : STD_LOGIC;
  signal \counter_reg[0]_i_2__2_n_1\ : STD_LOGIC;
  signal \counter_reg[0]_i_2__2_n_2\ : STD_LOGIC;
  signal \counter_reg[0]_i_2__2_n_3\ : STD_LOGIC;
  signal \counter_reg[0]_i_2__2_n_4\ : STD_LOGIC;
  signal \counter_reg[0]_i_2__2_n_5\ : STD_LOGIC;
  signal \counter_reg[0]_i_2__2_n_6\ : STD_LOGIC;
  signal \counter_reg[0]_i_2__2_n_7\ : STD_LOGIC;
  signal \counter_reg[12]_i_1__2_n_0\ : STD_LOGIC;
  signal \counter_reg[12]_i_1__2_n_1\ : STD_LOGIC;
  signal \counter_reg[12]_i_1__2_n_2\ : STD_LOGIC;
  signal \counter_reg[12]_i_1__2_n_3\ : STD_LOGIC;
  signal \counter_reg[12]_i_1__2_n_4\ : STD_LOGIC;
  signal \counter_reg[12]_i_1__2_n_5\ : STD_LOGIC;
  signal \counter_reg[12]_i_1__2_n_6\ : STD_LOGIC;
  signal \counter_reg[12]_i_1__2_n_7\ : STD_LOGIC;
  signal \counter_reg[16]_i_1__2_n_0\ : STD_LOGIC;
  signal \counter_reg[16]_i_1__2_n_1\ : STD_LOGIC;
  signal \counter_reg[16]_i_1__2_n_2\ : STD_LOGIC;
  signal \counter_reg[16]_i_1__2_n_3\ : STD_LOGIC;
  signal \counter_reg[16]_i_1__2_n_4\ : STD_LOGIC;
  signal \counter_reg[16]_i_1__2_n_5\ : STD_LOGIC;
  signal \counter_reg[16]_i_1__2_n_6\ : STD_LOGIC;
  signal \counter_reg[16]_i_1__2_n_7\ : STD_LOGIC;
  signal \counter_reg[20]_i_1__2_n_0\ : STD_LOGIC;
  signal \counter_reg[20]_i_1__2_n_1\ : STD_LOGIC;
  signal \counter_reg[20]_i_1__2_n_2\ : STD_LOGIC;
  signal \counter_reg[20]_i_1__2_n_3\ : STD_LOGIC;
  signal \counter_reg[20]_i_1__2_n_4\ : STD_LOGIC;
  signal \counter_reg[20]_i_1__2_n_5\ : STD_LOGIC;
  signal \counter_reg[20]_i_1__2_n_6\ : STD_LOGIC;
  signal \counter_reg[20]_i_1__2_n_7\ : STD_LOGIC;
  signal \counter_reg[24]_i_1__2_n_0\ : STD_LOGIC;
  signal \counter_reg[24]_i_1__2_n_1\ : STD_LOGIC;
  signal \counter_reg[24]_i_1__2_n_2\ : STD_LOGIC;
  signal \counter_reg[24]_i_1__2_n_3\ : STD_LOGIC;
  signal \counter_reg[24]_i_1__2_n_4\ : STD_LOGIC;
  signal \counter_reg[24]_i_1__2_n_5\ : STD_LOGIC;
  signal \counter_reg[24]_i_1__2_n_6\ : STD_LOGIC;
  signal \counter_reg[24]_i_1__2_n_7\ : STD_LOGIC;
  signal \counter_reg[28]_i_1__2_n_1\ : STD_LOGIC;
  signal \counter_reg[28]_i_1__2_n_2\ : STD_LOGIC;
  signal \counter_reg[28]_i_1__2_n_3\ : STD_LOGIC;
  signal \counter_reg[28]_i_1__2_n_4\ : STD_LOGIC;
  signal \counter_reg[28]_i_1__2_n_5\ : STD_LOGIC;
  signal \counter_reg[28]_i_1__2_n_6\ : STD_LOGIC;
  signal \counter_reg[28]_i_1__2_n_7\ : STD_LOGIC;
  signal \counter_reg[4]_i_1__2_n_0\ : STD_LOGIC;
  signal \counter_reg[4]_i_1__2_n_1\ : STD_LOGIC;
  signal \counter_reg[4]_i_1__2_n_2\ : STD_LOGIC;
  signal \counter_reg[4]_i_1__2_n_3\ : STD_LOGIC;
  signal \counter_reg[4]_i_1__2_n_4\ : STD_LOGIC;
  signal \counter_reg[4]_i_1__2_n_5\ : STD_LOGIC;
  signal \counter_reg[4]_i_1__2_n_6\ : STD_LOGIC;
  signal \counter_reg[4]_i_1__2_n_7\ : STD_LOGIC;
  signal \counter_reg[8]_i_1__2_n_0\ : STD_LOGIC;
  signal \counter_reg[8]_i_1__2_n_1\ : STD_LOGIC;
  signal \counter_reg[8]_i_1__2_n_2\ : STD_LOGIC;
  signal \counter_reg[8]_i_1__2_n_3\ : STD_LOGIC;
  signal \counter_reg[8]_i_1__2_n_4\ : STD_LOGIC;
  signal \counter_reg[8]_i_1__2_n_5\ : STD_LOGIC;
  signal \counter_reg[8]_i_1__2_n_6\ : STD_LOGIC;
  signal \counter_reg[8]_i_1__2_n_7\ : STD_LOGIC;
  signal \o_press_i_1__2_n_0\ : STD_LOGIC;
  signal \o_press_i_2__2_n_0\ : STD_LOGIC;
  signal \o_press_i_3__2_n_0\ : STD_LOGIC;
  signal \o_press_i_4__2_n_0\ : STD_LOGIC;
  signal \o_press_i_5__2_n_0\ : STD_LOGIC;
  signal \o_press_i_6__2_n_0\ : STD_LOGIC;
  signal \o_press_i_7__2_n_0\ : STD_LOGIC;
  signal \o_press_i_8__2_n_0\ : STD_LOGIC;
  signal \o_press_i_9__2_n_0\ : STD_LOGIC;
  signal NLW_counter1_carry_O_UNCONNECTED : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_counter1_carry__0_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_counter1_carry__1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_counter1_carry__2_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \NLW_counter1_carry__2_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_counter_reg[28]_i_1__2_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
begin
counter1_carry: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => counter1_carry_n_0,
      CO(2) => counter1_carry_n_1,
      CO(1) => counter1_carry_n_2,
      CO(0) => counter1_carry_n_3,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \counter1_carry_i_1__0_n_0\,
      DI(0) => \counter1_carry_i_2__0_n_0\,
      O(3 downto 0) => NLW_counter1_carry_O_UNCONNECTED(3 downto 0),
      S(3) => \counter1_carry_i_3__2_n_0\,
      S(2) => \counter1_carry_i_4__2_n_0\,
      S(1) => \counter1_carry_i_5__2_n_0\,
      S(0) => \counter1_carry_i_6__2_n_0\
    );
\counter1_carry__0\: unisim.vcomponents.CARRY4
     port map (
      CI => counter1_carry_n_0,
      CO(3) => \counter1_carry__0_n_0\,
      CO(2) => \counter1_carry__0_n_1\,
      CO(1) => \counter1_carry__0_n_2\,
      CO(0) => \counter1_carry__0_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => \counter1_carry__0_i_1__0_n_0\,
      DI(1) => \counter1_carry__0_i_2__0_n_0\,
      DI(0) => \counter1_carry__0_i_3__0_n_0\,
      O(3 downto 0) => \NLW_counter1_carry__0_O_UNCONNECTED\(3 downto 0),
      S(3) => \counter1_carry__0_i_4__2_n_0\,
      S(2) => \counter1_carry__0_i_5__2_n_0\,
      S(1) => \counter1_carry__0_i_6__2_n_0\,
      S(0) => \counter1_carry__0_i_7__2_n_0\
    );
\counter1_carry__0_i_1__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"7"
    )
        port map (
      I0 => counter_reg(18),
      I1 => counter_reg(19),
      O => \counter1_carry__0_i_1__0_n_0\
    );
\counter1_carry__0_i_2__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"7"
    )
        port map (
      I0 => counter_reg(16),
      I1 => counter_reg(17),
      O => \counter1_carry__0_i_2__0_n_0\
    );
\counter1_carry__0_i_3__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => counter_reg(14),
      I1 => counter_reg(15),
      O => \counter1_carry__0_i_3__0_n_0\
    );
\counter1_carry__0_i_4__2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => counter_reg(20),
      I1 => counter_reg(21),
      O => \counter1_carry__0_i_4__2_n_0\
    );
\counter1_carry__0_i_5__2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => counter_reg(18),
      I1 => counter_reg(19),
      O => \counter1_carry__0_i_5__2_n_0\
    );
\counter1_carry__0_i_6__2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => counter_reg(16),
      I1 => counter_reg(17),
      O => \counter1_carry__0_i_6__2_n_0\
    );
\counter1_carry__0_i_7__2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => counter_reg(14),
      I1 => counter_reg(15),
      O => \counter1_carry__0_i_7__2_n_0\
    );
\counter1_carry__1\: unisim.vcomponents.CARRY4
     port map (
      CI => \counter1_carry__0_n_0\,
      CO(3) => \counter1_carry__1_n_0\,
      CO(2) => \counter1_carry__1_n_1\,
      CO(1) => \counter1_carry__1_n_2\,
      CO(0) => \counter1_carry__1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => \NLW_counter1_carry__1_O_UNCONNECTED\(3 downto 0),
      S(3) => \counter1_carry__1_i_1__2_n_0\,
      S(2) => \counter1_carry__1_i_2__2_n_0\,
      S(1) => \counter1_carry__1_i_3__2_n_0\,
      S(0) => \counter1_carry__1_i_4__2_n_0\
    );
\counter1_carry__1_i_1__2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => counter_reg(28),
      I1 => counter_reg(29),
      O => \counter1_carry__1_i_1__2_n_0\
    );
\counter1_carry__1_i_2__2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => counter_reg(26),
      I1 => counter_reg(27),
      O => \counter1_carry__1_i_2__2_n_0\
    );
\counter1_carry__1_i_3__2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => counter_reg(24),
      I1 => counter_reg(25),
      O => \counter1_carry__1_i_3__2_n_0\
    );
\counter1_carry__1_i_4__2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => counter_reg(22),
      I1 => counter_reg(23),
      O => \counter1_carry__1_i_4__2_n_0\
    );
\counter1_carry__2\: unisim.vcomponents.CARRY4
     port map (
      CI => \counter1_carry__1_n_0\,
      CO(3 downto 1) => \NLW_counter1_carry__2_CO_UNCONNECTED\(3 downto 1),
      CO(0) => \counter1_carry__2_n_3\,
      CYINIT => '0',
      DI(3 downto 1) => B"000",
      DI(0) => counter_reg(31),
      O(3 downto 0) => \NLW_counter1_carry__2_O_UNCONNECTED\(3 downto 0),
      S(3 downto 1) => B"000",
      S(0) => \counter1_carry__2_i_1__2_n_0\
    );
\counter1_carry__2_i_1__2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => counter_reg(31),
      I1 => counter_reg(30),
      O => \counter1_carry__2_i_1__2_n_0\
    );
\counter1_carry_i_1__0\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => counter_reg(9),
      O => \counter1_carry_i_1__0_n_0\
    );
\counter1_carry_i_2__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => counter_reg(6),
      I1 => counter_reg(7),
      O => \counter1_carry_i_2__0_n_0\
    );
\counter1_carry_i_3__2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => counter_reg(12),
      I1 => counter_reg(13),
      O => \counter1_carry_i_3__2_n_0\
    );
\counter1_carry_i_4__2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => counter_reg(10),
      I1 => counter_reg(11),
      O => \counter1_carry_i_4__2_n_0\
    );
\counter1_carry_i_5__2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => counter_reg(9),
      I1 => counter_reg(8),
      O => \counter1_carry_i_5__2_n_0\
    );
\counter1_carry_i_6__2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => counter_reg(6),
      I1 => counter_reg(7),
      O => \counter1_carry_i_6__2_n_0\
    );
\counter[0]_i_1__1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"7"
    )
        port map (
      I0 => button_down,
      I1 => CO(0),
      O => \counter_reg[31]_0\
    );
\counter[0]_i_1__6\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => i_button_down,
      O => counter
    );
\counter[0]_i_3__2\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => counter_reg(0),
      O => \counter[0]_i_3__2_n_0\
    );
\counter_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[0]_i_2__2_n_7\,
      Q => counter_reg(0),
      R => counter
    );
\counter_reg[0]_i_2__2\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \counter_reg[0]_i_2__2_n_0\,
      CO(2) => \counter_reg[0]_i_2__2_n_1\,
      CO(1) => \counter_reg[0]_i_2__2_n_2\,
      CO(0) => \counter_reg[0]_i_2__2_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0001",
      O(3) => \counter_reg[0]_i_2__2_n_4\,
      O(2) => \counter_reg[0]_i_2__2_n_5\,
      O(1) => \counter_reg[0]_i_2__2_n_6\,
      O(0) => \counter_reg[0]_i_2__2_n_7\,
      S(3 downto 1) => counter_reg(3 downto 1),
      S(0) => \counter[0]_i_3__2_n_0\
    );
\counter_reg[10]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[8]_i_1__2_n_5\,
      Q => counter_reg(10),
      R => counter
    );
\counter_reg[11]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[8]_i_1__2_n_4\,
      Q => counter_reg(11),
      R => counter
    );
\counter_reg[12]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[12]_i_1__2_n_7\,
      Q => counter_reg(12),
      R => counter
    );
\counter_reg[12]_i_1__2\: unisim.vcomponents.CARRY4
     port map (
      CI => \counter_reg[8]_i_1__2_n_0\,
      CO(3) => \counter_reg[12]_i_1__2_n_0\,
      CO(2) => \counter_reg[12]_i_1__2_n_1\,
      CO(1) => \counter_reg[12]_i_1__2_n_2\,
      CO(0) => \counter_reg[12]_i_1__2_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \counter_reg[12]_i_1__2_n_4\,
      O(2) => \counter_reg[12]_i_1__2_n_5\,
      O(1) => \counter_reg[12]_i_1__2_n_6\,
      O(0) => \counter_reg[12]_i_1__2_n_7\,
      S(3 downto 0) => counter_reg(15 downto 12)
    );
\counter_reg[13]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[12]_i_1__2_n_6\,
      Q => counter_reg(13),
      R => counter
    );
\counter_reg[14]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[12]_i_1__2_n_5\,
      Q => counter_reg(14),
      R => counter
    );
\counter_reg[15]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[12]_i_1__2_n_4\,
      Q => counter_reg(15),
      R => counter
    );
\counter_reg[16]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[16]_i_1__2_n_7\,
      Q => counter_reg(16),
      R => counter
    );
\counter_reg[16]_i_1__2\: unisim.vcomponents.CARRY4
     port map (
      CI => \counter_reg[12]_i_1__2_n_0\,
      CO(3) => \counter_reg[16]_i_1__2_n_0\,
      CO(2) => \counter_reg[16]_i_1__2_n_1\,
      CO(1) => \counter_reg[16]_i_1__2_n_2\,
      CO(0) => \counter_reg[16]_i_1__2_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \counter_reg[16]_i_1__2_n_4\,
      O(2) => \counter_reg[16]_i_1__2_n_5\,
      O(1) => \counter_reg[16]_i_1__2_n_6\,
      O(0) => \counter_reg[16]_i_1__2_n_7\,
      S(3 downto 0) => counter_reg(19 downto 16)
    );
\counter_reg[17]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[16]_i_1__2_n_6\,
      Q => counter_reg(17),
      R => counter
    );
\counter_reg[18]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[16]_i_1__2_n_5\,
      Q => counter_reg(18),
      R => counter
    );
\counter_reg[19]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[16]_i_1__2_n_4\,
      Q => counter_reg(19),
      R => counter
    );
\counter_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[0]_i_2__2_n_6\,
      Q => counter_reg(1),
      R => counter
    );
\counter_reg[20]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[20]_i_1__2_n_7\,
      Q => counter_reg(20),
      R => counter
    );
\counter_reg[20]_i_1__2\: unisim.vcomponents.CARRY4
     port map (
      CI => \counter_reg[16]_i_1__2_n_0\,
      CO(3) => \counter_reg[20]_i_1__2_n_0\,
      CO(2) => \counter_reg[20]_i_1__2_n_1\,
      CO(1) => \counter_reg[20]_i_1__2_n_2\,
      CO(0) => \counter_reg[20]_i_1__2_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \counter_reg[20]_i_1__2_n_4\,
      O(2) => \counter_reg[20]_i_1__2_n_5\,
      O(1) => \counter_reg[20]_i_1__2_n_6\,
      O(0) => \counter_reg[20]_i_1__2_n_7\,
      S(3 downto 0) => counter_reg(23 downto 20)
    );
\counter_reg[21]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[20]_i_1__2_n_6\,
      Q => counter_reg(21),
      R => counter
    );
\counter_reg[22]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[20]_i_1__2_n_5\,
      Q => counter_reg(22),
      R => counter
    );
\counter_reg[23]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[20]_i_1__2_n_4\,
      Q => counter_reg(23),
      R => counter
    );
\counter_reg[24]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[24]_i_1__2_n_7\,
      Q => counter_reg(24),
      R => counter
    );
\counter_reg[24]_i_1__2\: unisim.vcomponents.CARRY4
     port map (
      CI => \counter_reg[20]_i_1__2_n_0\,
      CO(3) => \counter_reg[24]_i_1__2_n_0\,
      CO(2) => \counter_reg[24]_i_1__2_n_1\,
      CO(1) => \counter_reg[24]_i_1__2_n_2\,
      CO(0) => \counter_reg[24]_i_1__2_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \counter_reg[24]_i_1__2_n_4\,
      O(2) => \counter_reg[24]_i_1__2_n_5\,
      O(1) => \counter_reg[24]_i_1__2_n_6\,
      O(0) => \counter_reg[24]_i_1__2_n_7\,
      S(3 downto 0) => counter_reg(27 downto 24)
    );
\counter_reg[25]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[24]_i_1__2_n_6\,
      Q => counter_reg(25),
      R => counter
    );
\counter_reg[26]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[24]_i_1__2_n_5\,
      Q => counter_reg(26),
      R => counter
    );
\counter_reg[27]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[24]_i_1__2_n_4\,
      Q => counter_reg(27),
      R => counter
    );
\counter_reg[28]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[28]_i_1__2_n_7\,
      Q => counter_reg(28),
      R => counter
    );
\counter_reg[28]_i_1__2\: unisim.vcomponents.CARRY4
     port map (
      CI => \counter_reg[24]_i_1__2_n_0\,
      CO(3) => \NLW_counter_reg[28]_i_1__2_CO_UNCONNECTED\(3),
      CO(2) => \counter_reg[28]_i_1__2_n_1\,
      CO(1) => \counter_reg[28]_i_1__2_n_2\,
      CO(0) => \counter_reg[28]_i_1__2_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \counter_reg[28]_i_1__2_n_4\,
      O(2) => \counter_reg[28]_i_1__2_n_5\,
      O(1) => \counter_reg[28]_i_1__2_n_6\,
      O(0) => \counter_reg[28]_i_1__2_n_7\,
      S(3 downto 0) => counter_reg(31 downto 28)
    );
\counter_reg[29]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[28]_i_1__2_n_6\,
      Q => counter_reg(29),
      R => counter
    );
\counter_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[0]_i_2__2_n_5\,
      Q => counter_reg(2),
      R => counter
    );
\counter_reg[30]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[28]_i_1__2_n_5\,
      Q => counter_reg(30),
      R => counter
    );
\counter_reg[31]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[28]_i_1__2_n_4\,
      Q => counter_reg(31),
      R => counter
    );
\counter_reg[3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[0]_i_2__2_n_4\,
      Q => counter_reg(3),
      R => counter
    );
\counter_reg[4]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[4]_i_1__2_n_7\,
      Q => counter_reg(4),
      R => counter
    );
\counter_reg[4]_i_1__2\: unisim.vcomponents.CARRY4
     port map (
      CI => \counter_reg[0]_i_2__2_n_0\,
      CO(3) => \counter_reg[4]_i_1__2_n_0\,
      CO(2) => \counter_reg[4]_i_1__2_n_1\,
      CO(1) => \counter_reg[4]_i_1__2_n_2\,
      CO(0) => \counter_reg[4]_i_1__2_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \counter_reg[4]_i_1__2_n_4\,
      O(2) => \counter_reg[4]_i_1__2_n_5\,
      O(1) => \counter_reg[4]_i_1__2_n_6\,
      O(0) => \counter_reg[4]_i_1__2_n_7\,
      S(3 downto 0) => counter_reg(7 downto 4)
    );
\counter_reg[5]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[4]_i_1__2_n_6\,
      Q => counter_reg(5),
      R => counter
    );
\counter_reg[6]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[4]_i_1__2_n_5\,
      Q => counter_reg(6),
      R => counter
    );
\counter_reg[7]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[4]_i_1__2_n_4\,
      Q => counter_reg(7),
      R => counter
    );
\counter_reg[8]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[8]_i_1__2_n_7\,
      Q => counter_reg(8),
      R => counter
    );
\counter_reg[8]_i_1__2\: unisim.vcomponents.CARRY4
     port map (
      CI => \counter_reg[4]_i_1__2_n_0\,
      CO(3) => \counter_reg[8]_i_1__2_n_0\,
      CO(2) => \counter_reg[8]_i_1__2_n_1\,
      CO(1) => \counter_reg[8]_i_1__2_n_2\,
      CO(0) => \counter_reg[8]_i_1__2_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \counter_reg[8]_i_1__2_n_4\,
      O(2) => \counter_reg[8]_i_1__2_n_5\,
      O(1) => \counter_reg[8]_i_1__2_n_6\,
      O(0) => \counter_reg[8]_i_1__2_n_7\,
      S(3 downto 0) => counter_reg(11 downto 8)
    );
\counter_reg[9]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[8]_i_1__2_n_6\,
      Q => counter_reg(9),
      R => counter
    );
\o_press_i_1__2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000000001"
    )
        port map (
      I0 => \o_press_i_2__2_n_0\,
      I1 => \o_press_i_3__2_n_0\,
      I2 => counter_reg(30),
      I3 => counter_reg(31),
      I4 => \o_press_i_4__2_n_0\,
      I5 => \o_press_i_5__2_n_0\,
      O => \o_press_i_1__2_n_0\
    );
\o_press_i_2__2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFFFFFE"
    )
        port map (
      I0 => counter_reg(21),
      I1 => counter_reg(20),
      I2 => counter_reg(23),
      I3 => counter_reg(22),
      I4 => \o_press_i_6__2_n_0\,
      O => \o_press_i_2__2_n_0\
    );
\o_press_i_3__2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => counter_reg(29),
      I1 => counter_reg(28),
      O => \o_press_i_3__2_n_0\
    );
\o_press_i_4__2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFFE"
    )
        port map (
      I0 => counter_reg(26),
      I1 => counter_reg(27),
      I2 => counter_reg(24),
      I3 => counter_reg(25),
      O => \o_press_i_4__2_n_0\
    );
\o_press_i_5__2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFFFFE"
    )
        port map (
      I0 => \o_press_i_7__2_n_0\,
      I1 => counter_reg(3),
      I2 => counter_reg(15),
      I3 => counter_reg(12),
      I4 => counter_reg(13),
      I5 => \o_press_i_8__2_n_0\,
      O => \o_press_i_5__2_n_0\
    );
\o_press_i_6__2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFFE"
    )
        port map (
      I0 => counter_reg(0),
      I1 => counter_reg(5),
      I2 => counter_reg(2),
      I3 => counter_reg(1),
      O => \o_press_i_6__2_n_0\
    );
\o_press_i_7__2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFFE"
    )
        port map (
      I0 => counter_reg(10),
      I1 => counter_reg(11),
      I2 => counter_reg(8),
      I3 => counter_reg(4),
      O => \o_press_i_7__2_n_0\
    );
\o_press_i_8__2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFFF7FF"
    )
        port map (
      I0 => counter_reg(6),
      I1 => counter_reg(9),
      I2 => counter_reg(7),
      I3 => counter_reg(19),
      I4 => \o_press_i_9__2_n_0\,
      O => \o_press_i_8__2_n_0\
    );
\o_press_i_9__2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"7FFF"
    )
        port map (
      I0 => counter_reg(16),
      I1 => counter_reg(14),
      I2 => counter_reg(18),
      I3 => counter_reg(17),
      O => \o_press_i_9__2_n_0\
    );
o_press_reg: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \o_press_i_1__2_n_0\,
      Q => button_down,
      R => '0'
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_debounce_0 is
  port (
    clear : out STD_LOGIC;
    s00_axi_aclk : in STD_LOGIC;
    CO : in STD_LOGIC_VECTOR ( 0 to 0 );
    i_button_left : in STD_LOGIC
  );
  attribute ORIG_REF_NAME : string;
  attribute ORIG_REF_NAME of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_debounce_0 : entity is "debounce";
end decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_debounce_0;

architecture STRUCTURE of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_debounce_0 is
  signal button_Left : STD_LOGIC;
  signal counter : STD_LOGIC;
  signal \counter1_carry__0_i_1__3_n_0\ : STD_LOGIC;
  signal \counter1_carry__0_i_2__3_n_0\ : STD_LOGIC;
  signal \counter1_carry__0_i_3__3_n_0\ : STD_LOGIC;
  signal \counter1_carry__0_i_4_n_0\ : STD_LOGIC;
  signal \counter1_carry__0_i_5_n_0\ : STD_LOGIC;
  signal \counter1_carry__0_i_6_n_0\ : STD_LOGIC;
  signal \counter1_carry__0_i_7_n_0\ : STD_LOGIC;
  signal \counter1_carry__0_n_0\ : STD_LOGIC;
  signal \counter1_carry__0_n_1\ : STD_LOGIC;
  signal \counter1_carry__0_n_2\ : STD_LOGIC;
  signal \counter1_carry__0_n_3\ : STD_LOGIC;
  signal \counter1_carry__1_i_1_n_0\ : STD_LOGIC;
  signal \counter1_carry__1_i_2_n_0\ : STD_LOGIC;
  signal \counter1_carry__1_i_3_n_0\ : STD_LOGIC;
  signal \counter1_carry__1_i_4_n_0\ : STD_LOGIC;
  signal \counter1_carry__1_n_0\ : STD_LOGIC;
  signal \counter1_carry__1_n_1\ : STD_LOGIC;
  signal \counter1_carry__1_n_2\ : STD_LOGIC;
  signal \counter1_carry__1_n_3\ : STD_LOGIC;
  signal \counter1_carry__2_i_1_n_0\ : STD_LOGIC;
  signal \counter1_carry__2_n_3\ : STD_LOGIC;
  signal \counter1_carry_i_1__3_n_0\ : STD_LOGIC;
  signal \counter1_carry_i_2__3_n_0\ : STD_LOGIC;
  signal counter1_carry_i_3_n_0 : STD_LOGIC;
  signal counter1_carry_i_4_n_0 : STD_LOGIC;
  signal counter1_carry_i_5_n_0 : STD_LOGIC;
  signal counter1_carry_i_6_n_0 : STD_LOGIC;
  signal counter1_carry_n_0 : STD_LOGIC;
  signal counter1_carry_n_1 : STD_LOGIC;
  signal counter1_carry_n_2 : STD_LOGIC;
  signal counter1_carry_n_3 : STD_LOGIC;
  signal \counter[0]_i_3_n_0\ : STD_LOGIC;
  signal counter_reg : STD_LOGIC_VECTOR ( 31 downto 0 );
  signal \counter_reg[0]_i_2_n_0\ : STD_LOGIC;
  signal \counter_reg[0]_i_2_n_1\ : STD_LOGIC;
  signal \counter_reg[0]_i_2_n_2\ : STD_LOGIC;
  signal \counter_reg[0]_i_2_n_3\ : STD_LOGIC;
  signal \counter_reg[0]_i_2_n_4\ : STD_LOGIC;
  signal \counter_reg[0]_i_2_n_5\ : STD_LOGIC;
  signal \counter_reg[0]_i_2_n_6\ : STD_LOGIC;
  signal \counter_reg[0]_i_2_n_7\ : STD_LOGIC;
  signal \counter_reg[12]_i_1_n_0\ : STD_LOGIC;
  signal \counter_reg[12]_i_1_n_1\ : STD_LOGIC;
  signal \counter_reg[12]_i_1_n_2\ : STD_LOGIC;
  signal \counter_reg[12]_i_1_n_3\ : STD_LOGIC;
  signal \counter_reg[12]_i_1_n_4\ : STD_LOGIC;
  signal \counter_reg[12]_i_1_n_5\ : STD_LOGIC;
  signal \counter_reg[12]_i_1_n_6\ : STD_LOGIC;
  signal \counter_reg[12]_i_1_n_7\ : STD_LOGIC;
  signal \counter_reg[16]_i_1_n_0\ : STD_LOGIC;
  signal \counter_reg[16]_i_1_n_1\ : STD_LOGIC;
  signal \counter_reg[16]_i_1_n_2\ : STD_LOGIC;
  signal \counter_reg[16]_i_1_n_3\ : STD_LOGIC;
  signal \counter_reg[16]_i_1_n_4\ : STD_LOGIC;
  signal \counter_reg[16]_i_1_n_5\ : STD_LOGIC;
  signal \counter_reg[16]_i_1_n_6\ : STD_LOGIC;
  signal \counter_reg[16]_i_1_n_7\ : STD_LOGIC;
  signal \counter_reg[20]_i_1_n_0\ : STD_LOGIC;
  signal \counter_reg[20]_i_1_n_1\ : STD_LOGIC;
  signal \counter_reg[20]_i_1_n_2\ : STD_LOGIC;
  signal \counter_reg[20]_i_1_n_3\ : STD_LOGIC;
  signal \counter_reg[20]_i_1_n_4\ : STD_LOGIC;
  signal \counter_reg[20]_i_1_n_5\ : STD_LOGIC;
  signal \counter_reg[20]_i_1_n_6\ : STD_LOGIC;
  signal \counter_reg[20]_i_1_n_7\ : STD_LOGIC;
  signal \counter_reg[24]_i_1_n_0\ : STD_LOGIC;
  signal \counter_reg[24]_i_1_n_1\ : STD_LOGIC;
  signal \counter_reg[24]_i_1_n_2\ : STD_LOGIC;
  signal \counter_reg[24]_i_1_n_3\ : STD_LOGIC;
  signal \counter_reg[24]_i_1_n_4\ : STD_LOGIC;
  signal \counter_reg[24]_i_1_n_5\ : STD_LOGIC;
  signal \counter_reg[24]_i_1_n_6\ : STD_LOGIC;
  signal \counter_reg[24]_i_1_n_7\ : STD_LOGIC;
  signal \counter_reg[28]_i_1_n_1\ : STD_LOGIC;
  signal \counter_reg[28]_i_1_n_2\ : STD_LOGIC;
  signal \counter_reg[28]_i_1_n_3\ : STD_LOGIC;
  signal \counter_reg[28]_i_1_n_4\ : STD_LOGIC;
  signal \counter_reg[28]_i_1_n_5\ : STD_LOGIC;
  signal \counter_reg[28]_i_1_n_6\ : STD_LOGIC;
  signal \counter_reg[28]_i_1_n_7\ : STD_LOGIC;
  signal \counter_reg[4]_i_1_n_0\ : STD_LOGIC;
  signal \counter_reg[4]_i_1_n_1\ : STD_LOGIC;
  signal \counter_reg[4]_i_1_n_2\ : STD_LOGIC;
  signal \counter_reg[4]_i_1_n_3\ : STD_LOGIC;
  signal \counter_reg[4]_i_1_n_4\ : STD_LOGIC;
  signal \counter_reg[4]_i_1_n_5\ : STD_LOGIC;
  signal \counter_reg[4]_i_1_n_6\ : STD_LOGIC;
  signal \counter_reg[4]_i_1_n_7\ : STD_LOGIC;
  signal \counter_reg[8]_i_1_n_0\ : STD_LOGIC;
  signal \counter_reg[8]_i_1_n_1\ : STD_LOGIC;
  signal \counter_reg[8]_i_1_n_2\ : STD_LOGIC;
  signal \counter_reg[8]_i_1_n_3\ : STD_LOGIC;
  signal \counter_reg[8]_i_1_n_4\ : STD_LOGIC;
  signal \counter_reg[8]_i_1_n_5\ : STD_LOGIC;
  signal \counter_reg[8]_i_1_n_6\ : STD_LOGIC;
  signal \counter_reg[8]_i_1_n_7\ : STD_LOGIC;
  signal o_press_i_1_n_0 : STD_LOGIC;
  signal o_press_i_2_n_0 : STD_LOGIC;
  signal o_press_i_3_n_0 : STD_LOGIC;
  signal o_press_i_4_n_0 : STD_LOGIC;
  signal o_press_i_5_n_0 : STD_LOGIC;
  signal o_press_i_6_n_0 : STD_LOGIC;
  signal o_press_i_7_n_0 : STD_LOGIC;
  signal o_press_i_8_n_0 : STD_LOGIC;
  signal o_press_i_9_n_0 : STD_LOGIC;
  signal NLW_counter1_carry_O_UNCONNECTED : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_counter1_carry__0_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_counter1_carry__1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_counter1_carry__2_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \NLW_counter1_carry__2_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_counter_reg[28]_i_1_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
begin
counter1_carry: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => counter1_carry_n_0,
      CO(2) => counter1_carry_n_1,
      CO(1) => counter1_carry_n_2,
      CO(0) => counter1_carry_n_3,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \counter1_carry_i_1__3_n_0\,
      DI(0) => \counter1_carry_i_2__3_n_0\,
      O(3 downto 0) => NLW_counter1_carry_O_UNCONNECTED(3 downto 0),
      S(3) => counter1_carry_i_3_n_0,
      S(2) => counter1_carry_i_4_n_0,
      S(1) => counter1_carry_i_5_n_0,
      S(0) => counter1_carry_i_6_n_0
    );
\counter1_carry__0\: unisim.vcomponents.CARRY4
     port map (
      CI => counter1_carry_n_0,
      CO(3) => \counter1_carry__0_n_0\,
      CO(2) => \counter1_carry__0_n_1\,
      CO(1) => \counter1_carry__0_n_2\,
      CO(0) => \counter1_carry__0_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => \counter1_carry__0_i_1__3_n_0\,
      DI(1) => \counter1_carry__0_i_2__3_n_0\,
      DI(0) => \counter1_carry__0_i_3__3_n_0\,
      O(3 downto 0) => \NLW_counter1_carry__0_O_UNCONNECTED\(3 downto 0),
      S(3) => \counter1_carry__0_i_4_n_0\,
      S(2) => \counter1_carry__0_i_5_n_0\,
      S(1) => \counter1_carry__0_i_6_n_0\,
      S(0) => \counter1_carry__0_i_7_n_0\
    );
\counter1_carry__0_i_1__3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"7"
    )
        port map (
      I0 => counter_reg(18),
      I1 => counter_reg(19),
      O => \counter1_carry__0_i_1__3_n_0\
    );
\counter1_carry__0_i_2__3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"7"
    )
        port map (
      I0 => counter_reg(16),
      I1 => counter_reg(17),
      O => \counter1_carry__0_i_2__3_n_0\
    );
\counter1_carry__0_i_3__3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => counter_reg(14),
      I1 => counter_reg(15),
      O => \counter1_carry__0_i_3__3_n_0\
    );
\counter1_carry__0_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => counter_reg(20),
      I1 => counter_reg(21),
      O => \counter1_carry__0_i_4_n_0\
    );
\counter1_carry__0_i_5\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => counter_reg(18),
      I1 => counter_reg(19),
      O => \counter1_carry__0_i_5_n_0\
    );
\counter1_carry__0_i_6\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => counter_reg(16),
      I1 => counter_reg(17),
      O => \counter1_carry__0_i_6_n_0\
    );
\counter1_carry__0_i_7\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => counter_reg(14),
      I1 => counter_reg(15),
      O => \counter1_carry__0_i_7_n_0\
    );
\counter1_carry__1\: unisim.vcomponents.CARRY4
     port map (
      CI => \counter1_carry__0_n_0\,
      CO(3) => \counter1_carry__1_n_0\,
      CO(2) => \counter1_carry__1_n_1\,
      CO(1) => \counter1_carry__1_n_2\,
      CO(0) => \counter1_carry__1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => \NLW_counter1_carry__1_O_UNCONNECTED\(3 downto 0),
      S(3) => \counter1_carry__1_i_1_n_0\,
      S(2) => \counter1_carry__1_i_2_n_0\,
      S(1) => \counter1_carry__1_i_3_n_0\,
      S(0) => \counter1_carry__1_i_4_n_0\
    );
\counter1_carry__1_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => counter_reg(28),
      I1 => counter_reg(29),
      O => \counter1_carry__1_i_1_n_0\
    );
\counter1_carry__1_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => counter_reg(26),
      I1 => counter_reg(27),
      O => \counter1_carry__1_i_2_n_0\
    );
\counter1_carry__1_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => counter_reg(24),
      I1 => counter_reg(25),
      O => \counter1_carry__1_i_3_n_0\
    );
\counter1_carry__1_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => counter_reg(22),
      I1 => counter_reg(23),
      O => \counter1_carry__1_i_4_n_0\
    );
\counter1_carry__2\: unisim.vcomponents.CARRY4
     port map (
      CI => \counter1_carry__1_n_0\,
      CO(3 downto 1) => \NLW_counter1_carry__2_CO_UNCONNECTED\(3 downto 1),
      CO(0) => \counter1_carry__2_n_3\,
      CYINIT => '0',
      DI(3 downto 1) => B"000",
      DI(0) => counter_reg(31),
      O(3 downto 0) => \NLW_counter1_carry__2_O_UNCONNECTED\(3 downto 0),
      S(3 downto 1) => B"000",
      S(0) => \counter1_carry__2_i_1_n_0\
    );
\counter1_carry__2_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => counter_reg(31),
      I1 => counter_reg(30),
      O => \counter1_carry__2_i_1_n_0\
    );
\counter1_carry_i_1__3\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => counter_reg(9),
      O => \counter1_carry_i_1__3_n_0\
    );
\counter1_carry_i_2__3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => counter_reg(6),
      I1 => counter_reg(7),
      O => \counter1_carry_i_2__3_n_0\
    );
counter1_carry_i_3: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => counter_reg(12),
      I1 => counter_reg(13),
      O => counter1_carry_i_3_n_0
    );
counter1_carry_i_4: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => counter_reg(10),
      I1 => counter_reg(11),
      O => counter1_carry_i_4_n_0
    );
counter1_carry_i_5: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => counter_reg(9),
      I1 => counter_reg(8),
      O => counter1_carry_i_5_n_0
    );
counter1_carry_i_6: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => counter_reg(6),
      I1 => counter_reg(7),
      O => counter1_carry_i_6_n_0
    );
\counter[0]_i_1__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"7"
    )
        port map (
      I0 => button_Left,
      I1 => CO(0),
      O => clear
    );
\counter[0]_i_1__3\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => i_button_left,
      O => counter
    );
\counter[0]_i_3\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => counter_reg(0),
      O => \counter[0]_i_3_n_0\
    );
\counter_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[0]_i_2_n_7\,
      Q => counter_reg(0),
      R => counter
    );
\counter_reg[0]_i_2\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \counter_reg[0]_i_2_n_0\,
      CO(2) => \counter_reg[0]_i_2_n_1\,
      CO(1) => \counter_reg[0]_i_2_n_2\,
      CO(0) => \counter_reg[0]_i_2_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0001",
      O(3) => \counter_reg[0]_i_2_n_4\,
      O(2) => \counter_reg[0]_i_2_n_5\,
      O(1) => \counter_reg[0]_i_2_n_6\,
      O(0) => \counter_reg[0]_i_2_n_7\,
      S(3 downto 1) => counter_reg(3 downto 1),
      S(0) => \counter[0]_i_3_n_0\
    );
\counter_reg[10]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[8]_i_1_n_5\,
      Q => counter_reg(10),
      R => counter
    );
\counter_reg[11]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[8]_i_1_n_4\,
      Q => counter_reg(11),
      R => counter
    );
\counter_reg[12]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[12]_i_1_n_7\,
      Q => counter_reg(12),
      R => counter
    );
\counter_reg[12]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \counter_reg[8]_i_1_n_0\,
      CO(3) => \counter_reg[12]_i_1_n_0\,
      CO(2) => \counter_reg[12]_i_1_n_1\,
      CO(1) => \counter_reg[12]_i_1_n_2\,
      CO(0) => \counter_reg[12]_i_1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \counter_reg[12]_i_1_n_4\,
      O(2) => \counter_reg[12]_i_1_n_5\,
      O(1) => \counter_reg[12]_i_1_n_6\,
      O(0) => \counter_reg[12]_i_1_n_7\,
      S(3 downto 0) => counter_reg(15 downto 12)
    );
\counter_reg[13]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[12]_i_1_n_6\,
      Q => counter_reg(13),
      R => counter
    );
\counter_reg[14]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[12]_i_1_n_5\,
      Q => counter_reg(14),
      R => counter
    );
\counter_reg[15]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[12]_i_1_n_4\,
      Q => counter_reg(15),
      R => counter
    );
\counter_reg[16]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[16]_i_1_n_7\,
      Q => counter_reg(16),
      R => counter
    );
\counter_reg[16]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \counter_reg[12]_i_1_n_0\,
      CO(3) => \counter_reg[16]_i_1_n_0\,
      CO(2) => \counter_reg[16]_i_1_n_1\,
      CO(1) => \counter_reg[16]_i_1_n_2\,
      CO(0) => \counter_reg[16]_i_1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \counter_reg[16]_i_1_n_4\,
      O(2) => \counter_reg[16]_i_1_n_5\,
      O(1) => \counter_reg[16]_i_1_n_6\,
      O(0) => \counter_reg[16]_i_1_n_7\,
      S(3 downto 0) => counter_reg(19 downto 16)
    );
\counter_reg[17]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[16]_i_1_n_6\,
      Q => counter_reg(17),
      R => counter
    );
\counter_reg[18]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[16]_i_1_n_5\,
      Q => counter_reg(18),
      R => counter
    );
\counter_reg[19]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[16]_i_1_n_4\,
      Q => counter_reg(19),
      R => counter
    );
\counter_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[0]_i_2_n_6\,
      Q => counter_reg(1),
      R => counter
    );
\counter_reg[20]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[20]_i_1_n_7\,
      Q => counter_reg(20),
      R => counter
    );
\counter_reg[20]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \counter_reg[16]_i_1_n_0\,
      CO(3) => \counter_reg[20]_i_1_n_0\,
      CO(2) => \counter_reg[20]_i_1_n_1\,
      CO(1) => \counter_reg[20]_i_1_n_2\,
      CO(0) => \counter_reg[20]_i_1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \counter_reg[20]_i_1_n_4\,
      O(2) => \counter_reg[20]_i_1_n_5\,
      O(1) => \counter_reg[20]_i_1_n_6\,
      O(0) => \counter_reg[20]_i_1_n_7\,
      S(3 downto 0) => counter_reg(23 downto 20)
    );
\counter_reg[21]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[20]_i_1_n_6\,
      Q => counter_reg(21),
      R => counter
    );
\counter_reg[22]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[20]_i_1_n_5\,
      Q => counter_reg(22),
      R => counter
    );
\counter_reg[23]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[20]_i_1_n_4\,
      Q => counter_reg(23),
      R => counter
    );
\counter_reg[24]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[24]_i_1_n_7\,
      Q => counter_reg(24),
      R => counter
    );
\counter_reg[24]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \counter_reg[20]_i_1_n_0\,
      CO(3) => \counter_reg[24]_i_1_n_0\,
      CO(2) => \counter_reg[24]_i_1_n_1\,
      CO(1) => \counter_reg[24]_i_1_n_2\,
      CO(0) => \counter_reg[24]_i_1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \counter_reg[24]_i_1_n_4\,
      O(2) => \counter_reg[24]_i_1_n_5\,
      O(1) => \counter_reg[24]_i_1_n_6\,
      O(0) => \counter_reg[24]_i_1_n_7\,
      S(3 downto 0) => counter_reg(27 downto 24)
    );
\counter_reg[25]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[24]_i_1_n_6\,
      Q => counter_reg(25),
      R => counter
    );
\counter_reg[26]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[24]_i_1_n_5\,
      Q => counter_reg(26),
      R => counter
    );
\counter_reg[27]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[24]_i_1_n_4\,
      Q => counter_reg(27),
      R => counter
    );
\counter_reg[28]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[28]_i_1_n_7\,
      Q => counter_reg(28),
      R => counter
    );
\counter_reg[28]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \counter_reg[24]_i_1_n_0\,
      CO(3) => \NLW_counter_reg[28]_i_1_CO_UNCONNECTED\(3),
      CO(2) => \counter_reg[28]_i_1_n_1\,
      CO(1) => \counter_reg[28]_i_1_n_2\,
      CO(0) => \counter_reg[28]_i_1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \counter_reg[28]_i_1_n_4\,
      O(2) => \counter_reg[28]_i_1_n_5\,
      O(1) => \counter_reg[28]_i_1_n_6\,
      O(0) => \counter_reg[28]_i_1_n_7\,
      S(3 downto 0) => counter_reg(31 downto 28)
    );
\counter_reg[29]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[28]_i_1_n_6\,
      Q => counter_reg(29),
      R => counter
    );
\counter_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[0]_i_2_n_5\,
      Q => counter_reg(2),
      R => counter
    );
\counter_reg[30]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[28]_i_1_n_5\,
      Q => counter_reg(30),
      R => counter
    );
\counter_reg[31]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[28]_i_1_n_4\,
      Q => counter_reg(31),
      R => counter
    );
\counter_reg[3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[0]_i_2_n_4\,
      Q => counter_reg(3),
      R => counter
    );
\counter_reg[4]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[4]_i_1_n_7\,
      Q => counter_reg(4),
      R => counter
    );
\counter_reg[4]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \counter_reg[0]_i_2_n_0\,
      CO(3) => \counter_reg[4]_i_1_n_0\,
      CO(2) => \counter_reg[4]_i_1_n_1\,
      CO(1) => \counter_reg[4]_i_1_n_2\,
      CO(0) => \counter_reg[4]_i_1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \counter_reg[4]_i_1_n_4\,
      O(2) => \counter_reg[4]_i_1_n_5\,
      O(1) => \counter_reg[4]_i_1_n_6\,
      O(0) => \counter_reg[4]_i_1_n_7\,
      S(3 downto 0) => counter_reg(7 downto 4)
    );
\counter_reg[5]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[4]_i_1_n_6\,
      Q => counter_reg(5),
      R => counter
    );
\counter_reg[6]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[4]_i_1_n_5\,
      Q => counter_reg(6),
      R => counter
    );
\counter_reg[7]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[4]_i_1_n_4\,
      Q => counter_reg(7),
      R => counter
    );
\counter_reg[8]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[8]_i_1_n_7\,
      Q => counter_reg(8),
      R => counter
    );
\counter_reg[8]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \counter_reg[4]_i_1_n_0\,
      CO(3) => \counter_reg[8]_i_1_n_0\,
      CO(2) => \counter_reg[8]_i_1_n_1\,
      CO(1) => \counter_reg[8]_i_1_n_2\,
      CO(0) => \counter_reg[8]_i_1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \counter_reg[8]_i_1_n_4\,
      O(2) => \counter_reg[8]_i_1_n_5\,
      O(1) => \counter_reg[8]_i_1_n_6\,
      O(0) => \counter_reg[8]_i_1_n_7\,
      S(3 downto 0) => counter_reg(11 downto 8)
    );
\counter_reg[9]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[8]_i_1_n_6\,
      Q => counter_reg(9),
      R => counter
    );
o_press_i_1: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000000001"
    )
        port map (
      I0 => o_press_i_2_n_0,
      I1 => o_press_i_3_n_0,
      I2 => counter_reg(30),
      I3 => counter_reg(31),
      I4 => o_press_i_4_n_0,
      I5 => o_press_i_5_n_0,
      O => o_press_i_1_n_0
    );
o_press_i_2: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFFFFFE"
    )
        port map (
      I0 => counter_reg(21),
      I1 => counter_reg(20),
      I2 => counter_reg(23),
      I3 => counter_reg(22),
      I4 => o_press_i_6_n_0,
      O => o_press_i_2_n_0
    );
o_press_i_3: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => counter_reg(29),
      I1 => counter_reg(28),
      O => o_press_i_3_n_0
    );
o_press_i_4: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFFE"
    )
        port map (
      I0 => counter_reg(26),
      I1 => counter_reg(27),
      I2 => counter_reg(24),
      I3 => counter_reg(25),
      O => o_press_i_4_n_0
    );
o_press_i_5: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFFFFE"
    )
        port map (
      I0 => o_press_i_7_n_0,
      I1 => counter_reg(3),
      I2 => counter_reg(15),
      I3 => counter_reg(12),
      I4 => counter_reg(13),
      I5 => o_press_i_8_n_0,
      O => o_press_i_5_n_0
    );
o_press_i_6: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFFE"
    )
        port map (
      I0 => counter_reg(0),
      I1 => counter_reg(5),
      I2 => counter_reg(2),
      I3 => counter_reg(1),
      O => o_press_i_6_n_0
    );
o_press_i_7: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFFE"
    )
        port map (
      I0 => counter_reg(10),
      I1 => counter_reg(11),
      I2 => counter_reg(8),
      I3 => counter_reg(4),
      O => o_press_i_7_n_0
    );
o_press_i_8: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFFF7FF"
    )
        port map (
      I0 => counter_reg(6),
      I1 => counter_reg(9),
      I2 => counter_reg(7),
      I3 => counter_reg(19),
      I4 => o_press_i_9_n_0,
      O => o_press_i_8_n_0
    );
o_press_i_9: unisim.vcomponents.LUT4
    generic map(
      INIT => X"7FFF"
    )
        port map (
      I0 => counter_reg(16),
      I1 => counter_reg(14),
      I2 => counter_reg(18),
      I3 => counter_reg(17),
      O => o_press_i_9_n_0
    );
o_press_reg: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => o_press_i_1_n_0,
      Q => button_Left,
      R => '0'
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_debounce_1 is
  port (
    \counter_reg[31]_0\ : out STD_LOGIC;
    s00_axi_aclk : in STD_LOGIC;
    CO : in STD_LOGIC_VECTOR ( 0 to 0 );
    i_button_right : in STD_LOGIC
  );
  attribute ORIG_REF_NAME : string;
  attribute ORIG_REF_NAME of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_debounce_1 : entity is "debounce";
end decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_debounce_1;

architecture STRUCTURE of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_debounce_1 is
  signal button_Right : STD_LOGIC;
  signal counter : STD_LOGIC;
  signal \counter1_carry__0_i_1__2_n_0\ : STD_LOGIC;
  signal \counter1_carry__0_i_2__2_n_0\ : STD_LOGIC;
  signal \counter1_carry__0_i_3__2_n_0\ : STD_LOGIC;
  signal \counter1_carry__0_i_4__0_n_0\ : STD_LOGIC;
  signal \counter1_carry__0_i_5__0_n_0\ : STD_LOGIC;
  signal \counter1_carry__0_i_6__0_n_0\ : STD_LOGIC;
  signal \counter1_carry__0_i_7__0_n_0\ : STD_LOGIC;
  signal \counter1_carry__0_n_0\ : STD_LOGIC;
  signal \counter1_carry__0_n_1\ : STD_LOGIC;
  signal \counter1_carry__0_n_2\ : STD_LOGIC;
  signal \counter1_carry__0_n_3\ : STD_LOGIC;
  signal \counter1_carry__1_i_1__0_n_0\ : STD_LOGIC;
  signal \counter1_carry__1_i_2__0_n_0\ : STD_LOGIC;
  signal \counter1_carry__1_i_3__0_n_0\ : STD_LOGIC;
  signal \counter1_carry__1_i_4__0_n_0\ : STD_LOGIC;
  signal \counter1_carry__1_n_0\ : STD_LOGIC;
  signal \counter1_carry__1_n_1\ : STD_LOGIC;
  signal \counter1_carry__1_n_2\ : STD_LOGIC;
  signal \counter1_carry__1_n_3\ : STD_LOGIC;
  signal \counter1_carry__2_i_1__0_n_0\ : STD_LOGIC;
  signal \counter1_carry__2_n_3\ : STD_LOGIC;
  signal \counter1_carry_i_1__2_n_0\ : STD_LOGIC;
  signal \counter1_carry_i_2__2_n_0\ : STD_LOGIC;
  signal \counter1_carry_i_3__0_n_0\ : STD_LOGIC;
  signal \counter1_carry_i_4__0_n_0\ : STD_LOGIC;
  signal \counter1_carry_i_5__0_n_0\ : STD_LOGIC;
  signal \counter1_carry_i_6__0_n_0\ : STD_LOGIC;
  signal counter1_carry_n_0 : STD_LOGIC;
  signal counter1_carry_n_1 : STD_LOGIC;
  signal counter1_carry_n_2 : STD_LOGIC;
  signal counter1_carry_n_3 : STD_LOGIC;
  signal \counter[0]_i_3__0_n_0\ : STD_LOGIC;
  signal counter_reg : STD_LOGIC_VECTOR ( 31 downto 0 );
  signal \counter_reg[0]_i_2__0_n_0\ : STD_LOGIC;
  signal \counter_reg[0]_i_2__0_n_1\ : STD_LOGIC;
  signal \counter_reg[0]_i_2__0_n_2\ : STD_LOGIC;
  signal \counter_reg[0]_i_2__0_n_3\ : STD_LOGIC;
  signal \counter_reg[0]_i_2__0_n_4\ : STD_LOGIC;
  signal \counter_reg[0]_i_2__0_n_5\ : STD_LOGIC;
  signal \counter_reg[0]_i_2__0_n_6\ : STD_LOGIC;
  signal \counter_reg[0]_i_2__0_n_7\ : STD_LOGIC;
  signal \counter_reg[12]_i_1__0_n_0\ : STD_LOGIC;
  signal \counter_reg[12]_i_1__0_n_1\ : STD_LOGIC;
  signal \counter_reg[12]_i_1__0_n_2\ : STD_LOGIC;
  signal \counter_reg[12]_i_1__0_n_3\ : STD_LOGIC;
  signal \counter_reg[12]_i_1__0_n_4\ : STD_LOGIC;
  signal \counter_reg[12]_i_1__0_n_5\ : STD_LOGIC;
  signal \counter_reg[12]_i_1__0_n_6\ : STD_LOGIC;
  signal \counter_reg[12]_i_1__0_n_7\ : STD_LOGIC;
  signal \counter_reg[16]_i_1__0_n_0\ : STD_LOGIC;
  signal \counter_reg[16]_i_1__0_n_1\ : STD_LOGIC;
  signal \counter_reg[16]_i_1__0_n_2\ : STD_LOGIC;
  signal \counter_reg[16]_i_1__0_n_3\ : STD_LOGIC;
  signal \counter_reg[16]_i_1__0_n_4\ : STD_LOGIC;
  signal \counter_reg[16]_i_1__0_n_5\ : STD_LOGIC;
  signal \counter_reg[16]_i_1__0_n_6\ : STD_LOGIC;
  signal \counter_reg[16]_i_1__0_n_7\ : STD_LOGIC;
  signal \counter_reg[20]_i_1__0_n_0\ : STD_LOGIC;
  signal \counter_reg[20]_i_1__0_n_1\ : STD_LOGIC;
  signal \counter_reg[20]_i_1__0_n_2\ : STD_LOGIC;
  signal \counter_reg[20]_i_1__0_n_3\ : STD_LOGIC;
  signal \counter_reg[20]_i_1__0_n_4\ : STD_LOGIC;
  signal \counter_reg[20]_i_1__0_n_5\ : STD_LOGIC;
  signal \counter_reg[20]_i_1__0_n_6\ : STD_LOGIC;
  signal \counter_reg[20]_i_1__0_n_7\ : STD_LOGIC;
  signal \counter_reg[24]_i_1__0_n_0\ : STD_LOGIC;
  signal \counter_reg[24]_i_1__0_n_1\ : STD_LOGIC;
  signal \counter_reg[24]_i_1__0_n_2\ : STD_LOGIC;
  signal \counter_reg[24]_i_1__0_n_3\ : STD_LOGIC;
  signal \counter_reg[24]_i_1__0_n_4\ : STD_LOGIC;
  signal \counter_reg[24]_i_1__0_n_5\ : STD_LOGIC;
  signal \counter_reg[24]_i_1__0_n_6\ : STD_LOGIC;
  signal \counter_reg[24]_i_1__0_n_7\ : STD_LOGIC;
  signal \counter_reg[28]_i_1__0_n_1\ : STD_LOGIC;
  signal \counter_reg[28]_i_1__0_n_2\ : STD_LOGIC;
  signal \counter_reg[28]_i_1__0_n_3\ : STD_LOGIC;
  signal \counter_reg[28]_i_1__0_n_4\ : STD_LOGIC;
  signal \counter_reg[28]_i_1__0_n_5\ : STD_LOGIC;
  signal \counter_reg[28]_i_1__0_n_6\ : STD_LOGIC;
  signal \counter_reg[28]_i_1__0_n_7\ : STD_LOGIC;
  signal \counter_reg[4]_i_1__0_n_0\ : STD_LOGIC;
  signal \counter_reg[4]_i_1__0_n_1\ : STD_LOGIC;
  signal \counter_reg[4]_i_1__0_n_2\ : STD_LOGIC;
  signal \counter_reg[4]_i_1__0_n_3\ : STD_LOGIC;
  signal \counter_reg[4]_i_1__0_n_4\ : STD_LOGIC;
  signal \counter_reg[4]_i_1__0_n_5\ : STD_LOGIC;
  signal \counter_reg[4]_i_1__0_n_6\ : STD_LOGIC;
  signal \counter_reg[4]_i_1__0_n_7\ : STD_LOGIC;
  signal \counter_reg[8]_i_1__0_n_0\ : STD_LOGIC;
  signal \counter_reg[8]_i_1__0_n_1\ : STD_LOGIC;
  signal \counter_reg[8]_i_1__0_n_2\ : STD_LOGIC;
  signal \counter_reg[8]_i_1__0_n_3\ : STD_LOGIC;
  signal \counter_reg[8]_i_1__0_n_4\ : STD_LOGIC;
  signal \counter_reg[8]_i_1__0_n_5\ : STD_LOGIC;
  signal \counter_reg[8]_i_1__0_n_6\ : STD_LOGIC;
  signal \counter_reg[8]_i_1__0_n_7\ : STD_LOGIC;
  signal \o_press_i_1__0_n_0\ : STD_LOGIC;
  signal \o_press_i_2__0_n_0\ : STD_LOGIC;
  signal \o_press_i_3__0_n_0\ : STD_LOGIC;
  signal \o_press_i_4__0_n_0\ : STD_LOGIC;
  signal \o_press_i_5__0_n_0\ : STD_LOGIC;
  signal \o_press_i_6__0_n_0\ : STD_LOGIC;
  signal \o_press_i_7__0_n_0\ : STD_LOGIC;
  signal \o_press_i_8__0_n_0\ : STD_LOGIC;
  signal \o_press_i_9__0_n_0\ : STD_LOGIC;
  signal NLW_counter1_carry_O_UNCONNECTED : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_counter1_carry__0_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_counter1_carry__1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_counter1_carry__2_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \NLW_counter1_carry__2_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_counter_reg[28]_i_1__0_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
begin
counter1_carry: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => counter1_carry_n_0,
      CO(2) => counter1_carry_n_1,
      CO(1) => counter1_carry_n_2,
      CO(0) => counter1_carry_n_3,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \counter1_carry_i_1__2_n_0\,
      DI(0) => \counter1_carry_i_2__2_n_0\,
      O(3 downto 0) => NLW_counter1_carry_O_UNCONNECTED(3 downto 0),
      S(3) => \counter1_carry_i_3__0_n_0\,
      S(2) => \counter1_carry_i_4__0_n_0\,
      S(1) => \counter1_carry_i_5__0_n_0\,
      S(0) => \counter1_carry_i_6__0_n_0\
    );
\counter1_carry__0\: unisim.vcomponents.CARRY4
     port map (
      CI => counter1_carry_n_0,
      CO(3) => \counter1_carry__0_n_0\,
      CO(2) => \counter1_carry__0_n_1\,
      CO(1) => \counter1_carry__0_n_2\,
      CO(0) => \counter1_carry__0_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => \counter1_carry__0_i_1__2_n_0\,
      DI(1) => \counter1_carry__0_i_2__2_n_0\,
      DI(0) => \counter1_carry__0_i_3__2_n_0\,
      O(3 downto 0) => \NLW_counter1_carry__0_O_UNCONNECTED\(3 downto 0),
      S(3) => \counter1_carry__0_i_4__0_n_0\,
      S(2) => \counter1_carry__0_i_5__0_n_0\,
      S(1) => \counter1_carry__0_i_6__0_n_0\,
      S(0) => \counter1_carry__0_i_7__0_n_0\
    );
\counter1_carry__0_i_1__2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"7"
    )
        port map (
      I0 => counter_reg(18),
      I1 => counter_reg(19),
      O => \counter1_carry__0_i_1__2_n_0\
    );
\counter1_carry__0_i_2__2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"7"
    )
        port map (
      I0 => counter_reg(16),
      I1 => counter_reg(17),
      O => \counter1_carry__0_i_2__2_n_0\
    );
\counter1_carry__0_i_3__2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => counter_reg(14),
      I1 => counter_reg(15),
      O => \counter1_carry__0_i_3__2_n_0\
    );
\counter1_carry__0_i_4__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => counter_reg(20),
      I1 => counter_reg(21),
      O => \counter1_carry__0_i_4__0_n_0\
    );
\counter1_carry__0_i_5__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => counter_reg(18),
      I1 => counter_reg(19),
      O => \counter1_carry__0_i_5__0_n_0\
    );
\counter1_carry__0_i_6__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => counter_reg(16),
      I1 => counter_reg(17),
      O => \counter1_carry__0_i_6__0_n_0\
    );
\counter1_carry__0_i_7__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => counter_reg(14),
      I1 => counter_reg(15),
      O => \counter1_carry__0_i_7__0_n_0\
    );
\counter1_carry__1\: unisim.vcomponents.CARRY4
     port map (
      CI => \counter1_carry__0_n_0\,
      CO(3) => \counter1_carry__1_n_0\,
      CO(2) => \counter1_carry__1_n_1\,
      CO(1) => \counter1_carry__1_n_2\,
      CO(0) => \counter1_carry__1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => \NLW_counter1_carry__1_O_UNCONNECTED\(3 downto 0),
      S(3) => \counter1_carry__1_i_1__0_n_0\,
      S(2) => \counter1_carry__1_i_2__0_n_0\,
      S(1) => \counter1_carry__1_i_3__0_n_0\,
      S(0) => \counter1_carry__1_i_4__0_n_0\
    );
\counter1_carry__1_i_1__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => counter_reg(28),
      I1 => counter_reg(29),
      O => \counter1_carry__1_i_1__0_n_0\
    );
\counter1_carry__1_i_2__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => counter_reg(26),
      I1 => counter_reg(27),
      O => \counter1_carry__1_i_2__0_n_0\
    );
\counter1_carry__1_i_3__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => counter_reg(24),
      I1 => counter_reg(25),
      O => \counter1_carry__1_i_3__0_n_0\
    );
\counter1_carry__1_i_4__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => counter_reg(22),
      I1 => counter_reg(23),
      O => \counter1_carry__1_i_4__0_n_0\
    );
\counter1_carry__2\: unisim.vcomponents.CARRY4
     port map (
      CI => \counter1_carry__1_n_0\,
      CO(3 downto 1) => \NLW_counter1_carry__2_CO_UNCONNECTED\(3 downto 1),
      CO(0) => \counter1_carry__2_n_3\,
      CYINIT => '0',
      DI(3 downto 1) => B"000",
      DI(0) => counter_reg(31),
      O(3 downto 0) => \NLW_counter1_carry__2_O_UNCONNECTED\(3 downto 0),
      S(3 downto 1) => B"000",
      S(0) => \counter1_carry__2_i_1__0_n_0\
    );
\counter1_carry__2_i_1__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => counter_reg(31),
      I1 => counter_reg(30),
      O => \counter1_carry__2_i_1__0_n_0\
    );
\counter1_carry_i_1__2\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => counter_reg(9),
      O => \counter1_carry_i_1__2_n_0\
    );
\counter1_carry_i_2__2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => counter_reg(6),
      I1 => counter_reg(7),
      O => \counter1_carry_i_2__2_n_0\
    );
\counter1_carry_i_3__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => counter_reg(12),
      I1 => counter_reg(13),
      O => \counter1_carry_i_3__0_n_0\
    );
\counter1_carry_i_4__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => counter_reg(10),
      I1 => counter_reg(11),
      O => \counter1_carry_i_4__0_n_0\
    );
\counter1_carry_i_5__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => counter_reg(9),
      I1 => counter_reg(8),
      O => \counter1_carry_i_5__0_n_0\
    );
\counter1_carry_i_6__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => counter_reg(6),
      I1 => counter_reg(7),
      O => \counter1_carry_i_6__0_n_0\
    );
\counter[0]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"7"
    )
        port map (
      I0 => button_Right,
      I1 => CO(0),
      O => \counter_reg[31]_0\
    );
\counter[0]_i_1__4\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => i_button_right,
      O => counter
    );
\counter[0]_i_3__0\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => counter_reg(0),
      O => \counter[0]_i_3__0_n_0\
    );
\counter_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[0]_i_2__0_n_7\,
      Q => counter_reg(0),
      R => counter
    );
\counter_reg[0]_i_2__0\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \counter_reg[0]_i_2__0_n_0\,
      CO(2) => \counter_reg[0]_i_2__0_n_1\,
      CO(1) => \counter_reg[0]_i_2__0_n_2\,
      CO(0) => \counter_reg[0]_i_2__0_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0001",
      O(3) => \counter_reg[0]_i_2__0_n_4\,
      O(2) => \counter_reg[0]_i_2__0_n_5\,
      O(1) => \counter_reg[0]_i_2__0_n_6\,
      O(0) => \counter_reg[0]_i_2__0_n_7\,
      S(3 downto 1) => counter_reg(3 downto 1),
      S(0) => \counter[0]_i_3__0_n_0\
    );
\counter_reg[10]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[8]_i_1__0_n_5\,
      Q => counter_reg(10),
      R => counter
    );
\counter_reg[11]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[8]_i_1__0_n_4\,
      Q => counter_reg(11),
      R => counter
    );
\counter_reg[12]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[12]_i_1__0_n_7\,
      Q => counter_reg(12),
      R => counter
    );
\counter_reg[12]_i_1__0\: unisim.vcomponents.CARRY4
     port map (
      CI => \counter_reg[8]_i_1__0_n_0\,
      CO(3) => \counter_reg[12]_i_1__0_n_0\,
      CO(2) => \counter_reg[12]_i_1__0_n_1\,
      CO(1) => \counter_reg[12]_i_1__0_n_2\,
      CO(0) => \counter_reg[12]_i_1__0_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \counter_reg[12]_i_1__0_n_4\,
      O(2) => \counter_reg[12]_i_1__0_n_5\,
      O(1) => \counter_reg[12]_i_1__0_n_6\,
      O(0) => \counter_reg[12]_i_1__0_n_7\,
      S(3 downto 0) => counter_reg(15 downto 12)
    );
\counter_reg[13]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[12]_i_1__0_n_6\,
      Q => counter_reg(13),
      R => counter
    );
\counter_reg[14]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[12]_i_1__0_n_5\,
      Q => counter_reg(14),
      R => counter
    );
\counter_reg[15]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[12]_i_1__0_n_4\,
      Q => counter_reg(15),
      R => counter
    );
\counter_reg[16]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[16]_i_1__0_n_7\,
      Q => counter_reg(16),
      R => counter
    );
\counter_reg[16]_i_1__0\: unisim.vcomponents.CARRY4
     port map (
      CI => \counter_reg[12]_i_1__0_n_0\,
      CO(3) => \counter_reg[16]_i_1__0_n_0\,
      CO(2) => \counter_reg[16]_i_1__0_n_1\,
      CO(1) => \counter_reg[16]_i_1__0_n_2\,
      CO(0) => \counter_reg[16]_i_1__0_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \counter_reg[16]_i_1__0_n_4\,
      O(2) => \counter_reg[16]_i_1__0_n_5\,
      O(1) => \counter_reg[16]_i_1__0_n_6\,
      O(0) => \counter_reg[16]_i_1__0_n_7\,
      S(3 downto 0) => counter_reg(19 downto 16)
    );
\counter_reg[17]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[16]_i_1__0_n_6\,
      Q => counter_reg(17),
      R => counter
    );
\counter_reg[18]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[16]_i_1__0_n_5\,
      Q => counter_reg(18),
      R => counter
    );
\counter_reg[19]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[16]_i_1__0_n_4\,
      Q => counter_reg(19),
      R => counter
    );
\counter_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[0]_i_2__0_n_6\,
      Q => counter_reg(1),
      R => counter
    );
\counter_reg[20]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[20]_i_1__0_n_7\,
      Q => counter_reg(20),
      R => counter
    );
\counter_reg[20]_i_1__0\: unisim.vcomponents.CARRY4
     port map (
      CI => \counter_reg[16]_i_1__0_n_0\,
      CO(3) => \counter_reg[20]_i_1__0_n_0\,
      CO(2) => \counter_reg[20]_i_1__0_n_1\,
      CO(1) => \counter_reg[20]_i_1__0_n_2\,
      CO(0) => \counter_reg[20]_i_1__0_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \counter_reg[20]_i_1__0_n_4\,
      O(2) => \counter_reg[20]_i_1__0_n_5\,
      O(1) => \counter_reg[20]_i_1__0_n_6\,
      O(0) => \counter_reg[20]_i_1__0_n_7\,
      S(3 downto 0) => counter_reg(23 downto 20)
    );
\counter_reg[21]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[20]_i_1__0_n_6\,
      Q => counter_reg(21),
      R => counter
    );
\counter_reg[22]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[20]_i_1__0_n_5\,
      Q => counter_reg(22),
      R => counter
    );
\counter_reg[23]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[20]_i_1__0_n_4\,
      Q => counter_reg(23),
      R => counter
    );
\counter_reg[24]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[24]_i_1__0_n_7\,
      Q => counter_reg(24),
      R => counter
    );
\counter_reg[24]_i_1__0\: unisim.vcomponents.CARRY4
     port map (
      CI => \counter_reg[20]_i_1__0_n_0\,
      CO(3) => \counter_reg[24]_i_1__0_n_0\,
      CO(2) => \counter_reg[24]_i_1__0_n_1\,
      CO(1) => \counter_reg[24]_i_1__0_n_2\,
      CO(0) => \counter_reg[24]_i_1__0_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \counter_reg[24]_i_1__0_n_4\,
      O(2) => \counter_reg[24]_i_1__0_n_5\,
      O(1) => \counter_reg[24]_i_1__0_n_6\,
      O(0) => \counter_reg[24]_i_1__0_n_7\,
      S(3 downto 0) => counter_reg(27 downto 24)
    );
\counter_reg[25]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[24]_i_1__0_n_6\,
      Q => counter_reg(25),
      R => counter
    );
\counter_reg[26]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[24]_i_1__0_n_5\,
      Q => counter_reg(26),
      R => counter
    );
\counter_reg[27]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[24]_i_1__0_n_4\,
      Q => counter_reg(27),
      R => counter
    );
\counter_reg[28]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[28]_i_1__0_n_7\,
      Q => counter_reg(28),
      R => counter
    );
\counter_reg[28]_i_1__0\: unisim.vcomponents.CARRY4
     port map (
      CI => \counter_reg[24]_i_1__0_n_0\,
      CO(3) => \NLW_counter_reg[28]_i_1__0_CO_UNCONNECTED\(3),
      CO(2) => \counter_reg[28]_i_1__0_n_1\,
      CO(1) => \counter_reg[28]_i_1__0_n_2\,
      CO(0) => \counter_reg[28]_i_1__0_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \counter_reg[28]_i_1__0_n_4\,
      O(2) => \counter_reg[28]_i_1__0_n_5\,
      O(1) => \counter_reg[28]_i_1__0_n_6\,
      O(0) => \counter_reg[28]_i_1__0_n_7\,
      S(3 downto 0) => counter_reg(31 downto 28)
    );
\counter_reg[29]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[28]_i_1__0_n_6\,
      Q => counter_reg(29),
      R => counter
    );
\counter_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[0]_i_2__0_n_5\,
      Q => counter_reg(2),
      R => counter
    );
\counter_reg[30]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[28]_i_1__0_n_5\,
      Q => counter_reg(30),
      R => counter
    );
\counter_reg[31]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[28]_i_1__0_n_4\,
      Q => counter_reg(31),
      R => counter
    );
\counter_reg[3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[0]_i_2__0_n_4\,
      Q => counter_reg(3),
      R => counter
    );
\counter_reg[4]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[4]_i_1__0_n_7\,
      Q => counter_reg(4),
      R => counter
    );
\counter_reg[4]_i_1__0\: unisim.vcomponents.CARRY4
     port map (
      CI => \counter_reg[0]_i_2__0_n_0\,
      CO(3) => \counter_reg[4]_i_1__0_n_0\,
      CO(2) => \counter_reg[4]_i_1__0_n_1\,
      CO(1) => \counter_reg[4]_i_1__0_n_2\,
      CO(0) => \counter_reg[4]_i_1__0_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \counter_reg[4]_i_1__0_n_4\,
      O(2) => \counter_reg[4]_i_1__0_n_5\,
      O(1) => \counter_reg[4]_i_1__0_n_6\,
      O(0) => \counter_reg[4]_i_1__0_n_7\,
      S(3 downto 0) => counter_reg(7 downto 4)
    );
\counter_reg[5]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[4]_i_1__0_n_6\,
      Q => counter_reg(5),
      R => counter
    );
\counter_reg[6]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[4]_i_1__0_n_5\,
      Q => counter_reg(6),
      R => counter
    );
\counter_reg[7]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[4]_i_1__0_n_4\,
      Q => counter_reg(7),
      R => counter
    );
\counter_reg[8]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[8]_i_1__0_n_7\,
      Q => counter_reg(8),
      R => counter
    );
\counter_reg[8]_i_1__0\: unisim.vcomponents.CARRY4
     port map (
      CI => \counter_reg[4]_i_1__0_n_0\,
      CO(3) => \counter_reg[8]_i_1__0_n_0\,
      CO(2) => \counter_reg[8]_i_1__0_n_1\,
      CO(1) => \counter_reg[8]_i_1__0_n_2\,
      CO(0) => \counter_reg[8]_i_1__0_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \counter_reg[8]_i_1__0_n_4\,
      O(2) => \counter_reg[8]_i_1__0_n_5\,
      O(1) => \counter_reg[8]_i_1__0_n_6\,
      O(0) => \counter_reg[8]_i_1__0_n_7\,
      S(3 downto 0) => counter_reg(11 downto 8)
    );
\counter_reg[9]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[8]_i_1__0_n_6\,
      Q => counter_reg(9),
      R => counter
    );
\o_press_i_1__0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000000001"
    )
        port map (
      I0 => \o_press_i_2__0_n_0\,
      I1 => \o_press_i_3__0_n_0\,
      I2 => counter_reg(30),
      I3 => counter_reg(31),
      I4 => \o_press_i_4__0_n_0\,
      I5 => \o_press_i_5__0_n_0\,
      O => \o_press_i_1__0_n_0\
    );
\o_press_i_2__0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFFFFFE"
    )
        port map (
      I0 => counter_reg(21),
      I1 => counter_reg(20),
      I2 => counter_reg(23),
      I3 => counter_reg(22),
      I4 => \o_press_i_6__0_n_0\,
      O => \o_press_i_2__0_n_0\
    );
\o_press_i_3__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => counter_reg(29),
      I1 => counter_reg(28),
      O => \o_press_i_3__0_n_0\
    );
\o_press_i_4__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFFE"
    )
        port map (
      I0 => counter_reg(26),
      I1 => counter_reg(27),
      I2 => counter_reg(24),
      I3 => counter_reg(25),
      O => \o_press_i_4__0_n_0\
    );
\o_press_i_5__0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFFFFE"
    )
        port map (
      I0 => \o_press_i_7__0_n_0\,
      I1 => counter_reg(3),
      I2 => counter_reg(15),
      I3 => counter_reg(12),
      I4 => counter_reg(13),
      I5 => \o_press_i_8__0_n_0\,
      O => \o_press_i_5__0_n_0\
    );
\o_press_i_6__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFFE"
    )
        port map (
      I0 => counter_reg(0),
      I1 => counter_reg(5),
      I2 => counter_reg(2),
      I3 => counter_reg(1),
      O => \o_press_i_6__0_n_0\
    );
\o_press_i_7__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFFE"
    )
        port map (
      I0 => counter_reg(10),
      I1 => counter_reg(11),
      I2 => counter_reg(8),
      I3 => counter_reg(4),
      O => \o_press_i_7__0_n_0\
    );
\o_press_i_8__0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFFF7FF"
    )
        port map (
      I0 => counter_reg(6),
      I1 => counter_reg(9),
      I2 => counter_reg(7),
      I3 => counter_reg(19),
      I4 => \o_press_i_9__0_n_0\,
      O => \o_press_i_8__0_n_0\
    );
\o_press_i_9__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"7FFF"
    )
        port map (
      I0 => counter_reg(16),
      I1 => counter_reg(14),
      I2 => counter_reg(18),
      I3 => counter_reg(17),
      O => \o_press_i_9__0_n_0\
    );
o_press_reg: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \o_press_i_1__0_n_0\,
      Q => button_Right,
      R => '0'
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_debounce_2 is
  port (
    \counter_reg[31]_0\ : out STD_LOGIC;
    s00_axi_aclk : in STD_LOGIC;
    CO : in STD_LOGIC_VECTOR ( 0 to 0 );
    i_button_up : in STD_LOGIC
  );
  attribute ORIG_REF_NAME : string;
  attribute ORIG_REF_NAME of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_debounce_2 : entity is "debounce";
end decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_debounce_2;

architecture STRUCTURE of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_debounce_2 is
  signal button_up : STD_LOGIC;
  signal counter : STD_LOGIC;
  signal \counter1_carry__0_i_1__1_n_0\ : STD_LOGIC;
  signal \counter1_carry__0_i_2__1_n_0\ : STD_LOGIC;
  signal \counter1_carry__0_i_3__1_n_0\ : STD_LOGIC;
  signal \counter1_carry__0_i_4__1_n_0\ : STD_LOGIC;
  signal \counter1_carry__0_i_5__1_n_0\ : STD_LOGIC;
  signal \counter1_carry__0_i_6__1_n_0\ : STD_LOGIC;
  signal \counter1_carry__0_i_7__1_n_0\ : STD_LOGIC;
  signal \counter1_carry__0_n_0\ : STD_LOGIC;
  signal \counter1_carry__0_n_1\ : STD_LOGIC;
  signal \counter1_carry__0_n_2\ : STD_LOGIC;
  signal \counter1_carry__0_n_3\ : STD_LOGIC;
  signal \counter1_carry__1_i_1__1_n_0\ : STD_LOGIC;
  signal \counter1_carry__1_i_2__1_n_0\ : STD_LOGIC;
  signal \counter1_carry__1_i_3__1_n_0\ : STD_LOGIC;
  signal \counter1_carry__1_i_4__1_n_0\ : STD_LOGIC;
  signal \counter1_carry__1_n_0\ : STD_LOGIC;
  signal \counter1_carry__1_n_1\ : STD_LOGIC;
  signal \counter1_carry__1_n_2\ : STD_LOGIC;
  signal \counter1_carry__1_n_3\ : STD_LOGIC;
  signal \counter1_carry__2_i_1__1_n_0\ : STD_LOGIC;
  signal \counter1_carry__2_n_3\ : STD_LOGIC;
  signal \counter1_carry_i_1__1_n_0\ : STD_LOGIC;
  signal \counter1_carry_i_2__1_n_0\ : STD_LOGIC;
  signal \counter1_carry_i_3__1_n_0\ : STD_LOGIC;
  signal \counter1_carry_i_4__1_n_0\ : STD_LOGIC;
  signal \counter1_carry_i_5__1_n_0\ : STD_LOGIC;
  signal \counter1_carry_i_6__1_n_0\ : STD_LOGIC;
  signal counter1_carry_n_0 : STD_LOGIC;
  signal counter1_carry_n_1 : STD_LOGIC;
  signal counter1_carry_n_2 : STD_LOGIC;
  signal counter1_carry_n_3 : STD_LOGIC;
  signal \counter[0]_i_3__1_n_0\ : STD_LOGIC;
  signal counter_reg : STD_LOGIC_VECTOR ( 31 downto 0 );
  signal \counter_reg[0]_i_2__1_n_0\ : STD_LOGIC;
  signal \counter_reg[0]_i_2__1_n_1\ : STD_LOGIC;
  signal \counter_reg[0]_i_2__1_n_2\ : STD_LOGIC;
  signal \counter_reg[0]_i_2__1_n_3\ : STD_LOGIC;
  signal \counter_reg[0]_i_2__1_n_4\ : STD_LOGIC;
  signal \counter_reg[0]_i_2__1_n_5\ : STD_LOGIC;
  signal \counter_reg[0]_i_2__1_n_6\ : STD_LOGIC;
  signal \counter_reg[0]_i_2__1_n_7\ : STD_LOGIC;
  signal \counter_reg[12]_i_1__1_n_0\ : STD_LOGIC;
  signal \counter_reg[12]_i_1__1_n_1\ : STD_LOGIC;
  signal \counter_reg[12]_i_1__1_n_2\ : STD_LOGIC;
  signal \counter_reg[12]_i_1__1_n_3\ : STD_LOGIC;
  signal \counter_reg[12]_i_1__1_n_4\ : STD_LOGIC;
  signal \counter_reg[12]_i_1__1_n_5\ : STD_LOGIC;
  signal \counter_reg[12]_i_1__1_n_6\ : STD_LOGIC;
  signal \counter_reg[12]_i_1__1_n_7\ : STD_LOGIC;
  signal \counter_reg[16]_i_1__1_n_0\ : STD_LOGIC;
  signal \counter_reg[16]_i_1__1_n_1\ : STD_LOGIC;
  signal \counter_reg[16]_i_1__1_n_2\ : STD_LOGIC;
  signal \counter_reg[16]_i_1__1_n_3\ : STD_LOGIC;
  signal \counter_reg[16]_i_1__1_n_4\ : STD_LOGIC;
  signal \counter_reg[16]_i_1__1_n_5\ : STD_LOGIC;
  signal \counter_reg[16]_i_1__1_n_6\ : STD_LOGIC;
  signal \counter_reg[16]_i_1__1_n_7\ : STD_LOGIC;
  signal \counter_reg[20]_i_1__1_n_0\ : STD_LOGIC;
  signal \counter_reg[20]_i_1__1_n_1\ : STD_LOGIC;
  signal \counter_reg[20]_i_1__1_n_2\ : STD_LOGIC;
  signal \counter_reg[20]_i_1__1_n_3\ : STD_LOGIC;
  signal \counter_reg[20]_i_1__1_n_4\ : STD_LOGIC;
  signal \counter_reg[20]_i_1__1_n_5\ : STD_LOGIC;
  signal \counter_reg[20]_i_1__1_n_6\ : STD_LOGIC;
  signal \counter_reg[20]_i_1__1_n_7\ : STD_LOGIC;
  signal \counter_reg[24]_i_1__1_n_0\ : STD_LOGIC;
  signal \counter_reg[24]_i_1__1_n_1\ : STD_LOGIC;
  signal \counter_reg[24]_i_1__1_n_2\ : STD_LOGIC;
  signal \counter_reg[24]_i_1__1_n_3\ : STD_LOGIC;
  signal \counter_reg[24]_i_1__1_n_4\ : STD_LOGIC;
  signal \counter_reg[24]_i_1__1_n_5\ : STD_LOGIC;
  signal \counter_reg[24]_i_1__1_n_6\ : STD_LOGIC;
  signal \counter_reg[24]_i_1__1_n_7\ : STD_LOGIC;
  signal \counter_reg[28]_i_1__1_n_1\ : STD_LOGIC;
  signal \counter_reg[28]_i_1__1_n_2\ : STD_LOGIC;
  signal \counter_reg[28]_i_1__1_n_3\ : STD_LOGIC;
  signal \counter_reg[28]_i_1__1_n_4\ : STD_LOGIC;
  signal \counter_reg[28]_i_1__1_n_5\ : STD_LOGIC;
  signal \counter_reg[28]_i_1__1_n_6\ : STD_LOGIC;
  signal \counter_reg[28]_i_1__1_n_7\ : STD_LOGIC;
  signal \counter_reg[4]_i_1__1_n_0\ : STD_LOGIC;
  signal \counter_reg[4]_i_1__1_n_1\ : STD_LOGIC;
  signal \counter_reg[4]_i_1__1_n_2\ : STD_LOGIC;
  signal \counter_reg[4]_i_1__1_n_3\ : STD_LOGIC;
  signal \counter_reg[4]_i_1__1_n_4\ : STD_LOGIC;
  signal \counter_reg[4]_i_1__1_n_5\ : STD_LOGIC;
  signal \counter_reg[4]_i_1__1_n_6\ : STD_LOGIC;
  signal \counter_reg[4]_i_1__1_n_7\ : STD_LOGIC;
  signal \counter_reg[8]_i_1__1_n_0\ : STD_LOGIC;
  signal \counter_reg[8]_i_1__1_n_1\ : STD_LOGIC;
  signal \counter_reg[8]_i_1__1_n_2\ : STD_LOGIC;
  signal \counter_reg[8]_i_1__1_n_3\ : STD_LOGIC;
  signal \counter_reg[8]_i_1__1_n_4\ : STD_LOGIC;
  signal \counter_reg[8]_i_1__1_n_5\ : STD_LOGIC;
  signal \counter_reg[8]_i_1__1_n_6\ : STD_LOGIC;
  signal \counter_reg[8]_i_1__1_n_7\ : STD_LOGIC;
  signal \o_press_i_1__1_n_0\ : STD_LOGIC;
  signal \o_press_i_2__1_n_0\ : STD_LOGIC;
  signal \o_press_i_3__1_n_0\ : STD_LOGIC;
  signal \o_press_i_4__1_n_0\ : STD_LOGIC;
  signal \o_press_i_5__1_n_0\ : STD_LOGIC;
  signal \o_press_i_6__1_n_0\ : STD_LOGIC;
  signal \o_press_i_7__1_n_0\ : STD_LOGIC;
  signal \o_press_i_8__1_n_0\ : STD_LOGIC;
  signal \o_press_i_9__1_n_0\ : STD_LOGIC;
  signal NLW_counter1_carry_O_UNCONNECTED : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_counter1_carry__0_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_counter1_carry__1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_counter1_carry__2_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \NLW_counter1_carry__2_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_counter_reg[28]_i_1__1_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
begin
counter1_carry: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => counter1_carry_n_0,
      CO(2) => counter1_carry_n_1,
      CO(1) => counter1_carry_n_2,
      CO(0) => counter1_carry_n_3,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \counter1_carry_i_1__1_n_0\,
      DI(0) => \counter1_carry_i_2__1_n_0\,
      O(3 downto 0) => NLW_counter1_carry_O_UNCONNECTED(3 downto 0),
      S(3) => \counter1_carry_i_3__1_n_0\,
      S(2) => \counter1_carry_i_4__1_n_0\,
      S(1) => \counter1_carry_i_5__1_n_0\,
      S(0) => \counter1_carry_i_6__1_n_0\
    );
\counter1_carry__0\: unisim.vcomponents.CARRY4
     port map (
      CI => counter1_carry_n_0,
      CO(3) => \counter1_carry__0_n_0\,
      CO(2) => \counter1_carry__0_n_1\,
      CO(1) => \counter1_carry__0_n_2\,
      CO(0) => \counter1_carry__0_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => \counter1_carry__0_i_1__1_n_0\,
      DI(1) => \counter1_carry__0_i_2__1_n_0\,
      DI(0) => \counter1_carry__0_i_3__1_n_0\,
      O(3 downto 0) => \NLW_counter1_carry__0_O_UNCONNECTED\(3 downto 0),
      S(3) => \counter1_carry__0_i_4__1_n_0\,
      S(2) => \counter1_carry__0_i_5__1_n_0\,
      S(1) => \counter1_carry__0_i_6__1_n_0\,
      S(0) => \counter1_carry__0_i_7__1_n_0\
    );
\counter1_carry__0_i_1__1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"7"
    )
        port map (
      I0 => counter_reg(18),
      I1 => counter_reg(19),
      O => \counter1_carry__0_i_1__1_n_0\
    );
\counter1_carry__0_i_2__1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"7"
    )
        port map (
      I0 => counter_reg(16),
      I1 => counter_reg(17),
      O => \counter1_carry__0_i_2__1_n_0\
    );
\counter1_carry__0_i_3__1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => counter_reg(14),
      I1 => counter_reg(15),
      O => \counter1_carry__0_i_3__1_n_0\
    );
\counter1_carry__0_i_4__1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => counter_reg(20),
      I1 => counter_reg(21),
      O => \counter1_carry__0_i_4__1_n_0\
    );
\counter1_carry__0_i_5__1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => counter_reg(18),
      I1 => counter_reg(19),
      O => \counter1_carry__0_i_5__1_n_0\
    );
\counter1_carry__0_i_6__1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => counter_reg(16),
      I1 => counter_reg(17),
      O => \counter1_carry__0_i_6__1_n_0\
    );
\counter1_carry__0_i_7__1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => counter_reg(14),
      I1 => counter_reg(15),
      O => \counter1_carry__0_i_7__1_n_0\
    );
\counter1_carry__1\: unisim.vcomponents.CARRY4
     port map (
      CI => \counter1_carry__0_n_0\,
      CO(3) => \counter1_carry__1_n_0\,
      CO(2) => \counter1_carry__1_n_1\,
      CO(1) => \counter1_carry__1_n_2\,
      CO(0) => \counter1_carry__1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => \NLW_counter1_carry__1_O_UNCONNECTED\(3 downto 0),
      S(3) => \counter1_carry__1_i_1__1_n_0\,
      S(2) => \counter1_carry__1_i_2__1_n_0\,
      S(1) => \counter1_carry__1_i_3__1_n_0\,
      S(0) => \counter1_carry__1_i_4__1_n_0\
    );
\counter1_carry__1_i_1__1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => counter_reg(28),
      I1 => counter_reg(29),
      O => \counter1_carry__1_i_1__1_n_0\
    );
\counter1_carry__1_i_2__1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => counter_reg(26),
      I1 => counter_reg(27),
      O => \counter1_carry__1_i_2__1_n_0\
    );
\counter1_carry__1_i_3__1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => counter_reg(24),
      I1 => counter_reg(25),
      O => \counter1_carry__1_i_3__1_n_0\
    );
\counter1_carry__1_i_4__1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => counter_reg(22),
      I1 => counter_reg(23),
      O => \counter1_carry__1_i_4__1_n_0\
    );
\counter1_carry__2\: unisim.vcomponents.CARRY4
     port map (
      CI => \counter1_carry__1_n_0\,
      CO(3 downto 1) => \NLW_counter1_carry__2_CO_UNCONNECTED\(3 downto 1),
      CO(0) => \counter1_carry__2_n_3\,
      CYINIT => '0',
      DI(3 downto 1) => B"000",
      DI(0) => counter_reg(31),
      O(3 downto 0) => \NLW_counter1_carry__2_O_UNCONNECTED\(3 downto 0),
      S(3 downto 1) => B"000",
      S(0) => \counter1_carry__2_i_1__1_n_0\
    );
\counter1_carry__2_i_1__1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => counter_reg(31),
      I1 => counter_reg(30),
      O => \counter1_carry__2_i_1__1_n_0\
    );
\counter1_carry_i_1__1\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => counter_reg(9),
      O => \counter1_carry_i_1__1_n_0\
    );
\counter1_carry_i_2__1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => counter_reg(6),
      I1 => counter_reg(7),
      O => \counter1_carry_i_2__1_n_0\
    );
\counter1_carry_i_3__1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => counter_reg(12),
      I1 => counter_reg(13),
      O => \counter1_carry_i_3__1_n_0\
    );
\counter1_carry_i_4__1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => counter_reg(10),
      I1 => counter_reg(11),
      O => \counter1_carry_i_4__1_n_0\
    );
\counter1_carry_i_5__1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => counter_reg(9),
      I1 => counter_reg(8),
      O => \counter1_carry_i_5__1_n_0\
    );
\counter1_carry_i_6__1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => counter_reg(6),
      I1 => counter_reg(7),
      O => \counter1_carry_i_6__1_n_0\
    );
\counter[0]_i_1__2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"7"
    )
        port map (
      I0 => button_up,
      I1 => CO(0),
      O => \counter_reg[31]_0\
    );
\counter[0]_i_1__5\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => i_button_up,
      O => counter
    );
\counter[0]_i_3__1\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => counter_reg(0),
      O => \counter[0]_i_3__1_n_0\
    );
\counter_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[0]_i_2__1_n_7\,
      Q => counter_reg(0),
      R => counter
    );
\counter_reg[0]_i_2__1\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \counter_reg[0]_i_2__1_n_0\,
      CO(2) => \counter_reg[0]_i_2__1_n_1\,
      CO(1) => \counter_reg[0]_i_2__1_n_2\,
      CO(0) => \counter_reg[0]_i_2__1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0001",
      O(3) => \counter_reg[0]_i_2__1_n_4\,
      O(2) => \counter_reg[0]_i_2__1_n_5\,
      O(1) => \counter_reg[0]_i_2__1_n_6\,
      O(0) => \counter_reg[0]_i_2__1_n_7\,
      S(3 downto 1) => counter_reg(3 downto 1),
      S(0) => \counter[0]_i_3__1_n_0\
    );
\counter_reg[10]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[8]_i_1__1_n_5\,
      Q => counter_reg(10),
      R => counter
    );
\counter_reg[11]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[8]_i_1__1_n_4\,
      Q => counter_reg(11),
      R => counter
    );
\counter_reg[12]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[12]_i_1__1_n_7\,
      Q => counter_reg(12),
      R => counter
    );
\counter_reg[12]_i_1__1\: unisim.vcomponents.CARRY4
     port map (
      CI => \counter_reg[8]_i_1__1_n_0\,
      CO(3) => \counter_reg[12]_i_1__1_n_0\,
      CO(2) => \counter_reg[12]_i_1__1_n_1\,
      CO(1) => \counter_reg[12]_i_1__1_n_2\,
      CO(0) => \counter_reg[12]_i_1__1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \counter_reg[12]_i_1__1_n_4\,
      O(2) => \counter_reg[12]_i_1__1_n_5\,
      O(1) => \counter_reg[12]_i_1__1_n_6\,
      O(0) => \counter_reg[12]_i_1__1_n_7\,
      S(3 downto 0) => counter_reg(15 downto 12)
    );
\counter_reg[13]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[12]_i_1__1_n_6\,
      Q => counter_reg(13),
      R => counter
    );
\counter_reg[14]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[12]_i_1__1_n_5\,
      Q => counter_reg(14),
      R => counter
    );
\counter_reg[15]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[12]_i_1__1_n_4\,
      Q => counter_reg(15),
      R => counter
    );
\counter_reg[16]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[16]_i_1__1_n_7\,
      Q => counter_reg(16),
      R => counter
    );
\counter_reg[16]_i_1__1\: unisim.vcomponents.CARRY4
     port map (
      CI => \counter_reg[12]_i_1__1_n_0\,
      CO(3) => \counter_reg[16]_i_1__1_n_0\,
      CO(2) => \counter_reg[16]_i_1__1_n_1\,
      CO(1) => \counter_reg[16]_i_1__1_n_2\,
      CO(0) => \counter_reg[16]_i_1__1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \counter_reg[16]_i_1__1_n_4\,
      O(2) => \counter_reg[16]_i_1__1_n_5\,
      O(1) => \counter_reg[16]_i_1__1_n_6\,
      O(0) => \counter_reg[16]_i_1__1_n_7\,
      S(3 downto 0) => counter_reg(19 downto 16)
    );
\counter_reg[17]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[16]_i_1__1_n_6\,
      Q => counter_reg(17),
      R => counter
    );
\counter_reg[18]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[16]_i_1__1_n_5\,
      Q => counter_reg(18),
      R => counter
    );
\counter_reg[19]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[16]_i_1__1_n_4\,
      Q => counter_reg(19),
      R => counter
    );
\counter_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[0]_i_2__1_n_6\,
      Q => counter_reg(1),
      R => counter
    );
\counter_reg[20]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[20]_i_1__1_n_7\,
      Q => counter_reg(20),
      R => counter
    );
\counter_reg[20]_i_1__1\: unisim.vcomponents.CARRY4
     port map (
      CI => \counter_reg[16]_i_1__1_n_0\,
      CO(3) => \counter_reg[20]_i_1__1_n_0\,
      CO(2) => \counter_reg[20]_i_1__1_n_1\,
      CO(1) => \counter_reg[20]_i_1__1_n_2\,
      CO(0) => \counter_reg[20]_i_1__1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \counter_reg[20]_i_1__1_n_4\,
      O(2) => \counter_reg[20]_i_1__1_n_5\,
      O(1) => \counter_reg[20]_i_1__1_n_6\,
      O(0) => \counter_reg[20]_i_1__1_n_7\,
      S(3 downto 0) => counter_reg(23 downto 20)
    );
\counter_reg[21]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[20]_i_1__1_n_6\,
      Q => counter_reg(21),
      R => counter
    );
\counter_reg[22]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[20]_i_1__1_n_5\,
      Q => counter_reg(22),
      R => counter
    );
\counter_reg[23]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[20]_i_1__1_n_4\,
      Q => counter_reg(23),
      R => counter
    );
\counter_reg[24]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[24]_i_1__1_n_7\,
      Q => counter_reg(24),
      R => counter
    );
\counter_reg[24]_i_1__1\: unisim.vcomponents.CARRY4
     port map (
      CI => \counter_reg[20]_i_1__1_n_0\,
      CO(3) => \counter_reg[24]_i_1__1_n_0\,
      CO(2) => \counter_reg[24]_i_1__1_n_1\,
      CO(1) => \counter_reg[24]_i_1__1_n_2\,
      CO(0) => \counter_reg[24]_i_1__1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \counter_reg[24]_i_1__1_n_4\,
      O(2) => \counter_reg[24]_i_1__1_n_5\,
      O(1) => \counter_reg[24]_i_1__1_n_6\,
      O(0) => \counter_reg[24]_i_1__1_n_7\,
      S(3 downto 0) => counter_reg(27 downto 24)
    );
\counter_reg[25]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[24]_i_1__1_n_6\,
      Q => counter_reg(25),
      R => counter
    );
\counter_reg[26]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[24]_i_1__1_n_5\,
      Q => counter_reg(26),
      R => counter
    );
\counter_reg[27]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[24]_i_1__1_n_4\,
      Q => counter_reg(27),
      R => counter
    );
\counter_reg[28]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[28]_i_1__1_n_7\,
      Q => counter_reg(28),
      R => counter
    );
\counter_reg[28]_i_1__1\: unisim.vcomponents.CARRY4
     port map (
      CI => \counter_reg[24]_i_1__1_n_0\,
      CO(3) => \NLW_counter_reg[28]_i_1__1_CO_UNCONNECTED\(3),
      CO(2) => \counter_reg[28]_i_1__1_n_1\,
      CO(1) => \counter_reg[28]_i_1__1_n_2\,
      CO(0) => \counter_reg[28]_i_1__1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \counter_reg[28]_i_1__1_n_4\,
      O(2) => \counter_reg[28]_i_1__1_n_5\,
      O(1) => \counter_reg[28]_i_1__1_n_6\,
      O(0) => \counter_reg[28]_i_1__1_n_7\,
      S(3 downto 0) => counter_reg(31 downto 28)
    );
\counter_reg[29]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[28]_i_1__1_n_6\,
      Q => counter_reg(29),
      R => counter
    );
\counter_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[0]_i_2__1_n_5\,
      Q => counter_reg(2),
      R => counter
    );
\counter_reg[30]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[28]_i_1__1_n_5\,
      Q => counter_reg(30),
      R => counter
    );
\counter_reg[31]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[28]_i_1__1_n_4\,
      Q => counter_reg(31),
      R => counter
    );
\counter_reg[3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[0]_i_2__1_n_4\,
      Q => counter_reg(3),
      R => counter
    );
\counter_reg[4]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[4]_i_1__1_n_7\,
      Q => counter_reg(4),
      R => counter
    );
\counter_reg[4]_i_1__1\: unisim.vcomponents.CARRY4
     port map (
      CI => \counter_reg[0]_i_2__1_n_0\,
      CO(3) => \counter_reg[4]_i_1__1_n_0\,
      CO(2) => \counter_reg[4]_i_1__1_n_1\,
      CO(1) => \counter_reg[4]_i_1__1_n_2\,
      CO(0) => \counter_reg[4]_i_1__1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \counter_reg[4]_i_1__1_n_4\,
      O(2) => \counter_reg[4]_i_1__1_n_5\,
      O(1) => \counter_reg[4]_i_1__1_n_6\,
      O(0) => \counter_reg[4]_i_1__1_n_7\,
      S(3 downto 0) => counter_reg(7 downto 4)
    );
\counter_reg[5]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[4]_i_1__1_n_6\,
      Q => counter_reg(5),
      R => counter
    );
\counter_reg[6]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[4]_i_1__1_n_5\,
      Q => counter_reg(6),
      R => counter
    );
\counter_reg[7]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[4]_i_1__1_n_4\,
      Q => counter_reg(7),
      R => counter
    );
\counter_reg[8]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[8]_i_1__1_n_7\,
      Q => counter_reg(8),
      R => counter
    );
\counter_reg[8]_i_1__1\: unisim.vcomponents.CARRY4
     port map (
      CI => \counter_reg[4]_i_1__1_n_0\,
      CO(3) => \counter_reg[8]_i_1__1_n_0\,
      CO(2) => \counter_reg[8]_i_1__1_n_1\,
      CO(1) => \counter_reg[8]_i_1__1_n_2\,
      CO(0) => \counter_reg[8]_i_1__1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \counter_reg[8]_i_1__1_n_4\,
      O(2) => \counter_reg[8]_i_1__1_n_5\,
      O(1) => \counter_reg[8]_i_1__1_n_6\,
      O(0) => \counter_reg[8]_i_1__1_n_7\,
      S(3 downto 0) => counter_reg(11 downto 8)
    );
\counter_reg[9]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[8]_i_1__1_n_6\,
      Q => counter_reg(9),
      R => counter
    );
\o_press_i_1__1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000000001"
    )
        port map (
      I0 => \o_press_i_2__1_n_0\,
      I1 => \o_press_i_3__1_n_0\,
      I2 => counter_reg(30),
      I3 => counter_reg(31),
      I4 => \o_press_i_4__1_n_0\,
      I5 => \o_press_i_5__1_n_0\,
      O => \o_press_i_1__1_n_0\
    );
\o_press_i_2__1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFFFFFE"
    )
        port map (
      I0 => counter_reg(21),
      I1 => counter_reg(20),
      I2 => counter_reg(23),
      I3 => counter_reg(22),
      I4 => \o_press_i_6__1_n_0\,
      O => \o_press_i_2__1_n_0\
    );
\o_press_i_3__1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => counter_reg(29),
      I1 => counter_reg(28),
      O => \o_press_i_3__1_n_0\
    );
\o_press_i_4__1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFFE"
    )
        port map (
      I0 => counter_reg(26),
      I1 => counter_reg(27),
      I2 => counter_reg(24),
      I3 => counter_reg(25),
      O => \o_press_i_4__1_n_0\
    );
\o_press_i_5__1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFFFFE"
    )
        port map (
      I0 => \o_press_i_7__1_n_0\,
      I1 => counter_reg(3),
      I2 => counter_reg(15),
      I3 => counter_reg(12),
      I4 => counter_reg(13),
      I5 => \o_press_i_8__1_n_0\,
      O => \o_press_i_5__1_n_0\
    );
\o_press_i_6__1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFFE"
    )
        port map (
      I0 => counter_reg(0),
      I1 => counter_reg(5),
      I2 => counter_reg(2),
      I3 => counter_reg(1),
      O => \o_press_i_6__1_n_0\
    );
\o_press_i_7__1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFFE"
    )
        port map (
      I0 => counter_reg(10),
      I1 => counter_reg(11),
      I2 => counter_reg(8),
      I3 => counter_reg(4),
      O => \o_press_i_7__1_n_0\
    );
\o_press_i_8__1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFFF7FF"
    )
        port map (
      I0 => counter_reg(6),
      I1 => counter_reg(9),
      I2 => counter_reg(7),
      I3 => counter_reg(19),
      I4 => \o_press_i_9__1_n_0\,
      O => \o_press_i_8__1_n_0\
    );
\o_press_i_9__1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"7FFF"
    )
        port map (
      I0 => counter_reg(16),
      I1 => counter_reg(14),
      I2 => counter_reg(18),
      I3 => counter_reg(17),
      O => \o_press_i_9__1_n_0\
    );
o_press_reg: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \o_press_i_1__1_n_0\,
      Q => button_up,
      R => '0'
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_pulseGen is
  port (
    \o_y_pos_reg[0]\ : out STD_LOGIC;
    CO : out STD_LOGIC_VECTOR ( 0 to 0 );
    O : out STD_LOGIC_VECTOR ( 3 downto 0 );
    \o_y_pos_reg[7]\ : out STD_LOGIC_VECTOR ( 3 downto 0 );
    \o_y_pos_reg[11]\ : out STD_LOGIC_VECTOR ( 3 downto 0 );
    \o_y_pos_reg[15]\ : out STD_LOGIC_VECTOR ( 3 downto 0 );
    s00_axi_aclk : in STD_LOGIC;
    Q : in STD_LOGIC_VECTOR ( 0 to 0 );
    \maxCountReg_reg[31]\ : in STD_LOGIC_VECTOR ( 31 downto 0 );
    posReg : in STD_LOGIC_VECTOR ( 14 downto 0 );
    DI : in STD_LOGIC_VECTOR ( 0 to 0 );
    S : in STD_LOGIC_VECTOR ( 0 to 0 );
    \maxCoordinateReg_reg[31]\ : in STD_LOGIC_VECTOR ( 13 downto 0 );
    o_press_reg : in STD_LOGIC
  );
end decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_pulseGen;

architecture STRUCTURE of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_pulseGen is
  signal \counter2_carry__0_i_1__1_n_0\ : STD_LOGIC;
  signal \counter2_carry__0_i_2__1_n_0\ : STD_LOGIC;
  signal \counter2_carry__0_i_3__1_n_0\ : STD_LOGIC;
  signal \counter2_carry__0_i_4__1_n_0\ : STD_LOGIC;
  signal \counter2_carry__0_i_5__1_n_0\ : STD_LOGIC;
  signal \counter2_carry__0_i_6__1_n_0\ : STD_LOGIC;
  signal \counter2_carry__0_i_7__1_n_0\ : STD_LOGIC;
  signal \counter2_carry__0_i_8__1_n_0\ : STD_LOGIC;
  signal \counter2_carry__0_n_0\ : STD_LOGIC;
  signal \counter2_carry__0_n_1\ : STD_LOGIC;
  signal \counter2_carry__0_n_2\ : STD_LOGIC;
  signal \counter2_carry__0_n_3\ : STD_LOGIC;
  signal \counter2_carry__1_i_1__1_n_0\ : STD_LOGIC;
  signal \counter2_carry__1_i_2__1_n_0\ : STD_LOGIC;
  signal \counter2_carry__1_i_3__1_n_0\ : STD_LOGIC;
  signal \counter2_carry__1_i_4__1_n_0\ : STD_LOGIC;
  signal \counter2_carry__1_i_5__1_n_0\ : STD_LOGIC;
  signal \counter2_carry__1_i_6__1_n_0\ : STD_LOGIC;
  signal \counter2_carry__1_i_7__1_n_0\ : STD_LOGIC;
  signal \counter2_carry__1_i_8__1_n_0\ : STD_LOGIC;
  signal \counter2_carry__1_n_0\ : STD_LOGIC;
  signal \counter2_carry__1_n_1\ : STD_LOGIC;
  signal \counter2_carry__1_n_2\ : STD_LOGIC;
  signal \counter2_carry__1_n_3\ : STD_LOGIC;
  signal \counter2_carry__2_i_1__1_n_0\ : STD_LOGIC;
  signal \counter2_carry__2_i_2__1_n_0\ : STD_LOGIC;
  signal \counter2_carry__2_i_3__1_n_0\ : STD_LOGIC;
  signal \counter2_carry__2_i_4__1_n_0\ : STD_LOGIC;
  signal \counter2_carry__2_i_5__1_n_0\ : STD_LOGIC;
  signal \counter2_carry__2_i_6__1_n_0\ : STD_LOGIC;
  signal \counter2_carry__2_i_7__1_n_0\ : STD_LOGIC;
  signal \counter2_carry__2_i_8__1_n_0\ : STD_LOGIC;
  signal \counter2_carry__2_n_1\ : STD_LOGIC;
  signal \counter2_carry__2_n_2\ : STD_LOGIC;
  signal \counter2_carry__2_n_3\ : STD_LOGIC;
  signal \counter2_carry_i_1__1_n_0\ : STD_LOGIC;
  signal \counter2_carry_i_2__1_n_0\ : STD_LOGIC;
  signal \counter2_carry_i_3__1_n_0\ : STD_LOGIC;
  signal \counter2_carry_i_4__1_n_0\ : STD_LOGIC;
  signal \counter2_carry_i_5__1_n_0\ : STD_LOGIC;
  signal \counter2_carry_i_6__1_n_0\ : STD_LOGIC;
  signal \counter2_carry_i_7__1_n_0\ : STD_LOGIC;
  signal \counter2_carry_i_8__1_n_0\ : STD_LOGIC;
  signal counter2_carry_n_0 : STD_LOGIC;
  signal counter2_carry_n_1 : STD_LOGIC;
  signal counter2_carry_n_2 : STD_LOGIC;
  signal counter2_carry_n_3 : STD_LOGIC;
  signal \counter[0]_i_3__4_n_0\ : STD_LOGIC;
  signal counter_reg : STD_LOGIC_VECTOR ( 31 downto 0 );
  signal \counter_reg[0]_i_2__5_n_0\ : STD_LOGIC;
  signal \counter_reg[0]_i_2__5_n_1\ : STD_LOGIC;
  signal \counter_reg[0]_i_2__5_n_2\ : STD_LOGIC;
  signal \counter_reg[0]_i_2__5_n_3\ : STD_LOGIC;
  signal \counter_reg[0]_i_2__5_n_4\ : STD_LOGIC;
  signal \counter_reg[0]_i_2__5_n_5\ : STD_LOGIC;
  signal \counter_reg[0]_i_2__5_n_6\ : STD_LOGIC;
  signal \counter_reg[0]_i_2__5_n_7\ : STD_LOGIC;
  signal \counter_reg[12]_i_1__5_n_0\ : STD_LOGIC;
  signal \counter_reg[12]_i_1__5_n_1\ : STD_LOGIC;
  signal \counter_reg[12]_i_1__5_n_2\ : STD_LOGIC;
  signal \counter_reg[12]_i_1__5_n_3\ : STD_LOGIC;
  signal \counter_reg[12]_i_1__5_n_4\ : STD_LOGIC;
  signal \counter_reg[12]_i_1__5_n_5\ : STD_LOGIC;
  signal \counter_reg[12]_i_1__5_n_6\ : STD_LOGIC;
  signal \counter_reg[12]_i_1__5_n_7\ : STD_LOGIC;
  signal \counter_reg[16]_i_1__5_n_0\ : STD_LOGIC;
  signal \counter_reg[16]_i_1__5_n_1\ : STD_LOGIC;
  signal \counter_reg[16]_i_1__5_n_2\ : STD_LOGIC;
  signal \counter_reg[16]_i_1__5_n_3\ : STD_LOGIC;
  signal \counter_reg[16]_i_1__5_n_4\ : STD_LOGIC;
  signal \counter_reg[16]_i_1__5_n_5\ : STD_LOGIC;
  signal \counter_reg[16]_i_1__5_n_6\ : STD_LOGIC;
  signal \counter_reg[16]_i_1__5_n_7\ : STD_LOGIC;
  signal \counter_reg[20]_i_1__5_n_0\ : STD_LOGIC;
  signal \counter_reg[20]_i_1__5_n_1\ : STD_LOGIC;
  signal \counter_reg[20]_i_1__5_n_2\ : STD_LOGIC;
  signal \counter_reg[20]_i_1__5_n_3\ : STD_LOGIC;
  signal \counter_reg[20]_i_1__5_n_4\ : STD_LOGIC;
  signal \counter_reg[20]_i_1__5_n_5\ : STD_LOGIC;
  signal \counter_reg[20]_i_1__5_n_6\ : STD_LOGIC;
  signal \counter_reg[20]_i_1__5_n_7\ : STD_LOGIC;
  signal \counter_reg[24]_i_1__5_n_0\ : STD_LOGIC;
  signal \counter_reg[24]_i_1__5_n_1\ : STD_LOGIC;
  signal \counter_reg[24]_i_1__5_n_2\ : STD_LOGIC;
  signal \counter_reg[24]_i_1__5_n_3\ : STD_LOGIC;
  signal \counter_reg[24]_i_1__5_n_4\ : STD_LOGIC;
  signal \counter_reg[24]_i_1__5_n_5\ : STD_LOGIC;
  signal \counter_reg[24]_i_1__5_n_6\ : STD_LOGIC;
  signal \counter_reg[24]_i_1__5_n_7\ : STD_LOGIC;
  signal \counter_reg[28]_i_1__5_n_1\ : STD_LOGIC;
  signal \counter_reg[28]_i_1__5_n_2\ : STD_LOGIC;
  signal \counter_reg[28]_i_1__5_n_3\ : STD_LOGIC;
  signal \counter_reg[28]_i_1__5_n_4\ : STD_LOGIC;
  signal \counter_reg[28]_i_1__5_n_5\ : STD_LOGIC;
  signal \counter_reg[28]_i_1__5_n_6\ : STD_LOGIC;
  signal \counter_reg[28]_i_1__5_n_7\ : STD_LOGIC;
  signal \counter_reg[4]_i_1__5_n_0\ : STD_LOGIC;
  signal \counter_reg[4]_i_1__5_n_1\ : STD_LOGIC;
  signal \counter_reg[4]_i_1__5_n_2\ : STD_LOGIC;
  signal \counter_reg[4]_i_1__5_n_3\ : STD_LOGIC;
  signal \counter_reg[4]_i_1__5_n_4\ : STD_LOGIC;
  signal \counter_reg[4]_i_1__5_n_5\ : STD_LOGIC;
  signal \counter_reg[4]_i_1__5_n_6\ : STD_LOGIC;
  signal \counter_reg[4]_i_1__5_n_7\ : STD_LOGIC;
  signal \counter_reg[8]_i_1__5_n_0\ : STD_LOGIC;
  signal \counter_reg[8]_i_1__5_n_1\ : STD_LOGIC;
  signal \counter_reg[8]_i_1__5_n_2\ : STD_LOGIC;
  signal \counter_reg[8]_i_1__5_n_3\ : STD_LOGIC;
  signal \counter_reg[8]_i_1__5_n_4\ : STD_LOGIC;
  signal \counter_reg[8]_i_1__5_n_5\ : STD_LOGIC;
  signal \counter_reg[8]_i_1__5_n_6\ : STD_LOGIC;
  signal \counter_reg[8]_i_1__5_n_7\ : STD_LOGIC;
  signal \o_pulse0_carry__0_i_1__1_n_0\ : STD_LOGIC;
  signal \o_pulse0_carry__0_i_2__1_n_0\ : STD_LOGIC;
  signal \o_pulse0_carry__0_i_3__1_n_0\ : STD_LOGIC;
  signal \o_pulse0_carry__0_i_4__1_n_0\ : STD_LOGIC;
  signal \o_pulse0_carry__0_n_0\ : STD_LOGIC;
  signal \o_pulse0_carry__0_n_1\ : STD_LOGIC;
  signal \o_pulse0_carry__0_n_2\ : STD_LOGIC;
  signal \o_pulse0_carry__0_n_3\ : STD_LOGIC;
  signal \o_pulse0_carry__1_i_1__1_n_0\ : STD_LOGIC;
  signal \o_pulse0_carry__1_i_2__1_n_0\ : STD_LOGIC;
  signal \o_pulse0_carry__1_i_3__1_n_0\ : STD_LOGIC;
  signal \o_pulse0_carry__1_n_1\ : STD_LOGIC;
  signal \o_pulse0_carry__1_n_2\ : STD_LOGIC;
  signal \o_pulse0_carry__1_n_3\ : STD_LOGIC;
  signal \o_pulse0_carry_i_1__1_n_0\ : STD_LOGIC;
  signal \o_pulse0_carry_i_2__1_n_0\ : STD_LOGIC;
  signal \o_pulse0_carry_i_3__1_n_0\ : STD_LOGIC;
  signal \o_pulse0_carry_i_4__1_n_0\ : STD_LOGIC;
  signal o_pulse0_carry_n_0 : STD_LOGIC;
  signal o_pulse0_carry_n_1 : STD_LOGIC;
  signal o_pulse0_carry_n_2 : STD_LOGIC;
  signal o_pulse0_carry_n_3 : STD_LOGIC;
  signal \o_y_pos[0]_i_3_n_0\ : STD_LOGIC;
  signal \o_y_pos[0]_i_4_n_0\ : STD_LOGIC;
  signal \o_y_pos[0]_i_5_n_0\ : STD_LOGIC;
  signal \o_y_pos[0]_i_7_n_0\ : STD_LOGIC;
  signal \o_y_pos[0]_i_8_n_0\ : STD_LOGIC;
  signal \o_y_pos[0]_i_9_n_0\ : STD_LOGIC;
  signal \o_y_pos[12]_i_2_n_0\ : STD_LOGIC;
  signal \o_y_pos[12]_i_3_n_0\ : STD_LOGIC;
  signal \o_y_pos[12]_i_4_n_0\ : STD_LOGIC;
  signal \o_y_pos[12]_i_5_n_0\ : STD_LOGIC;
  signal \o_y_pos[12]_i_6_n_0\ : STD_LOGIC;
  signal \o_y_pos[12]_i_7_n_0\ : STD_LOGIC;
  signal \o_y_pos[12]_i_8_n_0\ : STD_LOGIC;
  signal \o_y_pos[4]_i_2_n_0\ : STD_LOGIC;
  signal \o_y_pos[4]_i_3_n_0\ : STD_LOGIC;
  signal \o_y_pos[4]_i_4_n_0\ : STD_LOGIC;
  signal \o_y_pos[4]_i_5_n_0\ : STD_LOGIC;
  signal \o_y_pos[4]_i_6_n_0\ : STD_LOGIC;
  signal \o_y_pos[4]_i_7_n_0\ : STD_LOGIC;
  signal \o_y_pos[4]_i_8_n_0\ : STD_LOGIC;
  signal \o_y_pos[4]_i_9_n_0\ : STD_LOGIC;
  signal \o_y_pos[8]_i_2_n_0\ : STD_LOGIC;
  signal \o_y_pos[8]_i_3_n_0\ : STD_LOGIC;
  signal \o_y_pos[8]_i_4_n_0\ : STD_LOGIC;
  signal \o_y_pos[8]_i_5_n_0\ : STD_LOGIC;
  signal \o_y_pos[8]_i_6_n_0\ : STD_LOGIC;
  signal \o_y_pos[8]_i_7_n_0\ : STD_LOGIC;
  signal \o_y_pos[8]_i_8_n_0\ : STD_LOGIC;
  signal \o_y_pos[8]_i_9_n_0\ : STD_LOGIC;
  signal \^o_y_pos_reg[0]\ : STD_LOGIC;
  signal \o_y_pos_reg[0]_i_2_n_0\ : STD_LOGIC;
  signal \o_y_pos_reg[0]_i_2_n_1\ : STD_LOGIC;
  signal \o_y_pos_reg[0]_i_2_n_2\ : STD_LOGIC;
  signal \o_y_pos_reg[0]_i_2_n_3\ : STD_LOGIC;
  signal \o_y_pos_reg[12]_i_1_n_1\ : STD_LOGIC;
  signal \o_y_pos_reg[12]_i_1_n_2\ : STD_LOGIC;
  signal \o_y_pos_reg[12]_i_1_n_3\ : STD_LOGIC;
  signal \o_y_pos_reg[4]_i_1_n_0\ : STD_LOGIC;
  signal \o_y_pos_reg[4]_i_1_n_1\ : STD_LOGIC;
  signal \o_y_pos_reg[4]_i_1_n_2\ : STD_LOGIC;
  signal \o_y_pos_reg[4]_i_1_n_3\ : STD_LOGIC;
  signal \o_y_pos_reg[8]_i_1_n_0\ : STD_LOGIC;
  signal \o_y_pos_reg[8]_i_1_n_1\ : STD_LOGIC;
  signal \o_y_pos_reg[8]_i_1_n_2\ : STD_LOGIC;
  signal \o_y_pos_reg[8]_i_1_n_3\ : STD_LOGIC;
  signal NLW_counter2_carry_O_UNCONNECTED : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_counter2_carry__0_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_counter2_carry__1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_counter2_carry__2_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_counter_reg[28]_i_1__5_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal NLW_o_pulse0_carry_O_UNCONNECTED : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_o_pulse0_carry__0_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_o_pulse0_carry__1_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_o_pulse0_carry__1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_o_y_pos_reg[12]_i_1_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
begin
  \o_y_pos_reg[0]\ <= \^o_y_pos_reg[0]\;
counter2_carry: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => counter2_carry_n_0,
      CO(2) => counter2_carry_n_1,
      CO(1) => counter2_carry_n_2,
      CO(0) => counter2_carry_n_3,
      CYINIT => '0',
      DI(3) => \counter2_carry_i_1__1_n_0\,
      DI(2) => \counter2_carry_i_2__1_n_0\,
      DI(1) => \counter2_carry_i_3__1_n_0\,
      DI(0) => \counter2_carry_i_4__1_n_0\,
      O(3 downto 0) => NLW_counter2_carry_O_UNCONNECTED(3 downto 0),
      S(3) => \counter2_carry_i_5__1_n_0\,
      S(2) => \counter2_carry_i_6__1_n_0\,
      S(1) => \counter2_carry_i_7__1_n_0\,
      S(0) => \counter2_carry_i_8__1_n_0\
    );
\counter2_carry__0\: unisim.vcomponents.CARRY4
     port map (
      CI => counter2_carry_n_0,
      CO(3) => \counter2_carry__0_n_0\,
      CO(2) => \counter2_carry__0_n_1\,
      CO(1) => \counter2_carry__0_n_2\,
      CO(0) => \counter2_carry__0_n_3\,
      CYINIT => '0',
      DI(3) => \counter2_carry__0_i_1__1_n_0\,
      DI(2) => \counter2_carry__0_i_2__1_n_0\,
      DI(1) => \counter2_carry__0_i_3__1_n_0\,
      DI(0) => \counter2_carry__0_i_4__1_n_0\,
      O(3 downto 0) => \NLW_counter2_carry__0_O_UNCONNECTED\(3 downto 0),
      S(3) => \counter2_carry__0_i_5__1_n_0\,
      S(2) => \counter2_carry__0_i_6__1_n_0\,
      S(1) => \counter2_carry__0_i_7__1_n_0\,
      S(0) => \counter2_carry__0_i_8__1_n_0\
    );
\counter2_carry__0_i_1__1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"2F02"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(14),
      I1 => counter_reg(14),
      I2 => counter_reg(15),
      I3 => \maxCountReg_reg[31]\(15),
      O => \counter2_carry__0_i_1__1_n_0\
    );
\counter2_carry__0_i_2__1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"2F02"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(12),
      I1 => counter_reg(12),
      I2 => counter_reg(13),
      I3 => \maxCountReg_reg[31]\(13),
      O => \counter2_carry__0_i_2__1_n_0\
    );
\counter2_carry__0_i_3__1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"2F02"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(10),
      I1 => counter_reg(10),
      I2 => counter_reg(11),
      I3 => \maxCountReg_reg[31]\(11),
      O => \counter2_carry__0_i_3__1_n_0\
    );
\counter2_carry__0_i_4__1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"2F02"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(8),
      I1 => counter_reg(8),
      I2 => counter_reg(9),
      I3 => \maxCountReg_reg[31]\(9),
      O => \counter2_carry__0_i_4__1_n_0\
    );
\counter2_carry__0_i_5__1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9009"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(14),
      I1 => counter_reg(14),
      I2 => \maxCountReg_reg[31]\(15),
      I3 => counter_reg(15),
      O => \counter2_carry__0_i_5__1_n_0\
    );
\counter2_carry__0_i_6__1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9009"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(12),
      I1 => counter_reg(12),
      I2 => \maxCountReg_reg[31]\(13),
      I3 => counter_reg(13),
      O => \counter2_carry__0_i_6__1_n_0\
    );
\counter2_carry__0_i_7__1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9009"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(10),
      I1 => counter_reg(10),
      I2 => \maxCountReg_reg[31]\(11),
      I3 => counter_reg(11),
      O => \counter2_carry__0_i_7__1_n_0\
    );
\counter2_carry__0_i_8__1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9009"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(8),
      I1 => counter_reg(8),
      I2 => \maxCountReg_reg[31]\(9),
      I3 => counter_reg(9),
      O => \counter2_carry__0_i_8__1_n_0\
    );
\counter2_carry__1\: unisim.vcomponents.CARRY4
     port map (
      CI => \counter2_carry__0_n_0\,
      CO(3) => \counter2_carry__1_n_0\,
      CO(2) => \counter2_carry__1_n_1\,
      CO(1) => \counter2_carry__1_n_2\,
      CO(0) => \counter2_carry__1_n_3\,
      CYINIT => '0',
      DI(3) => \counter2_carry__1_i_1__1_n_0\,
      DI(2) => \counter2_carry__1_i_2__1_n_0\,
      DI(1) => \counter2_carry__1_i_3__1_n_0\,
      DI(0) => \counter2_carry__1_i_4__1_n_0\,
      O(3 downto 0) => \NLW_counter2_carry__1_O_UNCONNECTED\(3 downto 0),
      S(3) => \counter2_carry__1_i_5__1_n_0\,
      S(2) => \counter2_carry__1_i_6__1_n_0\,
      S(1) => \counter2_carry__1_i_7__1_n_0\,
      S(0) => \counter2_carry__1_i_8__1_n_0\
    );
\counter2_carry__1_i_1__1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"2F02"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(22),
      I1 => counter_reg(22),
      I2 => counter_reg(23),
      I3 => \maxCountReg_reg[31]\(23),
      O => \counter2_carry__1_i_1__1_n_0\
    );
\counter2_carry__1_i_2__1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"2F02"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(20),
      I1 => counter_reg(20),
      I2 => counter_reg(21),
      I3 => \maxCountReg_reg[31]\(21),
      O => \counter2_carry__1_i_2__1_n_0\
    );
\counter2_carry__1_i_3__1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"2F02"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(18),
      I1 => counter_reg(18),
      I2 => counter_reg(19),
      I3 => \maxCountReg_reg[31]\(19),
      O => \counter2_carry__1_i_3__1_n_0\
    );
\counter2_carry__1_i_4__1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"2F02"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(16),
      I1 => counter_reg(16),
      I2 => counter_reg(17),
      I3 => \maxCountReg_reg[31]\(17),
      O => \counter2_carry__1_i_4__1_n_0\
    );
\counter2_carry__1_i_5__1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9009"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(22),
      I1 => counter_reg(22),
      I2 => \maxCountReg_reg[31]\(23),
      I3 => counter_reg(23),
      O => \counter2_carry__1_i_5__1_n_0\
    );
\counter2_carry__1_i_6__1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9009"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(20),
      I1 => counter_reg(20),
      I2 => \maxCountReg_reg[31]\(21),
      I3 => counter_reg(21),
      O => \counter2_carry__1_i_6__1_n_0\
    );
\counter2_carry__1_i_7__1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9009"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(18),
      I1 => counter_reg(18),
      I2 => \maxCountReg_reg[31]\(19),
      I3 => counter_reg(19),
      O => \counter2_carry__1_i_7__1_n_0\
    );
\counter2_carry__1_i_8__1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9009"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(16),
      I1 => counter_reg(16),
      I2 => \maxCountReg_reg[31]\(17),
      I3 => counter_reg(17),
      O => \counter2_carry__1_i_8__1_n_0\
    );
\counter2_carry__2\: unisim.vcomponents.CARRY4
     port map (
      CI => \counter2_carry__1_n_0\,
      CO(3) => CO(0),
      CO(2) => \counter2_carry__2_n_1\,
      CO(1) => \counter2_carry__2_n_2\,
      CO(0) => \counter2_carry__2_n_3\,
      CYINIT => '0',
      DI(3) => \counter2_carry__2_i_1__1_n_0\,
      DI(2) => \counter2_carry__2_i_2__1_n_0\,
      DI(1) => \counter2_carry__2_i_3__1_n_0\,
      DI(0) => \counter2_carry__2_i_4__1_n_0\,
      O(3 downto 0) => \NLW_counter2_carry__2_O_UNCONNECTED\(3 downto 0),
      S(3) => \counter2_carry__2_i_5__1_n_0\,
      S(2) => \counter2_carry__2_i_6__1_n_0\,
      S(1) => \counter2_carry__2_i_7__1_n_0\,
      S(0) => \counter2_carry__2_i_8__1_n_0\
    );
\counter2_carry__2_i_1__1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"2F02"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(30),
      I1 => counter_reg(30),
      I2 => counter_reg(31),
      I3 => \maxCountReg_reg[31]\(31),
      O => \counter2_carry__2_i_1__1_n_0\
    );
\counter2_carry__2_i_2__1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"2F02"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(28),
      I1 => counter_reg(28),
      I2 => counter_reg(29),
      I3 => \maxCountReg_reg[31]\(29),
      O => \counter2_carry__2_i_2__1_n_0\
    );
\counter2_carry__2_i_3__1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"2F02"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(26),
      I1 => counter_reg(26),
      I2 => counter_reg(27),
      I3 => \maxCountReg_reg[31]\(27),
      O => \counter2_carry__2_i_3__1_n_0\
    );
\counter2_carry__2_i_4__1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"2F02"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(24),
      I1 => counter_reg(24),
      I2 => counter_reg(25),
      I3 => \maxCountReg_reg[31]\(25),
      O => \counter2_carry__2_i_4__1_n_0\
    );
\counter2_carry__2_i_5__1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9009"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(30),
      I1 => counter_reg(30),
      I2 => \maxCountReg_reg[31]\(31),
      I3 => counter_reg(31),
      O => \counter2_carry__2_i_5__1_n_0\
    );
\counter2_carry__2_i_6__1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9009"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(28),
      I1 => counter_reg(28),
      I2 => \maxCountReg_reg[31]\(29),
      I3 => counter_reg(29),
      O => \counter2_carry__2_i_6__1_n_0\
    );
\counter2_carry__2_i_7__1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9009"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(26),
      I1 => counter_reg(26),
      I2 => \maxCountReg_reg[31]\(27),
      I3 => counter_reg(27),
      O => \counter2_carry__2_i_7__1_n_0\
    );
\counter2_carry__2_i_8__1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9009"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(24),
      I1 => counter_reg(24),
      I2 => \maxCountReg_reg[31]\(25),
      I3 => counter_reg(25),
      O => \counter2_carry__2_i_8__1_n_0\
    );
\counter2_carry_i_1__1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"2F02"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(6),
      I1 => counter_reg(6),
      I2 => counter_reg(7),
      I3 => \maxCountReg_reg[31]\(7),
      O => \counter2_carry_i_1__1_n_0\
    );
\counter2_carry_i_2__1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"2F02"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(4),
      I1 => counter_reg(4),
      I2 => counter_reg(5),
      I3 => \maxCountReg_reg[31]\(5),
      O => \counter2_carry_i_2__1_n_0\
    );
\counter2_carry_i_3__1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"2F02"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(2),
      I1 => counter_reg(2),
      I2 => counter_reg(3),
      I3 => \maxCountReg_reg[31]\(3),
      O => \counter2_carry_i_3__1_n_0\
    );
\counter2_carry_i_4__1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"2F02"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(0),
      I1 => counter_reg(0),
      I2 => counter_reg(1),
      I3 => \maxCountReg_reg[31]\(1),
      O => \counter2_carry_i_4__1_n_0\
    );
\counter2_carry_i_5__1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9009"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(6),
      I1 => counter_reg(6),
      I2 => \maxCountReg_reg[31]\(7),
      I3 => counter_reg(7),
      O => \counter2_carry_i_5__1_n_0\
    );
\counter2_carry_i_6__1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9009"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(4),
      I1 => counter_reg(4),
      I2 => \maxCountReg_reg[31]\(5),
      I3 => counter_reg(5),
      O => \counter2_carry_i_6__1_n_0\
    );
\counter2_carry_i_7__1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9009"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(2),
      I1 => counter_reg(2),
      I2 => \maxCountReg_reg[31]\(3),
      I3 => counter_reg(3),
      O => \counter2_carry_i_7__1_n_0\
    );
\counter2_carry_i_8__1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9009"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(0),
      I1 => counter_reg(0),
      I2 => \maxCountReg_reg[31]\(1),
      I3 => counter_reg(1),
      O => \counter2_carry_i_8__1_n_0\
    );
\counter[0]_i_3__4\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => counter_reg(0),
      O => \counter[0]_i_3__4_n_0\
    );
\counter_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[0]_i_2__5_n_7\,
      Q => counter_reg(0),
      R => o_press_reg
    );
\counter_reg[0]_i_2__5\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \counter_reg[0]_i_2__5_n_0\,
      CO(2) => \counter_reg[0]_i_2__5_n_1\,
      CO(1) => \counter_reg[0]_i_2__5_n_2\,
      CO(0) => \counter_reg[0]_i_2__5_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0001",
      O(3) => \counter_reg[0]_i_2__5_n_4\,
      O(2) => \counter_reg[0]_i_2__5_n_5\,
      O(1) => \counter_reg[0]_i_2__5_n_6\,
      O(0) => \counter_reg[0]_i_2__5_n_7\,
      S(3 downto 1) => counter_reg(3 downto 1),
      S(0) => \counter[0]_i_3__4_n_0\
    );
\counter_reg[10]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[8]_i_1__5_n_5\,
      Q => counter_reg(10),
      R => o_press_reg
    );
\counter_reg[11]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[8]_i_1__5_n_4\,
      Q => counter_reg(11),
      R => o_press_reg
    );
\counter_reg[12]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[12]_i_1__5_n_7\,
      Q => counter_reg(12),
      R => o_press_reg
    );
\counter_reg[12]_i_1__5\: unisim.vcomponents.CARRY4
     port map (
      CI => \counter_reg[8]_i_1__5_n_0\,
      CO(3) => \counter_reg[12]_i_1__5_n_0\,
      CO(2) => \counter_reg[12]_i_1__5_n_1\,
      CO(1) => \counter_reg[12]_i_1__5_n_2\,
      CO(0) => \counter_reg[12]_i_1__5_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \counter_reg[12]_i_1__5_n_4\,
      O(2) => \counter_reg[12]_i_1__5_n_5\,
      O(1) => \counter_reg[12]_i_1__5_n_6\,
      O(0) => \counter_reg[12]_i_1__5_n_7\,
      S(3 downto 0) => counter_reg(15 downto 12)
    );
\counter_reg[13]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[12]_i_1__5_n_6\,
      Q => counter_reg(13),
      R => o_press_reg
    );
\counter_reg[14]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[12]_i_1__5_n_5\,
      Q => counter_reg(14),
      R => o_press_reg
    );
\counter_reg[15]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[12]_i_1__5_n_4\,
      Q => counter_reg(15),
      R => o_press_reg
    );
\counter_reg[16]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[16]_i_1__5_n_7\,
      Q => counter_reg(16),
      R => o_press_reg
    );
\counter_reg[16]_i_1__5\: unisim.vcomponents.CARRY4
     port map (
      CI => \counter_reg[12]_i_1__5_n_0\,
      CO(3) => \counter_reg[16]_i_1__5_n_0\,
      CO(2) => \counter_reg[16]_i_1__5_n_1\,
      CO(1) => \counter_reg[16]_i_1__5_n_2\,
      CO(0) => \counter_reg[16]_i_1__5_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \counter_reg[16]_i_1__5_n_4\,
      O(2) => \counter_reg[16]_i_1__5_n_5\,
      O(1) => \counter_reg[16]_i_1__5_n_6\,
      O(0) => \counter_reg[16]_i_1__5_n_7\,
      S(3 downto 0) => counter_reg(19 downto 16)
    );
\counter_reg[17]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[16]_i_1__5_n_6\,
      Q => counter_reg(17),
      R => o_press_reg
    );
\counter_reg[18]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[16]_i_1__5_n_5\,
      Q => counter_reg(18),
      R => o_press_reg
    );
\counter_reg[19]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[16]_i_1__5_n_4\,
      Q => counter_reg(19),
      R => o_press_reg
    );
\counter_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[0]_i_2__5_n_6\,
      Q => counter_reg(1),
      R => o_press_reg
    );
\counter_reg[20]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[20]_i_1__5_n_7\,
      Q => counter_reg(20),
      R => o_press_reg
    );
\counter_reg[20]_i_1__5\: unisim.vcomponents.CARRY4
     port map (
      CI => \counter_reg[16]_i_1__5_n_0\,
      CO(3) => \counter_reg[20]_i_1__5_n_0\,
      CO(2) => \counter_reg[20]_i_1__5_n_1\,
      CO(1) => \counter_reg[20]_i_1__5_n_2\,
      CO(0) => \counter_reg[20]_i_1__5_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \counter_reg[20]_i_1__5_n_4\,
      O(2) => \counter_reg[20]_i_1__5_n_5\,
      O(1) => \counter_reg[20]_i_1__5_n_6\,
      O(0) => \counter_reg[20]_i_1__5_n_7\,
      S(3 downto 0) => counter_reg(23 downto 20)
    );
\counter_reg[21]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[20]_i_1__5_n_6\,
      Q => counter_reg(21),
      R => o_press_reg
    );
\counter_reg[22]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[20]_i_1__5_n_5\,
      Q => counter_reg(22),
      R => o_press_reg
    );
\counter_reg[23]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[20]_i_1__5_n_4\,
      Q => counter_reg(23),
      R => o_press_reg
    );
\counter_reg[24]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[24]_i_1__5_n_7\,
      Q => counter_reg(24),
      R => o_press_reg
    );
\counter_reg[24]_i_1__5\: unisim.vcomponents.CARRY4
     port map (
      CI => \counter_reg[20]_i_1__5_n_0\,
      CO(3) => \counter_reg[24]_i_1__5_n_0\,
      CO(2) => \counter_reg[24]_i_1__5_n_1\,
      CO(1) => \counter_reg[24]_i_1__5_n_2\,
      CO(0) => \counter_reg[24]_i_1__5_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \counter_reg[24]_i_1__5_n_4\,
      O(2) => \counter_reg[24]_i_1__5_n_5\,
      O(1) => \counter_reg[24]_i_1__5_n_6\,
      O(0) => \counter_reg[24]_i_1__5_n_7\,
      S(3 downto 0) => counter_reg(27 downto 24)
    );
\counter_reg[25]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[24]_i_1__5_n_6\,
      Q => counter_reg(25),
      R => o_press_reg
    );
\counter_reg[26]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[24]_i_1__5_n_5\,
      Q => counter_reg(26),
      R => o_press_reg
    );
\counter_reg[27]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[24]_i_1__5_n_4\,
      Q => counter_reg(27),
      R => o_press_reg
    );
\counter_reg[28]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[28]_i_1__5_n_7\,
      Q => counter_reg(28),
      R => o_press_reg
    );
\counter_reg[28]_i_1__5\: unisim.vcomponents.CARRY4
     port map (
      CI => \counter_reg[24]_i_1__5_n_0\,
      CO(3) => \NLW_counter_reg[28]_i_1__5_CO_UNCONNECTED\(3),
      CO(2) => \counter_reg[28]_i_1__5_n_1\,
      CO(1) => \counter_reg[28]_i_1__5_n_2\,
      CO(0) => \counter_reg[28]_i_1__5_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \counter_reg[28]_i_1__5_n_4\,
      O(2) => \counter_reg[28]_i_1__5_n_5\,
      O(1) => \counter_reg[28]_i_1__5_n_6\,
      O(0) => \counter_reg[28]_i_1__5_n_7\,
      S(3 downto 0) => counter_reg(31 downto 28)
    );
\counter_reg[29]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[28]_i_1__5_n_6\,
      Q => counter_reg(29),
      R => o_press_reg
    );
\counter_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[0]_i_2__5_n_5\,
      Q => counter_reg(2),
      R => o_press_reg
    );
\counter_reg[30]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[28]_i_1__5_n_5\,
      Q => counter_reg(30),
      R => o_press_reg
    );
\counter_reg[31]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[28]_i_1__5_n_4\,
      Q => counter_reg(31),
      R => o_press_reg
    );
\counter_reg[3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[0]_i_2__5_n_4\,
      Q => counter_reg(3),
      R => o_press_reg
    );
\counter_reg[4]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[4]_i_1__5_n_7\,
      Q => counter_reg(4),
      R => o_press_reg
    );
\counter_reg[4]_i_1__5\: unisim.vcomponents.CARRY4
     port map (
      CI => \counter_reg[0]_i_2__5_n_0\,
      CO(3) => \counter_reg[4]_i_1__5_n_0\,
      CO(2) => \counter_reg[4]_i_1__5_n_1\,
      CO(1) => \counter_reg[4]_i_1__5_n_2\,
      CO(0) => \counter_reg[4]_i_1__5_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \counter_reg[4]_i_1__5_n_4\,
      O(2) => \counter_reg[4]_i_1__5_n_5\,
      O(1) => \counter_reg[4]_i_1__5_n_6\,
      O(0) => \counter_reg[4]_i_1__5_n_7\,
      S(3 downto 0) => counter_reg(7 downto 4)
    );
\counter_reg[5]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[4]_i_1__5_n_6\,
      Q => counter_reg(5),
      R => o_press_reg
    );
\counter_reg[6]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[4]_i_1__5_n_5\,
      Q => counter_reg(6),
      R => o_press_reg
    );
\counter_reg[7]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[4]_i_1__5_n_4\,
      Q => counter_reg(7),
      R => o_press_reg
    );
\counter_reg[8]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[8]_i_1__5_n_7\,
      Q => counter_reg(8),
      R => o_press_reg
    );
\counter_reg[8]_i_1__5\: unisim.vcomponents.CARRY4
     port map (
      CI => \counter_reg[4]_i_1__5_n_0\,
      CO(3) => \counter_reg[8]_i_1__5_n_0\,
      CO(2) => \counter_reg[8]_i_1__5_n_1\,
      CO(1) => \counter_reg[8]_i_1__5_n_2\,
      CO(0) => \counter_reg[8]_i_1__5_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \counter_reg[8]_i_1__5_n_4\,
      O(2) => \counter_reg[8]_i_1__5_n_5\,
      O(1) => \counter_reg[8]_i_1__5_n_6\,
      O(0) => \counter_reg[8]_i_1__5_n_7\,
      S(3 downto 0) => counter_reg(11 downto 8)
    );
\counter_reg[9]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[8]_i_1__5_n_6\,
      Q => counter_reg(9),
      R => o_press_reg
    );
o_pulse0_carry: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => o_pulse0_carry_n_0,
      CO(2) => o_pulse0_carry_n_1,
      CO(1) => o_pulse0_carry_n_2,
      CO(0) => o_pulse0_carry_n_3,
      CYINIT => '1',
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => NLW_o_pulse0_carry_O_UNCONNECTED(3 downto 0),
      S(3) => \o_pulse0_carry_i_1__1_n_0\,
      S(2) => \o_pulse0_carry_i_2__1_n_0\,
      S(1) => \o_pulse0_carry_i_3__1_n_0\,
      S(0) => \o_pulse0_carry_i_4__1_n_0\
    );
\o_pulse0_carry__0\: unisim.vcomponents.CARRY4
     port map (
      CI => o_pulse0_carry_n_0,
      CO(3) => \o_pulse0_carry__0_n_0\,
      CO(2) => \o_pulse0_carry__0_n_1\,
      CO(1) => \o_pulse0_carry__0_n_2\,
      CO(0) => \o_pulse0_carry__0_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => \NLW_o_pulse0_carry__0_O_UNCONNECTED\(3 downto 0),
      S(3) => \o_pulse0_carry__0_i_1__1_n_0\,
      S(2) => \o_pulse0_carry__0_i_2__1_n_0\,
      S(1) => \o_pulse0_carry__0_i_3__1_n_0\,
      S(0) => \o_pulse0_carry__0_i_4__1_n_0\
    );
\o_pulse0_carry__0_i_1__1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"9009000000009009"
    )
        port map (
      I0 => counter_reg(21),
      I1 => \maxCountReg_reg[31]\(21),
      I2 => \maxCountReg_reg[31]\(23),
      I3 => counter_reg(23),
      I4 => \maxCountReg_reg[31]\(22),
      I5 => counter_reg(22),
      O => \o_pulse0_carry__0_i_1__1_n_0\
    );
\o_pulse0_carry__0_i_2__1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"9009000000009009"
    )
        port map (
      I0 => counter_reg(18),
      I1 => \maxCountReg_reg[31]\(18),
      I2 => \maxCountReg_reg[31]\(20),
      I3 => counter_reg(20),
      I4 => \maxCountReg_reg[31]\(19),
      I5 => counter_reg(19),
      O => \o_pulse0_carry__0_i_2__1_n_0\
    );
\o_pulse0_carry__0_i_3__1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"9009000000009009"
    )
        port map (
      I0 => counter_reg(15),
      I1 => \maxCountReg_reg[31]\(15),
      I2 => \maxCountReg_reg[31]\(17),
      I3 => counter_reg(17),
      I4 => \maxCountReg_reg[31]\(16),
      I5 => counter_reg(16),
      O => \o_pulse0_carry__0_i_3__1_n_0\
    );
\o_pulse0_carry__0_i_4__1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"9009000000009009"
    )
        port map (
      I0 => counter_reg(12),
      I1 => \maxCountReg_reg[31]\(12),
      I2 => \maxCountReg_reg[31]\(14),
      I3 => counter_reg(14),
      I4 => \maxCountReg_reg[31]\(13),
      I5 => counter_reg(13),
      O => \o_pulse0_carry__0_i_4__1_n_0\
    );
\o_pulse0_carry__1\: unisim.vcomponents.CARRY4
     port map (
      CI => \o_pulse0_carry__0_n_0\,
      CO(3) => \NLW_o_pulse0_carry__1_CO_UNCONNECTED\(3),
      CO(2) => \o_pulse0_carry__1_n_1\,
      CO(1) => \o_pulse0_carry__1_n_2\,
      CO(0) => \o_pulse0_carry__1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => \NLW_o_pulse0_carry__1_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => \o_pulse0_carry__1_i_1__1_n_0\,
      S(1) => \o_pulse0_carry__1_i_2__1_n_0\,
      S(0) => \o_pulse0_carry__1_i_3__1_n_0\
    );
\o_pulse0_carry__1_i_1__1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9009"
    )
        port map (
      I0 => counter_reg(30),
      I1 => \maxCountReg_reg[31]\(30),
      I2 => counter_reg(31),
      I3 => \maxCountReg_reg[31]\(31),
      O => \o_pulse0_carry__1_i_1__1_n_0\
    );
\o_pulse0_carry__1_i_2__1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"9009000000009009"
    )
        port map (
      I0 => counter_reg(27),
      I1 => \maxCountReg_reg[31]\(27),
      I2 => \maxCountReg_reg[31]\(29),
      I3 => counter_reg(29),
      I4 => \maxCountReg_reg[31]\(28),
      I5 => counter_reg(28),
      O => \o_pulse0_carry__1_i_2__1_n_0\
    );
\o_pulse0_carry__1_i_3__1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"9009000000009009"
    )
        port map (
      I0 => counter_reg(24),
      I1 => \maxCountReg_reg[31]\(24),
      I2 => \maxCountReg_reg[31]\(26),
      I3 => counter_reg(26),
      I4 => \maxCountReg_reg[31]\(25),
      I5 => counter_reg(25),
      O => \o_pulse0_carry__1_i_3__1_n_0\
    );
\o_pulse0_carry_i_1__1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"9009000000009009"
    )
        port map (
      I0 => counter_reg(9),
      I1 => \maxCountReg_reg[31]\(9),
      I2 => \maxCountReg_reg[31]\(11),
      I3 => counter_reg(11),
      I4 => \maxCountReg_reg[31]\(10),
      I5 => counter_reg(10),
      O => \o_pulse0_carry_i_1__1_n_0\
    );
\o_pulse0_carry_i_2__1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"9009000000009009"
    )
        port map (
      I0 => counter_reg(6),
      I1 => \maxCountReg_reg[31]\(6),
      I2 => \maxCountReg_reg[31]\(8),
      I3 => counter_reg(8),
      I4 => \maxCountReg_reg[31]\(7),
      I5 => counter_reg(7),
      O => \o_pulse0_carry_i_2__1_n_0\
    );
\o_pulse0_carry_i_3__1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"9009000000009009"
    )
        port map (
      I0 => counter_reg(3),
      I1 => \maxCountReg_reg[31]\(3),
      I2 => \maxCountReg_reg[31]\(5),
      I3 => counter_reg(5),
      I4 => \maxCountReg_reg[31]\(4),
      I5 => counter_reg(4),
      O => \o_pulse0_carry_i_3__1_n_0\
    );
\o_pulse0_carry_i_4__1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"9009000000009009"
    )
        port map (
      I0 => counter_reg(0),
      I1 => \maxCountReg_reg[31]\(0),
      I2 => \maxCountReg_reg[31]\(2),
      I3 => counter_reg(2),
      I4 => \maxCountReg_reg[31]\(1),
      I5 => counter_reg(1),
      O => \o_pulse0_carry_i_4__1_n_0\
    );
o_pulse_reg: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \o_pulse0_carry__1_n_1\,
      Q => \^o_y_pos_reg[0]\,
      R => '0'
    );
\o_y_pos[0]_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \^o_y_pos_reg[0]\,
      I1 => Q(0),
      O => \o_y_pos[0]_i_3_n_0\
    );
\o_y_pos[0]_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \^o_y_pos_reg[0]\,
      I1 => Q(0),
      O => \o_y_pos[0]_i_4_n_0\
    );
\o_y_pos[0]_i_5\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \^o_y_pos_reg[0]\,
      I1 => Q(0),
      O => \o_y_pos[0]_i_5_n_0\
    );
\o_y_pos[0]_i_7\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"F909"
    )
        port map (
      I0 => \^o_y_pos_reg[0]\,
      I1 => posReg(2),
      I2 => Q(0),
      I3 => \maxCoordinateReg_reg[31]\(2),
      O => \o_y_pos[0]_i_7_n_0\
    );
\o_y_pos[0]_i_8\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"F909"
    )
        port map (
      I0 => \^o_y_pos_reg[0]\,
      I1 => posReg(1),
      I2 => Q(0),
      I3 => \maxCoordinateReg_reg[31]\(1),
      O => \o_y_pos[0]_i_8_n_0\
    );
\o_y_pos[0]_i_9\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"F909"
    )
        port map (
      I0 => \^o_y_pos_reg[0]\,
      I1 => posReg(0),
      I2 => Q(0),
      I3 => \maxCoordinateReg_reg[31]\(0),
      O => \o_y_pos[0]_i_9_n_0\
    );
\o_y_pos[12]_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \^o_y_pos_reg[0]\,
      I1 => Q(0),
      O => \o_y_pos[12]_i_2_n_0\
    );
\o_y_pos[12]_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \^o_y_pos_reg[0]\,
      I1 => Q(0),
      O => \o_y_pos[12]_i_3_n_0\
    );
\o_y_pos[12]_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \^o_y_pos_reg[0]\,
      I1 => Q(0),
      O => \o_y_pos[12]_i_4_n_0\
    );
\o_y_pos[12]_i_5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"21"
    )
        port map (
      I0 => \^o_y_pos_reg[0]\,
      I1 => Q(0),
      I2 => posReg(14),
      O => \o_y_pos[12]_i_5_n_0\
    );
\o_y_pos[12]_i_6\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"F909"
    )
        port map (
      I0 => \^o_y_pos_reg[0]\,
      I1 => posReg(13),
      I2 => Q(0),
      I3 => \maxCoordinateReg_reg[31]\(13),
      O => \o_y_pos[12]_i_6_n_0\
    );
\o_y_pos[12]_i_7\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"F909"
    )
        port map (
      I0 => \^o_y_pos_reg[0]\,
      I1 => posReg(12),
      I2 => Q(0),
      I3 => \maxCoordinateReg_reg[31]\(12),
      O => \o_y_pos[12]_i_7_n_0\
    );
\o_y_pos[12]_i_8\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"F909"
    )
        port map (
      I0 => \^o_y_pos_reg[0]\,
      I1 => posReg(11),
      I2 => Q(0),
      I3 => \maxCoordinateReg_reg[31]\(11),
      O => \o_y_pos[12]_i_8_n_0\
    );
\o_y_pos[4]_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \^o_y_pos_reg[0]\,
      I1 => Q(0),
      O => \o_y_pos[4]_i_2_n_0\
    );
\o_y_pos[4]_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \^o_y_pos_reg[0]\,
      I1 => Q(0),
      O => \o_y_pos[4]_i_3_n_0\
    );
\o_y_pos[4]_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \^o_y_pos_reg[0]\,
      I1 => Q(0),
      O => \o_y_pos[4]_i_4_n_0\
    );
\o_y_pos[4]_i_5\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \^o_y_pos_reg[0]\,
      I1 => Q(0),
      O => \o_y_pos[4]_i_5_n_0\
    );
\o_y_pos[4]_i_6\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"F909"
    )
        port map (
      I0 => \^o_y_pos_reg[0]\,
      I1 => posReg(6),
      I2 => Q(0),
      I3 => \maxCoordinateReg_reg[31]\(6),
      O => \o_y_pos[4]_i_6_n_0\
    );
\o_y_pos[4]_i_7\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"F909"
    )
        port map (
      I0 => \^o_y_pos_reg[0]\,
      I1 => posReg(5),
      I2 => Q(0),
      I3 => \maxCoordinateReg_reg[31]\(5),
      O => \o_y_pos[4]_i_7_n_0\
    );
\o_y_pos[4]_i_8\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"F909"
    )
        port map (
      I0 => \^o_y_pos_reg[0]\,
      I1 => posReg(4),
      I2 => Q(0),
      I3 => \maxCoordinateReg_reg[31]\(4),
      O => \o_y_pos[4]_i_8_n_0\
    );
\o_y_pos[4]_i_9\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"F909"
    )
        port map (
      I0 => \^o_y_pos_reg[0]\,
      I1 => posReg(3),
      I2 => Q(0),
      I3 => \maxCoordinateReg_reg[31]\(3),
      O => \o_y_pos[4]_i_9_n_0\
    );
\o_y_pos[8]_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \^o_y_pos_reg[0]\,
      I1 => Q(0),
      O => \o_y_pos[8]_i_2_n_0\
    );
\o_y_pos[8]_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \^o_y_pos_reg[0]\,
      I1 => Q(0),
      O => \o_y_pos[8]_i_3_n_0\
    );
\o_y_pos[8]_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \^o_y_pos_reg[0]\,
      I1 => Q(0),
      O => \o_y_pos[8]_i_4_n_0\
    );
\o_y_pos[8]_i_5\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \^o_y_pos_reg[0]\,
      I1 => Q(0),
      O => \o_y_pos[8]_i_5_n_0\
    );
\o_y_pos[8]_i_6\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"F909"
    )
        port map (
      I0 => \^o_y_pos_reg[0]\,
      I1 => posReg(10),
      I2 => Q(0),
      I3 => \maxCoordinateReg_reg[31]\(10),
      O => \o_y_pos[8]_i_6_n_0\
    );
\o_y_pos[8]_i_7\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"F909"
    )
        port map (
      I0 => \^o_y_pos_reg[0]\,
      I1 => posReg(9),
      I2 => Q(0),
      I3 => \maxCoordinateReg_reg[31]\(9),
      O => \o_y_pos[8]_i_7_n_0\
    );
\o_y_pos[8]_i_8\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"F909"
    )
        port map (
      I0 => \^o_y_pos_reg[0]\,
      I1 => posReg(8),
      I2 => Q(0),
      I3 => \maxCoordinateReg_reg[31]\(8),
      O => \o_y_pos[8]_i_8_n_0\
    );
\o_y_pos[8]_i_9\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"F909"
    )
        port map (
      I0 => \^o_y_pos_reg[0]\,
      I1 => posReg(7),
      I2 => Q(0),
      I3 => \maxCoordinateReg_reg[31]\(7),
      O => \o_y_pos[8]_i_9_n_0\
    );
\o_y_pos_reg[0]_i_2\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \o_y_pos_reg[0]_i_2_n_0\,
      CO(2) => \o_y_pos_reg[0]_i_2_n_1\,
      CO(1) => \o_y_pos_reg[0]_i_2_n_2\,
      CO(0) => \o_y_pos_reg[0]_i_2_n_3\,
      CYINIT => '0',
      DI(3) => \o_y_pos[0]_i_3_n_0\,
      DI(2) => \o_y_pos[0]_i_4_n_0\,
      DI(1) => \o_y_pos[0]_i_5_n_0\,
      DI(0) => DI(0),
      O(3 downto 0) => O(3 downto 0),
      S(3) => \o_y_pos[0]_i_7_n_0\,
      S(2) => \o_y_pos[0]_i_8_n_0\,
      S(1) => \o_y_pos[0]_i_9_n_0\,
      S(0) => S(0)
    );
\o_y_pos_reg[12]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \o_y_pos_reg[8]_i_1_n_0\,
      CO(3) => \NLW_o_y_pos_reg[12]_i_1_CO_UNCONNECTED\(3),
      CO(2) => \o_y_pos_reg[12]_i_1_n_1\,
      CO(1) => \o_y_pos_reg[12]_i_1_n_2\,
      CO(0) => \o_y_pos_reg[12]_i_1_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => \o_y_pos[12]_i_2_n_0\,
      DI(1) => \o_y_pos[12]_i_3_n_0\,
      DI(0) => \o_y_pos[12]_i_4_n_0\,
      O(3 downto 0) => \o_y_pos_reg[15]\(3 downto 0),
      S(3) => \o_y_pos[12]_i_5_n_0\,
      S(2) => \o_y_pos[12]_i_6_n_0\,
      S(1) => \o_y_pos[12]_i_7_n_0\,
      S(0) => \o_y_pos[12]_i_8_n_0\
    );
\o_y_pos_reg[4]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \o_y_pos_reg[0]_i_2_n_0\,
      CO(3) => \o_y_pos_reg[4]_i_1_n_0\,
      CO(2) => \o_y_pos_reg[4]_i_1_n_1\,
      CO(1) => \o_y_pos_reg[4]_i_1_n_2\,
      CO(0) => \o_y_pos_reg[4]_i_1_n_3\,
      CYINIT => '0',
      DI(3) => \o_y_pos[4]_i_2_n_0\,
      DI(2) => \o_y_pos[4]_i_3_n_0\,
      DI(1) => \o_y_pos[4]_i_4_n_0\,
      DI(0) => \o_y_pos[4]_i_5_n_0\,
      O(3 downto 0) => \o_y_pos_reg[7]\(3 downto 0),
      S(3) => \o_y_pos[4]_i_6_n_0\,
      S(2) => \o_y_pos[4]_i_7_n_0\,
      S(1) => \o_y_pos[4]_i_8_n_0\,
      S(0) => \o_y_pos[4]_i_9_n_0\
    );
\o_y_pos_reg[8]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \o_y_pos_reg[4]_i_1_n_0\,
      CO(3) => \o_y_pos_reg[8]_i_1_n_0\,
      CO(2) => \o_y_pos_reg[8]_i_1_n_1\,
      CO(1) => \o_y_pos_reg[8]_i_1_n_2\,
      CO(0) => \o_y_pos_reg[8]_i_1_n_3\,
      CYINIT => '0',
      DI(3) => \o_y_pos[8]_i_2_n_0\,
      DI(2) => \o_y_pos[8]_i_3_n_0\,
      DI(1) => \o_y_pos[8]_i_4_n_0\,
      DI(0) => \o_y_pos[8]_i_5_n_0\,
      O(3 downto 0) => \o_y_pos_reg[11]\(3 downto 0),
      S(3) => \o_y_pos[8]_i_6_n_0\,
      S(2) => \o_y_pos[8]_i_7_n_0\,
      S(1) => \o_y_pos[8]_i_8_n_0\,
      S(0) => \o_y_pos[8]_i_9_n_0\
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_pulseGen_3 is
  port (
    o_pulse : out STD_LOGIC;
    CO : out STD_LOGIC_VECTOR ( 0 to 0 );
    s00_axi_aclk : in STD_LOGIC;
    \maxCountReg_reg[31]\ : in STD_LOGIC_VECTOR ( 31 downto 0 );
    clear : in STD_LOGIC
  );
  attribute ORIG_REF_NAME : string;
  attribute ORIG_REF_NAME of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_pulseGen_3 : entity is "pulseGen";
end decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_pulseGen_3;

architecture STRUCTURE of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_pulseGen_3 is
  signal \counter2_carry__0_i_1__0_n_0\ : STD_LOGIC;
  signal \counter2_carry__0_i_2__0_n_0\ : STD_LOGIC;
  signal \counter2_carry__0_i_3__0_n_0\ : STD_LOGIC;
  signal \counter2_carry__0_i_4__0_n_0\ : STD_LOGIC;
  signal \counter2_carry__0_i_5__0_n_0\ : STD_LOGIC;
  signal \counter2_carry__0_i_6__0_n_0\ : STD_LOGIC;
  signal \counter2_carry__0_i_7__0_n_0\ : STD_LOGIC;
  signal \counter2_carry__0_i_8__0_n_0\ : STD_LOGIC;
  signal \counter2_carry__0_n_0\ : STD_LOGIC;
  signal \counter2_carry__0_n_1\ : STD_LOGIC;
  signal \counter2_carry__0_n_2\ : STD_LOGIC;
  signal \counter2_carry__0_n_3\ : STD_LOGIC;
  signal \counter2_carry__1_i_1__0_n_0\ : STD_LOGIC;
  signal \counter2_carry__1_i_2__0_n_0\ : STD_LOGIC;
  signal \counter2_carry__1_i_3__0_n_0\ : STD_LOGIC;
  signal \counter2_carry__1_i_4__0_n_0\ : STD_LOGIC;
  signal \counter2_carry__1_i_5__0_n_0\ : STD_LOGIC;
  signal \counter2_carry__1_i_6__0_n_0\ : STD_LOGIC;
  signal \counter2_carry__1_i_7__0_n_0\ : STD_LOGIC;
  signal \counter2_carry__1_i_8__0_n_0\ : STD_LOGIC;
  signal \counter2_carry__1_n_0\ : STD_LOGIC;
  signal \counter2_carry__1_n_1\ : STD_LOGIC;
  signal \counter2_carry__1_n_2\ : STD_LOGIC;
  signal \counter2_carry__1_n_3\ : STD_LOGIC;
  signal \counter2_carry__2_i_1__0_n_0\ : STD_LOGIC;
  signal \counter2_carry__2_i_2__0_n_0\ : STD_LOGIC;
  signal \counter2_carry__2_i_3__0_n_0\ : STD_LOGIC;
  signal \counter2_carry__2_i_4__0_n_0\ : STD_LOGIC;
  signal \counter2_carry__2_i_5__0_n_0\ : STD_LOGIC;
  signal \counter2_carry__2_i_6__0_n_0\ : STD_LOGIC;
  signal \counter2_carry__2_i_7__0_n_0\ : STD_LOGIC;
  signal \counter2_carry__2_i_8__0_n_0\ : STD_LOGIC;
  signal \counter2_carry__2_n_1\ : STD_LOGIC;
  signal \counter2_carry__2_n_2\ : STD_LOGIC;
  signal \counter2_carry__2_n_3\ : STD_LOGIC;
  signal \counter2_carry_i_1__0_n_0\ : STD_LOGIC;
  signal \counter2_carry_i_2__0_n_0\ : STD_LOGIC;
  signal \counter2_carry_i_3__0_n_0\ : STD_LOGIC;
  signal \counter2_carry_i_4__0_n_0\ : STD_LOGIC;
  signal \counter2_carry_i_5__0_n_0\ : STD_LOGIC;
  signal \counter2_carry_i_6__0_n_0\ : STD_LOGIC;
  signal \counter2_carry_i_7__0_n_0\ : STD_LOGIC;
  signal \counter2_carry_i_8__0_n_0\ : STD_LOGIC;
  signal counter2_carry_n_0 : STD_LOGIC;
  signal counter2_carry_n_1 : STD_LOGIC;
  signal counter2_carry_n_2 : STD_LOGIC;
  signal counter2_carry_n_3 : STD_LOGIC;
  signal \counter[0]_i_3__7_n_0\ : STD_LOGIC;
  signal counter_reg : STD_LOGIC_VECTOR ( 31 downto 0 );
  signal \counter_reg[0]_i_2__4_n_0\ : STD_LOGIC;
  signal \counter_reg[0]_i_2__4_n_1\ : STD_LOGIC;
  signal \counter_reg[0]_i_2__4_n_2\ : STD_LOGIC;
  signal \counter_reg[0]_i_2__4_n_3\ : STD_LOGIC;
  signal \counter_reg[0]_i_2__4_n_4\ : STD_LOGIC;
  signal \counter_reg[0]_i_2__4_n_5\ : STD_LOGIC;
  signal \counter_reg[0]_i_2__4_n_6\ : STD_LOGIC;
  signal \counter_reg[0]_i_2__4_n_7\ : STD_LOGIC;
  signal \counter_reg[12]_i_1__4_n_0\ : STD_LOGIC;
  signal \counter_reg[12]_i_1__4_n_1\ : STD_LOGIC;
  signal \counter_reg[12]_i_1__4_n_2\ : STD_LOGIC;
  signal \counter_reg[12]_i_1__4_n_3\ : STD_LOGIC;
  signal \counter_reg[12]_i_1__4_n_4\ : STD_LOGIC;
  signal \counter_reg[12]_i_1__4_n_5\ : STD_LOGIC;
  signal \counter_reg[12]_i_1__4_n_6\ : STD_LOGIC;
  signal \counter_reg[12]_i_1__4_n_7\ : STD_LOGIC;
  signal \counter_reg[16]_i_1__4_n_0\ : STD_LOGIC;
  signal \counter_reg[16]_i_1__4_n_1\ : STD_LOGIC;
  signal \counter_reg[16]_i_1__4_n_2\ : STD_LOGIC;
  signal \counter_reg[16]_i_1__4_n_3\ : STD_LOGIC;
  signal \counter_reg[16]_i_1__4_n_4\ : STD_LOGIC;
  signal \counter_reg[16]_i_1__4_n_5\ : STD_LOGIC;
  signal \counter_reg[16]_i_1__4_n_6\ : STD_LOGIC;
  signal \counter_reg[16]_i_1__4_n_7\ : STD_LOGIC;
  signal \counter_reg[20]_i_1__4_n_0\ : STD_LOGIC;
  signal \counter_reg[20]_i_1__4_n_1\ : STD_LOGIC;
  signal \counter_reg[20]_i_1__4_n_2\ : STD_LOGIC;
  signal \counter_reg[20]_i_1__4_n_3\ : STD_LOGIC;
  signal \counter_reg[20]_i_1__4_n_4\ : STD_LOGIC;
  signal \counter_reg[20]_i_1__4_n_5\ : STD_LOGIC;
  signal \counter_reg[20]_i_1__4_n_6\ : STD_LOGIC;
  signal \counter_reg[20]_i_1__4_n_7\ : STD_LOGIC;
  signal \counter_reg[24]_i_1__4_n_0\ : STD_LOGIC;
  signal \counter_reg[24]_i_1__4_n_1\ : STD_LOGIC;
  signal \counter_reg[24]_i_1__4_n_2\ : STD_LOGIC;
  signal \counter_reg[24]_i_1__4_n_3\ : STD_LOGIC;
  signal \counter_reg[24]_i_1__4_n_4\ : STD_LOGIC;
  signal \counter_reg[24]_i_1__4_n_5\ : STD_LOGIC;
  signal \counter_reg[24]_i_1__4_n_6\ : STD_LOGIC;
  signal \counter_reg[24]_i_1__4_n_7\ : STD_LOGIC;
  signal \counter_reg[28]_i_1__4_n_1\ : STD_LOGIC;
  signal \counter_reg[28]_i_1__4_n_2\ : STD_LOGIC;
  signal \counter_reg[28]_i_1__4_n_3\ : STD_LOGIC;
  signal \counter_reg[28]_i_1__4_n_4\ : STD_LOGIC;
  signal \counter_reg[28]_i_1__4_n_5\ : STD_LOGIC;
  signal \counter_reg[28]_i_1__4_n_6\ : STD_LOGIC;
  signal \counter_reg[28]_i_1__4_n_7\ : STD_LOGIC;
  signal \counter_reg[4]_i_1__4_n_0\ : STD_LOGIC;
  signal \counter_reg[4]_i_1__4_n_1\ : STD_LOGIC;
  signal \counter_reg[4]_i_1__4_n_2\ : STD_LOGIC;
  signal \counter_reg[4]_i_1__4_n_3\ : STD_LOGIC;
  signal \counter_reg[4]_i_1__4_n_4\ : STD_LOGIC;
  signal \counter_reg[4]_i_1__4_n_5\ : STD_LOGIC;
  signal \counter_reg[4]_i_1__4_n_6\ : STD_LOGIC;
  signal \counter_reg[4]_i_1__4_n_7\ : STD_LOGIC;
  signal \counter_reg[8]_i_1__4_n_0\ : STD_LOGIC;
  signal \counter_reg[8]_i_1__4_n_1\ : STD_LOGIC;
  signal \counter_reg[8]_i_1__4_n_2\ : STD_LOGIC;
  signal \counter_reg[8]_i_1__4_n_3\ : STD_LOGIC;
  signal \counter_reg[8]_i_1__4_n_4\ : STD_LOGIC;
  signal \counter_reg[8]_i_1__4_n_5\ : STD_LOGIC;
  signal \counter_reg[8]_i_1__4_n_6\ : STD_LOGIC;
  signal \counter_reg[8]_i_1__4_n_7\ : STD_LOGIC;
  signal \o_pulse0_carry__0_i_1__0_n_0\ : STD_LOGIC;
  signal \o_pulse0_carry__0_i_2__0_n_0\ : STD_LOGIC;
  signal \o_pulse0_carry__0_i_3__0_n_0\ : STD_LOGIC;
  signal \o_pulse0_carry__0_i_4__0_n_0\ : STD_LOGIC;
  signal \o_pulse0_carry__0_n_0\ : STD_LOGIC;
  signal \o_pulse0_carry__0_n_1\ : STD_LOGIC;
  signal \o_pulse0_carry__0_n_2\ : STD_LOGIC;
  signal \o_pulse0_carry__0_n_3\ : STD_LOGIC;
  signal \o_pulse0_carry__1_i_1__0_n_0\ : STD_LOGIC;
  signal \o_pulse0_carry__1_i_2__0_n_0\ : STD_LOGIC;
  signal \o_pulse0_carry__1_i_3__0_n_0\ : STD_LOGIC;
  signal \o_pulse0_carry__1_n_1\ : STD_LOGIC;
  signal \o_pulse0_carry__1_n_2\ : STD_LOGIC;
  signal \o_pulse0_carry__1_n_3\ : STD_LOGIC;
  signal \o_pulse0_carry_i_1__0_n_0\ : STD_LOGIC;
  signal \o_pulse0_carry_i_2__0_n_0\ : STD_LOGIC;
  signal \o_pulse0_carry_i_3__0_n_0\ : STD_LOGIC;
  signal \o_pulse0_carry_i_4__0_n_0\ : STD_LOGIC;
  signal o_pulse0_carry_n_0 : STD_LOGIC;
  signal o_pulse0_carry_n_1 : STD_LOGIC;
  signal o_pulse0_carry_n_2 : STD_LOGIC;
  signal o_pulse0_carry_n_3 : STD_LOGIC;
  signal NLW_counter2_carry_O_UNCONNECTED : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_counter2_carry__0_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_counter2_carry__1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_counter2_carry__2_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_counter_reg[28]_i_1__4_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal NLW_o_pulse0_carry_O_UNCONNECTED : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_o_pulse0_carry__0_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_o_pulse0_carry__1_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_o_pulse0_carry__1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
begin
counter2_carry: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => counter2_carry_n_0,
      CO(2) => counter2_carry_n_1,
      CO(1) => counter2_carry_n_2,
      CO(0) => counter2_carry_n_3,
      CYINIT => '0',
      DI(3) => \counter2_carry_i_1__0_n_0\,
      DI(2) => \counter2_carry_i_2__0_n_0\,
      DI(1) => \counter2_carry_i_3__0_n_0\,
      DI(0) => \counter2_carry_i_4__0_n_0\,
      O(3 downto 0) => NLW_counter2_carry_O_UNCONNECTED(3 downto 0),
      S(3) => \counter2_carry_i_5__0_n_0\,
      S(2) => \counter2_carry_i_6__0_n_0\,
      S(1) => \counter2_carry_i_7__0_n_0\,
      S(0) => \counter2_carry_i_8__0_n_0\
    );
\counter2_carry__0\: unisim.vcomponents.CARRY4
     port map (
      CI => counter2_carry_n_0,
      CO(3) => \counter2_carry__0_n_0\,
      CO(2) => \counter2_carry__0_n_1\,
      CO(1) => \counter2_carry__0_n_2\,
      CO(0) => \counter2_carry__0_n_3\,
      CYINIT => '0',
      DI(3) => \counter2_carry__0_i_1__0_n_0\,
      DI(2) => \counter2_carry__0_i_2__0_n_0\,
      DI(1) => \counter2_carry__0_i_3__0_n_0\,
      DI(0) => \counter2_carry__0_i_4__0_n_0\,
      O(3 downto 0) => \NLW_counter2_carry__0_O_UNCONNECTED\(3 downto 0),
      S(3) => \counter2_carry__0_i_5__0_n_0\,
      S(2) => \counter2_carry__0_i_6__0_n_0\,
      S(1) => \counter2_carry__0_i_7__0_n_0\,
      S(0) => \counter2_carry__0_i_8__0_n_0\
    );
\counter2_carry__0_i_1__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"2F02"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(14),
      I1 => counter_reg(14),
      I2 => counter_reg(15),
      I3 => \maxCountReg_reg[31]\(15),
      O => \counter2_carry__0_i_1__0_n_0\
    );
\counter2_carry__0_i_2__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"2F02"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(12),
      I1 => counter_reg(12),
      I2 => counter_reg(13),
      I3 => \maxCountReg_reg[31]\(13),
      O => \counter2_carry__0_i_2__0_n_0\
    );
\counter2_carry__0_i_3__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"2F02"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(10),
      I1 => counter_reg(10),
      I2 => counter_reg(11),
      I3 => \maxCountReg_reg[31]\(11),
      O => \counter2_carry__0_i_3__0_n_0\
    );
\counter2_carry__0_i_4__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"2F02"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(8),
      I1 => counter_reg(8),
      I2 => counter_reg(9),
      I3 => \maxCountReg_reg[31]\(9),
      O => \counter2_carry__0_i_4__0_n_0\
    );
\counter2_carry__0_i_5__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9009"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(14),
      I1 => counter_reg(14),
      I2 => \maxCountReg_reg[31]\(15),
      I3 => counter_reg(15),
      O => \counter2_carry__0_i_5__0_n_0\
    );
\counter2_carry__0_i_6__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9009"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(12),
      I1 => counter_reg(12),
      I2 => \maxCountReg_reg[31]\(13),
      I3 => counter_reg(13),
      O => \counter2_carry__0_i_6__0_n_0\
    );
\counter2_carry__0_i_7__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9009"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(10),
      I1 => counter_reg(10),
      I2 => \maxCountReg_reg[31]\(11),
      I3 => counter_reg(11),
      O => \counter2_carry__0_i_7__0_n_0\
    );
\counter2_carry__0_i_8__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9009"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(8),
      I1 => counter_reg(8),
      I2 => \maxCountReg_reg[31]\(9),
      I3 => counter_reg(9),
      O => \counter2_carry__0_i_8__0_n_0\
    );
\counter2_carry__1\: unisim.vcomponents.CARRY4
     port map (
      CI => \counter2_carry__0_n_0\,
      CO(3) => \counter2_carry__1_n_0\,
      CO(2) => \counter2_carry__1_n_1\,
      CO(1) => \counter2_carry__1_n_2\,
      CO(0) => \counter2_carry__1_n_3\,
      CYINIT => '0',
      DI(3) => \counter2_carry__1_i_1__0_n_0\,
      DI(2) => \counter2_carry__1_i_2__0_n_0\,
      DI(1) => \counter2_carry__1_i_3__0_n_0\,
      DI(0) => \counter2_carry__1_i_4__0_n_0\,
      O(3 downto 0) => \NLW_counter2_carry__1_O_UNCONNECTED\(3 downto 0),
      S(3) => \counter2_carry__1_i_5__0_n_0\,
      S(2) => \counter2_carry__1_i_6__0_n_0\,
      S(1) => \counter2_carry__1_i_7__0_n_0\,
      S(0) => \counter2_carry__1_i_8__0_n_0\
    );
\counter2_carry__1_i_1__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"2F02"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(22),
      I1 => counter_reg(22),
      I2 => counter_reg(23),
      I3 => \maxCountReg_reg[31]\(23),
      O => \counter2_carry__1_i_1__0_n_0\
    );
\counter2_carry__1_i_2__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"2F02"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(20),
      I1 => counter_reg(20),
      I2 => counter_reg(21),
      I3 => \maxCountReg_reg[31]\(21),
      O => \counter2_carry__1_i_2__0_n_0\
    );
\counter2_carry__1_i_3__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"2F02"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(18),
      I1 => counter_reg(18),
      I2 => counter_reg(19),
      I3 => \maxCountReg_reg[31]\(19),
      O => \counter2_carry__1_i_3__0_n_0\
    );
\counter2_carry__1_i_4__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"2F02"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(16),
      I1 => counter_reg(16),
      I2 => counter_reg(17),
      I3 => \maxCountReg_reg[31]\(17),
      O => \counter2_carry__1_i_4__0_n_0\
    );
\counter2_carry__1_i_5__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9009"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(22),
      I1 => counter_reg(22),
      I2 => \maxCountReg_reg[31]\(23),
      I3 => counter_reg(23),
      O => \counter2_carry__1_i_5__0_n_0\
    );
\counter2_carry__1_i_6__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9009"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(20),
      I1 => counter_reg(20),
      I2 => \maxCountReg_reg[31]\(21),
      I3 => counter_reg(21),
      O => \counter2_carry__1_i_6__0_n_0\
    );
\counter2_carry__1_i_7__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9009"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(18),
      I1 => counter_reg(18),
      I2 => \maxCountReg_reg[31]\(19),
      I3 => counter_reg(19),
      O => \counter2_carry__1_i_7__0_n_0\
    );
\counter2_carry__1_i_8__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9009"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(16),
      I1 => counter_reg(16),
      I2 => \maxCountReg_reg[31]\(17),
      I3 => counter_reg(17),
      O => \counter2_carry__1_i_8__0_n_0\
    );
\counter2_carry__2\: unisim.vcomponents.CARRY4
     port map (
      CI => \counter2_carry__1_n_0\,
      CO(3) => CO(0),
      CO(2) => \counter2_carry__2_n_1\,
      CO(1) => \counter2_carry__2_n_2\,
      CO(0) => \counter2_carry__2_n_3\,
      CYINIT => '0',
      DI(3) => \counter2_carry__2_i_1__0_n_0\,
      DI(2) => \counter2_carry__2_i_2__0_n_0\,
      DI(1) => \counter2_carry__2_i_3__0_n_0\,
      DI(0) => \counter2_carry__2_i_4__0_n_0\,
      O(3 downto 0) => \NLW_counter2_carry__2_O_UNCONNECTED\(3 downto 0),
      S(3) => \counter2_carry__2_i_5__0_n_0\,
      S(2) => \counter2_carry__2_i_6__0_n_0\,
      S(1) => \counter2_carry__2_i_7__0_n_0\,
      S(0) => \counter2_carry__2_i_8__0_n_0\
    );
\counter2_carry__2_i_1__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"2F02"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(30),
      I1 => counter_reg(30),
      I2 => counter_reg(31),
      I3 => \maxCountReg_reg[31]\(31),
      O => \counter2_carry__2_i_1__0_n_0\
    );
\counter2_carry__2_i_2__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"2F02"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(28),
      I1 => counter_reg(28),
      I2 => counter_reg(29),
      I3 => \maxCountReg_reg[31]\(29),
      O => \counter2_carry__2_i_2__0_n_0\
    );
\counter2_carry__2_i_3__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"2F02"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(26),
      I1 => counter_reg(26),
      I2 => counter_reg(27),
      I3 => \maxCountReg_reg[31]\(27),
      O => \counter2_carry__2_i_3__0_n_0\
    );
\counter2_carry__2_i_4__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"2F02"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(24),
      I1 => counter_reg(24),
      I2 => counter_reg(25),
      I3 => \maxCountReg_reg[31]\(25),
      O => \counter2_carry__2_i_4__0_n_0\
    );
\counter2_carry__2_i_5__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9009"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(30),
      I1 => counter_reg(30),
      I2 => \maxCountReg_reg[31]\(31),
      I3 => counter_reg(31),
      O => \counter2_carry__2_i_5__0_n_0\
    );
\counter2_carry__2_i_6__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9009"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(28),
      I1 => counter_reg(28),
      I2 => \maxCountReg_reg[31]\(29),
      I3 => counter_reg(29),
      O => \counter2_carry__2_i_6__0_n_0\
    );
\counter2_carry__2_i_7__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9009"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(26),
      I1 => counter_reg(26),
      I2 => \maxCountReg_reg[31]\(27),
      I3 => counter_reg(27),
      O => \counter2_carry__2_i_7__0_n_0\
    );
\counter2_carry__2_i_8__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9009"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(24),
      I1 => counter_reg(24),
      I2 => \maxCountReg_reg[31]\(25),
      I3 => counter_reg(25),
      O => \counter2_carry__2_i_8__0_n_0\
    );
\counter2_carry_i_1__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"2F02"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(6),
      I1 => counter_reg(6),
      I2 => counter_reg(7),
      I3 => \maxCountReg_reg[31]\(7),
      O => \counter2_carry_i_1__0_n_0\
    );
\counter2_carry_i_2__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"2F02"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(4),
      I1 => counter_reg(4),
      I2 => counter_reg(5),
      I3 => \maxCountReg_reg[31]\(5),
      O => \counter2_carry_i_2__0_n_0\
    );
\counter2_carry_i_3__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"2F02"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(2),
      I1 => counter_reg(2),
      I2 => counter_reg(3),
      I3 => \maxCountReg_reg[31]\(3),
      O => \counter2_carry_i_3__0_n_0\
    );
\counter2_carry_i_4__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"2F02"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(0),
      I1 => counter_reg(0),
      I2 => counter_reg(1),
      I3 => \maxCountReg_reg[31]\(1),
      O => \counter2_carry_i_4__0_n_0\
    );
\counter2_carry_i_5__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9009"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(6),
      I1 => counter_reg(6),
      I2 => \maxCountReg_reg[31]\(7),
      I3 => counter_reg(7),
      O => \counter2_carry_i_5__0_n_0\
    );
\counter2_carry_i_6__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9009"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(4),
      I1 => counter_reg(4),
      I2 => \maxCountReg_reg[31]\(5),
      I3 => counter_reg(5),
      O => \counter2_carry_i_6__0_n_0\
    );
\counter2_carry_i_7__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9009"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(2),
      I1 => counter_reg(2),
      I2 => \maxCountReg_reg[31]\(3),
      I3 => counter_reg(3),
      O => \counter2_carry_i_7__0_n_0\
    );
\counter2_carry_i_8__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9009"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(0),
      I1 => counter_reg(0),
      I2 => \maxCountReg_reg[31]\(1),
      I3 => counter_reg(1),
      O => \counter2_carry_i_8__0_n_0\
    );
\counter[0]_i_3__7\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => counter_reg(0),
      O => \counter[0]_i_3__7_n_0\
    );
\counter_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[0]_i_2__4_n_7\,
      Q => counter_reg(0),
      R => clear
    );
\counter_reg[0]_i_2__4\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \counter_reg[0]_i_2__4_n_0\,
      CO(2) => \counter_reg[0]_i_2__4_n_1\,
      CO(1) => \counter_reg[0]_i_2__4_n_2\,
      CO(0) => \counter_reg[0]_i_2__4_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0001",
      O(3) => \counter_reg[0]_i_2__4_n_4\,
      O(2) => \counter_reg[0]_i_2__4_n_5\,
      O(1) => \counter_reg[0]_i_2__4_n_6\,
      O(0) => \counter_reg[0]_i_2__4_n_7\,
      S(3 downto 1) => counter_reg(3 downto 1),
      S(0) => \counter[0]_i_3__7_n_0\
    );
\counter_reg[10]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[8]_i_1__4_n_5\,
      Q => counter_reg(10),
      R => clear
    );
\counter_reg[11]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[8]_i_1__4_n_4\,
      Q => counter_reg(11),
      R => clear
    );
\counter_reg[12]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[12]_i_1__4_n_7\,
      Q => counter_reg(12),
      R => clear
    );
\counter_reg[12]_i_1__4\: unisim.vcomponents.CARRY4
     port map (
      CI => \counter_reg[8]_i_1__4_n_0\,
      CO(3) => \counter_reg[12]_i_1__4_n_0\,
      CO(2) => \counter_reg[12]_i_1__4_n_1\,
      CO(1) => \counter_reg[12]_i_1__4_n_2\,
      CO(0) => \counter_reg[12]_i_1__4_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \counter_reg[12]_i_1__4_n_4\,
      O(2) => \counter_reg[12]_i_1__4_n_5\,
      O(1) => \counter_reg[12]_i_1__4_n_6\,
      O(0) => \counter_reg[12]_i_1__4_n_7\,
      S(3 downto 0) => counter_reg(15 downto 12)
    );
\counter_reg[13]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[12]_i_1__4_n_6\,
      Q => counter_reg(13),
      R => clear
    );
\counter_reg[14]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[12]_i_1__4_n_5\,
      Q => counter_reg(14),
      R => clear
    );
\counter_reg[15]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[12]_i_1__4_n_4\,
      Q => counter_reg(15),
      R => clear
    );
\counter_reg[16]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[16]_i_1__4_n_7\,
      Q => counter_reg(16),
      R => clear
    );
\counter_reg[16]_i_1__4\: unisim.vcomponents.CARRY4
     port map (
      CI => \counter_reg[12]_i_1__4_n_0\,
      CO(3) => \counter_reg[16]_i_1__4_n_0\,
      CO(2) => \counter_reg[16]_i_1__4_n_1\,
      CO(1) => \counter_reg[16]_i_1__4_n_2\,
      CO(0) => \counter_reg[16]_i_1__4_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \counter_reg[16]_i_1__4_n_4\,
      O(2) => \counter_reg[16]_i_1__4_n_5\,
      O(1) => \counter_reg[16]_i_1__4_n_6\,
      O(0) => \counter_reg[16]_i_1__4_n_7\,
      S(3 downto 0) => counter_reg(19 downto 16)
    );
\counter_reg[17]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[16]_i_1__4_n_6\,
      Q => counter_reg(17),
      R => clear
    );
\counter_reg[18]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[16]_i_1__4_n_5\,
      Q => counter_reg(18),
      R => clear
    );
\counter_reg[19]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[16]_i_1__4_n_4\,
      Q => counter_reg(19),
      R => clear
    );
\counter_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[0]_i_2__4_n_6\,
      Q => counter_reg(1),
      R => clear
    );
\counter_reg[20]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[20]_i_1__4_n_7\,
      Q => counter_reg(20),
      R => clear
    );
\counter_reg[20]_i_1__4\: unisim.vcomponents.CARRY4
     port map (
      CI => \counter_reg[16]_i_1__4_n_0\,
      CO(3) => \counter_reg[20]_i_1__4_n_0\,
      CO(2) => \counter_reg[20]_i_1__4_n_1\,
      CO(1) => \counter_reg[20]_i_1__4_n_2\,
      CO(0) => \counter_reg[20]_i_1__4_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \counter_reg[20]_i_1__4_n_4\,
      O(2) => \counter_reg[20]_i_1__4_n_5\,
      O(1) => \counter_reg[20]_i_1__4_n_6\,
      O(0) => \counter_reg[20]_i_1__4_n_7\,
      S(3 downto 0) => counter_reg(23 downto 20)
    );
\counter_reg[21]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[20]_i_1__4_n_6\,
      Q => counter_reg(21),
      R => clear
    );
\counter_reg[22]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[20]_i_1__4_n_5\,
      Q => counter_reg(22),
      R => clear
    );
\counter_reg[23]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[20]_i_1__4_n_4\,
      Q => counter_reg(23),
      R => clear
    );
\counter_reg[24]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[24]_i_1__4_n_7\,
      Q => counter_reg(24),
      R => clear
    );
\counter_reg[24]_i_1__4\: unisim.vcomponents.CARRY4
     port map (
      CI => \counter_reg[20]_i_1__4_n_0\,
      CO(3) => \counter_reg[24]_i_1__4_n_0\,
      CO(2) => \counter_reg[24]_i_1__4_n_1\,
      CO(1) => \counter_reg[24]_i_1__4_n_2\,
      CO(0) => \counter_reg[24]_i_1__4_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \counter_reg[24]_i_1__4_n_4\,
      O(2) => \counter_reg[24]_i_1__4_n_5\,
      O(1) => \counter_reg[24]_i_1__4_n_6\,
      O(0) => \counter_reg[24]_i_1__4_n_7\,
      S(3 downto 0) => counter_reg(27 downto 24)
    );
\counter_reg[25]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[24]_i_1__4_n_6\,
      Q => counter_reg(25),
      R => clear
    );
\counter_reg[26]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[24]_i_1__4_n_5\,
      Q => counter_reg(26),
      R => clear
    );
\counter_reg[27]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[24]_i_1__4_n_4\,
      Q => counter_reg(27),
      R => clear
    );
\counter_reg[28]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[28]_i_1__4_n_7\,
      Q => counter_reg(28),
      R => clear
    );
\counter_reg[28]_i_1__4\: unisim.vcomponents.CARRY4
     port map (
      CI => \counter_reg[24]_i_1__4_n_0\,
      CO(3) => \NLW_counter_reg[28]_i_1__4_CO_UNCONNECTED\(3),
      CO(2) => \counter_reg[28]_i_1__4_n_1\,
      CO(1) => \counter_reg[28]_i_1__4_n_2\,
      CO(0) => \counter_reg[28]_i_1__4_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \counter_reg[28]_i_1__4_n_4\,
      O(2) => \counter_reg[28]_i_1__4_n_5\,
      O(1) => \counter_reg[28]_i_1__4_n_6\,
      O(0) => \counter_reg[28]_i_1__4_n_7\,
      S(3 downto 0) => counter_reg(31 downto 28)
    );
\counter_reg[29]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[28]_i_1__4_n_6\,
      Q => counter_reg(29),
      R => clear
    );
\counter_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[0]_i_2__4_n_5\,
      Q => counter_reg(2),
      R => clear
    );
\counter_reg[30]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[28]_i_1__4_n_5\,
      Q => counter_reg(30),
      R => clear
    );
\counter_reg[31]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[28]_i_1__4_n_4\,
      Q => counter_reg(31),
      R => clear
    );
\counter_reg[3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[0]_i_2__4_n_4\,
      Q => counter_reg(3),
      R => clear
    );
\counter_reg[4]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[4]_i_1__4_n_7\,
      Q => counter_reg(4),
      R => clear
    );
\counter_reg[4]_i_1__4\: unisim.vcomponents.CARRY4
     port map (
      CI => \counter_reg[0]_i_2__4_n_0\,
      CO(3) => \counter_reg[4]_i_1__4_n_0\,
      CO(2) => \counter_reg[4]_i_1__4_n_1\,
      CO(1) => \counter_reg[4]_i_1__4_n_2\,
      CO(0) => \counter_reg[4]_i_1__4_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \counter_reg[4]_i_1__4_n_4\,
      O(2) => \counter_reg[4]_i_1__4_n_5\,
      O(1) => \counter_reg[4]_i_1__4_n_6\,
      O(0) => \counter_reg[4]_i_1__4_n_7\,
      S(3 downto 0) => counter_reg(7 downto 4)
    );
\counter_reg[5]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[4]_i_1__4_n_6\,
      Q => counter_reg(5),
      R => clear
    );
\counter_reg[6]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[4]_i_1__4_n_5\,
      Q => counter_reg(6),
      R => clear
    );
\counter_reg[7]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[4]_i_1__4_n_4\,
      Q => counter_reg(7),
      R => clear
    );
\counter_reg[8]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[8]_i_1__4_n_7\,
      Q => counter_reg(8),
      R => clear
    );
\counter_reg[8]_i_1__4\: unisim.vcomponents.CARRY4
     port map (
      CI => \counter_reg[4]_i_1__4_n_0\,
      CO(3) => \counter_reg[8]_i_1__4_n_0\,
      CO(2) => \counter_reg[8]_i_1__4_n_1\,
      CO(1) => \counter_reg[8]_i_1__4_n_2\,
      CO(0) => \counter_reg[8]_i_1__4_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \counter_reg[8]_i_1__4_n_4\,
      O(2) => \counter_reg[8]_i_1__4_n_5\,
      O(1) => \counter_reg[8]_i_1__4_n_6\,
      O(0) => \counter_reg[8]_i_1__4_n_7\,
      S(3 downto 0) => counter_reg(11 downto 8)
    );
\counter_reg[9]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[8]_i_1__4_n_6\,
      Q => counter_reg(9),
      R => clear
    );
o_pulse0_carry: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => o_pulse0_carry_n_0,
      CO(2) => o_pulse0_carry_n_1,
      CO(1) => o_pulse0_carry_n_2,
      CO(0) => o_pulse0_carry_n_3,
      CYINIT => '1',
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => NLW_o_pulse0_carry_O_UNCONNECTED(3 downto 0),
      S(3) => \o_pulse0_carry_i_1__0_n_0\,
      S(2) => \o_pulse0_carry_i_2__0_n_0\,
      S(1) => \o_pulse0_carry_i_3__0_n_0\,
      S(0) => \o_pulse0_carry_i_4__0_n_0\
    );
\o_pulse0_carry__0\: unisim.vcomponents.CARRY4
     port map (
      CI => o_pulse0_carry_n_0,
      CO(3) => \o_pulse0_carry__0_n_0\,
      CO(2) => \o_pulse0_carry__0_n_1\,
      CO(1) => \o_pulse0_carry__0_n_2\,
      CO(0) => \o_pulse0_carry__0_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => \NLW_o_pulse0_carry__0_O_UNCONNECTED\(3 downto 0),
      S(3) => \o_pulse0_carry__0_i_1__0_n_0\,
      S(2) => \o_pulse0_carry__0_i_2__0_n_0\,
      S(1) => \o_pulse0_carry__0_i_3__0_n_0\,
      S(0) => \o_pulse0_carry__0_i_4__0_n_0\
    );
\o_pulse0_carry__0_i_1__0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"9009000000009009"
    )
        port map (
      I0 => counter_reg(21),
      I1 => \maxCountReg_reg[31]\(21),
      I2 => \maxCountReg_reg[31]\(23),
      I3 => counter_reg(23),
      I4 => \maxCountReg_reg[31]\(22),
      I5 => counter_reg(22),
      O => \o_pulse0_carry__0_i_1__0_n_0\
    );
\o_pulse0_carry__0_i_2__0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"9009000000009009"
    )
        port map (
      I0 => counter_reg(18),
      I1 => \maxCountReg_reg[31]\(18),
      I2 => \maxCountReg_reg[31]\(20),
      I3 => counter_reg(20),
      I4 => \maxCountReg_reg[31]\(19),
      I5 => counter_reg(19),
      O => \o_pulse0_carry__0_i_2__0_n_0\
    );
\o_pulse0_carry__0_i_3__0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"9009000000009009"
    )
        port map (
      I0 => counter_reg(15),
      I1 => \maxCountReg_reg[31]\(15),
      I2 => \maxCountReg_reg[31]\(17),
      I3 => counter_reg(17),
      I4 => \maxCountReg_reg[31]\(16),
      I5 => counter_reg(16),
      O => \o_pulse0_carry__0_i_3__0_n_0\
    );
\o_pulse0_carry__0_i_4__0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"9009000000009009"
    )
        port map (
      I0 => counter_reg(12),
      I1 => \maxCountReg_reg[31]\(12),
      I2 => \maxCountReg_reg[31]\(14),
      I3 => counter_reg(14),
      I4 => \maxCountReg_reg[31]\(13),
      I5 => counter_reg(13),
      O => \o_pulse0_carry__0_i_4__0_n_0\
    );
\o_pulse0_carry__1\: unisim.vcomponents.CARRY4
     port map (
      CI => \o_pulse0_carry__0_n_0\,
      CO(3) => \NLW_o_pulse0_carry__1_CO_UNCONNECTED\(3),
      CO(2) => \o_pulse0_carry__1_n_1\,
      CO(1) => \o_pulse0_carry__1_n_2\,
      CO(0) => \o_pulse0_carry__1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => \NLW_o_pulse0_carry__1_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => \o_pulse0_carry__1_i_1__0_n_0\,
      S(1) => \o_pulse0_carry__1_i_2__0_n_0\,
      S(0) => \o_pulse0_carry__1_i_3__0_n_0\
    );
\o_pulse0_carry__1_i_1__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9009"
    )
        port map (
      I0 => counter_reg(30),
      I1 => \maxCountReg_reg[31]\(30),
      I2 => counter_reg(31),
      I3 => \maxCountReg_reg[31]\(31),
      O => \o_pulse0_carry__1_i_1__0_n_0\
    );
\o_pulse0_carry__1_i_2__0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"9009000000009009"
    )
        port map (
      I0 => counter_reg(27),
      I1 => \maxCountReg_reg[31]\(27),
      I2 => \maxCountReg_reg[31]\(29),
      I3 => counter_reg(29),
      I4 => \maxCountReg_reg[31]\(28),
      I5 => counter_reg(28),
      O => \o_pulse0_carry__1_i_2__0_n_0\
    );
\o_pulse0_carry__1_i_3__0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"9009000000009009"
    )
        port map (
      I0 => counter_reg(24),
      I1 => \maxCountReg_reg[31]\(24),
      I2 => \maxCountReg_reg[31]\(26),
      I3 => counter_reg(26),
      I4 => \maxCountReg_reg[31]\(25),
      I5 => counter_reg(25),
      O => \o_pulse0_carry__1_i_3__0_n_0\
    );
\o_pulse0_carry_i_1__0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"9009000000009009"
    )
        port map (
      I0 => counter_reg(9),
      I1 => \maxCountReg_reg[31]\(9),
      I2 => \maxCountReg_reg[31]\(11),
      I3 => counter_reg(11),
      I4 => \maxCountReg_reg[31]\(10),
      I5 => counter_reg(10),
      O => \o_pulse0_carry_i_1__0_n_0\
    );
\o_pulse0_carry_i_2__0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"9009000000009009"
    )
        port map (
      I0 => counter_reg(6),
      I1 => \maxCountReg_reg[31]\(6),
      I2 => \maxCountReg_reg[31]\(8),
      I3 => counter_reg(8),
      I4 => \maxCountReg_reg[31]\(7),
      I5 => counter_reg(7),
      O => \o_pulse0_carry_i_2__0_n_0\
    );
\o_pulse0_carry_i_3__0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"9009000000009009"
    )
        port map (
      I0 => counter_reg(3),
      I1 => \maxCountReg_reg[31]\(3),
      I2 => \maxCountReg_reg[31]\(5),
      I3 => counter_reg(5),
      I4 => \maxCountReg_reg[31]\(4),
      I5 => counter_reg(4),
      O => \o_pulse0_carry_i_3__0_n_0\
    );
\o_pulse0_carry_i_4__0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"9009000000009009"
    )
        port map (
      I0 => counter_reg(0),
      I1 => \maxCountReg_reg[31]\(0),
      I2 => \maxCountReg_reg[31]\(2),
      I3 => counter_reg(2),
      I4 => \maxCountReg_reg[31]\(1),
      I5 => counter_reg(1),
      O => \o_pulse0_carry_i_4__0_n_0\
    );
o_pulse_reg: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \o_pulse0_carry__1_n_1\,
      Q => o_pulse,
      R => '0'
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_pulseGen_4 is
  port (
    CO : out STD_LOGIC_VECTOR ( 0 to 0 );
    o_intr1_out : out STD_LOGIC;
    sel : out STD_LOGIC;
    O : out STD_LOGIC_VECTOR ( 3 downto 0 );
    \o_x_pos_reg[7]\ : out STD_LOGIC_VECTOR ( 3 downto 0 );
    \o_x_pos_reg[11]\ : out STD_LOGIC_VECTOR ( 3 downto 0 );
    \o_x_pos_reg[15]\ : out STD_LOGIC_VECTOR ( 3 downto 0 );
    s00_axi_aclk : in STD_LOGIC;
    Q : in STD_LOGIC_VECTOR ( 0 to 0 );
    o_pulse_reg_0 : in STD_LOGIC;
    p_1_in : in STD_LOGIC;
    o_pulse_reg_1 : in STD_LOGIC;
    \maxCoordinateReg_reg[30]\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \maxCountReg_reg[31]\ : in STD_LOGIC_VECTOR ( 31 downto 0 );
    posReg : in STD_LOGIC_VECTOR ( 14 downto 0 );
    \maxCoordinateReg_reg[14]\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    o_pulse : in STD_LOGIC;
    \o_x_pos_reg[12]\ : in STD_LOGIC;
    \o_x_pos_reg[4]\ : in STD_LOGIC;
    DI : in STD_LOGIC_VECTOR ( 0 to 0 );
    S : in STD_LOGIC_VECTOR ( 0 to 0 );
    \maxCoordinateReg_reg[15]\ : in STD_LOGIC_VECTOR ( 13 downto 0 );
    o_press_reg : in STD_LOGIC
  );
  attribute ORIG_REF_NAME : string;
  attribute ORIG_REF_NAME of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_pulseGen_4 : entity is "pulseGen";
end decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_pulseGen_4;

architecture STRUCTURE of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_pulseGen_4 is
  signal \counter2_carry__0_i_1_n_0\ : STD_LOGIC;
  signal \counter2_carry__0_i_2_n_0\ : STD_LOGIC;
  signal \counter2_carry__0_i_3_n_0\ : STD_LOGIC;
  signal \counter2_carry__0_i_4_n_0\ : STD_LOGIC;
  signal \counter2_carry__0_i_5_n_0\ : STD_LOGIC;
  signal \counter2_carry__0_i_6_n_0\ : STD_LOGIC;
  signal \counter2_carry__0_i_7_n_0\ : STD_LOGIC;
  signal \counter2_carry__0_i_8_n_0\ : STD_LOGIC;
  signal \counter2_carry__0_n_0\ : STD_LOGIC;
  signal \counter2_carry__0_n_1\ : STD_LOGIC;
  signal \counter2_carry__0_n_2\ : STD_LOGIC;
  signal \counter2_carry__0_n_3\ : STD_LOGIC;
  signal \counter2_carry__1_i_1_n_0\ : STD_LOGIC;
  signal \counter2_carry__1_i_2_n_0\ : STD_LOGIC;
  signal \counter2_carry__1_i_3_n_0\ : STD_LOGIC;
  signal \counter2_carry__1_i_4_n_0\ : STD_LOGIC;
  signal \counter2_carry__1_i_5_n_0\ : STD_LOGIC;
  signal \counter2_carry__1_i_6_n_0\ : STD_LOGIC;
  signal \counter2_carry__1_i_7_n_0\ : STD_LOGIC;
  signal \counter2_carry__1_i_8_n_0\ : STD_LOGIC;
  signal \counter2_carry__1_n_0\ : STD_LOGIC;
  signal \counter2_carry__1_n_1\ : STD_LOGIC;
  signal \counter2_carry__1_n_2\ : STD_LOGIC;
  signal \counter2_carry__1_n_3\ : STD_LOGIC;
  signal \counter2_carry__2_i_1_n_0\ : STD_LOGIC;
  signal \counter2_carry__2_i_2_n_0\ : STD_LOGIC;
  signal \counter2_carry__2_i_3_n_0\ : STD_LOGIC;
  signal \counter2_carry__2_i_4_n_0\ : STD_LOGIC;
  signal \counter2_carry__2_i_5_n_0\ : STD_LOGIC;
  signal \counter2_carry__2_i_6_n_0\ : STD_LOGIC;
  signal \counter2_carry__2_i_7_n_0\ : STD_LOGIC;
  signal \counter2_carry__2_i_8_n_0\ : STD_LOGIC;
  signal \counter2_carry__2_n_1\ : STD_LOGIC;
  signal \counter2_carry__2_n_2\ : STD_LOGIC;
  signal \counter2_carry__2_n_3\ : STD_LOGIC;
  signal counter2_carry_i_1_n_0 : STD_LOGIC;
  signal counter2_carry_i_2_n_0 : STD_LOGIC;
  signal counter2_carry_i_3_n_0 : STD_LOGIC;
  signal counter2_carry_i_4_n_0 : STD_LOGIC;
  signal counter2_carry_i_5_n_0 : STD_LOGIC;
  signal counter2_carry_i_6_n_0 : STD_LOGIC;
  signal counter2_carry_i_7_n_0 : STD_LOGIC;
  signal counter2_carry_i_8_n_0 : STD_LOGIC;
  signal counter2_carry_n_0 : STD_LOGIC;
  signal counter2_carry_n_1 : STD_LOGIC;
  signal counter2_carry_n_2 : STD_LOGIC;
  signal counter2_carry_n_3 : STD_LOGIC;
  signal \counter[0]_i_3__6_n_0\ : STD_LOGIC;
  signal counter_reg : STD_LOGIC_VECTOR ( 31 downto 0 );
  signal \counter_reg[0]_i_2__3_n_0\ : STD_LOGIC;
  signal \counter_reg[0]_i_2__3_n_1\ : STD_LOGIC;
  signal \counter_reg[0]_i_2__3_n_2\ : STD_LOGIC;
  signal \counter_reg[0]_i_2__3_n_3\ : STD_LOGIC;
  signal \counter_reg[0]_i_2__3_n_4\ : STD_LOGIC;
  signal \counter_reg[0]_i_2__3_n_5\ : STD_LOGIC;
  signal \counter_reg[0]_i_2__3_n_6\ : STD_LOGIC;
  signal \counter_reg[0]_i_2__3_n_7\ : STD_LOGIC;
  signal \counter_reg[12]_i_1__3_n_0\ : STD_LOGIC;
  signal \counter_reg[12]_i_1__3_n_1\ : STD_LOGIC;
  signal \counter_reg[12]_i_1__3_n_2\ : STD_LOGIC;
  signal \counter_reg[12]_i_1__3_n_3\ : STD_LOGIC;
  signal \counter_reg[12]_i_1__3_n_4\ : STD_LOGIC;
  signal \counter_reg[12]_i_1__3_n_5\ : STD_LOGIC;
  signal \counter_reg[12]_i_1__3_n_6\ : STD_LOGIC;
  signal \counter_reg[12]_i_1__3_n_7\ : STD_LOGIC;
  signal \counter_reg[16]_i_1__3_n_0\ : STD_LOGIC;
  signal \counter_reg[16]_i_1__3_n_1\ : STD_LOGIC;
  signal \counter_reg[16]_i_1__3_n_2\ : STD_LOGIC;
  signal \counter_reg[16]_i_1__3_n_3\ : STD_LOGIC;
  signal \counter_reg[16]_i_1__3_n_4\ : STD_LOGIC;
  signal \counter_reg[16]_i_1__3_n_5\ : STD_LOGIC;
  signal \counter_reg[16]_i_1__3_n_6\ : STD_LOGIC;
  signal \counter_reg[16]_i_1__3_n_7\ : STD_LOGIC;
  signal \counter_reg[20]_i_1__3_n_0\ : STD_LOGIC;
  signal \counter_reg[20]_i_1__3_n_1\ : STD_LOGIC;
  signal \counter_reg[20]_i_1__3_n_2\ : STD_LOGIC;
  signal \counter_reg[20]_i_1__3_n_3\ : STD_LOGIC;
  signal \counter_reg[20]_i_1__3_n_4\ : STD_LOGIC;
  signal \counter_reg[20]_i_1__3_n_5\ : STD_LOGIC;
  signal \counter_reg[20]_i_1__3_n_6\ : STD_LOGIC;
  signal \counter_reg[20]_i_1__3_n_7\ : STD_LOGIC;
  signal \counter_reg[24]_i_1__3_n_0\ : STD_LOGIC;
  signal \counter_reg[24]_i_1__3_n_1\ : STD_LOGIC;
  signal \counter_reg[24]_i_1__3_n_2\ : STD_LOGIC;
  signal \counter_reg[24]_i_1__3_n_3\ : STD_LOGIC;
  signal \counter_reg[24]_i_1__3_n_4\ : STD_LOGIC;
  signal \counter_reg[24]_i_1__3_n_5\ : STD_LOGIC;
  signal \counter_reg[24]_i_1__3_n_6\ : STD_LOGIC;
  signal \counter_reg[24]_i_1__3_n_7\ : STD_LOGIC;
  signal \counter_reg[28]_i_1__3_n_1\ : STD_LOGIC;
  signal \counter_reg[28]_i_1__3_n_2\ : STD_LOGIC;
  signal \counter_reg[28]_i_1__3_n_3\ : STD_LOGIC;
  signal \counter_reg[28]_i_1__3_n_4\ : STD_LOGIC;
  signal \counter_reg[28]_i_1__3_n_5\ : STD_LOGIC;
  signal \counter_reg[28]_i_1__3_n_6\ : STD_LOGIC;
  signal \counter_reg[28]_i_1__3_n_7\ : STD_LOGIC;
  signal \counter_reg[4]_i_1__3_n_0\ : STD_LOGIC;
  signal \counter_reg[4]_i_1__3_n_1\ : STD_LOGIC;
  signal \counter_reg[4]_i_1__3_n_2\ : STD_LOGIC;
  signal \counter_reg[4]_i_1__3_n_3\ : STD_LOGIC;
  signal \counter_reg[4]_i_1__3_n_4\ : STD_LOGIC;
  signal \counter_reg[4]_i_1__3_n_5\ : STD_LOGIC;
  signal \counter_reg[4]_i_1__3_n_6\ : STD_LOGIC;
  signal \counter_reg[4]_i_1__3_n_7\ : STD_LOGIC;
  signal \counter_reg[8]_i_1__3_n_0\ : STD_LOGIC;
  signal \counter_reg[8]_i_1__3_n_1\ : STD_LOGIC;
  signal \counter_reg[8]_i_1__3_n_2\ : STD_LOGIC;
  signal \counter_reg[8]_i_1__3_n_3\ : STD_LOGIC;
  signal \counter_reg[8]_i_1__3_n_4\ : STD_LOGIC;
  signal \counter_reg[8]_i_1__3_n_5\ : STD_LOGIC;
  signal \counter_reg[8]_i_1__3_n_6\ : STD_LOGIC;
  signal \counter_reg[8]_i_1__3_n_7\ : STD_LOGIC;
  signal o_intr_i_2_n_0 : STD_LOGIC;
  signal \o_pulse0_carry__0_i_1_n_0\ : STD_LOGIC;
  signal \o_pulse0_carry__0_i_2_n_0\ : STD_LOGIC;
  signal \o_pulse0_carry__0_i_3_n_0\ : STD_LOGIC;
  signal \o_pulse0_carry__0_i_4_n_0\ : STD_LOGIC;
  signal \o_pulse0_carry__0_n_0\ : STD_LOGIC;
  signal \o_pulse0_carry__0_n_1\ : STD_LOGIC;
  signal \o_pulse0_carry__0_n_2\ : STD_LOGIC;
  signal \o_pulse0_carry__0_n_3\ : STD_LOGIC;
  signal \o_pulse0_carry__1_i_1_n_0\ : STD_LOGIC;
  signal \o_pulse0_carry__1_i_2_n_0\ : STD_LOGIC;
  signal \o_pulse0_carry__1_i_3_n_0\ : STD_LOGIC;
  signal \o_pulse0_carry__1_n_1\ : STD_LOGIC;
  signal \o_pulse0_carry__1_n_2\ : STD_LOGIC;
  signal \o_pulse0_carry__1_n_3\ : STD_LOGIC;
  signal o_pulse0_carry_i_1_n_0 : STD_LOGIC;
  signal o_pulse0_carry_i_2_n_0 : STD_LOGIC;
  signal o_pulse0_carry_i_3_n_0 : STD_LOGIC;
  signal o_pulse0_carry_i_4_n_0 : STD_LOGIC;
  signal o_pulse0_carry_n_0 : STD_LOGIC;
  signal o_pulse0_carry_n_1 : STD_LOGIC;
  signal o_pulse0_carry_n_2 : STD_LOGIC;
  signal o_pulse0_carry_n_3 : STD_LOGIC;
  signal o_pulse_reg_n_0 : STD_LOGIC;
  signal \o_x_pos[0]_i_3_n_0\ : STD_LOGIC;
  signal \o_x_pos[0]_i_4_n_0\ : STD_LOGIC;
  signal \o_x_pos[0]_i_5_n_0\ : STD_LOGIC;
  signal \o_x_pos[0]_i_7_n_0\ : STD_LOGIC;
  signal \o_x_pos[0]_i_8_n_0\ : STD_LOGIC;
  signal \o_x_pos[0]_i_9_n_0\ : STD_LOGIC;
  signal \o_x_pos[12]_i_2_n_0\ : STD_LOGIC;
  signal \o_x_pos[12]_i_3_n_0\ : STD_LOGIC;
  signal \o_x_pos[12]_i_4_n_0\ : STD_LOGIC;
  signal \o_x_pos[12]_i_5_n_0\ : STD_LOGIC;
  signal \o_x_pos[12]_i_6_n_0\ : STD_LOGIC;
  signal \o_x_pos[12]_i_7_n_0\ : STD_LOGIC;
  signal \o_x_pos[12]_i_8_n_0\ : STD_LOGIC;
  signal \o_x_pos[4]_i_2_n_0\ : STD_LOGIC;
  signal \o_x_pos[4]_i_3_n_0\ : STD_LOGIC;
  signal \o_x_pos[4]_i_4_n_0\ : STD_LOGIC;
  signal \o_x_pos[4]_i_5_n_0\ : STD_LOGIC;
  signal \o_x_pos[4]_i_6_n_0\ : STD_LOGIC;
  signal \o_x_pos[4]_i_7_n_0\ : STD_LOGIC;
  signal \o_x_pos[4]_i_8_n_0\ : STD_LOGIC;
  signal \o_x_pos[4]_i_9_n_0\ : STD_LOGIC;
  signal \o_x_pos[8]_i_2_n_0\ : STD_LOGIC;
  signal \o_x_pos[8]_i_3_n_0\ : STD_LOGIC;
  signal \o_x_pos[8]_i_4_n_0\ : STD_LOGIC;
  signal \o_x_pos[8]_i_5_n_0\ : STD_LOGIC;
  signal \o_x_pos[8]_i_6_n_0\ : STD_LOGIC;
  signal \o_x_pos[8]_i_7_n_0\ : STD_LOGIC;
  signal \o_x_pos[8]_i_8_n_0\ : STD_LOGIC;
  signal \o_x_pos[8]_i_9_n_0\ : STD_LOGIC;
  signal \o_x_pos_reg[0]_i_2_n_0\ : STD_LOGIC;
  signal \o_x_pos_reg[0]_i_2_n_1\ : STD_LOGIC;
  signal \o_x_pos_reg[0]_i_2_n_2\ : STD_LOGIC;
  signal \o_x_pos_reg[0]_i_2_n_3\ : STD_LOGIC;
  signal \o_x_pos_reg[12]_i_1_n_1\ : STD_LOGIC;
  signal \o_x_pos_reg[12]_i_1_n_2\ : STD_LOGIC;
  signal \o_x_pos_reg[12]_i_1_n_3\ : STD_LOGIC;
  signal \o_x_pos_reg[4]_i_1_n_0\ : STD_LOGIC;
  signal \o_x_pos_reg[4]_i_1_n_1\ : STD_LOGIC;
  signal \o_x_pos_reg[4]_i_1_n_2\ : STD_LOGIC;
  signal \o_x_pos_reg[4]_i_1_n_3\ : STD_LOGIC;
  signal \o_x_pos_reg[8]_i_1_n_0\ : STD_LOGIC;
  signal \o_x_pos_reg[8]_i_1_n_1\ : STD_LOGIC;
  signal \o_x_pos_reg[8]_i_1_n_2\ : STD_LOGIC;
  signal \o_x_pos_reg[8]_i_1_n_3\ : STD_LOGIC;
  signal NLW_counter2_carry_O_UNCONNECTED : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_counter2_carry__0_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_counter2_carry__1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_counter2_carry__2_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_counter_reg[28]_i_1__3_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal NLW_o_pulse0_carry_O_UNCONNECTED : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_o_pulse0_carry__0_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_o_pulse0_carry__1_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_o_pulse0_carry__1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_o_x_pos_reg[12]_i_1_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
begin
counter2_carry: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => counter2_carry_n_0,
      CO(2) => counter2_carry_n_1,
      CO(1) => counter2_carry_n_2,
      CO(0) => counter2_carry_n_3,
      CYINIT => '0',
      DI(3) => counter2_carry_i_1_n_0,
      DI(2) => counter2_carry_i_2_n_0,
      DI(1) => counter2_carry_i_3_n_0,
      DI(0) => counter2_carry_i_4_n_0,
      O(3 downto 0) => NLW_counter2_carry_O_UNCONNECTED(3 downto 0),
      S(3) => counter2_carry_i_5_n_0,
      S(2) => counter2_carry_i_6_n_0,
      S(1) => counter2_carry_i_7_n_0,
      S(0) => counter2_carry_i_8_n_0
    );
\counter2_carry__0\: unisim.vcomponents.CARRY4
     port map (
      CI => counter2_carry_n_0,
      CO(3) => \counter2_carry__0_n_0\,
      CO(2) => \counter2_carry__0_n_1\,
      CO(1) => \counter2_carry__0_n_2\,
      CO(0) => \counter2_carry__0_n_3\,
      CYINIT => '0',
      DI(3) => \counter2_carry__0_i_1_n_0\,
      DI(2) => \counter2_carry__0_i_2_n_0\,
      DI(1) => \counter2_carry__0_i_3_n_0\,
      DI(0) => \counter2_carry__0_i_4_n_0\,
      O(3 downto 0) => \NLW_counter2_carry__0_O_UNCONNECTED\(3 downto 0),
      S(3) => \counter2_carry__0_i_5_n_0\,
      S(2) => \counter2_carry__0_i_6_n_0\,
      S(1) => \counter2_carry__0_i_7_n_0\,
      S(0) => \counter2_carry__0_i_8_n_0\
    );
\counter2_carry__0_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"2F02"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(14),
      I1 => counter_reg(14),
      I2 => counter_reg(15),
      I3 => \maxCountReg_reg[31]\(15),
      O => \counter2_carry__0_i_1_n_0\
    );
\counter2_carry__0_i_2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"2F02"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(12),
      I1 => counter_reg(12),
      I2 => counter_reg(13),
      I3 => \maxCountReg_reg[31]\(13),
      O => \counter2_carry__0_i_2_n_0\
    );
\counter2_carry__0_i_3\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"2F02"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(10),
      I1 => counter_reg(10),
      I2 => counter_reg(11),
      I3 => \maxCountReg_reg[31]\(11),
      O => \counter2_carry__0_i_3_n_0\
    );
\counter2_carry__0_i_4\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"2F02"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(8),
      I1 => counter_reg(8),
      I2 => counter_reg(9),
      I3 => \maxCountReg_reg[31]\(9),
      O => \counter2_carry__0_i_4_n_0\
    );
\counter2_carry__0_i_5\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9009"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(14),
      I1 => counter_reg(14),
      I2 => \maxCountReg_reg[31]\(15),
      I3 => counter_reg(15),
      O => \counter2_carry__0_i_5_n_0\
    );
\counter2_carry__0_i_6\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9009"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(12),
      I1 => counter_reg(12),
      I2 => \maxCountReg_reg[31]\(13),
      I3 => counter_reg(13),
      O => \counter2_carry__0_i_6_n_0\
    );
\counter2_carry__0_i_7\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9009"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(10),
      I1 => counter_reg(10),
      I2 => \maxCountReg_reg[31]\(11),
      I3 => counter_reg(11),
      O => \counter2_carry__0_i_7_n_0\
    );
\counter2_carry__0_i_8\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9009"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(8),
      I1 => counter_reg(8),
      I2 => \maxCountReg_reg[31]\(9),
      I3 => counter_reg(9),
      O => \counter2_carry__0_i_8_n_0\
    );
\counter2_carry__1\: unisim.vcomponents.CARRY4
     port map (
      CI => \counter2_carry__0_n_0\,
      CO(3) => \counter2_carry__1_n_0\,
      CO(2) => \counter2_carry__1_n_1\,
      CO(1) => \counter2_carry__1_n_2\,
      CO(0) => \counter2_carry__1_n_3\,
      CYINIT => '0',
      DI(3) => \counter2_carry__1_i_1_n_0\,
      DI(2) => \counter2_carry__1_i_2_n_0\,
      DI(1) => \counter2_carry__1_i_3_n_0\,
      DI(0) => \counter2_carry__1_i_4_n_0\,
      O(3 downto 0) => \NLW_counter2_carry__1_O_UNCONNECTED\(3 downto 0),
      S(3) => \counter2_carry__1_i_5_n_0\,
      S(2) => \counter2_carry__1_i_6_n_0\,
      S(1) => \counter2_carry__1_i_7_n_0\,
      S(0) => \counter2_carry__1_i_8_n_0\
    );
\counter2_carry__1_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"2F02"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(22),
      I1 => counter_reg(22),
      I2 => counter_reg(23),
      I3 => \maxCountReg_reg[31]\(23),
      O => \counter2_carry__1_i_1_n_0\
    );
\counter2_carry__1_i_2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"2F02"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(20),
      I1 => counter_reg(20),
      I2 => counter_reg(21),
      I3 => \maxCountReg_reg[31]\(21),
      O => \counter2_carry__1_i_2_n_0\
    );
\counter2_carry__1_i_3\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"2F02"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(18),
      I1 => counter_reg(18),
      I2 => counter_reg(19),
      I3 => \maxCountReg_reg[31]\(19),
      O => \counter2_carry__1_i_3_n_0\
    );
\counter2_carry__1_i_4\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"2F02"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(16),
      I1 => counter_reg(16),
      I2 => counter_reg(17),
      I3 => \maxCountReg_reg[31]\(17),
      O => \counter2_carry__1_i_4_n_0\
    );
\counter2_carry__1_i_5\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9009"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(22),
      I1 => counter_reg(22),
      I2 => \maxCountReg_reg[31]\(23),
      I3 => counter_reg(23),
      O => \counter2_carry__1_i_5_n_0\
    );
\counter2_carry__1_i_6\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9009"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(20),
      I1 => counter_reg(20),
      I2 => \maxCountReg_reg[31]\(21),
      I3 => counter_reg(21),
      O => \counter2_carry__1_i_6_n_0\
    );
\counter2_carry__1_i_7\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9009"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(18),
      I1 => counter_reg(18),
      I2 => \maxCountReg_reg[31]\(19),
      I3 => counter_reg(19),
      O => \counter2_carry__1_i_7_n_0\
    );
\counter2_carry__1_i_8\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9009"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(16),
      I1 => counter_reg(16),
      I2 => \maxCountReg_reg[31]\(17),
      I3 => counter_reg(17),
      O => \counter2_carry__1_i_8_n_0\
    );
\counter2_carry__2\: unisim.vcomponents.CARRY4
     port map (
      CI => \counter2_carry__1_n_0\,
      CO(3) => CO(0),
      CO(2) => \counter2_carry__2_n_1\,
      CO(1) => \counter2_carry__2_n_2\,
      CO(0) => \counter2_carry__2_n_3\,
      CYINIT => '0',
      DI(3) => \counter2_carry__2_i_1_n_0\,
      DI(2) => \counter2_carry__2_i_2_n_0\,
      DI(1) => \counter2_carry__2_i_3_n_0\,
      DI(0) => \counter2_carry__2_i_4_n_0\,
      O(3 downto 0) => \NLW_counter2_carry__2_O_UNCONNECTED\(3 downto 0),
      S(3) => \counter2_carry__2_i_5_n_0\,
      S(2) => \counter2_carry__2_i_6_n_0\,
      S(1) => \counter2_carry__2_i_7_n_0\,
      S(0) => \counter2_carry__2_i_8_n_0\
    );
\counter2_carry__2_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"2F02"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(30),
      I1 => counter_reg(30),
      I2 => counter_reg(31),
      I3 => \maxCountReg_reg[31]\(31),
      O => \counter2_carry__2_i_1_n_0\
    );
\counter2_carry__2_i_2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"2F02"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(28),
      I1 => counter_reg(28),
      I2 => counter_reg(29),
      I3 => \maxCountReg_reg[31]\(29),
      O => \counter2_carry__2_i_2_n_0\
    );
\counter2_carry__2_i_3\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"2F02"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(26),
      I1 => counter_reg(26),
      I2 => counter_reg(27),
      I3 => \maxCountReg_reg[31]\(27),
      O => \counter2_carry__2_i_3_n_0\
    );
\counter2_carry__2_i_4\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"2F02"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(24),
      I1 => counter_reg(24),
      I2 => counter_reg(25),
      I3 => \maxCountReg_reg[31]\(25),
      O => \counter2_carry__2_i_4_n_0\
    );
\counter2_carry__2_i_5\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9009"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(30),
      I1 => counter_reg(30),
      I2 => \maxCountReg_reg[31]\(31),
      I3 => counter_reg(31),
      O => \counter2_carry__2_i_5_n_0\
    );
\counter2_carry__2_i_6\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9009"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(28),
      I1 => counter_reg(28),
      I2 => \maxCountReg_reg[31]\(29),
      I3 => counter_reg(29),
      O => \counter2_carry__2_i_6_n_0\
    );
\counter2_carry__2_i_7\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9009"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(26),
      I1 => counter_reg(26),
      I2 => \maxCountReg_reg[31]\(27),
      I3 => counter_reg(27),
      O => \counter2_carry__2_i_7_n_0\
    );
\counter2_carry__2_i_8\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9009"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(24),
      I1 => counter_reg(24),
      I2 => \maxCountReg_reg[31]\(25),
      I3 => counter_reg(25),
      O => \counter2_carry__2_i_8_n_0\
    );
counter2_carry_i_1: unisim.vcomponents.LUT4
    generic map(
      INIT => X"2F02"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(6),
      I1 => counter_reg(6),
      I2 => counter_reg(7),
      I3 => \maxCountReg_reg[31]\(7),
      O => counter2_carry_i_1_n_0
    );
counter2_carry_i_2: unisim.vcomponents.LUT4
    generic map(
      INIT => X"2F02"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(4),
      I1 => counter_reg(4),
      I2 => counter_reg(5),
      I3 => \maxCountReg_reg[31]\(5),
      O => counter2_carry_i_2_n_0
    );
counter2_carry_i_3: unisim.vcomponents.LUT4
    generic map(
      INIT => X"2F02"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(2),
      I1 => counter_reg(2),
      I2 => counter_reg(3),
      I3 => \maxCountReg_reg[31]\(3),
      O => counter2_carry_i_3_n_0
    );
counter2_carry_i_4: unisim.vcomponents.LUT4
    generic map(
      INIT => X"2F02"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(0),
      I1 => counter_reg(0),
      I2 => counter_reg(1),
      I3 => \maxCountReg_reg[31]\(1),
      O => counter2_carry_i_4_n_0
    );
counter2_carry_i_5: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9009"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(6),
      I1 => counter_reg(6),
      I2 => \maxCountReg_reg[31]\(7),
      I3 => counter_reg(7),
      O => counter2_carry_i_5_n_0
    );
counter2_carry_i_6: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9009"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(4),
      I1 => counter_reg(4),
      I2 => \maxCountReg_reg[31]\(5),
      I3 => counter_reg(5),
      O => counter2_carry_i_6_n_0
    );
counter2_carry_i_7: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9009"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(2),
      I1 => counter_reg(2),
      I2 => \maxCountReg_reg[31]\(3),
      I3 => counter_reg(3),
      O => counter2_carry_i_7_n_0
    );
counter2_carry_i_8: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9009"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(0),
      I1 => counter_reg(0),
      I2 => \maxCountReg_reg[31]\(1),
      I3 => counter_reg(1),
      O => counter2_carry_i_8_n_0
    );
\counter[0]_i_3__6\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => counter_reg(0),
      O => \counter[0]_i_3__6_n_0\
    );
\counter_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[0]_i_2__3_n_7\,
      Q => counter_reg(0),
      R => o_press_reg
    );
\counter_reg[0]_i_2__3\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \counter_reg[0]_i_2__3_n_0\,
      CO(2) => \counter_reg[0]_i_2__3_n_1\,
      CO(1) => \counter_reg[0]_i_2__3_n_2\,
      CO(0) => \counter_reg[0]_i_2__3_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0001",
      O(3) => \counter_reg[0]_i_2__3_n_4\,
      O(2) => \counter_reg[0]_i_2__3_n_5\,
      O(1) => \counter_reg[0]_i_2__3_n_6\,
      O(0) => \counter_reg[0]_i_2__3_n_7\,
      S(3 downto 1) => counter_reg(3 downto 1),
      S(0) => \counter[0]_i_3__6_n_0\
    );
\counter_reg[10]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[8]_i_1__3_n_5\,
      Q => counter_reg(10),
      R => o_press_reg
    );
\counter_reg[11]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[8]_i_1__3_n_4\,
      Q => counter_reg(11),
      R => o_press_reg
    );
\counter_reg[12]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[12]_i_1__3_n_7\,
      Q => counter_reg(12),
      R => o_press_reg
    );
\counter_reg[12]_i_1__3\: unisim.vcomponents.CARRY4
     port map (
      CI => \counter_reg[8]_i_1__3_n_0\,
      CO(3) => \counter_reg[12]_i_1__3_n_0\,
      CO(2) => \counter_reg[12]_i_1__3_n_1\,
      CO(1) => \counter_reg[12]_i_1__3_n_2\,
      CO(0) => \counter_reg[12]_i_1__3_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \counter_reg[12]_i_1__3_n_4\,
      O(2) => \counter_reg[12]_i_1__3_n_5\,
      O(1) => \counter_reg[12]_i_1__3_n_6\,
      O(0) => \counter_reg[12]_i_1__3_n_7\,
      S(3 downto 0) => counter_reg(15 downto 12)
    );
\counter_reg[13]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[12]_i_1__3_n_6\,
      Q => counter_reg(13),
      R => o_press_reg
    );
\counter_reg[14]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[12]_i_1__3_n_5\,
      Q => counter_reg(14),
      R => o_press_reg
    );
\counter_reg[15]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[12]_i_1__3_n_4\,
      Q => counter_reg(15),
      R => o_press_reg
    );
\counter_reg[16]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[16]_i_1__3_n_7\,
      Q => counter_reg(16),
      R => o_press_reg
    );
\counter_reg[16]_i_1__3\: unisim.vcomponents.CARRY4
     port map (
      CI => \counter_reg[12]_i_1__3_n_0\,
      CO(3) => \counter_reg[16]_i_1__3_n_0\,
      CO(2) => \counter_reg[16]_i_1__3_n_1\,
      CO(1) => \counter_reg[16]_i_1__3_n_2\,
      CO(0) => \counter_reg[16]_i_1__3_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \counter_reg[16]_i_1__3_n_4\,
      O(2) => \counter_reg[16]_i_1__3_n_5\,
      O(1) => \counter_reg[16]_i_1__3_n_6\,
      O(0) => \counter_reg[16]_i_1__3_n_7\,
      S(3 downto 0) => counter_reg(19 downto 16)
    );
\counter_reg[17]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[16]_i_1__3_n_6\,
      Q => counter_reg(17),
      R => o_press_reg
    );
\counter_reg[18]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[16]_i_1__3_n_5\,
      Q => counter_reg(18),
      R => o_press_reg
    );
\counter_reg[19]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[16]_i_1__3_n_4\,
      Q => counter_reg(19),
      R => o_press_reg
    );
\counter_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[0]_i_2__3_n_6\,
      Q => counter_reg(1),
      R => o_press_reg
    );
\counter_reg[20]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[20]_i_1__3_n_7\,
      Q => counter_reg(20),
      R => o_press_reg
    );
\counter_reg[20]_i_1__3\: unisim.vcomponents.CARRY4
     port map (
      CI => \counter_reg[16]_i_1__3_n_0\,
      CO(3) => \counter_reg[20]_i_1__3_n_0\,
      CO(2) => \counter_reg[20]_i_1__3_n_1\,
      CO(1) => \counter_reg[20]_i_1__3_n_2\,
      CO(0) => \counter_reg[20]_i_1__3_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \counter_reg[20]_i_1__3_n_4\,
      O(2) => \counter_reg[20]_i_1__3_n_5\,
      O(1) => \counter_reg[20]_i_1__3_n_6\,
      O(0) => \counter_reg[20]_i_1__3_n_7\,
      S(3 downto 0) => counter_reg(23 downto 20)
    );
\counter_reg[21]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[20]_i_1__3_n_6\,
      Q => counter_reg(21),
      R => o_press_reg
    );
\counter_reg[22]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[20]_i_1__3_n_5\,
      Q => counter_reg(22),
      R => o_press_reg
    );
\counter_reg[23]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[20]_i_1__3_n_4\,
      Q => counter_reg(23),
      R => o_press_reg
    );
\counter_reg[24]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[24]_i_1__3_n_7\,
      Q => counter_reg(24),
      R => o_press_reg
    );
\counter_reg[24]_i_1__3\: unisim.vcomponents.CARRY4
     port map (
      CI => \counter_reg[20]_i_1__3_n_0\,
      CO(3) => \counter_reg[24]_i_1__3_n_0\,
      CO(2) => \counter_reg[24]_i_1__3_n_1\,
      CO(1) => \counter_reg[24]_i_1__3_n_2\,
      CO(0) => \counter_reg[24]_i_1__3_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \counter_reg[24]_i_1__3_n_4\,
      O(2) => \counter_reg[24]_i_1__3_n_5\,
      O(1) => \counter_reg[24]_i_1__3_n_6\,
      O(0) => \counter_reg[24]_i_1__3_n_7\,
      S(3 downto 0) => counter_reg(27 downto 24)
    );
\counter_reg[25]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[24]_i_1__3_n_6\,
      Q => counter_reg(25),
      R => o_press_reg
    );
\counter_reg[26]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[24]_i_1__3_n_5\,
      Q => counter_reg(26),
      R => o_press_reg
    );
\counter_reg[27]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[24]_i_1__3_n_4\,
      Q => counter_reg(27),
      R => o_press_reg
    );
\counter_reg[28]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[28]_i_1__3_n_7\,
      Q => counter_reg(28),
      R => o_press_reg
    );
\counter_reg[28]_i_1__3\: unisim.vcomponents.CARRY4
     port map (
      CI => \counter_reg[24]_i_1__3_n_0\,
      CO(3) => \NLW_counter_reg[28]_i_1__3_CO_UNCONNECTED\(3),
      CO(2) => \counter_reg[28]_i_1__3_n_1\,
      CO(1) => \counter_reg[28]_i_1__3_n_2\,
      CO(0) => \counter_reg[28]_i_1__3_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \counter_reg[28]_i_1__3_n_4\,
      O(2) => \counter_reg[28]_i_1__3_n_5\,
      O(1) => \counter_reg[28]_i_1__3_n_6\,
      O(0) => \counter_reg[28]_i_1__3_n_7\,
      S(3 downto 0) => counter_reg(31 downto 28)
    );
\counter_reg[29]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[28]_i_1__3_n_6\,
      Q => counter_reg(29),
      R => o_press_reg
    );
\counter_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[0]_i_2__3_n_5\,
      Q => counter_reg(2),
      R => o_press_reg
    );
\counter_reg[30]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[28]_i_1__3_n_5\,
      Q => counter_reg(30),
      R => o_press_reg
    );
\counter_reg[31]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[28]_i_1__3_n_4\,
      Q => counter_reg(31),
      R => o_press_reg
    );
\counter_reg[3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[0]_i_2__3_n_4\,
      Q => counter_reg(3),
      R => o_press_reg
    );
\counter_reg[4]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[4]_i_1__3_n_7\,
      Q => counter_reg(4),
      R => o_press_reg
    );
\counter_reg[4]_i_1__3\: unisim.vcomponents.CARRY4
     port map (
      CI => \counter_reg[0]_i_2__3_n_0\,
      CO(3) => \counter_reg[4]_i_1__3_n_0\,
      CO(2) => \counter_reg[4]_i_1__3_n_1\,
      CO(1) => \counter_reg[4]_i_1__3_n_2\,
      CO(0) => \counter_reg[4]_i_1__3_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \counter_reg[4]_i_1__3_n_4\,
      O(2) => \counter_reg[4]_i_1__3_n_5\,
      O(1) => \counter_reg[4]_i_1__3_n_6\,
      O(0) => \counter_reg[4]_i_1__3_n_7\,
      S(3 downto 0) => counter_reg(7 downto 4)
    );
\counter_reg[5]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[4]_i_1__3_n_6\,
      Q => counter_reg(5),
      R => o_press_reg
    );
\counter_reg[6]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[4]_i_1__3_n_5\,
      Q => counter_reg(6),
      R => o_press_reg
    );
\counter_reg[7]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[4]_i_1__3_n_4\,
      Q => counter_reg(7),
      R => o_press_reg
    );
\counter_reg[8]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[8]_i_1__3_n_7\,
      Q => counter_reg(8),
      R => o_press_reg
    );
\counter_reg[8]_i_1__3\: unisim.vcomponents.CARRY4
     port map (
      CI => \counter_reg[4]_i_1__3_n_0\,
      CO(3) => \counter_reg[8]_i_1__3_n_0\,
      CO(2) => \counter_reg[8]_i_1__3_n_1\,
      CO(1) => \counter_reg[8]_i_1__3_n_2\,
      CO(0) => \counter_reg[8]_i_1__3_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \counter_reg[8]_i_1__3_n_4\,
      O(2) => \counter_reg[8]_i_1__3_n_5\,
      O(1) => \counter_reg[8]_i_1__3_n_6\,
      O(0) => \counter_reg[8]_i_1__3_n_7\,
      S(3 downto 0) => counter_reg(11 downto 8)
    );
\counter_reg[9]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[8]_i_1__3_n_6\,
      Q => counter_reg(9),
      R => o_press_reg
    );
o_intr_i_1: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000FFEAAAEA"
    )
        port map (
      I0 => o_intr_i_2_n_0,
      I1 => o_pulse_reg_0,
      I2 => p_1_in,
      I3 => o_pulse_reg_1,
      I4 => \maxCoordinateReg_reg[30]\(0),
      I5 => Q(0),
      O => o_intr1_out
    );
o_intr_i_2: unisim.vcomponents.LUT5
    generic map(
      INIT => X"88B8B8B8"
    )
        port map (
      I0 => \maxCoordinateReg_reg[14]\(0),
      I1 => o_pulse_reg_n_0,
      I2 => o_pulse,
      I3 => \o_x_pos_reg[12]\,
      I4 => \o_x_pos_reg[4]\,
      O => o_intr_i_2_n_0
    );
o_pulse0_carry: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => o_pulse0_carry_n_0,
      CO(2) => o_pulse0_carry_n_1,
      CO(1) => o_pulse0_carry_n_2,
      CO(0) => o_pulse0_carry_n_3,
      CYINIT => '1',
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => NLW_o_pulse0_carry_O_UNCONNECTED(3 downto 0),
      S(3) => o_pulse0_carry_i_1_n_0,
      S(2) => o_pulse0_carry_i_2_n_0,
      S(1) => o_pulse0_carry_i_3_n_0,
      S(0) => o_pulse0_carry_i_4_n_0
    );
\o_pulse0_carry__0\: unisim.vcomponents.CARRY4
     port map (
      CI => o_pulse0_carry_n_0,
      CO(3) => \o_pulse0_carry__0_n_0\,
      CO(2) => \o_pulse0_carry__0_n_1\,
      CO(1) => \o_pulse0_carry__0_n_2\,
      CO(0) => \o_pulse0_carry__0_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => \NLW_o_pulse0_carry__0_O_UNCONNECTED\(3 downto 0),
      S(3) => \o_pulse0_carry__0_i_1_n_0\,
      S(2) => \o_pulse0_carry__0_i_2_n_0\,
      S(1) => \o_pulse0_carry__0_i_3_n_0\,
      S(0) => \o_pulse0_carry__0_i_4_n_0\
    );
\o_pulse0_carry__0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"9009000000009009"
    )
        port map (
      I0 => counter_reg(21),
      I1 => \maxCountReg_reg[31]\(21),
      I2 => \maxCountReg_reg[31]\(23),
      I3 => counter_reg(23),
      I4 => \maxCountReg_reg[31]\(22),
      I5 => counter_reg(22),
      O => \o_pulse0_carry__0_i_1_n_0\
    );
\o_pulse0_carry__0_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"9009000000009009"
    )
        port map (
      I0 => counter_reg(18),
      I1 => \maxCountReg_reg[31]\(18),
      I2 => \maxCountReg_reg[31]\(20),
      I3 => counter_reg(20),
      I4 => \maxCountReg_reg[31]\(19),
      I5 => counter_reg(19),
      O => \o_pulse0_carry__0_i_2_n_0\
    );
\o_pulse0_carry__0_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"9009000000009009"
    )
        port map (
      I0 => counter_reg(15),
      I1 => \maxCountReg_reg[31]\(15),
      I2 => \maxCountReg_reg[31]\(17),
      I3 => counter_reg(17),
      I4 => \maxCountReg_reg[31]\(16),
      I5 => counter_reg(16),
      O => \o_pulse0_carry__0_i_3_n_0\
    );
\o_pulse0_carry__0_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"9009000000009009"
    )
        port map (
      I0 => counter_reg(12),
      I1 => \maxCountReg_reg[31]\(12),
      I2 => \maxCountReg_reg[31]\(14),
      I3 => counter_reg(14),
      I4 => \maxCountReg_reg[31]\(13),
      I5 => counter_reg(13),
      O => \o_pulse0_carry__0_i_4_n_0\
    );
\o_pulse0_carry__1\: unisim.vcomponents.CARRY4
     port map (
      CI => \o_pulse0_carry__0_n_0\,
      CO(3) => \NLW_o_pulse0_carry__1_CO_UNCONNECTED\(3),
      CO(2) => \o_pulse0_carry__1_n_1\,
      CO(1) => \o_pulse0_carry__1_n_2\,
      CO(0) => \o_pulse0_carry__1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => \NLW_o_pulse0_carry__1_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => \o_pulse0_carry__1_i_1_n_0\,
      S(1) => \o_pulse0_carry__1_i_2_n_0\,
      S(0) => \o_pulse0_carry__1_i_3_n_0\
    );
\o_pulse0_carry__1_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9009"
    )
        port map (
      I0 => counter_reg(30),
      I1 => \maxCountReg_reg[31]\(30),
      I2 => counter_reg(31),
      I3 => \maxCountReg_reg[31]\(31),
      O => \o_pulse0_carry__1_i_1_n_0\
    );
\o_pulse0_carry__1_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"9009000000009009"
    )
        port map (
      I0 => counter_reg(27),
      I1 => \maxCountReg_reg[31]\(27),
      I2 => \maxCountReg_reg[31]\(29),
      I3 => counter_reg(29),
      I4 => \maxCountReg_reg[31]\(28),
      I5 => counter_reg(28),
      O => \o_pulse0_carry__1_i_2_n_0\
    );
\o_pulse0_carry__1_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"9009000000009009"
    )
        port map (
      I0 => counter_reg(24),
      I1 => \maxCountReg_reg[31]\(24),
      I2 => \maxCountReg_reg[31]\(26),
      I3 => counter_reg(26),
      I4 => \maxCountReg_reg[31]\(25),
      I5 => counter_reg(25),
      O => \o_pulse0_carry__1_i_3_n_0\
    );
o_pulse0_carry_i_1: unisim.vcomponents.LUT6
    generic map(
      INIT => X"9009000000009009"
    )
        port map (
      I0 => counter_reg(9),
      I1 => \maxCountReg_reg[31]\(9),
      I2 => \maxCountReg_reg[31]\(11),
      I3 => counter_reg(11),
      I4 => \maxCountReg_reg[31]\(10),
      I5 => counter_reg(10),
      O => o_pulse0_carry_i_1_n_0
    );
o_pulse0_carry_i_2: unisim.vcomponents.LUT6
    generic map(
      INIT => X"9009000000009009"
    )
        port map (
      I0 => counter_reg(6),
      I1 => \maxCountReg_reg[31]\(6),
      I2 => \maxCountReg_reg[31]\(8),
      I3 => counter_reg(8),
      I4 => \maxCountReg_reg[31]\(7),
      I5 => counter_reg(7),
      O => o_pulse0_carry_i_2_n_0
    );
o_pulse0_carry_i_3: unisim.vcomponents.LUT6
    generic map(
      INIT => X"9009000000009009"
    )
        port map (
      I0 => counter_reg(3),
      I1 => \maxCountReg_reg[31]\(3),
      I2 => \maxCountReg_reg[31]\(5),
      I3 => counter_reg(5),
      I4 => \maxCountReg_reg[31]\(4),
      I5 => counter_reg(4),
      O => o_pulse0_carry_i_3_n_0
    );
o_pulse0_carry_i_4: unisim.vcomponents.LUT6
    generic map(
      INIT => X"9009000000009009"
    )
        port map (
      I0 => counter_reg(0),
      I1 => \maxCountReg_reg[31]\(0),
      I2 => \maxCountReg_reg[31]\(2),
      I3 => counter_reg(2),
      I4 => \maxCountReg_reg[31]\(1),
      I5 => counter_reg(1),
      O => o_pulse0_carry_i_4_n_0
    );
o_pulse_reg: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \o_pulse0_carry__1_n_1\,
      Q => o_pulse_reg_n_0,
      R => '0'
    );
\o_x_pos[0]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => Q(0),
      I1 => o_intr_i_2_n_0,
      O => sel
    );
\o_x_pos[0]_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => o_pulse_reg_n_0,
      I1 => Q(0),
      O => \o_x_pos[0]_i_3_n_0\
    );
\o_x_pos[0]_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => o_pulse_reg_n_0,
      I1 => Q(0),
      O => \o_x_pos[0]_i_4_n_0\
    );
\o_x_pos[0]_i_5\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => o_pulse_reg_n_0,
      I1 => Q(0),
      O => \o_x_pos[0]_i_5_n_0\
    );
\o_x_pos[0]_i_7\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"F909"
    )
        port map (
      I0 => o_pulse_reg_n_0,
      I1 => posReg(2),
      I2 => Q(0),
      I3 => \maxCoordinateReg_reg[15]\(2),
      O => \o_x_pos[0]_i_7_n_0\
    );
\o_x_pos[0]_i_8\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"F909"
    )
        port map (
      I0 => o_pulse_reg_n_0,
      I1 => posReg(1),
      I2 => Q(0),
      I3 => \maxCoordinateReg_reg[15]\(1),
      O => \o_x_pos[0]_i_8_n_0\
    );
\o_x_pos[0]_i_9\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"F909"
    )
        port map (
      I0 => o_pulse_reg_n_0,
      I1 => posReg(0),
      I2 => Q(0),
      I3 => \maxCoordinateReg_reg[15]\(0),
      O => \o_x_pos[0]_i_9_n_0\
    );
\o_x_pos[12]_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => o_pulse_reg_n_0,
      I1 => Q(0),
      O => \o_x_pos[12]_i_2_n_0\
    );
\o_x_pos[12]_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => o_pulse_reg_n_0,
      I1 => Q(0),
      O => \o_x_pos[12]_i_3_n_0\
    );
\o_x_pos[12]_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => o_pulse_reg_n_0,
      I1 => Q(0),
      O => \o_x_pos[12]_i_4_n_0\
    );
\o_x_pos[12]_i_5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"21"
    )
        port map (
      I0 => o_pulse_reg_n_0,
      I1 => Q(0),
      I2 => posReg(14),
      O => \o_x_pos[12]_i_5_n_0\
    );
\o_x_pos[12]_i_6\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"F909"
    )
        port map (
      I0 => o_pulse_reg_n_0,
      I1 => posReg(13),
      I2 => Q(0),
      I3 => \maxCoordinateReg_reg[15]\(13),
      O => \o_x_pos[12]_i_6_n_0\
    );
\o_x_pos[12]_i_7\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"F909"
    )
        port map (
      I0 => o_pulse_reg_n_0,
      I1 => posReg(12),
      I2 => Q(0),
      I3 => \maxCoordinateReg_reg[15]\(12),
      O => \o_x_pos[12]_i_7_n_0\
    );
\o_x_pos[12]_i_8\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"F909"
    )
        port map (
      I0 => o_pulse_reg_n_0,
      I1 => posReg(11),
      I2 => Q(0),
      I3 => \maxCoordinateReg_reg[15]\(11),
      O => \o_x_pos[12]_i_8_n_0\
    );
\o_x_pos[4]_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => o_pulse_reg_n_0,
      I1 => Q(0),
      O => \o_x_pos[4]_i_2_n_0\
    );
\o_x_pos[4]_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => o_pulse_reg_n_0,
      I1 => Q(0),
      O => \o_x_pos[4]_i_3_n_0\
    );
\o_x_pos[4]_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => o_pulse_reg_n_0,
      I1 => Q(0),
      O => \o_x_pos[4]_i_4_n_0\
    );
\o_x_pos[4]_i_5\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => o_pulse_reg_n_0,
      I1 => Q(0),
      O => \o_x_pos[4]_i_5_n_0\
    );
\o_x_pos[4]_i_6\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"F909"
    )
        port map (
      I0 => o_pulse_reg_n_0,
      I1 => posReg(6),
      I2 => Q(0),
      I3 => \maxCoordinateReg_reg[15]\(6),
      O => \o_x_pos[4]_i_6_n_0\
    );
\o_x_pos[4]_i_7\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"F909"
    )
        port map (
      I0 => o_pulse_reg_n_0,
      I1 => posReg(5),
      I2 => Q(0),
      I3 => \maxCoordinateReg_reg[15]\(5),
      O => \o_x_pos[4]_i_7_n_0\
    );
\o_x_pos[4]_i_8\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"F909"
    )
        port map (
      I0 => o_pulse_reg_n_0,
      I1 => posReg(4),
      I2 => Q(0),
      I3 => \maxCoordinateReg_reg[15]\(4),
      O => \o_x_pos[4]_i_8_n_0\
    );
\o_x_pos[4]_i_9\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"F909"
    )
        port map (
      I0 => o_pulse_reg_n_0,
      I1 => posReg(3),
      I2 => Q(0),
      I3 => \maxCoordinateReg_reg[15]\(3),
      O => \o_x_pos[4]_i_9_n_0\
    );
\o_x_pos[8]_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => o_pulse_reg_n_0,
      I1 => Q(0),
      O => \o_x_pos[8]_i_2_n_0\
    );
\o_x_pos[8]_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => o_pulse_reg_n_0,
      I1 => Q(0),
      O => \o_x_pos[8]_i_3_n_0\
    );
\o_x_pos[8]_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => o_pulse_reg_n_0,
      I1 => Q(0),
      O => \o_x_pos[8]_i_4_n_0\
    );
\o_x_pos[8]_i_5\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => o_pulse_reg_n_0,
      I1 => Q(0),
      O => \o_x_pos[8]_i_5_n_0\
    );
\o_x_pos[8]_i_6\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"F909"
    )
        port map (
      I0 => o_pulse_reg_n_0,
      I1 => posReg(10),
      I2 => Q(0),
      I3 => \maxCoordinateReg_reg[15]\(10),
      O => \o_x_pos[8]_i_6_n_0\
    );
\o_x_pos[8]_i_7\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"F909"
    )
        port map (
      I0 => o_pulse_reg_n_0,
      I1 => posReg(9),
      I2 => Q(0),
      I3 => \maxCoordinateReg_reg[15]\(9),
      O => \o_x_pos[8]_i_7_n_0\
    );
\o_x_pos[8]_i_8\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"F909"
    )
        port map (
      I0 => o_pulse_reg_n_0,
      I1 => posReg(8),
      I2 => Q(0),
      I3 => \maxCoordinateReg_reg[15]\(8),
      O => \o_x_pos[8]_i_8_n_0\
    );
\o_x_pos[8]_i_9\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"F909"
    )
        port map (
      I0 => o_pulse_reg_n_0,
      I1 => posReg(7),
      I2 => Q(0),
      I3 => \maxCoordinateReg_reg[15]\(7),
      O => \o_x_pos[8]_i_9_n_0\
    );
\o_x_pos_reg[0]_i_2\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \o_x_pos_reg[0]_i_2_n_0\,
      CO(2) => \o_x_pos_reg[0]_i_2_n_1\,
      CO(1) => \o_x_pos_reg[0]_i_2_n_2\,
      CO(0) => \o_x_pos_reg[0]_i_2_n_3\,
      CYINIT => '0',
      DI(3) => \o_x_pos[0]_i_3_n_0\,
      DI(2) => \o_x_pos[0]_i_4_n_0\,
      DI(1) => \o_x_pos[0]_i_5_n_0\,
      DI(0) => DI(0),
      O(3 downto 0) => O(3 downto 0),
      S(3) => \o_x_pos[0]_i_7_n_0\,
      S(2) => \o_x_pos[0]_i_8_n_0\,
      S(1) => \o_x_pos[0]_i_9_n_0\,
      S(0) => S(0)
    );
\o_x_pos_reg[12]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \o_x_pos_reg[8]_i_1_n_0\,
      CO(3) => \NLW_o_x_pos_reg[12]_i_1_CO_UNCONNECTED\(3),
      CO(2) => \o_x_pos_reg[12]_i_1_n_1\,
      CO(1) => \o_x_pos_reg[12]_i_1_n_2\,
      CO(0) => \o_x_pos_reg[12]_i_1_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => \o_x_pos[12]_i_2_n_0\,
      DI(1) => \o_x_pos[12]_i_3_n_0\,
      DI(0) => \o_x_pos[12]_i_4_n_0\,
      O(3 downto 0) => \o_x_pos_reg[15]\(3 downto 0),
      S(3) => \o_x_pos[12]_i_5_n_0\,
      S(2) => \o_x_pos[12]_i_6_n_0\,
      S(1) => \o_x_pos[12]_i_7_n_0\,
      S(0) => \o_x_pos[12]_i_8_n_0\
    );
\o_x_pos_reg[4]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \o_x_pos_reg[0]_i_2_n_0\,
      CO(3) => \o_x_pos_reg[4]_i_1_n_0\,
      CO(2) => \o_x_pos_reg[4]_i_1_n_1\,
      CO(1) => \o_x_pos_reg[4]_i_1_n_2\,
      CO(0) => \o_x_pos_reg[4]_i_1_n_3\,
      CYINIT => '0',
      DI(3) => \o_x_pos[4]_i_2_n_0\,
      DI(2) => \o_x_pos[4]_i_3_n_0\,
      DI(1) => \o_x_pos[4]_i_4_n_0\,
      DI(0) => \o_x_pos[4]_i_5_n_0\,
      O(3 downto 0) => \o_x_pos_reg[7]\(3 downto 0),
      S(3) => \o_x_pos[4]_i_6_n_0\,
      S(2) => \o_x_pos[4]_i_7_n_0\,
      S(1) => \o_x_pos[4]_i_8_n_0\,
      S(0) => \o_x_pos[4]_i_9_n_0\
    );
\o_x_pos_reg[8]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \o_x_pos_reg[4]_i_1_n_0\,
      CO(3) => \o_x_pos_reg[8]_i_1_n_0\,
      CO(2) => \o_x_pos_reg[8]_i_1_n_1\,
      CO(1) => \o_x_pos_reg[8]_i_1_n_2\,
      CO(0) => \o_x_pos_reg[8]_i_1_n_3\,
      CYINIT => '0',
      DI(3) => \o_x_pos[8]_i_2_n_0\,
      DI(2) => \o_x_pos[8]_i_3_n_0\,
      DI(1) => \o_x_pos[8]_i_4_n_0\,
      DI(0) => \o_x_pos[8]_i_5_n_0\,
      O(3 downto 0) => \o_x_pos_reg[11]\(3 downto 0),
      S(3) => \o_x_pos[8]_i_6_n_0\,
      S(2) => \o_x_pos[8]_i_7_n_0\,
      S(1) => \o_x_pos[8]_i_8_n_0\,
      S(0) => \o_x_pos[8]_i_9_n_0\
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_pulseGen_5 is
  port (
    \o_y_pos_reg[0]\ : out STD_LOGIC;
    CO : out STD_LOGIC_VECTOR ( 0 to 0 );
    \o_y_pos_reg[0]_0\ : out STD_LOGIC;
    s00_axi_aclk : in STD_LOGIC;
    \maxCountReg_reg[31]\ : in STD_LOGIC_VECTOR ( 31 downto 0 );
    Q : in STD_LOGIC_VECTOR ( 0 to 0 );
    p_1_in : in STD_LOGIC;
    o_pulse_reg_0 : in STD_LOGIC;
    \maxCoordinateReg_reg[30]\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    o_press_reg : in STD_LOGIC
  );
  attribute ORIG_REF_NAME : string;
  attribute ORIG_REF_NAME of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_pulseGen_5 : entity is "pulseGen";
end decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_pulseGen_5;

architecture STRUCTURE of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_pulseGen_5 is
  signal \counter2_carry__0_i_1__2_n_0\ : STD_LOGIC;
  signal \counter2_carry__0_i_2__2_n_0\ : STD_LOGIC;
  signal \counter2_carry__0_i_3__2_n_0\ : STD_LOGIC;
  signal \counter2_carry__0_i_4__2_n_0\ : STD_LOGIC;
  signal \counter2_carry__0_i_5__2_n_0\ : STD_LOGIC;
  signal \counter2_carry__0_i_6__2_n_0\ : STD_LOGIC;
  signal \counter2_carry__0_i_7__2_n_0\ : STD_LOGIC;
  signal \counter2_carry__0_i_8__2_n_0\ : STD_LOGIC;
  signal \counter2_carry__0_n_0\ : STD_LOGIC;
  signal \counter2_carry__0_n_1\ : STD_LOGIC;
  signal \counter2_carry__0_n_2\ : STD_LOGIC;
  signal \counter2_carry__0_n_3\ : STD_LOGIC;
  signal \counter2_carry__1_i_1__2_n_0\ : STD_LOGIC;
  signal \counter2_carry__1_i_2__2_n_0\ : STD_LOGIC;
  signal \counter2_carry__1_i_3__2_n_0\ : STD_LOGIC;
  signal \counter2_carry__1_i_4__2_n_0\ : STD_LOGIC;
  signal \counter2_carry__1_i_5__2_n_0\ : STD_LOGIC;
  signal \counter2_carry__1_i_6__2_n_0\ : STD_LOGIC;
  signal \counter2_carry__1_i_7__2_n_0\ : STD_LOGIC;
  signal \counter2_carry__1_i_8__2_n_0\ : STD_LOGIC;
  signal \counter2_carry__1_n_0\ : STD_LOGIC;
  signal \counter2_carry__1_n_1\ : STD_LOGIC;
  signal \counter2_carry__1_n_2\ : STD_LOGIC;
  signal \counter2_carry__1_n_3\ : STD_LOGIC;
  signal \counter2_carry__2_i_1__2_n_0\ : STD_LOGIC;
  signal \counter2_carry__2_i_2__2_n_0\ : STD_LOGIC;
  signal \counter2_carry__2_i_3__2_n_0\ : STD_LOGIC;
  signal \counter2_carry__2_i_4__2_n_0\ : STD_LOGIC;
  signal \counter2_carry__2_i_5__2_n_0\ : STD_LOGIC;
  signal \counter2_carry__2_i_6__2_n_0\ : STD_LOGIC;
  signal \counter2_carry__2_i_7__2_n_0\ : STD_LOGIC;
  signal \counter2_carry__2_i_8__2_n_0\ : STD_LOGIC;
  signal \counter2_carry__2_n_1\ : STD_LOGIC;
  signal \counter2_carry__2_n_2\ : STD_LOGIC;
  signal \counter2_carry__2_n_3\ : STD_LOGIC;
  signal \counter2_carry_i_1__2_n_0\ : STD_LOGIC;
  signal \counter2_carry_i_2__2_n_0\ : STD_LOGIC;
  signal \counter2_carry_i_3__2_n_0\ : STD_LOGIC;
  signal \counter2_carry_i_4__2_n_0\ : STD_LOGIC;
  signal \counter2_carry_i_5__2_n_0\ : STD_LOGIC;
  signal \counter2_carry_i_6__2_n_0\ : STD_LOGIC;
  signal \counter2_carry_i_7__2_n_0\ : STD_LOGIC;
  signal \counter2_carry_i_8__2_n_0\ : STD_LOGIC;
  signal counter2_carry_n_0 : STD_LOGIC;
  signal counter2_carry_n_1 : STD_LOGIC;
  signal counter2_carry_n_2 : STD_LOGIC;
  signal counter2_carry_n_3 : STD_LOGIC;
  signal \counter[0]_i_3__5_n_0\ : STD_LOGIC;
  signal counter_reg : STD_LOGIC_VECTOR ( 31 downto 0 );
  signal \counter_reg[0]_i_2__6_n_0\ : STD_LOGIC;
  signal \counter_reg[0]_i_2__6_n_1\ : STD_LOGIC;
  signal \counter_reg[0]_i_2__6_n_2\ : STD_LOGIC;
  signal \counter_reg[0]_i_2__6_n_3\ : STD_LOGIC;
  signal \counter_reg[0]_i_2__6_n_4\ : STD_LOGIC;
  signal \counter_reg[0]_i_2__6_n_5\ : STD_LOGIC;
  signal \counter_reg[0]_i_2__6_n_6\ : STD_LOGIC;
  signal \counter_reg[0]_i_2__6_n_7\ : STD_LOGIC;
  signal \counter_reg[12]_i_1__6_n_0\ : STD_LOGIC;
  signal \counter_reg[12]_i_1__6_n_1\ : STD_LOGIC;
  signal \counter_reg[12]_i_1__6_n_2\ : STD_LOGIC;
  signal \counter_reg[12]_i_1__6_n_3\ : STD_LOGIC;
  signal \counter_reg[12]_i_1__6_n_4\ : STD_LOGIC;
  signal \counter_reg[12]_i_1__6_n_5\ : STD_LOGIC;
  signal \counter_reg[12]_i_1__6_n_6\ : STD_LOGIC;
  signal \counter_reg[12]_i_1__6_n_7\ : STD_LOGIC;
  signal \counter_reg[16]_i_1__6_n_0\ : STD_LOGIC;
  signal \counter_reg[16]_i_1__6_n_1\ : STD_LOGIC;
  signal \counter_reg[16]_i_1__6_n_2\ : STD_LOGIC;
  signal \counter_reg[16]_i_1__6_n_3\ : STD_LOGIC;
  signal \counter_reg[16]_i_1__6_n_4\ : STD_LOGIC;
  signal \counter_reg[16]_i_1__6_n_5\ : STD_LOGIC;
  signal \counter_reg[16]_i_1__6_n_6\ : STD_LOGIC;
  signal \counter_reg[16]_i_1__6_n_7\ : STD_LOGIC;
  signal \counter_reg[20]_i_1__6_n_0\ : STD_LOGIC;
  signal \counter_reg[20]_i_1__6_n_1\ : STD_LOGIC;
  signal \counter_reg[20]_i_1__6_n_2\ : STD_LOGIC;
  signal \counter_reg[20]_i_1__6_n_3\ : STD_LOGIC;
  signal \counter_reg[20]_i_1__6_n_4\ : STD_LOGIC;
  signal \counter_reg[20]_i_1__6_n_5\ : STD_LOGIC;
  signal \counter_reg[20]_i_1__6_n_6\ : STD_LOGIC;
  signal \counter_reg[20]_i_1__6_n_7\ : STD_LOGIC;
  signal \counter_reg[24]_i_1__6_n_0\ : STD_LOGIC;
  signal \counter_reg[24]_i_1__6_n_1\ : STD_LOGIC;
  signal \counter_reg[24]_i_1__6_n_2\ : STD_LOGIC;
  signal \counter_reg[24]_i_1__6_n_3\ : STD_LOGIC;
  signal \counter_reg[24]_i_1__6_n_4\ : STD_LOGIC;
  signal \counter_reg[24]_i_1__6_n_5\ : STD_LOGIC;
  signal \counter_reg[24]_i_1__6_n_6\ : STD_LOGIC;
  signal \counter_reg[24]_i_1__6_n_7\ : STD_LOGIC;
  signal \counter_reg[28]_i_1__6_n_1\ : STD_LOGIC;
  signal \counter_reg[28]_i_1__6_n_2\ : STD_LOGIC;
  signal \counter_reg[28]_i_1__6_n_3\ : STD_LOGIC;
  signal \counter_reg[28]_i_1__6_n_4\ : STD_LOGIC;
  signal \counter_reg[28]_i_1__6_n_5\ : STD_LOGIC;
  signal \counter_reg[28]_i_1__6_n_6\ : STD_LOGIC;
  signal \counter_reg[28]_i_1__6_n_7\ : STD_LOGIC;
  signal \counter_reg[4]_i_1__6_n_0\ : STD_LOGIC;
  signal \counter_reg[4]_i_1__6_n_1\ : STD_LOGIC;
  signal \counter_reg[4]_i_1__6_n_2\ : STD_LOGIC;
  signal \counter_reg[4]_i_1__6_n_3\ : STD_LOGIC;
  signal \counter_reg[4]_i_1__6_n_4\ : STD_LOGIC;
  signal \counter_reg[4]_i_1__6_n_5\ : STD_LOGIC;
  signal \counter_reg[4]_i_1__6_n_6\ : STD_LOGIC;
  signal \counter_reg[4]_i_1__6_n_7\ : STD_LOGIC;
  signal \counter_reg[8]_i_1__6_n_0\ : STD_LOGIC;
  signal \counter_reg[8]_i_1__6_n_1\ : STD_LOGIC;
  signal \counter_reg[8]_i_1__6_n_2\ : STD_LOGIC;
  signal \counter_reg[8]_i_1__6_n_3\ : STD_LOGIC;
  signal \counter_reg[8]_i_1__6_n_4\ : STD_LOGIC;
  signal \counter_reg[8]_i_1__6_n_5\ : STD_LOGIC;
  signal \counter_reg[8]_i_1__6_n_6\ : STD_LOGIC;
  signal \counter_reg[8]_i_1__6_n_7\ : STD_LOGIC;
  signal \o_pulse0_carry__0_i_1__2_n_0\ : STD_LOGIC;
  signal \o_pulse0_carry__0_i_2__2_n_0\ : STD_LOGIC;
  signal \o_pulse0_carry__0_i_3__2_n_0\ : STD_LOGIC;
  signal \o_pulse0_carry__0_i_4__2_n_0\ : STD_LOGIC;
  signal \o_pulse0_carry__0_n_0\ : STD_LOGIC;
  signal \o_pulse0_carry__0_n_1\ : STD_LOGIC;
  signal \o_pulse0_carry__0_n_2\ : STD_LOGIC;
  signal \o_pulse0_carry__0_n_3\ : STD_LOGIC;
  signal \o_pulse0_carry__1_i_1__2_n_0\ : STD_LOGIC;
  signal \o_pulse0_carry__1_i_2__2_n_0\ : STD_LOGIC;
  signal \o_pulse0_carry__1_i_3__2_n_0\ : STD_LOGIC;
  signal \o_pulse0_carry__1_n_1\ : STD_LOGIC;
  signal \o_pulse0_carry__1_n_2\ : STD_LOGIC;
  signal \o_pulse0_carry__1_n_3\ : STD_LOGIC;
  signal \o_pulse0_carry_i_1__2_n_0\ : STD_LOGIC;
  signal \o_pulse0_carry_i_2__2_n_0\ : STD_LOGIC;
  signal \o_pulse0_carry_i_3__2_n_0\ : STD_LOGIC;
  signal \o_pulse0_carry_i_4__2_n_0\ : STD_LOGIC;
  signal o_pulse0_carry_n_0 : STD_LOGIC;
  signal o_pulse0_carry_n_1 : STD_LOGIC;
  signal o_pulse0_carry_n_2 : STD_LOGIC;
  signal o_pulse0_carry_n_3 : STD_LOGIC;
  signal \^o_y_pos_reg[0]\ : STD_LOGIC;
  signal NLW_counter2_carry_O_UNCONNECTED : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_counter2_carry__0_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_counter2_carry__1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_counter2_carry__2_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_counter_reg[28]_i_1__6_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal NLW_o_pulse0_carry_O_UNCONNECTED : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_o_pulse0_carry__0_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_o_pulse0_carry__1_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_o_pulse0_carry__1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
begin
  \o_y_pos_reg[0]\ <= \^o_y_pos_reg[0]\;
counter2_carry: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => counter2_carry_n_0,
      CO(2) => counter2_carry_n_1,
      CO(1) => counter2_carry_n_2,
      CO(0) => counter2_carry_n_3,
      CYINIT => '0',
      DI(3) => \counter2_carry_i_1__2_n_0\,
      DI(2) => \counter2_carry_i_2__2_n_0\,
      DI(1) => \counter2_carry_i_3__2_n_0\,
      DI(0) => \counter2_carry_i_4__2_n_0\,
      O(3 downto 0) => NLW_counter2_carry_O_UNCONNECTED(3 downto 0),
      S(3) => \counter2_carry_i_5__2_n_0\,
      S(2) => \counter2_carry_i_6__2_n_0\,
      S(1) => \counter2_carry_i_7__2_n_0\,
      S(0) => \counter2_carry_i_8__2_n_0\
    );
\counter2_carry__0\: unisim.vcomponents.CARRY4
     port map (
      CI => counter2_carry_n_0,
      CO(3) => \counter2_carry__0_n_0\,
      CO(2) => \counter2_carry__0_n_1\,
      CO(1) => \counter2_carry__0_n_2\,
      CO(0) => \counter2_carry__0_n_3\,
      CYINIT => '0',
      DI(3) => \counter2_carry__0_i_1__2_n_0\,
      DI(2) => \counter2_carry__0_i_2__2_n_0\,
      DI(1) => \counter2_carry__0_i_3__2_n_0\,
      DI(0) => \counter2_carry__0_i_4__2_n_0\,
      O(3 downto 0) => \NLW_counter2_carry__0_O_UNCONNECTED\(3 downto 0),
      S(3) => \counter2_carry__0_i_5__2_n_0\,
      S(2) => \counter2_carry__0_i_6__2_n_0\,
      S(1) => \counter2_carry__0_i_7__2_n_0\,
      S(0) => \counter2_carry__0_i_8__2_n_0\
    );
\counter2_carry__0_i_1__2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"2F02"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(14),
      I1 => counter_reg(14),
      I2 => counter_reg(15),
      I3 => \maxCountReg_reg[31]\(15),
      O => \counter2_carry__0_i_1__2_n_0\
    );
\counter2_carry__0_i_2__2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"2F02"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(12),
      I1 => counter_reg(12),
      I2 => counter_reg(13),
      I3 => \maxCountReg_reg[31]\(13),
      O => \counter2_carry__0_i_2__2_n_0\
    );
\counter2_carry__0_i_3__2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"2F02"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(10),
      I1 => counter_reg(10),
      I2 => counter_reg(11),
      I3 => \maxCountReg_reg[31]\(11),
      O => \counter2_carry__0_i_3__2_n_0\
    );
\counter2_carry__0_i_4__2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"2F02"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(8),
      I1 => counter_reg(8),
      I2 => counter_reg(9),
      I3 => \maxCountReg_reg[31]\(9),
      O => \counter2_carry__0_i_4__2_n_0\
    );
\counter2_carry__0_i_5__2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9009"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(14),
      I1 => counter_reg(14),
      I2 => \maxCountReg_reg[31]\(15),
      I3 => counter_reg(15),
      O => \counter2_carry__0_i_5__2_n_0\
    );
\counter2_carry__0_i_6__2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9009"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(12),
      I1 => counter_reg(12),
      I2 => \maxCountReg_reg[31]\(13),
      I3 => counter_reg(13),
      O => \counter2_carry__0_i_6__2_n_0\
    );
\counter2_carry__0_i_7__2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9009"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(10),
      I1 => counter_reg(10),
      I2 => \maxCountReg_reg[31]\(11),
      I3 => counter_reg(11),
      O => \counter2_carry__0_i_7__2_n_0\
    );
\counter2_carry__0_i_8__2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9009"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(8),
      I1 => counter_reg(8),
      I2 => \maxCountReg_reg[31]\(9),
      I3 => counter_reg(9),
      O => \counter2_carry__0_i_8__2_n_0\
    );
\counter2_carry__1\: unisim.vcomponents.CARRY4
     port map (
      CI => \counter2_carry__0_n_0\,
      CO(3) => \counter2_carry__1_n_0\,
      CO(2) => \counter2_carry__1_n_1\,
      CO(1) => \counter2_carry__1_n_2\,
      CO(0) => \counter2_carry__1_n_3\,
      CYINIT => '0',
      DI(3) => \counter2_carry__1_i_1__2_n_0\,
      DI(2) => \counter2_carry__1_i_2__2_n_0\,
      DI(1) => \counter2_carry__1_i_3__2_n_0\,
      DI(0) => \counter2_carry__1_i_4__2_n_0\,
      O(3 downto 0) => \NLW_counter2_carry__1_O_UNCONNECTED\(3 downto 0),
      S(3) => \counter2_carry__1_i_5__2_n_0\,
      S(2) => \counter2_carry__1_i_6__2_n_0\,
      S(1) => \counter2_carry__1_i_7__2_n_0\,
      S(0) => \counter2_carry__1_i_8__2_n_0\
    );
\counter2_carry__1_i_1__2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"2F02"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(22),
      I1 => counter_reg(22),
      I2 => counter_reg(23),
      I3 => \maxCountReg_reg[31]\(23),
      O => \counter2_carry__1_i_1__2_n_0\
    );
\counter2_carry__1_i_2__2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"2F02"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(20),
      I1 => counter_reg(20),
      I2 => counter_reg(21),
      I3 => \maxCountReg_reg[31]\(21),
      O => \counter2_carry__1_i_2__2_n_0\
    );
\counter2_carry__1_i_3__2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"2F02"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(18),
      I1 => counter_reg(18),
      I2 => counter_reg(19),
      I3 => \maxCountReg_reg[31]\(19),
      O => \counter2_carry__1_i_3__2_n_0\
    );
\counter2_carry__1_i_4__2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"2F02"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(16),
      I1 => counter_reg(16),
      I2 => counter_reg(17),
      I3 => \maxCountReg_reg[31]\(17),
      O => \counter2_carry__1_i_4__2_n_0\
    );
\counter2_carry__1_i_5__2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9009"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(22),
      I1 => counter_reg(22),
      I2 => \maxCountReg_reg[31]\(23),
      I3 => counter_reg(23),
      O => \counter2_carry__1_i_5__2_n_0\
    );
\counter2_carry__1_i_6__2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9009"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(20),
      I1 => counter_reg(20),
      I2 => \maxCountReg_reg[31]\(21),
      I3 => counter_reg(21),
      O => \counter2_carry__1_i_6__2_n_0\
    );
\counter2_carry__1_i_7__2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9009"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(18),
      I1 => counter_reg(18),
      I2 => \maxCountReg_reg[31]\(19),
      I3 => counter_reg(19),
      O => \counter2_carry__1_i_7__2_n_0\
    );
\counter2_carry__1_i_8__2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9009"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(16),
      I1 => counter_reg(16),
      I2 => \maxCountReg_reg[31]\(17),
      I3 => counter_reg(17),
      O => \counter2_carry__1_i_8__2_n_0\
    );
\counter2_carry__2\: unisim.vcomponents.CARRY4
     port map (
      CI => \counter2_carry__1_n_0\,
      CO(3) => CO(0),
      CO(2) => \counter2_carry__2_n_1\,
      CO(1) => \counter2_carry__2_n_2\,
      CO(0) => \counter2_carry__2_n_3\,
      CYINIT => '0',
      DI(3) => \counter2_carry__2_i_1__2_n_0\,
      DI(2) => \counter2_carry__2_i_2__2_n_0\,
      DI(1) => \counter2_carry__2_i_3__2_n_0\,
      DI(0) => \counter2_carry__2_i_4__2_n_0\,
      O(3 downto 0) => \NLW_counter2_carry__2_O_UNCONNECTED\(3 downto 0),
      S(3) => \counter2_carry__2_i_5__2_n_0\,
      S(2) => \counter2_carry__2_i_6__2_n_0\,
      S(1) => \counter2_carry__2_i_7__2_n_0\,
      S(0) => \counter2_carry__2_i_8__2_n_0\
    );
\counter2_carry__2_i_1__2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"2F02"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(30),
      I1 => counter_reg(30),
      I2 => counter_reg(31),
      I3 => \maxCountReg_reg[31]\(31),
      O => \counter2_carry__2_i_1__2_n_0\
    );
\counter2_carry__2_i_2__2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"2F02"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(28),
      I1 => counter_reg(28),
      I2 => counter_reg(29),
      I3 => \maxCountReg_reg[31]\(29),
      O => \counter2_carry__2_i_2__2_n_0\
    );
\counter2_carry__2_i_3__2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"2F02"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(26),
      I1 => counter_reg(26),
      I2 => counter_reg(27),
      I3 => \maxCountReg_reg[31]\(27),
      O => \counter2_carry__2_i_3__2_n_0\
    );
\counter2_carry__2_i_4__2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"2F02"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(24),
      I1 => counter_reg(24),
      I2 => counter_reg(25),
      I3 => \maxCountReg_reg[31]\(25),
      O => \counter2_carry__2_i_4__2_n_0\
    );
\counter2_carry__2_i_5__2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9009"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(30),
      I1 => counter_reg(30),
      I2 => \maxCountReg_reg[31]\(31),
      I3 => counter_reg(31),
      O => \counter2_carry__2_i_5__2_n_0\
    );
\counter2_carry__2_i_6__2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9009"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(28),
      I1 => counter_reg(28),
      I2 => \maxCountReg_reg[31]\(29),
      I3 => counter_reg(29),
      O => \counter2_carry__2_i_6__2_n_0\
    );
\counter2_carry__2_i_7__2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9009"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(26),
      I1 => counter_reg(26),
      I2 => \maxCountReg_reg[31]\(27),
      I3 => counter_reg(27),
      O => \counter2_carry__2_i_7__2_n_0\
    );
\counter2_carry__2_i_8__2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9009"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(24),
      I1 => counter_reg(24),
      I2 => \maxCountReg_reg[31]\(25),
      I3 => counter_reg(25),
      O => \counter2_carry__2_i_8__2_n_0\
    );
\counter2_carry_i_1__2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"2F02"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(6),
      I1 => counter_reg(6),
      I2 => counter_reg(7),
      I3 => \maxCountReg_reg[31]\(7),
      O => \counter2_carry_i_1__2_n_0\
    );
\counter2_carry_i_2__2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"2F02"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(4),
      I1 => counter_reg(4),
      I2 => counter_reg(5),
      I3 => \maxCountReg_reg[31]\(5),
      O => \counter2_carry_i_2__2_n_0\
    );
\counter2_carry_i_3__2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"2F02"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(2),
      I1 => counter_reg(2),
      I2 => counter_reg(3),
      I3 => \maxCountReg_reg[31]\(3),
      O => \counter2_carry_i_3__2_n_0\
    );
\counter2_carry_i_4__2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"2F02"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(0),
      I1 => counter_reg(0),
      I2 => counter_reg(1),
      I3 => \maxCountReg_reg[31]\(1),
      O => \counter2_carry_i_4__2_n_0\
    );
\counter2_carry_i_5__2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9009"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(6),
      I1 => counter_reg(6),
      I2 => \maxCountReg_reg[31]\(7),
      I3 => counter_reg(7),
      O => \counter2_carry_i_5__2_n_0\
    );
\counter2_carry_i_6__2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9009"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(4),
      I1 => counter_reg(4),
      I2 => \maxCountReg_reg[31]\(5),
      I3 => counter_reg(5),
      O => \counter2_carry_i_6__2_n_0\
    );
\counter2_carry_i_7__2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9009"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(2),
      I1 => counter_reg(2),
      I2 => \maxCountReg_reg[31]\(3),
      I3 => counter_reg(3),
      O => \counter2_carry_i_7__2_n_0\
    );
\counter2_carry_i_8__2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9009"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(0),
      I1 => counter_reg(0),
      I2 => \maxCountReg_reg[31]\(1),
      I3 => counter_reg(1),
      O => \counter2_carry_i_8__2_n_0\
    );
\counter[0]_i_3__5\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => counter_reg(0),
      O => \counter[0]_i_3__5_n_0\
    );
\counter_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[0]_i_2__6_n_7\,
      Q => counter_reg(0),
      R => o_press_reg
    );
\counter_reg[0]_i_2__6\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \counter_reg[0]_i_2__6_n_0\,
      CO(2) => \counter_reg[0]_i_2__6_n_1\,
      CO(1) => \counter_reg[0]_i_2__6_n_2\,
      CO(0) => \counter_reg[0]_i_2__6_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0001",
      O(3) => \counter_reg[0]_i_2__6_n_4\,
      O(2) => \counter_reg[0]_i_2__6_n_5\,
      O(1) => \counter_reg[0]_i_2__6_n_6\,
      O(0) => \counter_reg[0]_i_2__6_n_7\,
      S(3 downto 1) => counter_reg(3 downto 1),
      S(0) => \counter[0]_i_3__5_n_0\
    );
\counter_reg[10]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[8]_i_1__6_n_5\,
      Q => counter_reg(10),
      R => o_press_reg
    );
\counter_reg[11]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[8]_i_1__6_n_4\,
      Q => counter_reg(11),
      R => o_press_reg
    );
\counter_reg[12]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[12]_i_1__6_n_7\,
      Q => counter_reg(12),
      R => o_press_reg
    );
\counter_reg[12]_i_1__6\: unisim.vcomponents.CARRY4
     port map (
      CI => \counter_reg[8]_i_1__6_n_0\,
      CO(3) => \counter_reg[12]_i_1__6_n_0\,
      CO(2) => \counter_reg[12]_i_1__6_n_1\,
      CO(1) => \counter_reg[12]_i_1__6_n_2\,
      CO(0) => \counter_reg[12]_i_1__6_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \counter_reg[12]_i_1__6_n_4\,
      O(2) => \counter_reg[12]_i_1__6_n_5\,
      O(1) => \counter_reg[12]_i_1__6_n_6\,
      O(0) => \counter_reg[12]_i_1__6_n_7\,
      S(3 downto 0) => counter_reg(15 downto 12)
    );
\counter_reg[13]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[12]_i_1__6_n_6\,
      Q => counter_reg(13),
      R => o_press_reg
    );
\counter_reg[14]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[12]_i_1__6_n_5\,
      Q => counter_reg(14),
      R => o_press_reg
    );
\counter_reg[15]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[12]_i_1__6_n_4\,
      Q => counter_reg(15),
      R => o_press_reg
    );
\counter_reg[16]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[16]_i_1__6_n_7\,
      Q => counter_reg(16),
      R => o_press_reg
    );
\counter_reg[16]_i_1__6\: unisim.vcomponents.CARRY4
     port map (
      CI => \counter_reg[12]_i_1__6_n_0\,
      CO(3) => \counter_reg[16]_i_1__6_n_0\,
      CO(2) => \counter_reg[16]_i_1__6_n_1\,
      CO(1) => \counter_reg[16]_i_1__6_n_2\,
      CO(0) => \counter_reg[16]_i_1__6_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \counter_reg[16]_i_1__6_n_4\,
      O(2) => \counter_reg[16]_i_1__6_n_5\,
      O(1) => \counter_reg[16]_i_1__6_n_6\,
      O(0) => \counter_reg[16]_i_1__6_n_7\,
      S(3 downto 0) => counter_reg(19 downto 16)
    );
\counter_reg[17]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[16]_i_1__6_n_6\,
      Q => counter_reg(17),
      R => o_press_reg
    );
\counter_reg[18]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[16]_i_1__6_n_5\,
      Q => counter_reg(18),
      R => o_press_reg
    );
\counter_reg[19]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[16]_i_1__6_n_4\,
      Q => counter_reg(19),
      R => o_press_reg
    );
\counter_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[0]_i_2__6_n_6\,
      Q => counter_reg(1),
      R => o_press_reg
    );
\counter_reg[20]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[20]_i_1__6_n_7\,
      Q => counter_reg(20),
      R => o_press_reg
    );
\counter_reg[20]_i_1__6\: unisim.vcomponents.CARRY4
     port map (
      CI => \counter_reg[16]_i_1__6_n_0\,
      CO(3) => \counter_reg[20]_i_1__6_n_0\,
      CO(2) => \counter_reg[20]_i_1__6_n_1\,
      CO(1) => \counter_reg[20]_i_1__6_n_2\,
      CO(0) => \counter_reg[20]_i_1__6_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \counter_reg[20]_i_1__6_n_4\,
      O(2) => \counter_reg[20]_i_1__6_n_5\,
      O(1) => \counter_reg[20]_i_1__6_n_6\,
      O(0) => \counter_reg[20]_i_1__6_n_7\,
      S(3 downto 0) => counter_reg(23 downto 20)
    );
\counter_reg[21]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[20]_i_1__6_n_6\,
      Q => counter_reg(21),
      R => o_press_reg
    );
\counter_reg[22]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[20]_i_1__6_n_5\,
      Q => counter_reg(22),
      R => o_press_reg
    );
\counter_reg[23]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[20]_i_1__6_n_4\,
      Q => counter_reg(23),
      R => o_press_reg
    );
\counter_reg[24]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[24]_i_1__6_n_7\,
      Q => counter_reg(24),
      R => o_press_reg
    );
\counter_reg[24]_i_1__6\: unisim.vcomponents.CARRY4
     port map (
      CI => \counter_reg[20]_i_1__6_n_0\,
      CO(3) => \counter_reg[24]_i_1__6_n_0\,
      CO(2) => \counter_reg[24]_i_1__6_n_1\,
      CO(1) => \counter_reg[24]_i_1__6_n_2\,
      CO(0) => \counter_reg[24]_i_1__6_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \counter_reg[24]_i_1__6_n_4\,
      O(2) => \counter_reg[24]_i_1__6_n_5\,
      O(1) => \counter_reg[24]_i_1__6_n_6\,
      O(0) => \counter_reg[24]_i_1__6_n_7\,
      S(3 downto 0) => counter_reg(27 downto 24)
    );
\counter_reg[25]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[24]_i_1__6_n_6\,
      Q => counter_reg(25),
      R => o_press_reg
    );
\counter_reg[26]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[24]_i_1__6_n_5\,
      Q => counter_reg(26),
      R => o_press_reg
    );
\counter_reg[27]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[24]_i_1__6_n_4\,
      Q => counter_reg(27),
      R => o_press_reg
    );
\counter_reg[28]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[28]_i_1__6_n_7\,
      Q => counter_reg(28),
      R => o_press_reg
    );
\counter_reg[28]_i_1__6\: unisim.vcomponents.CARRY4
     port map (
      CI => \counter_reg[24]_i_1__6_n_0\,
      CO(3) => \NLW_counter_reg[28]_i_1__6_CO_UNCONNECTED\(3),
      CO(2) => \counter_reg[28]_i_1__6_n_1\,
      CO(1) => \counter_reg[28]_i_1__6_n_2\,
      CO(0) => \counter_reg[28]_i_1__6_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \counter_reg[28]_i_1__6_n_4\,
      O(2) => \counter_reg[28]_i_1__6_n_5\,
      O(1) => \counter_reg[28]_i_1__6_n_6\,
      O(0) => \counter_reg[28]_i_1__6_n_7\,
      S(3 downto 0) => counter_reg(31 downto 28)
    );
\counter_reg[29]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[28]_i_1__6_n_6\,
      Q => counter_reg(29),
      R => o_press_reg
    );
\counter_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[0]_i_2__6_n_5\,
      Q => counter_reg(2),
      R => o_press_reg
    );
\counter_reg[30]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[28]_i_1__6_n_5\,
      Q => counter_reg(30),
      R => o_press_reg
    );
\counter_reg[31]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[28]_i_1__6_n_4\,
      Q => counter_reg(31),
      R => o_press_reg
    );
\counter_reg[3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[0]_i_2__6_n_4\,
      Q => counter_reg(3),
      R => o_press_reg
    );
\counter_reg[4]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[4]_i_1__6_n_7\,
      Q => counter_reg(4),
      R => o_press_reg
    );
\counter_reg[4]_i_1__6\: unisim.vcomponents.CARRY4
     port map (
      CI => \counter_reg[0]_i_2__6_n_0\,
      CO(3) => \counter_reg[4]_i_1__6_n_0\,
      CO(2) => \counter_reg[4]_i_1__6_n_1\,
      CO(1) => \counter_reg[4]_i_1__6_n_2\,
      CO(0) => \counter_reg[4]_i_1__6_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \counter_reg[4]_i_1__6_n_4\,
      O(2) => \counter_reg[4]_i_1__6_n_5\,
      O(1) => \counter_reg[4]_i_1__6_n_6\,
      O(0) => \counter_reg[4]_i_1__6_n_7\,
      S(3 downto 0) => counter_reg(7 downto 4)
    );
\counter_reg[5]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[4]_i_1__6_n_6\,
      Q => counter_reg(5),
      R => o_press_reg
    );
\counter_reg[6]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[4]_i_1__6_n_5\,
      Q => counter_reg(6),
      R => o_press_reg
    );
\counter_reg[7]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[4]_i_1__6_n_4\,
      Q => counter_reg(7),
      R => o_press_reg
    );
\counter_reg[8]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[8]_i_1__6_n_7\,
      Q => counter_reg(8),
      R => o_press_reg
    );
\counter_reg[8]_i_1__6\: unisim.vcomponents.CARRY4
     port map (
      CI => \counter_reg[4]_i_1__6_n_0\,
      CO(3) => \counter_reg[8]_i_1__6_n_0\,
      CO(2) => \counter_reg[8]_i_1__6_n_1\,
      CO(1) => \counter_reg[8]_i_1__6_n_2\,
      CO(0) => \counter_reg[8]_i_1__6_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \counter_reg[8]_i_1__6_n_4\,
      O(2) => \counter_reg[8]_i_1__6_n_5\,
      O(1) => \counter_reg[8]_i_1__6_n_6\,
      O(0) => \counter_reg[8]_i_1__6_n_7\,
      S(3 downto 0) => counter_reg(11 downto 8)
    );
\counter_reg[9]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \counter_reg[8]_i_1__6_n_6\,
      Q => counter_reg(9),
      R => o_press_reg
    );
o_pulse0_carry: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => o_pulse0_carry_n_0,
      CO(2) => o_pulse0_carry_n_1,
      CO(1) => o_pulse0_carry_n_2,
      CO(0) => o_pulse0_carry_n_3,
      CYINIT => '1',
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => NLW_o_pulse0_carry_O_UNCONNECTED(3 downto 0),
      S(3) => \o_pulse0_carry_i_1__2_n_0\,
      S(2) => \o_pulse0_carry_i_2__2_n_0\,
      S(1) => \o_pulse0_carry_i_3__2_n_0\,
      S(0) => \o_pulse0_carry_i_4__2_n_0\
    );
\o_pulse0_carry__0\: unisim.vcomponents.CARRY4
     port map (
      CI => o_pulse0_carry_n_0,
      CO(3) => \o_pulse0_carry__0_n_0\,
      CO(2) => \o_pulse0_carry__0_n_1\,
      CO(1) => \o_pulse0_carry__0_n_2\,
      CO(0) => \o_pulse0_carry__0_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => \NLW_o_pulse0_carry__0_O_UNCONNECTED\(3 downto 0),
      S(3) => \o_pulse0_carry__0_i_1__2_n_0\,
      S(2) => \o_pulse0_carry__0_i_2__2_n_0\,
      S(1) => \o_pulse0_carry__0_i_3__2_n_0\,
      S(0) => \o_pulse0_carry__0_i_4__2_n_0\
    );
\o_pulse0_carry__0_i_1__2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"9009000000009009"
    )
        port map (
      I0 => counter_reg(21),
      I1 => \maxCountReg_reg[31]\(21),
      I2 => \maxCountReg_reg[31]\(23),
      I3 => counter_reg(23),
      I4 => \maxCountReg_reg[31]\(22),
      I5 => counter_reg(22),
      O => \o_pulse0_carry__0_i_1__2_n_0\
    );
\o_pulse0_carry__0_i_2__2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"9009000000009009"
    )
        port map (
      I0 => counter_reg(18),
      I1 => \maxCountReg_reg[31]\(18),
      I2 => \maxCountReg_reg[31]\(20),
      I3 => counter_reg(20),
      I4 => \maxCountReg_reg[31]\(19),
      I5 => counter_reg(19),
      O => \o_pulse0_carry__0_i_2__2_n_0\
    );
\o_pulse0_carry__0_i_3__2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"9009000000009009"
    )
        port map (
      I0 => counter_reg(15),
      I1 => \maxCountReg_reg[31]\(15),
      I2 => \maxCountReg_reg[31]\(17),
      I3 => counter_reg(17),
      I4 => \maxCountReg_reg[31]\(16),
      I5 => counter_reg(16),
      O => \o_pulse0_carry__0_i_3__2_n_0\
    );
\o_pulse0_carry__0_i_4__2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"9009000000009009"
    )
        port map (
      I0 => counter_reg(12),
      I1 => \maxCountReg_reg[31]\(12),
      I2 => \maxCountReg_reg[31]\(14),
      I3 => counter_reg(14),
      I4 => \maxCountReg_reg[31]\(13),
      I5 => counter_reg(13),
      O => \o_pulse0_carry__0_i_4__2_n_0\
    );
\o_pulse0_carry__1\: unisim.vcomponents.CARRY4
     port map (
      CI => \o_pulse0_carry__0_n_0\,
      CO(3) => \NLW_o_pulse0_carry__1_CO_UNCONNECTED\(3),
      CO(2) => \o_pulse0_carry__1_n_1\,
      CO(1) => \o_pulse0_carry__1_n_2\,
      CO(0) => \o_pulse0_carry__1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => \NLW_o_pulse0_carry__1_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => \o_pulse0_carry__1_i_1__2_n_0\,
      S(1) => \o_pulse0_carry__1_i_2__2_n_0\,
      S(0) => \o_pulse0_carry__1_i_3__2_n_0\
    );
\o_pulse0_carry__1_i_1__2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9009"
    )
        port map (
      I0 => counter_reg(30),
      I1 => \maxCountReg_reg[31]\(30),
      I2 => counter_reg(31),
      I3 => \maxCountReg_reg[31]\(31),
      O => \o_pulse0_carry__1_i_1__2_n_0\
    );
\o_pulse0_carry__1_i_2__2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"9009000000009009"
    )
        port map (
      I0 => counter_reg(27),
      I1 => \maxCountReg_reg[31]\(27),
      I2 => \maxCountReg_reg[31]\(29),
      I3 => counter_reg(29),
      I4 => \maxCountReg_reg[31]\(28),
      I5 => counter_reg(28),
      O => \o_pulse0_carry__1_i_2__2_n_0\
    );
\o_pulse0_carry__1_i_3__2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"9009000000009009"
    )
        port map (
      I0 => counter_reg(24),
      I1 => \maxCountReg_reg[31]\(24),
      I2 => \maxCountReg_reg[31]\(26),
      I3 => counter_reg(26),
      I4 => \maxCountReg_reg[31]\(25),
      I5 => counter_reg(25),
      O => \o_pulse0_carry__1_i_3__2_n_0\
    );
\o_pulse0_carry_i_1__2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"9009000000009009"
    )
        port map (
      I0 => counter_reg(9),
      I1 => \maxCountReg_reg[31]\(9),
      I2 => \maxCountReg_reg[31]\(11),
      I3 => counter_reg(11),
      I4 => \maxCountReg_reg[31]\(10),
      I5 => counter_reg(10),
      O => \o_pulse0_carry_i_1__2_n_0\
    );
\o_pulse0_carry_i_2__2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"9009000000009009"
    )
        port map (
      I0 => counter_reg(6),
      I1 => \maxCountReg_reg[31]\(6),
      I2 => \maxCountReg_reg[31]\(8),
      I3 => counter_reg(8),
      I4 => \maxCountReg_reg[31]\(7),
      I5 => counter_reg(7),
      O => \o_pulse0_carry_i_2__2_n_0\
    );
\o_pulse0_carry_i_3__2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"9009000000009009"
    )
        port map (
      I0 => counter_reg(3),
      I1 => \maxCountReg_reg[31]\(3),
      I2 => \maxCountReg_reg[31]\(5),
      I3 => counter_reg(5),
      I4 => \maxCountReg_reg[31]\(4),
      I5 => counter_reg(4),
      O => \o_pulse0_carry_i_3__2_n_0\
    );
\o_pulse0_carry_i_4__2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"9009000000009009"
    )
        port map (
      I0 => counter_reg(0),
      I1 => \maxCountReg_reg[31]\(0),
      I2 => \maxCountReg_reg[31]\(2),
      I3 => counter_reg(2),
      I4 => \maxCountReg_reg[31]\(1),
      I5 => counter_reg(1),
      O => \o_pulse0_carry_i_4__2_n_0\
    );
o_pulse_reg: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \o_pulse0_carry__1_n_1\,
      Q => \^o_y_pos_reg[0]\,
      R => '0'
    );
\o_y_pos[0]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFEAAAEA"
    )
        port map (
      I0 => Q(0),
      I1 => p_1_in,
      I2 => \^o_y_pos_reg[0]\,
      I3 => o_pulse_reg_0,
      I4 => \maxCoordinateReg_reg[30]\(0),
      O => \o_y_pos_reg[0]_0\
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_singlePulseDebounce is
  port (
    w_button_pulse : out STD_LOGIC;
    \intrStatReg_reg[0]\ : out STD_LOGIC;
    s00_axi_aclk : in STD_LOGIC;
    s00_axi_wdata : in STD_LOGIC_VECTOR ( 0 to 0 );
    \axi_awaddr_reg[4]\ : in STD_LOGIC;
    \intrStatReg_reg[0]_0\ : in STD_LOGIC;
    i_button_press : in STD_LOGIC
  );
end decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_singlePulseDebounce;

architecture STRUCTURE of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_singlePulseDebounce is
  signal counter : STD_LOGIC;
  signal \counter1_carry__0_i_1_n_0\ : STD_LOGIC;
  signal \counter1_carry__0_i_2_n_0\ : STD_LOGIC;
  signal \counter1_carry__0_i_3_n_0\ : STD_LOGIC;
  signal \counter1_carry__0_i_4__3_n_0\ : STD_LOGIC;
  signal \counter1_carry__0_i_5__3_n_0\ : STD_LOGIC;
  signal \counter1_carry__0_i_6__3_n_0\ : STD_LOGIC;
  signal \counter1_carry__0_i_7__3_n_0\ : STD_LOGIC;
  signal \counter1_carry__0_n_0\ : STD_LOGIC;
  signal \counter1_carry__0_n_1\ : STD_LOGIC;
  signal \counter1_carry__0_n_2\ : STD_LOGIC;
  signal \counter1_carry__0_n_3\ : STD_LOGIC;
  signal \counter1_carry__1_i_1__3_n_0\ : STD_LOGIC;
  signal \counter1_carry__1_i_2__3_n_0\ : STD_LOGIC;
  signal \counter1_carry__1_i_3__3_n_0\ : STD_LOGIC;
  signal \counter1_carry__1_i_4__3_n_0\ : STD_LOGIC;
  signal \counter1_carry__1_n_0\ : STD_LOGIC;
  signal \counter1_carry__1_n_1\ : STD_LOGIC;
  signal \counter1_carry__1_n_2\ : STD_LOGIC;
  signal \counter1_carry__1_n_3\ : STD_LOGIC;
  signal \counter1_carry__2_i_1__3_n_0\ : STD_LOGIC;
  signal \counter1_carry__2_n_3\ : STD_LOGIC;
  signal counter1_carry_i_1_n_0 : STD_LOGIC;
  signal counter1_carry_i_2_n_0 : STD_LOGIC;
  signal \counter1_carry_i_3__3_n_0\ : STD_LOGIC;
  signal \counter1_carry_i_4__3_n_0\ : STD_LOGIC;
  signal \counter1_carry_i_5__3_n_0\ : STD_LOGIC;
  signal \counter1_carry_i_6__3_n_0\ : STD_LOGIC;
  signal counter1_carry_n_0 : STD_LOGIC;
  signal counter1_carry_n_1 : STD_LOGIC;
  signal counter1_carry_n_2 : STD_LOGIC;
  signal counter1_carry_n_3 : STD_LOGIC;
  signal \counter[0]_i_3__3_n_0\ : STD_LOGIC;
  signal counter_reg : STD_LOGIC_VECTOR ( 31 downto 0 );
  signal \counter_reg[0]_i_2__7_n_0\ : STD_LOGIC;
  signal \counter_reg[0]_i_2__7_n_1\ : STD_LOGIC;
  signal \counter_reg[0]_i_2__7_n_2\ : STD_LOGIC;
  signal \counter_reg[0]_i_2__7_n_3\ : STD_LOGIC;
  signal \counter_reg[0]_i_2__7_n_4\ : STD_LOGIC;
  signal \counter_reg[0]_i_2__7_n_5\ : STD_LOGIC;
  signal \counter_reg[0]_i_2__7_n_6\ : STD_LOGIC;
  signal \counter_reg[0]_i_2__7_n_7\ : STD_LOGIC;
  signal \counter_reg[12]_i_1__7_n_0\ : STD_LOGIC;
  signal \counter_reg[12]_i_1__7_n_1\ : STD_LOGIC;
  signal \counter_reg[12]_i_1__7_n_2\ : STD_LOGIC;
  signal \counter_reg[12]_i_1__7_n_3\ : STD_LOGIC;
  signal \counter_reg[12]_i_1__7_n_4\ : STD_LOGIC;
  signal \counter_reg[12]_i_1__7_n_5\ : STD_LOGIC;
  signal \counter_reg[12]_i_1__7_n_6\ : STD_LOGIC;
  signal \counter_reg[12]_i_1__7_n_7\ : STD_LOGIC;
  signal \counter_reg[16]_i_1__7_n_0\ : STD_LOGIC;
  signal \counter_reg[16]_i_1__7_n_1\ : STD_LOGIC;
  signal \counter_reg[16]_i_1__7_n_2\ : STD_LOGIC;
  signal \counter_reg[16]_i_1__7_n_3\ : STD_LOGIC;
  signal \counter_reg[16]_i_1__7_n_4\ : STD_LOGIC;
  signal \counter_reg[16]_i_1__7_n_5\ : STD_LOGIC;
  signal \counter_reg[16]_i_1__7_n_6\ : STD_LOGIC;
  signal \counter_reg[16]_i_1__7_n_7\ : STD_LOGIC;
  signal \counter_reg[20]_i_1__7_n_0\ : STD_LOGIC;
  signal \counter_reg[20]_i_1__7_n_1\ : STD_LOGIC;
  signal \counter_reg[20]_i_1__7_n_2\ : STD_LOGIC;
  signal \counter_reg[20]_i_1__7_n_3\ : STD_LOGIC;
  signal \counter_reg[20]_i_1__7_n_4\ : STD_LOGIC;
  signal \counter_reg[20]_i_1__7_n_5\ : STD_LOGIC;
  signal \counter_reg[20]_i_1__7_n_6\ : STD_LOGIC;
  signal \counter_reg[20]_i_1__7_n_7\ : STD_LOGIC;
  signal \counter_reg[24]_i_1__7_n_0\ : STD_LOGIC;
  signal \counter_reg[24]_i_1__7_n_1\ : STD_LOGIC;
  signal \counter_reg[24]_i_1__7_n_2\ : STD_LOGIC;
  signal \counter_reg[24]_i_1__7_n_3\ : STD_LOGIC;
  signal \counter_reg[24]_i_1__7_n_4\ : STD_LOGIC;
  signal \counter_reg[24]_i_1__7_n_5\ : STD_LOGIC;
  signal \counter_reg[24]_i_1__7_n_6\ : STD_LOGIC;
  signal \counter_reg[24]_i_1__7_n_7\ : STD_LOGIC;
  signal \counter_reg[28]_i_1__7_n_1\ : STD_LOGIC;
  signal \counter_reg[28]_i_1__7_n_2\ : STD_LOGIC;
  signal \counter_reg[28]_i_1__7_n_3\ : STD_LOGIC;
  signal \counter_reg[28]_i_1__7_n_4\ : STD_LOGIC;
  signal \counter_reg[28]_i_1__7_n_5\ : STD_LOGIC;
  signal \counter_reg[28]_i_1__7_n_6\ : STD_LOGIC;
  signal \counter_reg[28]_i_1__7_n_7\ : STD_LOGIC;
  signal \counter_reg[4]_i_1__7_n_0\ : STD_LOGIC;
  signal \counter_reg[4]_i_1__7_n_1\ : STD_LOGIC;
  signal \counter_reg[4]_i_1__7_n_2\ : STD_LOGIC;
  signal \counter_reg[4]_i_1__7_n_3\ : STD_LOGIC;
  signal \counter_reg[4]_i_1__7_n_4\ : STD_LOGIC;
  signal \counter_reg[4]_i_1__7_n_5\ : STD_LOGIC;
  signal \counter_reg[4]_i_1__7_n_6\ : STD_LOGIC;
  signal \counter_reg[4]_i_1__7_n_7\ : STD_LOGIC;
  signal \counter_reg[8]_i_1__7_n_0\ : STD_LOGIC;
  signal \counter_reg[8]_i_1__7_n_1\ : STD_LOGIC;
  signal \counter_reg[8]_i_1__7_n_2\ : STD_LOGIC;
  signal \counter_reg[8]_i_1__7_n_3\ : STD_LOGIC;
  signal \counter_reg[8]_i_1__7_n_4\ : STD_LOGIC;
  signal \counter_reg[8]_i_1__7_n_5\ : STD_LOGIC;
  signal \counter_reg[8]_i_1__7_n_6\ : STD_LOGIC;
  signal \counter_reg[8]_i_1__7_n_7\ : STD_LOGIC;
  signal \o_press_i_1__3_n_0\ : STD_LOGIC;
  signal \o_press_i_2__3_n_0\ : STD_LOGIC;
  signal \o_press_i_3__3_n_0\ : STD_LOGIC;
  signal \o_press_i_4__3_n_0\ : STD_LOGIC;
  signal \o_press_i_5__3_n_0\ : STD_LOGIC;
  signal \o_press_i_6__3_n_0\ : STD_LOGIC;
  signal \o_press_i_7__3_n_0\ : STD_LOGIC;
  signal \o_press_i_8__3_n_0\ : STD_LOGIC;
  signal \o_press_i_9__3_n_0\ : STD_LOGIC;
  signal \^w_button_pulse\ : STD_LOGIC;
  signal NLW_counter1_carry_O_UNCONNECTED : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_counter1_carry__0_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_counter1_carry__1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_counter1_carry__2_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \NLW_counter1_carry__2_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_counter_reg[28]_i_1__7_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
begin
  w_button_pulse <= \^w_button_pulse\;
counter1_carry: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => counter1_carry_n_0,
      CO(2) => counter1_carry_n_1,
      CO(1) => counter1_carry_n_2,
      CO(0) => counter1_carry_n_3,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => counter1_carry_i_1_n_0,
      DI(0) => counter1_carry_i_2_n_0,
      O(3 downto 0) => NLW_counter1_carry_O_UNCONNECTED(3 downto 0),
      S(3) => \counter1_carry_i_3__3_n_0\,
      S(2) => \counter1_carry_i_4__3_n_0\,
      S(1) => \counter1_carry_i_5__3_n_0\,
      S(0) => \counter1_carry_i_6__3_n_0\
    );
\counter1_carry__0\: unisim.vcomponents.CARRY4
     port map (
      CI => counter1_carry_n_0,
      CO(3) => \counter1_carry__0_n_0\,
      CO(2) => \counter1_carry__0_n_1\,
      CO(1) => \counter1_carry__0_n_2\,
      CO(0) => \counter1_carry__0_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => \counter1_carry__0_i_1_n_0\,
      DI(1) => \counter1_carry__0_i_2_n_0\,
      DI(0) => \counter1_carry__0_i_3_n_0\,
      O(3 downto 0) => \NLW_counter1_carry__0_O_UNCONNECTED\(3 downto 0),
      S(3) => \counter1_carry__0_i_4__3_n_0\,
      S(2) => \counter1_carry__0_i_5__3_n_0\,
      S(1) => \counter1_carry__0_i_6__3_n_0\,
      S(0) => \counter1_carry__0_i_7__3_n_0\
    );
\counter1_carry__0_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"7"
    )
        port map (
      I0 => counter_reg(18),
      I1 => counter_reg(19),
      O => \counter1_carry__0_i_1_n_0\
    );
\counter1_carry__0_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"7"
    )
        port map (
      I0 => counter_reg(16),
      I1 => counter_reg(17),
      O => \counter1_carry__0_i_2_n_0\
    );
\counter1_carry__0_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => counter_reg(14),
      I1 => counter_reg(15),
      O => \counter1_carry__0_i_3_n_0\
    );
\counter1_carry__0_i_4__3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => counter_reg(20),
      I1 => counter_reg(21),
      O => \counter1_carry__0_i_4__3_n_0\
    );
\counter1_carry__0_i_5__3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => counter_reg(18),
      I1 => counter_reg(19),
      O => \counter1_carry__0_i_5__3_n_0\
    );
\counter1_carry__0_i_6__3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => counter_reg(16),
      I1 => counter_reg(17),
      O => \counter1_carry__0_i_6__3_n_0\
    );
\counter1_carry__0_i_7__3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => counter_reg(14),
      I1 => counter_reg(15),
      O => \counter1_carry__0_i_7__3_n_0\
    );
\counter1_carry__1\: unisim.vcomponents.CARRY4
     port map (
      CI => \counter1_carry__0_n_0\,
      CO(3) => \counter1_carry__1_n_0\,
      CO(2) => \counter1_carry__1_n_1\,
      CO(1) => \counter1_carry__1_n_2\,
      CO(0) => \counter1_carry__1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => \NLW_counter1_carry__1_O_UNCONNECTED\(3 downto 0),
      S(3) => \counter1_carry__1_i_1__3_n_0\,
      S(2) => \counter1_carry__1_i_2__3_n_0\,
      S(1) => \counter1_carry__1_i_3__3_n_0\,
      S(0) => \counter1_carry__1_i_4__3_n_0\
    );
\counter1_carry__1_i_1__3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => counter_reg(28),
      I1 => counter_reg(29),
      O => \counter1_carry__1_i_1__3_n_0\
    );
\counter1_carry__1_i_2__3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => counter_reg(26),
      I1 => counter_reg(27),
      O => \counter1_carry__1_i_2__3_n_0\
    );
\counter1_carry__1_i_3__3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => counter_reg(24),
      I1 => counter_reg(25),
      O => \counter1_carry__1_i_3__3_n_0\
    );
\counter1_carry__1_i_4__3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => counter_reg(22),
      I1 => counter_reg(23),
      O => \counter1_carry__1_i_4__3_n_0\
    );
\counter1_carry__2\: unisim.vcomponents.CARRY4
     port map (
      CI => \counter1_carry__1_n_0\,
      CO(3 downto 1) => \NLW_counter1_carry__2_CO_UNCONNECTED\(3 downto 1),
      CO(0) => \counter1_carry__2_n_3\,
      CYINIT => '0',
      DI(3 downto 1) => B"000",
      DI(0) => counter_reg(31),
      O(3 downto 0) => \NLW_counter1_carry__2_O_UNCONNECTED\(3 downto 0),
      S(3 downto 1) => B"000",
      S(0) => \counter1_carry__2_i_1__3_n_0\
    );
\counter1_carry__2_i_1__3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => counter_reg(31),
      I1 => counter_reg(30),
      O => \counter1_carry__2_i_1__3_n_0\
    );
counter1_carry_i_1: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => counter_reg(9),
      O => counter1_carry_i_1_n_0
    );
counter1_carry_i_2: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => counter_reg(6),
      I1 => counter_reg(7),
      O => counter1_carry_i_2_n_0
    );
\counter1_carry_i_3__3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => counter_reg(12),
      I1 => counter_reg(13),
      O => \counter1_carry_i_3__3_n_0\
    );
\counter1_carry_i_4__3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => counter_reg(10),
      I1 => counter_reg(11),
      O => \counter1_carry_i_4__3_n_0\
    );
\counter1_carry_i_5__3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => counter_reg(9),
      I1 => counter_reg(8),
      O => \counter1_carry_i_5__3_n_0\
    );
\counter1_carry_i_6__3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => counter_reg(6),
      I1 => counter_reg(7),
      O => \counter1_carry_i_6__3_n_0\
    );
\counter[0]_i_1__7\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => i_button_press,
      O => counter
    );
\counter[0]_i_3__3\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => counter_reg(0),
      O => \counter[0]_i_3__3_n_0\
    );
\counter_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[0]_i_2__7_n_7\,
      Q => counter_reg(0),
      R => counter
    );
\counter_reg[0]_i_2__7\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \counter_reg[0]_i_2__7_n_0\,
      CO(2) => \counter_reg[0]_i_2__7_n_1\,
      CO(1) => \counter_reg[0]_i_2__7_n_2\,
      CO(0) => \counter_reg[0]_i_2__7_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0001",
      O(3) => \counter_reg[0]_i_2__7_n_4\,
      O(2) => \counter_reg[0]_i_2__7_n_5\,
      O(1) => \counter_reg[0]_i_2__7_n_6\,
      O(0) => \counter_reg[0]_i_2__7_n_7\,
      S(3 downto 1) => counter_reg(3 downto 1),
      S(0) => \counter[0]_i_3__3_n_0\
    );
\counter_reg[10]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[8]_i_1__7_n_5\,
      Q => counter_reg(10),
      R => counter
    );
\counter_reg[11]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[8]_i_1__7_n_4\,
      Q => counter_reg(11),
      R => counter
    );
\counter_reg[12]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[12]_i_1__7_n_7\,
      Q => counter_reg(12),
      R => counter
    );
\counter_reg[12]_i_1__7\: unisim.vcomponents.CARRY4
     port map (
      CI => \counter_reg[8]_i_1__7_n_0\,
      CO(3) => \counter_reg[12]_i_1__7_n_0\,
      CO(2) => \counter_reg[12]_i_1__7_n_1\,
      CO(1) => \counter_reg[12]_i_1__7_n_2\,
      CO(0) => \counter_reg[12]_i_1__7_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \counter_reg[12]_i_1__7_n_4\,
      O(2) => \counter_reg[12]_i_1__7_n_5\,
      O(1) => \counter_reg[12]_i_1__7_n_6\,
      O(0) => \counter_reg[12]_i_1__7_n_7\,
      S(3 downto 0) => counter_reg(15 downto 12)
    );
\counter_reg[13]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[12]_i_1__7_n_6\,
      Q => counter_reg(13),
      R => counter
    );
\counter_reg[14]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[12]_i_1__7_n_5\,
      Q => counter_reg(14),
      R => counter
    );
\counter_reg[15]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[12]_i_1__7_n_4\,
      Q => counter_reg(15),
      R => counter
    );
\counter_reg[16]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[16]_i_1__7_n_7\,
      Q => counter_reg(16),
      R => counter
    );
\counter_reg[16]_i_1__7\: unisim.vcomponents.CARRY4
     port map (
      CI => \counter_reg[12]_i_1__7_n_0\,
      CO(3) => \counter_reg[16]_i_1__7_n_0\,
      CO(2) => \counter_reg[16]_i_1__7_n_1\,
      CO(1) => \counter_reg[16]_i_1__7_n_2\,
      CO(0) => \counter_reg[16]_i_1__7_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \counter_reg[16]_i_1__7_n_4\,
      O(2) => \counter_reg[16]_i_1__7_n_5\,
      O(1) => \counter_reg[16]_i_1__7_n_6\,
      O(0) => \counter_reg[16]_i_1__7_n_7\,
      S(3 downto 0) => counter_reg(19 downto 16)
    );
\counter_reg[17]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[16]_i_1__7_n_6\,
      Q => counter_reg(17),
      R => counter
    );
\counter_reg[18]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[16]_i_1__7_n_5\,
      Q => counter_reg(18),
      R => counter
    );
\counter_reg[19]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[16]_i_1__7_n_4\,
      Q => counter_reg(19),
      R => counter
    );
\counter_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[0]_i_2__7_n_6\,
      Q => counter_reg(1),
      R => counter
    );
\counter_reg[20]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[20]_i_1__7_n_7\,
      Q => counter_reg(20),
      R => counter
    );
\counter_reg[20]_i_1__7\: unisim.vcomponents.CARRY4
     port map (
      CI => \counter_reg[16]_i_1__7_n_0\,
      CO(3) => \counter_reg[20]_i_1__7_n_0\,
      CO(2) => \counter_reg[20]_i_1__7_n_1\,
      CO(1) => \counter_reg[20]_i_1__7_n_2\,
      CO(0) => \counter_reg[20]_i_1__7_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \counter_reg[20]_i_1__7_n_4\,
      O(2) => \counter_reg[20]_i_1__7_n_5\,
      O(1) => \counter_reg[20]_i_1__7_n_6\,
      O(0) => \counter_reg[20]_i_1__7_n_7\,
      S(3 downto 0) => counter_reg(23 downto 20)
    );
\counter_reg[21]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[20]_i_1__7_n_6\,
      Q => counter_reg(21),
      R => counter
    );
\counter_reg[22]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[20]_i_1__7_n_5\,
      Q => counter_reg(22),
      R => counter
    );
\counter_reg[23]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[20]_i_1__7_n_4\,
      Q => counter_reg(23),
      R => counter
    );
\counter_reg[24]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[24]_i_1__7_n_7\,
      Q => counter_reg(24),
      R => counter
    );
\counter_reg[24]_i_1__7\: unisim.vcomponents.CARRY4
     port map (
      CI => \counter_reg[20]_i_1__7_n_0\,
      CO(3) => \counter_reg[24]_i_1__7_n_0\,
      CO(2) => \counter_reg[24]_i_1__7_n_1\,
      CO(1) => \counter_reg[24]_i_1__7_n_2\,
      CO(0) => \counter_reg[24]_i_1__7_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \counter_reg[24]_i_1__7_n_4\,
      O(2) => \counter_reg[24]_i_1__7_n_5\,
      O(1) => \counter_reg[24]_i_1__7_n_6\,
      O(0) => \counter_reg[24]_i_1__7_n_7\,
      S(3 downto 0) => counter_reg(27 downto 24)
    );
\counter_reg[25]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[24]_i_1__7_n_6\,
      Q => counter_reg(25),
      R => counter
    );
\counter_reg[26]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[24]_i_1__7_n_5\,
      Q => counter_reg(26),
      R => counter
    );
\counter_reg[27]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[24]_i_1__7_n_4\,
      Q => counter_reg(27),
      R => counter
    );
\counter_reg[28]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[28]_i_1__7_n_7\,
      Q => counter_reg(28),
      R => counter
    );
\counter_reg[28]_i_1__7\: unisim.vcomponents.CARRY4
     port map (
      CI => \counter_reg[24]_i_1__7_n_0\,
      CO(3) => \NLW_counter_reg[28]_i_1__7_CO_UNCONNECTED\(3),
      CO(2) => \counter_reg[28]_i_1__7_n_1\,
      CO(1) => \counter_reg[28]_i_1__7_n_2\,
      CO(0) => \counter_reg[28]_i_1__7_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \counter_reg[28]_i_1__7_n_4\,
      O(2) => \counter_reg[28]_i_1__7_n_5\,
      O(1) => \counter_reg[28]_i_1__7_n_6\,
      O(0) => \counter_reg[28]_i_1__7_n_7\,
      S(3 downto 0) => counter_reg(31 downto 28)
    );
\counter_reg[29]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[28]_i_1__7_n_6\,
      Q => counter_reg(29),
      R => counter
    );
\counter_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[0]_i_2__7_n_5\,
      Q => counter_reg(2),
      R => counter
    );
\counter_reg[30]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[28]_i_1__7_n_5\,
      Q => counter_reg(30),
      R => counter
    );
\counter_reg[31]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[28]_i_1__7_n_4\,
      Q => counter_reg(31),
      R => counter
    );
\counter_reg[3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[0]_i_2__7_n_4\,
      Q => counter_reg(3),
      R => counter
    );
\counter_reg[4]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[4]_i_1__7_n_7\,
      Q => counter_reg(4),
      R => counter
    );
\counter_reg[4]_i_1__7\: unisim.vcomponents.CARRY4
     port map (
      CI => \counter_reg[0]_i_2__7_n_0\,
      CO(3) => \counter_reg[4]_i_1__7_n_0\,
      CO(2) => \counter_reg[4]_i_1__7_n_1\,
      CO(1) => \counter_reg[4]_i_1__7_n_2\,
      CO(0) => \counter_reg[4]_i_1__7_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \counter_reg[4]_i_1__7_n_4\,
      O(2) => \counter_reg[4]_i_1__7_n_5\,
      O(1) => \counter_reg[4]_i_1__7_n_6\,
      O(0) => \counter_reg[4]_i_1__7_n_7\,
      S(3 downto 0) => counter_reg(7 downto 4)
    );
\counter_reg[5]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[4]_i_1__7_n_6\,
      Q => counter_reg(5),
      R => counter
    );
\counter_reg[6]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[4]_i_1__7_n_5\,
      Q => counter_reg(6),
      R => counter
    );
\counter_reg[7]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[4]_i_1__7_n_4\,
      Q => counter_reg(7),
      R => counter
    );
\counter_reg[8]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[8]_i_1__7_n_7\,
      Q => counter_reg(8),
      R => counter
    );
\counter_reg[8]_i_1__7\: unisim.vcomponents.CARRY4
     port map (
      CI => \counter_reg[4]_i_1__7_n_0\,
      CO(3) => \counter_reg[8]_i_1__7_n_0\,
      CO(2) => \counter_reg[8]_i_1__7_n_1\,
      CO(1) => \counter_reg[8]_i_1__7_n_2\,
      CO(0) => \counter_reg[8]_i_1__7_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \counter_reg[8]_i_1__7_n_4\,
      O(2) => \counter_reg[8]_i_1__7_n_5\,
      O(1) => \counter_reg[8]_i_1__7_n_6\,
      O(0) => \counter_reg[8]_i_1__7_n_7\,
      S(3 downto 0) => counter_reg(11 downto 8)
    );
\counter_reg[9]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => \counter1_carry__2_n_3\,
      D => \counter_reg[8]_i_1__7_n_6\,
      Q => counter_reg(9),
      R => counter
    );
\intrStatReg[0]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"F5CA"
    )
        port map (
      I0 => s00_axi_wdata(0),
      I1 => \^w_button_pulse\,
      I2 => \axi_awaddr_reg[4]\,
      I3 => \intrStatReg_reg[0]_0\,
      O => \intrStatReg_reg[0]\
    );
\o_press_i_1__3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000000001"
    )
        port map (
      I0 => \o_press_i_2__3_n_0\,
      I1 => \o_press_i_3__3_n_0\,
      I2 => counter_reg(30),
      I3 => counter_reg(31),
      I4 => \o_press_i_4__3_n_0\,
      I5 => \o_press_i_5__3_n_0\,
      O => \o_press_i_1__3_n_0\
    );
\o_press_i_2__3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFFFFFE"
    )
        port map (
      I0 => counter_reg(21),
      I1 => counter_reg(20),
      I2 => counter_reg(23),
      I3 => counter_reg(22),
      I4 => \o_press_i_6__3_n_0\,
      O => \o_press_i_2__3_n_0\
    );
\o_press_i_3__3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => counter_reg(29),
      I1 => counter_reg(28),
      O => \o_press_i_3__3_n_0\
    );
\o_press_i_4__3\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFFE"
    )
        port map (
      I0 => counter_reg(26),
      I1 => counter_reg(27),
      I2 => counter_reg(24),
      I3 => counter_reg(25),
      O => \o_press_i_4__3_n_0\
    );
\o_press_i_5__3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFFFFE"
    )
        port map (
      I0 => \o_press_i_7__3_n_0\,
      I1 => counter_reg(10),
      I2 => counter_reg(15),
      I3 => counter_reg(12),
      I4 => counter_reg(13),
      I5 => \o_press_i_8__3_n_0\,
      O => \o_press_i_5__3_n_0\
    );
\o_press_i_6__3\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFFE"
    )
        port map (
      I0 => counter_reg(6),
      I1 => counter_reg(11),
      I2 => counter_reg(8),
      I3 => counter_reg(7),
      O => \o_press_i_6__3_n_0\
    );
\o_press_i_7__3\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"7FFF"
    )
        port map (
      I0 => counter_reg(14),
      I1 => counter_reg(19),
      I2 => counter_reg(16),
      I3 => counter_reg(9),
      O => \o_press_i_7__3_n_0\
    );
\o_press_i_8__3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFF7FFF"
    )
        port map (
      I0 => counter_reg(5),
      I1 => counter_reg(4),
      I2 => counter_reg(17),
      I3 => counter_reg(18),
      I4 => \o_press_i_9__3_n_0\,
      O => \o_press_i_8__3_n_0\
    );
\o_press_i_9__3\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"7FFF"
    )
        port map (
      I0 => counter_reg(2),
      I1 => counter_reg(3),
      I2 => counter_reg(0),
      I3 => counter_reg(1),
      O => \o_press_i_9__3_n_0\
    );
o_press_reg: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \o_press_i_1__3_n_0\,
      Q => \^w_button_pulse\,
      R => '0'
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_mouseTracker is
  port (
    \intrStatReg_reg[1]\ : out STD_LOGIC;
    D : out STD_LOGIC_VECTOR ( 31 downto 0 );
    s00_axi_aclk : in STD_LOGIC;
    Q : in STD_LOGIC_VECTOR ( 31 downto 0 );
    \maxCoordinateReg_reg[31]\ : in STD_LOGIC_VECTOR ( 31 downto 0 );
    s00_axi_wdata : in STD_LOGIC_VECTOR ( 0 to 0 );
    w_button_pulse : in STD_LOGIC;
    \axi_awaddr_reg[4]\ : in STD_LOGIC;
    \intrStatReg_reg[1]_0\ : in STD_LOGIC;
    \maxCountReg_reg[31]\ : in STD_LOGIC_VECTOR ( 31 downto 0 );
    \axi_araddr_reg[4]\ : in STD_LOGIC;
    \axi_araddr_reg[3]\ : in STD_LOGIC;
    \axi_araddr_reg[5]\ : in STD_LOGIC;
    \intrEnableReg_reg[31]\ : in STD_LOGIC_VECTOR ( 31 downto 0 );
    \axi_araddr_reg[3]_0\ : in STD_LOGIC_VECTOR ( 1 downto 0 );
    \intrStatReg_reg[0]\ : in STD_LOGIC;
    \intrStatReg_reg[2]\ : in STD_LOGIC;
    \intrStatReg_reg[3]\ : in STD_LOGIC;
    \intrStatReg_reg[4]\ : in STD_LOGIC;
    \intrStatReg_reg[5]\ : in STD_LOGIC;
    \intrStatReg_reg[6]\ : in STD_LOGIC;
    \intrStatReg_reg[7]\ : in STD_LOGIC;
    \intrStatReg_reg[8]\ : in STD_LOGIC;
    \intrStatReg_reg[9]\ : in STD_LOGIC;
    \intrStatReg_reg[10]\ : in STD_LOGIC;
    \intrStatReg_reg[11]\ : in STD_LOGIC;
    \intrStatReg_reg[12]\ : in STD_LOGIC;
    \intrStatReg_reg[13]\ : in STD_LOGIC;
    \intrStatReg_reg[14]\ : in STD_LOGIC;
    \intrStatReg_reg[15]\ : in STD_LOGIC;
    \intrStatReg_reg[16]\ : in STD_LOGIC;
    \intrStatReg_reg[17]\ : in STD_LOGIC;
    \intrStatReg_reg[18]\ : in STD_LOGIC;
    \intrStatReg_reg[19]\ : in STD_LOGIC;
    \intrStatReg_reg[20]\ : in STD_LOGIC;
    \intrStatReg_reg[21]\ : in STD_LOGIC;
    \intrStatReg_reg[22]\ : in STD_LOGIC;
    \intrStatReg_reg[23]\ : in STD_LOGIC;
    \intrStatReg_reg[24]\ : in STD_LOGIC;
    \intrStatReg_reg[25]\ : in STD_LOGIC;
    \intrStatReg_reg[26]\ : in STD_LOGIC;
    \intrStatReg_reg[27]\ : in STD_LOGIC;
    \intrStatReg_reg[28]\ : in STD_LOGIC;
    \intrStatReg_reg[29]\ : in STD_LOGIC;
    \intrStatReg_reg[30]\ : in STD_LOGIC;
    \intrStatReg_reg[31]\ : in STD_LOGIC;
    i_button_left : in STD_LOGIC;
    i_button_right : in STD_LOGIC;
    i_button_up : in STD_LOGIC;
    i_button_down : in STD_LOGIC
  );
end decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_mouseTracker;

architecture STRUCTURE of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_mouseTracker is
  signal \axi_rdata[0]_i_2_n_0\ : STD_LOGIC;
  signal \axi_rdata[10]_i_2_n_0\ : STD_LOGIC;
  signal \axi_rdata[11]_i_2_n_0\ : STD_LOGIC;
  signal \axi_rdata[12]_i_2_n_0\ : STD_LOGIC;
  signal \axi_rdata[13]_i_2_n_0\ : STD_LOGIC;
  signal \axi_rdata[14]_i_2_n_0\ : STD_LOGIC;
  signal \axi_rdata[15]_i_2_n_0\ : STD_LOGIC;
  signal \axi_rdata[16]_i_2_n_0\ : STD_LOGIC;
  signal \axi_rdata[17]_i_2_n_0\ : STD_LOGIC;
  signal \axi_rdata[18]_i_2_n_0\ : STD_LOGIC;
  signal \axi_rdata[19]_i_2_n_0\ : STD_LOGIC;
  signal \axi_rdata[1]_i_2_n_0\ : STD_LOGIC;
  signal \axi_rdata[20]_i_2_n_0\ : STD_LOGIC;
  signal \axi_rdata[21]_i_2_n_0\ : STD_LOGIC;
  signal \axi_rdata[22]_i_2_n_0\ : STD_LOGIC;
  signal \axi_rdata[23]_i_2_n_0\ : STD_LOGIC;
  signal \axi_rdata[24]_i_2_n_0\ : STD_LOGIC;
  signal \axi_rdata[25]_i_2_n_0\ : STD_LOGIC;
  signal \axi_rdata[26]_i_2_n_0\ : STD_LOGIC;
  signal \axi_rdata[27]_i_2_n_0\ : STD_LOGIC;
  signal \axi_rdata[28]_i_2_n_0\ : STD_LOGIC;
  signal \axi_rdata[29]_i_2_n_0\ : STD_LOGIC;
  signal \axi_rdata[2]_i_2_n_0\ : STD_LOGIC;
  signal \axi_rdata[30]_i_2_n_0\ : STD_LOGIC;
  signal \axi_rdata[31]_i_4_n_0\ : STD_LOGIC;
  signal \axi_rdata[3]_i_2_n_0\ : STD_LOGIC;
  signal \axi_rdata[4]_i_2_n_0\ : STD_LOGIC;
  signal \axi_rdata[5]_i_2_n_0\ : STD_LOGIC;
  signal \axi_rdata[6]_i_2_n_0\ : STD_LOGIC;
  signal \axi_rdata[7]_i_2_n_0\ : STD_LOGIC;
  signal \axi_rdata[8]_i_2_n_0\ : STD_LOGIC;
  signal \axi_rdata[9]_i_2_n_0\ : STD_LOGIC;
  signal clear : STD_LOGIC;
  signal counter2 : STD_LOGIC;
  signal dbDown_n_0 : STD_LOGIC;
  signal dbRight_n_0 : STD_LOGIC;
  signal dbUp_n_0 : STD_LOGIC;
  signal \i__carry__0_i_1__0_n_0\ : STD_LOGIC;
  signal \i__carry__0_i_1_n_0\ : STD_LOGIC;
  signal \i__carry__0_i_2__0_n_0\ : STD_LOGIC;
  signal \i__carry__0_i_2_n_0\ : STD_LOGIC;
  signal \i__carry__0_i_3__0_n_0\ : STD_LOGIC;
  signal \i__carry__0_i_3_n_0\ : STD_LOGIC;
  signal \i__carry__0_i_4__0_n_0\ : STD_LOGIC;
  signal \i__carry__0_i_4_n_0\ : STD_LOGIC;
  signal \i__carry__0_i_5__0_n_0\ : STD_LOGIC;
  signal \i__carry__0_i_5_n_0\ : STD_LOGIC;
  signal \i__carry__0_i_6__0_n_0\ : STD_LOGIC;
  signal \i__carry__0_i_6_n_0\ : STD_LOGIC;
  signal \i__carry__0_i_7__0_n_0\ : STD_LOGIC;
  signal \i__carry__0_i_7_n_0\ : STD_LOGIC;
  signal \i__carry__0_i_8__0_n_0\ : STD_LOGIC;
  signal \i__carry__0_i_8_n_0\ : STD_LOGIC;
  signal \i__carry_i_1__0_n_0\ : STD_LOGIC;
  signal \i__carry_i_1_n_0\ : STD_LOGIC;
  signal \i__carry_i_2__0_n_0\ : STD_LOGIC;
  signal \i__carry_i_2_n_0\ : STD_LOGIC;
  signal \i__carry_i_3__0_n_0\ : STD_LOGIC;
  signal \i__carry_i_3_n_0\ : STD_LOGIC;
  signal \i__carry_i_4__0_n_0\ : STD_LOGIC;
  signal \i__carry_i_4_n_0\ : STD_LOGIC;
  signal \i__carry_i_5__0_n_0\ : STD_LOGIC;
  signal \i__carry_i_5_n_0\ : STD_LOGIC;
  signal \i__carry_i_6__0_n_0\ : STD_LOGIC;
  signal \i__carry_i_6_n_0\ : STD_LOGIC;
  signal \i__carry_i_7__0_n_0\ : STD_LOGIC;
  signal \i__carry_i_7_n_0\ : STD_LOGIC;
  signal \i__carry_i_8__0_n_0\ : STD_LOGIC;
  signal \i__carry_i_8_n_0\ : STD_LOGIC;
  signal o_intr1_out : STD_LOGIC;
  signal o_intr_i_10_n_0 : STD_LOGIC;
  signal o_intr_i_4_n_0 : STD_LOGIC;
  signal o_intr_i_5_n_0 : STD_LOGIC;
  signal o_intr_i_6_n_0 : STD_LOGIC;
  signal o_intr_i_7_n_0 : STD_LOGIC;
  signal o_intr_i_8_n_0 : STD_LOGIC;
  signal o_intr_i_9_n_0 : STD_LOGIC;
  signal o_pulse : STD_LOGIC;
  signal \o_x_pos0_inferred__1/i__carry__0_n_1\ : STD_LOGIC;
  signal \o_x_pos0_inferred__1/i__carry__0_n_2\ : STD_LOGIC;
  signal \o_x_pos0_inferred__1/i__carry__0_n_3\ : STD_LOGIC;
  signal \o_x_pos0_inferred__1/i__carry_n_0\ : STD_LOGIC;
  signal \o_x_pos0_inferred__1/i__carry_n_1\ : STD_LOGIC;
  signal \o_x_pos0_inferred__1/i__carry_n_2\ : STD_LOGIC;
  signal \o_x_pos0_inferred__1/i__carry_n_3\ : STD_LOGIC;
  signal \o_x_pos[0]_i_10_n_0\ : STD_LOGIC;
  signal \o_x_pos[0]_i_6_n_0\ : STD_LOGIC;
  signal \o_y_pos0_inferred__1/i__carry__0_n_1\ : STD_LOGIC;
  signal \o_y_pos0_inferred__1/i__carry__0_n_2\ : STD_LOGIC;
  signal \o_y_pos0_inferred__1/i__carry__0_n_3\ : STD_LOGIC;
  signal \o_y_pos0_inferred__1/i__carry_n_0\ : STD_LOGIC;
  signal \o_y_pos0_inferred__1/i__carry_n_1\ : STD_LOGIC;
  signal \o_y_pos0_inferred__1/i__carry_n_2\ : STD_LOGIC;
  signal \o_y_pos0_inferred__1/i__carry_n_3\ : STD_LOGIC;
  signal \o_y_pos[0]_i_10_n_0\ : STD_LOGIC;
  signal \o_y_pos[0]_i_6_n_0\ : STD_LOGIC;
  signal pGDown_n_0 : STD_LOGIC;
  signal pGDown_n_1 : STD_LOGIC;
  signal pGDown_n_10 : STD_LOGIC;
  signal pGDown_n_11 : STD_LOGIC;
  signal pGDown_n_12 : STD_LOGIC;
  signal pGDown_n_13 : STD_LOGIC;
  signal pGDown_n_14 : STD_LOGIC;
  signal pGDown_n_15 : STD_LOGIC;
  signal pGDown_n_16 : STD_LOGIC;
  signal pGDown_n_17 : STD_LOGIC;
  signal pGDown_n_2 : STD_LOGIC;
  signal pGDown_n_3 : STD_LOGIC;
  signal pGDown_n_4 : STD_LOGIC;
  signal pGDown_n_5 : STD_LOGIC;
  signal pGDown_n_6 : STD_LOGIC;
  signal pGDown_n_7 : STD_LOGIC;
  signal pGDown_n_8 : STD_LOGIC;
  signal pGDown_n_9 : STD_LOGIC;
  signal pGRight_n_0 : STD_LOGIC;
  signal pGRight_n_10 : STD_LOGIC;
  signal pGRight_n_11 : STD_LOGIC;
  signal pGRight_n_12 : STD_LOGIC;
  signal pGRight_n_13 : STD_LOGIC;
  signal pGRight_n_14 : STD_LOGIC;
  signal pGRight_n_15 : STD_LOGIC;
  signal pGRight_n_16 : STD_LOGIC;
  signal pGRight_n_17 : STD_LOGIC;
  signal pGRight_n_18 : STD_LOGIC;
  signal pGRight_n_3 : STD_LOGIC;
  signal pGRight_n_4 : STD_LOGIC;
  signal pGRight_n_5 : STD_LOGIC;
  signal pGRight_n_6 : STD_LOGIC;
  signal pGRight_n_7 : STD_LOGIC;
  signal pGRight_n_8 : STD_LOGIC;
  signal pGRight_n_9 : STD_LOGIC;
  signal pGUp_n_0 : STD_LOGIC;
  signal pGUp_n_1 : STD_LOGIC;
  signal pGUp_n_2 : STD_LOGIC;
  signal p_0_in : STD_LOGIC;
  signal p_1_in : STD_LOGIC;
  signal p_2_in : STD_LOGIC;
  signal posReg : STD_LOGIC_VECTOR ( 31 downto 0 );
  signal sel : STD_LOGIC;
  signal w_mousemove : STD_LOGIC;
  signal \NLW_o_x_pos0_inferred__1/i__carry_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_o_x_pos0_inferred__1/i__carry__0_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_o_y_pos0_inferred__1/i__carry_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_o_y_pos0_inferred__1/i__carry__0_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
begin
\axi_rdata[0]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000CCE200E2"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(0),
      I1 => \axi_araddr_reg[4]\,
      I2 => \maxCoordinateReg_reg[31]\(0),
      I3 => \axi_araddr_reg[3]\,
      I4 => \axi_rdata[0]_i_2_n_0\,
      I5 => \axi_araddr_reg[5]\,
      O => D(0)
    );
\axi_rdata[0]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => posReg(0),
      I1 => \intrEnableReg_reg[31]\(0),
      I2 => \axi_araddr_reg[3]_0\(1),
      I3 => \intrStatReg_reg[0]\,
      I4 => \axi_araddr_reg[3]_0\(0),
      I5 => Q(0),
      O => \axi_rdata[0]_i_2_n_0\
    );
\axi_rdata[10]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000CCE200E2"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(10),
      I1 => \axi_araddr_reg[4]\,
      I2 => \maxCoordinateReg_reg[31]\(10),
      I3 => \axi_araddr_reg[3]\,
      I4 => \axi_rdata[10]_i_2_n_0\,
      I5 => \axi_araddr_reg[5]\,
      O => D(10)
    );
\axi_rdata[10]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => posReg(10),
      I1 => \intrEnableReg_reg[31]\(10),
      I2 => \axi_araddr_reg[3]_0\(1),
      I3 => \intrStatReg_reg[10]\,
      I4 => \axi_araddr_reg[3]_0\(0),
      I5 => Q(10),
      O => \axi_rdata[10]_i_2_n_0\
    );
\axi_rdata[11]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000CCE200E2"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(11),
      I1 => \axi_araddr_reg[4]\,
      I2 => \maxCoordinateReg_reg[31]\(11),
      I3 => \axi_araddr_reg[3]\,
      I4 => \axi_rdata[11]_i_2_n_0\,
      I5 => \axi_araddr_reg[5]\,
      O => D(11)
    );
\axi_rdata[11]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => posReg(11),
      I1 => \intrEnableReg_reg[31]\(11),
      I2 => \axi_araddr_reg[3]_0\(1),
      I3 => \intrStatReg_reg[11]\,
      I4 => \axi_araddr_reg[3]_0\(0),
      I5 => Q(11),
      O => \axi_rdata[11]_i_2_n_0\
    );
\axi_rdata[12]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000CCE200E2"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(12),
      I1 => \axi_araddr_reg[4]\,
      I2 => \maxCoordinateReg_reg[31]\(12),
      I3 => \axi_araddr_reg[3]\,
      I4 => \axi_rdata[12]_i_2_n_0\,
      I5 => \axi_araddr_reg[5]\,
      O => D(12)
    );
\axi_rdata[12]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => posReg(12),
      I1 => \intrEnableReg_reg[31]\(12),
      I2 => \axi_araddr_reg[3]_0\(1),
      I3 => \intrStatReg_reg[12]\,
      I4 => \axi_araddr_reg[3]_0\(0),
      I5 => Q(12),
      O => \axi_rdata[12]_i_2_n_0\
    );
\axi_rdata[13]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000CCE200E2"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(13),
      I1 => \axi_araddr_reg[4]\,
      I2 => \maxCoordinateReg_reg[31]\(13),
      I3 => \axi_araddr_reg[3]\,
      I4 => \axi_rdata[13]_i_2_n_0\,
      I5 => \axi_araddr_reg[5]\,
      O => D(13)
    );
\axi_rdata[13]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => posReg(13),
      I1 => \intrEnableReg_reg[31]\(13),
      I2 => \axi_araddr_reg[3]_0\(1),
      I3 => \intrStatReg_reg[13]\,
      I4 => \axi_araddr_reg[3]_0\(0),
      I5 => Q(13),
      O => \axi_rdata[13]_i_2_n_0\
    );
\axi_rdata[14]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000CCE200E2"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(14),
      I1 => \axi_araddr_reg[4]\,
      I2 => \maxCoordinateReg_reg[31]\(14),
      I3 => \axi_araddr_reg[3]\,
      I4 => \axi_rdata[14]_i_2_n_0\,
      I5 => \axi_araddr_reg[5]\,
      O => D(14)
    );
\axi_rdata[14]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => posReg(14),
      I1 => \intrEnableReg_reg[31]\(14),
      I2 => \axi_araddr_reg[3]_0\(1),
      I3 => \intrStatReg_reg[14]\,
      I4 => \axi_araddr_reg[3]_0\(0),
      I5 => Q(14),
      O => \axi_rdata[14]_i_2_n_0\
    );
\axi_rdata[15]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000CCE200E2"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(15),
      I1 => \axi_araddr_reg[4]\,
      I2 => \maxCoordinateReg_reg[31]\(15),
      I3 => \axi_araddr_reg[3]\,
      I4 => \axi_rdata[15]_i_2_n_0\,
      I5 => \axi_araddr_reg[5]\,
      O => D(15)
    );
\axi_rdata[15]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => posReg(15),
      I1 => \intrEnableReg_reg[31]\(15),
      I2 => \axi_araddr_reg[3]_0\(1),
      I3 => \intrStatReg_reg[15]\,
      I4 => \axi_araddr_reg[3]_0\(0),
      I5 => Q(15),
      O => \axi_rdata[15]_i_2_n_0\
    );
\axi_rdata[16]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000CCE200E2"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(16),
      I1 => \axi_araddr_reg[4]\,
      I2 => \maxCoordinateReg_reg[31]\(16),
      I3 => \axi_araddr_reg[3]\,
      I4 => \axi_rdata[16]_i_2_n_0\,
      I5 => \axi_araddr_reg[5]\,
      O => D(16)
    );
\axi_rdata[16]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => posReg(16),
      I1 => \intrEnableReg_reg[31]\(16),
      I2 => \axi_araddr_reg[3]_0\(1),
      I3 => \intrStatReg_reg[16]\,
      I4 => \axi_araddr_reg[3]_0\(0),
      I5 => Q(16),
      O => \axi_rdata[16]_i_2_n_0\
    );
\axi_rdata[17]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000CCE200E2"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(17),
      I1 => \axi_araddr_reg[4]\,
      I2 => \maxCoordinateReg_reg[31]\(17),
      I3 => \axi_araddr_reg[3]\,
      I4 => \axi_rdata[17]_i_2_n_0\,
      I5 => \axi_araddr_reg[5]\,
      O => D(17)
    );
\axi_rdata[17]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => posReg(17),
      I1 => \intrEnableReg_reg[31]\(17),
      I2 => \axi_araddr_reg[3]_0\(1),
      I3 => \intrStatReg_reg[17]\,
      I4 => \axi_araddr_reg[3]_0\(0),
      I5 => Q(17),
      O => \axi_rdata[17]_i_2_n_0\
    );
\axi_rdata[18]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000CCE200E2"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(18),
      I1 => \axi_araddr_reg[4]\,
      I2 => \maxCoordinateReg_reg[31]\(18),
      I3 => \axi_araddr_reg[3]\,
      I4 => \axi_rdata[18]_i_2_n_0\,
      I5 => \axi_araddr_reg[5]\,
      O => D(18)
    );
\axi_rdata[18]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => posReg(18),
      I1 => \intrEnableReg_reg[31]\(18),
      I2 => \axi_araddr_reg[3]_0\(1),
      I3 => \intrStatReg_reg[18]\,
      I4 => \axi_araddr_reg[3]_0\(0),
      I5 => Q(18),
      O => \axi_rdata[18]_i_2_n_0\
    );
\axi_rdata[19]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000CCE200E2"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(19),
      I1 => \axi_araddr_reg[4]\,
      I2 => \maxCoordinateReg_reg[31]\(19),
      I3 => \axi_araddr_reg[3]\,
      I4 => \axi_rdata[19]_i_2_n_0\,
      I5 => \axi_araddr_reg[5]\,
      O => D(19)
    );
\axi_rdata[19]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => posReg(19),
      I1 => \intrEnableReg_reg[31]\(19),
      I2 => \axi_araddr_reg[3]_0\(1),
      I3 => \intrStatReg_reg[19]\,
      I4 => \axi_araddr_reg[3]_0\(0),
      I5 => Q(19),
      O => \axi_rdata[19]_i_2_n_0\
    );
\axi_rdata[1]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000CCE200E2"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(1),
      I1 => \axi_araddr_reg[4]\,
      I2 => \maxCoordinateReg_reg[31]\(1),
      I3 => \axi_araddr_reg[3]\,
      I4 => \axi_rdata[1]_i_2_n_0\,
      I5 => \axi_araddr_reg[5]\,
      O => D(1)
    );
\axi_rdata[1]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => posReg(1),
      I1 => \intrEnableReg_reg[31]\(1),
      I2 => \axi_araddr_reg[3]_0\(1),
      I3 => \intrStatReg_reg[1]_0\,
      I4 => \axi_araddr_reg[3]_0\(0),
      I5 => Q(1),
      O => \axi_rdata[1]_i_2_n_0\
    );
\axi_rdata[20]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000CCE200E2"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(20),
      I1 => \axi_araddr_reg[4]\,
      I2 => \maxCoordinateReg_reg[31]\(20),
      I3 => \axi_araddr_reg[3]\,
      I4 => \axi_rdata[20]_i_2_n_0\,
      I5 => \axi_araddr_reg[5]\,
      O => D(20)
    );
\axi_rdata[20]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => posReg(20),
      I1 => \intrEnableReg_reg[31]\(20),
      I2 => \axi_araddr_reg[3]_0\(1),
      I3 => \intrStatReg_reg[20]\,
      I4 => \axi_araddr_reg[3]_0\(0),
      I5 => Q(20),
      O => \axi_rdata[20]_i_2_n_0\
    );
\axi_rdata[21]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000CCE200E2"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(21),
      I1 => \axi_araddr_reg[4]\,
      I2 => \maxCoordinateReg_reg[31]\(21),
      I3 => \axi_araddr_reg[3]\,
      I4 => \axi_rdata[21]_i_2_n_0\,
      I5 => \axi_araddr_reg[5]\,
      O => D(21)
    );
\axi_rdata[21]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => posReg(21),
      I1 => \intrEnableReg_reg[31]\(21),
      I2 => \axi_araddr_reg[3]_0\(1),
      I3 => \intrStatReg_reg[21]\,
      I4 => \axi_araddr_reg[3]_0\(0),
      I5 => Q(21),
      O => \axi_rdata[21]_i_2_n_0\
    );
\axi_rdata[22]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000CCE200E2"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(22),
      I1 => \axi_araddr_reg[4]\,
      I2 => \maxCoordinateReg_reg[31]\(22),
      I3 => \axi_araddr_reg[3]\,
      I4 => \axi_rdata[22]_i_2_n_0\,
      I5 => \axi_araddr_reg[5]\,
      O => D(22)
    );
\axi_rdata[22]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => posReg(22),
      I1 => \intrEnableReg_reg[31]\(22),
      I2 => \axi_araddr_reg[3]_0\(1),
      I3 => \intrStatReg_reg[22]\,
      I4 => \axi_araddr_reg[3]_0\(0),
      I5 => Q(22),
      O => \axi_rdata[22]_i_2_n_0\
    );
\axi_rdata[23]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000CCE200E2"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(23),
      I1 => \axi_araddr_reg[4]\,
      I2 => \maxCoordinateReg_reg[31]\(23),
      I3 => \axi_araddr_reg[3]\,
      I4 => \axi_rdata[23]_i_2_n_0\,
      I5 => \axi_araddr_reg[5]\,
      O => D(23)
    );
\axi_rdata[23]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => posReg(23),
      I1 => \intrEnableReg_reg[31]\(23),
      I2 => \axi_araddr_reg[3]_0\(1),
      I3 => \intrStatReg_reg[23]\,
      I4 => \axi_araddr_reg[3]_0\(0),
      I5 => Q(23),
      O => \axi_rdata[23]_i_2_n_0\
    );
\axi_rdata[24]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000CCE200E2"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(24),
      I1 => \axi_araddr_reg[4]\,
      I2 => \maxCoordinateReg_reg[31]\(24),
      I3 => \axi_araddr_reg[3]\,
      I4 => \axi_rdata[24]_i_2_n_0\,
      I5 => \axi_araddr_reg[5]\,
      O => D(24)
    );
\axi_rdata[24]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => posReg(24),
      I1 => \intrEnableReg_reg[31]\(24),
      I2 => \axi_araddr_reg[3]_0\(1),
      I3 => \intrStatReg_reg[24]\,
      I4 => \axi_araddr_reg[3]_0\(0),
      I5 => Q(24),
      O => \axi_rdata[24]_i_2_n_0\
    );
\axi_rdata[25]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000CCE200E2"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(25),
      I1 => \axi_araddr_reg[4]\,
      I2 => \maxCoordinateReg_reg[31]\(25),
      I3 => \axi_araddr_reg[3]\,
      I4 => \axi_rdata[25]_i_2_n_0\,
      I5 => \axi_araddr_reg[5]\,
      O => D(25)
    );
\axi_rdata[25]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => posReg(25),
      I1 => \intrEnableReg_reg[31]\(25),
      I2 => \axi_araddr_reg[3]_0\(1),
      I3 => \intrStatReg_reg[25]\,
      I4 => \axi_araddr_reg[3]_0\(0),
      I5 => Q(25),
      O => \axi_rdata[25]_i_2_n_0\
    );
\axi_rdata[26]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000CCE200E2"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(26),
      I1 => \axi_araddr_reg[4]\,
      I2 => \maxCoordinateReg_reg[31]\(26),
      I3 => \axi_araddr_reg[3]\,
      I4 => \axi_rdata[26]_i_2_n_0\,
      I5 => \axi_araddr_reg[5]\,
      O => D(26)
    );
\axi_rdata[26]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => posReg(26),
      I1 => \intrEnableReg_reg[31]\(26),
      I2 => \axi_araddr_reg[3]_0\(1),
      I3 => \intrStatReg_reg[26]\,
      I4 => \axi_araddr_reg[3]_0\(0),
      I5 => Q(26),
      O => \axi_rdata[26]_i_2_n_0\
    );
\axi_rdata[27]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000CCE200E2"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(27),
      I1 => \axi_araddr_reg[4]\,
      I2 => \maxCoordinateReg_reg[31]\(27),
      I3 => \axi_araddr_reg[3]\,
      I4 => \axi_rdata[27]_i_2_n_0\,
      I5 => \axi_araddr_reg[5]\,
      O => D(27)
    );
\axi_rdata[27]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => posReg(27),
      I1 => \intrEnableReg_reg[31]\(27),
      I2 => \axi_araddr_reg[3]_0\(1),
      I3 => \intrStatReg_reg[27]\,
      I4 => \axi_araddr_reg[3]_0\(0),
      I5 => Q(27),
      O => \axi_rdata[27]_i_2_n_0\
    );
\axi_rdata[28]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000CCE200E2"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(28),
      I1 => \axi_araddr_reg[4]\,
      I2 => \maxCoordinateReg_reg[31]\(28),
      I3 => \axi_araddr_reg[3]\,
      I4 => \axi_rdata[28]_i_2_n_0\,
      I5 => \axi_araddr_reg[5]\,
      O => D(28)
    );
\axi_rdata[28]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => posReg(28),
      I1 => \intrEnableReg_reg[31]\(28),
      I2 => \axi_araddr_reg[3]_0\(1),
      I3 => \intrStatReg_reg[28]\,
      I4 => \axi_araddr_reg[3]_0\(0),
      I5 => Q(28),
      O => \axi_rdata[28]_i_2_n_0\
    );
\axi_rdata[29]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000CCE200E2"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(29),
      I1 => \axi_araddr_reg[4]\,
      I2 => \maxCoordinateReg_reg[31]\(29),
      I3 => \axi_araddr_reg[3]\,
      I4 => \axi_rdata[29]_i_2_n_0\,
      I5 => \axi_araddr_reg[5]\,
      O => D(29)
    );
\axi_rdata[29]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => posReg(29),
      I1 => \intrEnableReg_reg[31]\(29),
      I2 => \axi_araddr_reg[3]_0\(1),
      I3 => \intrStatReg_reg[29]\,
      I4 => \axi_araddr_reg[3]_0\(0),
      I5 => Q(29),
      O => \axi_rdata[29]_i_2_n_0\
    );
\axi_rdata[2]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000CCE200E2"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(2),
      I1 => \axi_araddr_reg[4]\,
      I2 => \maxCoordinateReg_reg[31]\(2),
      I3 => \axi_araddr_reg[3]\,
      I4 => \axi_rdata[2]_i_2_n_0\,
      I5 => \axi_araddr_reg[5]\,
      O => D(2)
    );
\axi_rdata[2]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => posReg(2),
      I1 => \intrEnableReg_reg[31]\(2),
      I2 => \axi_araddr_reg[3]_0\(1),
      I3 => \intrStatReg_reg[2]\,
      I4 => \axi_araddr_reg[3]_0\(0),
      I5 => Q(2),
      O => \axi_rdata[2]_i_2_n_0\
    );
\axi_rdata[30]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000CCE200E2"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(30),
      I1 => \axi_araddr_reg[4]\,
      I2 => \maxCoordinateReg_reg[31]\(30),
      I3 => \axi_araddr_reg[3]\,
      I4 => \axi_rdata[30]_i_2_n_0\,
      I5 => \axi_araddr_reg[5]\,
      O => D(30)
    );
\axi_rdata[30]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => posReg(30),
      I1 => \intrEnableReg_reg[31]\(30),
      I2 => \axi_araddr_reg[3]_0\(1),
      I3 => \intrStatReg_reg[30]\,
      I4 => \axi_araddr_reg[3]_0\(0),
      I5 => Q(30),
      O => \axi_rdata[30]_i_2_n_0\
    );
\axi_rdata[31]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000CCE200E2"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(31),
      I1 => \axi_araddr_reg[4]\,
      I2 => \maxCoordinateReg_reg[31]\(31),
      I3 => \axi_araddr_reg[3]\,
      I4 => \axi_rdata[31]_i_4_n_0\,
      I5 => \axi_araddr_reg[5]\,
      O => D(31)
    );
\axi_rdata[31]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => posReg(31),
      I1 => \intrEnableReg_reg[31]\(31),
      I2 => \axi_araddr_reg[3]_0\(1),
      I3 => \intrStatReg_reg[31]\,
      I4 => \axi_araddr_reg[3]_0\(0),
      I5 => Q(31),
      O => \axi_rdata[31]_i_4_n_0\
    );
\axi_rdata[3]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000CCE200E2"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(3),
      I1 => \axi_araddr_reg[4]\,
      I2 => \maxCoordinateReg_reg[31]\(3),
      I3 => \axi_araddr_reg[3]\,
      I4 => \axi_rdata[3]_i_2_n_0\,
      I5 => \axi_araddr_reg[5]\,
      O => D(3)
    );
\axi_rdata[3]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => posReg(3),
      I1 => \intrEnableReg_reg[31]\(3),
      I2 => \axi_araddr_reg[3]_0\(1),
      I3 => \intrStatReg_reg[3]\,
      I4 => \axi_araddr_reg[3]_0\(0),
      I5 => Q(3),
      O => \axi_rdata[3]_i_2_n_0\
    );
\axi_rdata[4]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000CCE200E2"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(4),
      I1 => \axi_araddr_reg[4]\,
      I2 => \maxCoordinateReg_reg[31]\(4),
      I3 => \axi_araddr_reg[3]\,
      I4 => \axi_rdata[4]_i_2_n_0\,
      I5 => \axi_araddr_reg[5]\,
      O => D(4)
    );
\axi_rdata[4]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => posReg(4),
      I1 => \intrEnableReg_reg[31]\(4),
      I2 => \axi_araddr_reg[3]_0\(1),
      I3 => \intrStatReg_reg[4]\,
      I4 => \axi_araddr_reg[3]_0\(0),
      I5 => Q(4),
      O => \axi_rdata[4]_i_2_n_0\
    );
\axi_rdata[5]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000CCE200E2"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(5),
      I1 => \axi_araddr_reg[4]\,
      I2 => \maxCoordinateReg_reg[31]\(5),
      I3 => \axi_araddr_reg[3]\,
      I4 => \axi_rdata[5]_i_2_n_0\,
      I5 => \axi_araddr_reg[5]\,
      O => D(5)
    );
\axi_rdata[5]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => posReg(5),
      I1 => \intrEnableReg_reg[31]\(5),
      I2 => \axi_araddr_reg[3]_0\(1),
      I3 => \intrStatReg_reg[5]\,
      I4 => \axi_araddr_reg[3]_0\(0),
      I5 => Q(5),
      O => \axi_rdata[5]_i_2_n_0\
    );
\axi_rdata[6]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000CCE200E2"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(6),
      I1 => \axi_araddr_reg[4]\,
      I2 => \maxCoordinateReg_reg[31]\(6),
      I3 => \axi_araddr_reg[3]\,
      I4 => \axi_rdata[6]_i_2_n_0\,
      I5 => \axi_araddr_reg[5]\,
      O => D(6)
    );
\axi_rdata[6]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => posReg(6),
      I1 => \intrEnableReg_reg[31]\(6),
      I2 => \axi_araddr_reg[3]_0\(1),
      I3 => \intrStatReg_reg[6]\,
      I4 => \axi_araddr_reg[3]_0\(0),
      I5 => Q(6),
      O => \axi_rdata[6]_i_2_n_0\
    );
\axi_rdata[7]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000CCE200E2"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(7),
      I1 => \axi_araddr_reg[4]\,
      I2 => \maxCoordinateReg_reg[31]\(7),
      I3 => \axi_araddr_reg[3]\,
      I4 => \axi_rdata[7]_i_2_n_0\,
      I5 => \axi_araddr_reg[5]\,
      O => D(7)
    );
\axi_rdata[7]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => posReg(7),
      I1 => \intrEnableReg_reg[31]\(7),
      I2 => \axi_araddr_reg[3]_0\(1),
      I3 => \intrStatReg_reg[7]\,
      I4 => \axi_araddr_reg[3]_0\(0),
      I5 => Q(7),
      O => \axi_rdata[7]_i_2_n_0\
    );
\axi_rdata[8]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000CCE200E2"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(8),
      I1 => \axi_araddr_reg[4]\,
      I2 => \maxCoordinateReg_reg[31]\(8),
      I3 => \axi_araddr_reg[3]\,
      I4 => \axi_rdata[8]_i_2_n_0\,
      I5 => \axi_araddr_reg[5]\,
      O => D(8)
    );
\axi_rdata[8]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => posReg(8),
      I1 => \intrEnableReg_reg[31]\(8),
      I2 => \axi_araddr_reg[3]_0\(1),
      I3 => \intrStatReg_reg[8]\,
      I4 => \axi_araddr_reg[3]_0\(0),
      I5 => Q(8),
      O => \axi_rdata[8]_i_2_n_0\
    );
\axi_rdata[9]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000CCE200E2"
    )
        port map (
      I0 => \maxCountReg_reg[31]\(9),
      I1 => \axi_araddr_reg[4]\,
      I2 => \maxCoordinateReg_reg[31]\(9),
      I3 => \axi_araddr_reg[3]\,
      I4 => \axi_rdata[9]_i_2_n_0\,
      I5 => \axi_araddr_reg[5]\,
      O => D(9)
    );
\axi_rdata[9]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => posReg(9),
      I1 => \intrEnableReg_reg[31]\(9),
      I2 => \axi_araddr_reg[3]_0\(1),
      I3 => \intrStatReg_reg[9]\,
      I4 => \axi_araddr_reg[3]_0\(0),
      I5 => Q(9),
      O => \axi_rdata[9]_i_2_n_0\
    );
dbDown: entity work.decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_debounce
     port map (
      CO(0) => pGDown_n_1,
      \counter_reg[31]_0\ => dbDown_n_0,
      i_button_down => i_button_down,
      s00_axi_aclk => s00_axi_aclk
    );
dbLeft: entity work.decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_debounce_0
     port map (
      CO(0) => counter2,
      clear => clear,
      i_button_left => i_button_left,
      s00_axi_aclk => s00_axi_aclk
    );
dbRight: entity work.decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_debounce_1
     port map (
      CO(0) => pGRight_n_0,
      \counter_reg[31]_0\ => dbRight_n_0,
      i_button_right => i_button_right,
      s00_axi_aclk => s00_axi_aclk
    );
dbUp: entity work.decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_debounce_2
     port map (
      CO(0) => pGUp_n_1,
      \counter_reg[31]_0\ => dbUp_n_0,
      i_button_up => i_button_up,
      s00_axi_aclk => s00_axi_aclk
    );
\i__carry__0_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"2F02"
    )
        port map (
      I0 => \maxCoordinateReg_reg[31]\(14),
      I1 => posReg(14),
      I2 => posReg(15),
      I3 => \maxCoordinateReg_reg[31]\(15),
      O => \i__carry__0_i_1_n_0\
    );
\i__carry__0_i_1__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"2F02"
    )
        port map (
      I0 => \maxCoordinateReg_reg[31]\(30),
      I1 => posReg(30),
      I2 => posReg(31),
      I3 => \maxCoordinateReg_reg[31]\(31),
      O => \i__carry__0_i_1__0_n_0\
    );
\i__carry__0_i_2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"2F02"
    )
        port map (
      I0 => \maxCoordinateReg_reg[31]\(12),
      I1 => posReg(12),
      I2 => posReg(13),
      I3 => \maxCoordinateReg_reg[31]\(13),
      O => \i__carry__0_i_2_n_0\
    );
\i__carry__0_i_2__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"2F02"
    )
        port map (
      I0 => \maxCoordinateReg_reg[31]\(28),
      I1 => posReg(28),
      I2 => posReg(29),
      I3 => \maxCoordinateReg_reg[31]\(29),
      O => \i__carry__0_i_2__0_n_0\
    );
\i__carry__0_i_3\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"2F02"
    )
        port map (
      I0 => \maxCoordinateReg_reg[31]\(10),
      I1 => posReg(10),
      I2 => posReg(11),
      I3 => \maxCoordinateReg_reg[31]\(11),
      O => \i__carry__0_i_3_n_0\
    );
\i__carry__0_i_3__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"2F02"
    )
        port map (
      I0 => \maxCoordinateReg_reg[31]\(26),
      I1 => posReg(26),
      I2 => posReg(27),
      I3 => \maxCoordinateReg_reg[31]\(27),
      O => \i__carry__0_i_3__0_n_0\
    );
\i__carry__0_i_4\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"2F02"
    )
        port map (
      I0 => \maxCoordinateReg_reg[31]\(8),
      I1 => posReg(8),
      I2 => posReg(9),
      I3 => \maxCoordinateReg_reg[31]\(9),
      O => \i__carry__0_i_4_n_0\
    );
\i__carry__0_i_4__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"2F02"
    )
        port map (
      I0 => \maxCoordinateReg_reg[31]\(24),
      I1 => posReg(24),
      I2 => posReg(25),
      I3 => \maxCoordinateReg_reg[31]\(25),
      O => \i__carry__0_i_4__0_n_0\
    );
\i__carry__0_i_5\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9009"
    )
        port map (
      I0 => \maxCoordinateReg_reg[31]\(14),
      I1 => posReg(14),
      I2 => \maxCoordinateReg_reg[31]\(15),
      I3 => posReg(15),
      O => \i__carry__0_i_5_n_0\
    );
\i__carry__0_i_5__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9009"
    )
        port map (
      I0 => \maxCoordinateReg_reg[31]\(30),
      I1 => posReg(30),
      I2 => \maxCoordinateReg_reg[31]\(31),
      I3 => posReg(31),
      O => \i__carry__0_i_5__0_n_0\
    );
\i__carry__0_i_6\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9009"
    )
        port map (
      I0 => \maxCoordinateReg_reg[31]\(12),
      I1 => posReg(12),
      I2 => \maxCoordinateReg_reg[31]\(13),
      I3 => posReg(13),
      O => \i__carry__0_i_6_n_0\
    );
\i__carry__0_i_6__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9009"
    )
        port map (
      I0 => \maxCoordinateReg_reg[31]\(28),
      I1 => posReg(28),
      I2 => \maxCoordinateReg_reg[31]\(29),
      I3 => posReg(29),
      O => \i__carry__0_i_6__0_n_0\
    );
\i__carry__0_i_7\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9009"
    )
        port map (
      I0 => \maxCoordinateReg_reg[31]\(10),
      I1 => posReg(10),
      I2 => \maxCoordinateReg_reg[31]\(11),
      I3 => posReg(11),
      O => \i__carry__0_i_7_n_0\
    );
\i__carry__0_i_7__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9009"
    )
        port map (
      I0 => \maxCoordinateReg_reg[31]\(26),
      I1 => posReg(26),
      I2 => \maxCoordinateReg_reg[31]\(27),
      I3 => posReg(27),
      O => \i__carry__0_i_7__0_n_0\
    );
\i__carry__0_i_8\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9009"
    )
        port map (
      I0 => \maxCoordinateReg_reg[31]\(8),
      I1 => posReg(8),
      I2 => \maxCoordinateReg_reg[31]\(9),
      I3 => posReg(9),
      O => \i__carry__0_i_8_n_0\
    );
\i__carry__0_i_8__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9009"
    )
        port map (
      I0 => \maxCoordinateReg_reg[31]\(24),
      I1 => posReg(24),
      I2 => \maxCoordinateReg_reg[31]\(25),
      I3 => posReg(25),
      O => \i__carry__0_i_8__0_n_0\
    );
\i__carry_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"2F02"
    )
        port map (
      I0 => \maxCoordinateReg_reg[31]\(6),
      I1 => posReg(6),
      I2 => posReg(7),
      I3 => \maxCoordinateReg_reg[31]\(7),
      O => \i__carry_i_1_n_0\
    );
\i__carry_i_1__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"2F02"
    )
        port map (
      I0 => \maxCoordinateReg_reg[31]\(22),
      I1 => posReg(22),
      I2 => posReg(23),
      I3 => \maxCoordinateReg_reg[31]\(23),
      O => \i__carry_i_1__0_n_0\
    );
\i__carry_i_2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"2F02"
    )
        port map (
      I0 => \maxCoordinateReg_reg[31]\(4),
      I1 => posReg(4),
      I2 => posReg(5),
      I3 => \maxCoordinateReg_reg[31]\(5),
      O => \i__carry_i_2_n_0\
    );
\i__carry_i_2__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"2F02"
    )
        port map (
      I0 => \maxCoordinateReg_reg[31]\(20),
      I1 => posReg(20),
      I2 => posReg(21),
      I3 => \maxCoordinateReg_reg[31]\(21),
      O => \i__carry_i_2__0_n_0\
    );
\i__carry_i_3\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"2F02"
    )
        port map (
      I0 => \maxCoordinateReg_reg[31]\(2),
      I1 => posReg(2),
      I2 => posReg(3),
      I3 => \maxCoordinateReg_reg[31]\(3),
      O => \i__carry_i_3_n_0\
    );
\i__carry_i_3__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"2F02"
    )
        port map (
      I0 => \maxCoordinateReg_reg[31]\(18),
      I1 => posReg(18),
      I2 => posReg(19),
      I3 => \maxCoordinateReg_reg[31]\(19),
      O => \i__carry_i_3__0_n_0\
    );
\i__carry_i_4\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"2F02"
    )
        port map (
      I0 => \maxCoordinateReg_reg[31]\(0),
      I1 => posReg(0),
      I2 => posReg(1),
      I3 => \maxCoordinateReg_reg[31]\(1),
      O => \i__carry_i_4_n_0\
    );
\i__carry_i_4__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"2F02"
    )
        port map (
      I0 => \maxCoordinateReg_reg[31]\(16),
      I1 => posReg(16),
      I2 => posReg(17),
      I3 => \maxCoordinateReg_reg[31]\(17),
      O => \i__carry_i_4__0_n_0\
    );
\i__carry_i_5\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9009"
    )
        port map (
      I0 => \maxCoordinateReg_reg[31]\(6),
      I1 => posReg(6),
      I2 => \maxCoordinateReg_reg[31]\(7),
      I3 => posReg(7),
      O => \i__carry_i_5_n_0\
    );
\i__carry_i_5__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9009"
    )
        port map (
      I0 => \maxCoordinateReg_reg[31]\(22),
      I1 => posReg(22),
      I2 => \maxCoordinateReg_reg[31]\(23),
      I3 => posReg(23),
      O => \i__carry_i_5__0_n_0\
    );
\i__carry_i_6\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9009"
    )
        port map (
      I0 => \maxCoordinateReg_reg[31]\(4),
      I1 => posReg(4),
      I2 => \maxCoordinateReg_reg[31]\(5),
      I3 => posReg(5),
      O => \i__carry_i_6_n_0\
    );
\i__carry_i_6__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9009"
    )
        port map (
      I0 => \maxCoordinateReg_reg[31]\(20),
      I1 => posReg(20),
      I2 => \maxCoordinateReg_reg[31]\(21),
      I3 => posReg(21),
      O => \i__carry_i_6__0_n_0\
    );
\i__carry_i_7\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9009"
    )
        port map (
      I0 => \maxCoordinateReg_reg[31]\(2),
      I1 => posReg(2),
      I2 => \maxCoordinateReg_reg[31]\(3),
      I3 => posReg(3),
      O => \i__carry_i_7_n_0\
    );
\i__carry_i_7__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9009"
    )
        port map (
      I0 => \maxCoordinateReg_reg[31]\(18),
      I1 => posReg(18),
      I2 => \maxCoordinateReg_reg[31]\(19),
      I3 => posReg(19),
      O => \i__carry_i_7__0_n_0\
    );
\i__carry_i_8\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9009"
    )
        port map (
      I0 => \maxCoordinateReg_reg[31]\(0),
      I1 => posReg(0),
      I2 => \maxCoordinateReg_reg[31]\(1),
      I3 => posReg(1),
      O => \i__carry_i_8_n_0\
    );
\i__carry_i_8__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9009"
    )
        port map (
      I0 => \maxCoordinateReg_reg[31]\(16),
      I1 => posReg(16),
      I2 => \maxCoordinateReg_reg[31]\(17),
      I3 => posReg(17),
      O => \i__carry_i_8__0_n_0\
    );
\intrStatReg[1]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FF550CAA"
    )
        port map (
      I0 => s00_axi_wdata(0),
      I1 => w_mousemove,
      I2 => w_button_pulse,
      I3 => \axi_awaddr_reg[4]\,
      I4 => \intrStatReg_reg[1]_0\,
      O => \intrStatReg_reg[1]\
    );
o_intr_i_10: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFFE"
    )
        port map (
      I0 => posReg(25),
      I1 => posReg(24),
      I2 => posReg(27),
      I3 => posReg(26),
      O => o_intr_i_10_n_0
    );
o_intr_i_3: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFEFFFFFFFF"
    )
        port map (
      I0 => o_intr_i_6_n_0,
      I1 => posReg(23),
      I2 => posReg(22),
      I3 => posReg(21),
      I4 => posReg(20),
      I5 => o_intr_i_7_n_0,
      O => p_1_in
    );
o_intr_i_4: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00000001"
    )
        port map (
      I0 => posReg(12),
      I1 => posReg(13),
      I2 => posReg(15),
      I3 => posReg(14),
      I4 => o_intr_i_8_n_0,
      O => o_intr_i_4_n_0
    );
o_intr_i_5: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00000001"
    )
        port map (
      I0 => posReg(4),
      I1 => posReg(5),
      I2 => posReg(6),
      I3 => posReg(7),
      I4 => o_intr_i_9_n_0,
      O => o_intr_i_5_n_0
    );
o_intr_i_6: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFFE"
    )
        port map (
      I0 => posReg(17),
      I1 => posReg(16),
      I2 => posReg(19),
      I3 => posReg(18),
      O => o_intr_i_6_n_0
    );
o_intr_i_7: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00000001"
    )
        port map (
      I0 => posReg(28),
      I1 => posReg(29),
      I2 => posReg(31),
      I3 => posReg(30),
      I4 => o_intr_i_10_n_0,
      O => o_intr_i_7_n_0
    );
o_intr_i_8: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFFE"
    )
        port map (
      I0 => posReg(9),
      I1 => posReg(8),
      I2 => posReg(11),
      I3 => posReg(10),
      O => o_intr_i_8_n_0
    );
o_intr_i_9: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFFE"
    )
        port map (
      I0 => posReg(1),
      I1 => posReg(0),
      I2 => posReg(3),
      I3 => posReg(2),
      O => o_intr_i_9_n_0
    );
o_intr_reg: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => o_intr1_out,
      Q => w_mousemove,
      R => '0'
    );
\o_x_pos0_inferred__1/i__carry\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \o_x_pos0_inferred__1/i__carry_n_0\,
      CO(2) => \o_x_pos0_inferred__1/i__carry_n_1\,
      CO(1) => \o_x_pos0_inferred__1/i__carry_n_2\,
      CO(0) => \o_x_pos0_inferred__1/i__carry_n_3\,
      CYINIT => '0',
      DI(3) => \i__carry_i_1_n_0\,
      DI(2) => \i__carry_i_2_n_0\,
      DI(1) => \i__carry_i_3_n_0\,
      DI(0) => \i__carry_i_4_n_0\,
      O(3 downto 0) => \NLW_o_x_pos0_inferred__1/i__carry_O_UNCONNECTED\(3 downto 0),
      S(3) => \i__carry_i_5_n_0\,
      S(2) => \i__carry_i_6_n_0\,
      S(1) => \i__carry_i_7_n_0\,
      S(0) => \i__carry_i_8_n_0\
    );
\o_x_pos0_inferred__1/i__carry__0\: unisim.vcomponents.CARRY4
     port map (
      CI => \o_x_pos0_inferred__1/i__carry_n_0\,
      CO(3) => p_0_in,
      CO(2) => \o_x_pos0_inferred__1/i__carry__0_n_1\,
      CO(1) => \o_x_pos0_inferred__1/i__carry__0_n_2\,
      CO(0) => \o_x_pos0_inferred__1/i__carry__0_n_3\,
      CYINIT => '0',
      DI(3) => \i__carry__0_i_1_n_0\,
      DI(2) => \i__carry__0_i_2_n_0\,
      DI(1) => \i__carry__0_i_3_n_0\,
      DI(0) => \i__carry__0_i_4_n_0\,
      O(3 downto 0) => \NLW_o_x_pos0_inferred__1/i__carry__0_O_UNCONNECTED\(3 downto 0),
      S(3) => \i__carry__0_i_5_n_0\,
      S(2) => \i__carry__0_i_6_n_0\,
      S(1) => \i__carry__0_i_7_n_0\,
      S(0) => \i__carry__0_i_8_n_0\
    );
\o_x_pos[0]_i_10\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D1"
    )
        port map (
      I0 => posReg(0),
      I1 => Q(0),
      I2 => \maxCoordinateReg_reg[31]\(1),
      O => \o_x_pos[0]_i_10_n_0\
    );
\o_x_pos[0]_i_6\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => Q(0),
      O => \o_x_pos[0]_i_6_n_0\
    );
\o_x_pos_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => sel,
      D => pGRight_n_6,
      Q => posReg(0),
      R => '0'
    );
\o_x_pos_reg[10]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => sel,
      D => pGRight_n_12,
      Q => posReg(10),
      R => '0'
    );
\o_x_pos_reg[11]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => sel,
      D => pGRight_n_11,
      Q => posReg(11),
      R => '0'
    );
\o_x_pos_reg[12]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => sel,
      D => pGRight_n_18,
      Q => posReg(12),
      R => '0'
    );
\o_x_pos_reg[13]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => sel,
      D => pGRight_n_17,
      Q => posReg(13),
      R => '0'
    );
\o_x_pos_reg[14]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => sel,
      D => pGRight_n_16,
      Q => posReg(14),
      R => '0'
    );
\o_x_pos_reg[15]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => sel,
      D => pGRight_n_15,
      Q => posReg(15),
      R => '0'
    );
\o_x_pos_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => sel,
      D => pGRight_n_5,
      Q => posReg(1),
      R => '0'
    );
\o_x_pos_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => sel,
      D => pGRight_n_4,
      Q => posReg(2),
      R => '0'
    );
\o_x_pos_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => sel,
      D => pGRight_n_3,
      Q => posReg(3),
      R => '0'
    );
\o_x_pos_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => sel,
      D => pGRight_n_10,
      Q => posReg(4),
      R => '0'
    );
\o_x_pos_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => sel,
      D => pGRight_n_9,
      Q => posReg(5),
      R => '0'
    );
\o_x_pos_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => sel,
      D => pGRight_n_8,
      Q => posReg(6),
      R => '0'
    );
\o_x_pos_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => sel,
      D => pGRight_n_7,
      Q => posReg(7),
      R => '0'
    );
\o_x_pos_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => sel,
      D => pGRight_n_14,
      Q => posReg(8),
      R => '0'
    );
\o_x_pos_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => sel,
      D => pGRight_n_13,
      Q => posReg(9),
      R => '0'
    );
\o_y_pos0_inferred__1/i__carry\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \o_y_pos0_inferred__1/i__carry_n_0\,
      CO(2) => \o_y_pos0_inferred__1/i__carry_n_1\,
      CO(1) => \o_y_pos0_inferred__1/i__carry_n_2\,
      CO(0) => \o_y_pos0_inferred__1/i__carry_n_3\,
      CYINIT => '0',
      DI(3) => \i__carry_i_1__0_n_0\,
      DI(2) => \i__carry_i_2__0_n_0\,
      DI(1) => \i__carry_i_3__0_n_0\,
      DI(0) => \i__carry_i_4__0_n_0\,
      O(3 downto 0) => \NLW_o_y_pos0_inferred__1/i__carry_O_UNCONNECTED\(3 downto 0),
      S(3) => \i__carry_i_5__0_n_0\,
      S(2) => \i__carry_i_6__0_n_0\,
      S(1) => \i__carry_i_7__0_n_0\,
      S(0) => \i__carry_i_8__0_n_0\
    );
\o_y_pos0_inferred__1/i__carry__0\: unisim.vcomponents.CARRY4
     port map (
      CI => \o_y_pos0_inferred__1/i__carry_n_0\,
      CO(3) => p_2_in,
      CO(2) => \o_y_pos0_inferred__1/i__carry__0_n_1\,
      CO(1) => \o_y_pos0_inferred__1/i__carry__0_n_2\,
      CO(0) => \o_y_pos0_inferred__1/i__carry__0_n_3\,
      CYINIT => '0',
      DI(3) => \i__carry__0_i_1__0_n_0\,
      DI(2) => \i__carry__0_i_2__0_n_0\,
      DI(1) => \i__carry__0_i_3__0_n_0\,
      DI(0) => \i__carry__0_i_4__0_n_0\,
      O(3 downto 0) => \NLW_o_y_pos0_inferred__1/i__carry__0_O_UNCONNECTED\(3 downto 0),
      S(3) => \i__carry__0_i_5__0_n_0\,
      S(2) => \i__carry__0_i_6__0_n_0\,
      S(1) => \i__carry__0_i_7__0_n_0\,
      S(0) => \i__carry__0_i_8__0_n_0\
    );
\o_y_pos[0]_i_10\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D1"
    )
        port map (
      I0 => posReg(16),
      I1 => Q(0),
      I2 => \maxCoordinateReg_reg[31]\(17),
      O => \o_y_pos[0]_i_10_n_0\
    );
\o_y_pos[0]_i_6\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => Q(0),
      O => \o_y_pos[0]_i_6_n_0\
    );
\o_y_pos_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => pGUp_n_2,
      D => pGDown_n_5,
      Q => posReg(16),
      R => '0'
    );
\o_y_pos_reg[10]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => pGUp_n_2,
      D => pGDown_n_11,
      Q => posReg(26),
      R => '0'
    );
\o_y_pos_reg[11]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => pGUp_n_2,
      D => pGDown_n_10,
      Q => posReg(27),
      R => '0'
    );
\o_y_pos_reg[12]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => pGUp_n_2,
      D => pGDown_n_17,
      Q => posReg(28),
      R => '0'
    );
\o_y_pos_reg[13]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => pGUp_n_2,
      D => pGDown_n_16,
      Q => posReg(29),
      R => '0'
    );
\o_y_pos_reg[14]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => pGUp_n_2,
      D => pGDown_n_15,
      Q => posReg(30),
      R => '0'
    );
\o_y_pos_reg[15]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => pGUp_n_2,
      D => pGDown_n_14,
      Q => posReg(31),
      R => '0'
    );
\o_y_pos_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => pGUp_n_2,
      D => pGDown_n_4,
      Q => posReg(17),
      R => '0'
    );
\o_y_pos_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => pGUp_n_2,
      D => pGDown_n_3,
      Q => posReg(18),
      R => '0'
    );
\o_y_pos_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => pGUp_n_2,
      D => pGDown_n_2,
      Q => posReg(19),
      R => '0'
    );
\o_y_pos_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => pGUp_n_2,
      D => pGDown_n_9,
      Q => posReg(20),
      R => '0'
    );
\o_y_pos_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => pGUp_n_2,
      D => pGDown_n_8,
      Q => posReg(21),
      R => '0'
    );
\o_y_pos_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => pGUp_n_2,
      D => pGDown_n_7,
      Q => posReg(22),
      R => '0'
    );
\o_y_pos_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => pGUp_n_2,
      D => pGDown_n_6,
      Q => posReg(23),
      R => '0'
    );
\o_y_pos_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => pGUp_n_2,
      D => pGDown_n_13,
      Q => posReg(24),
      R => '0'
    );
\o_y_pos_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => pGUp_n_2,
      D => pGDown_n_12,
      Q => posReg(25),
      R => '0'
    );
pGDown: entity work.decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_pulseGen
     port map (
      CO(0) => pGDown_n_1,
      DI(0) => \o_y_pos[0]_i_6_n_0\,
      O(3) => pGDown_n_2,
      O(2) => pGDown_n_3,
      O(1) => pGDown_n_4,
      O(0) => pGDown_n_5,
      Q(0) => Q(0),
      S(0) => \o_y_pos[0]_i_10_n_0\,
      \maxCoordinateReg_reg[31]\(13 downto 0) => \maxCoordinateReg_reg[31]\(31 downto 18),
      \maxCountReg_reg[31]\(31 downto 0) => \maxCountReg_reg[31]\(31 downto 0),
      o_press_reg => dbDown_n_0,
      \o_y_pos_reg[0]\ => pGDown_n_0,
      \o_y_pos_reg[11]\(3) => pGDown_n_10,
      \o_y_pos_reg[11]\(2) => pGDown_n_11,
      \o_y_pos_reg[11]\(1) => pGDown_n_12,
      \o_y_pos_reg[11]\(0) => pGDown_n_13,
      \o_y_pos_reg[15]\(3) => pGDown_n_14,
      \o_y_pos_reg[15]\(2) => pGDown_n_15,
      \o_y_pos_reg[15]\(1) => pGDown_n_16,
      \o_y_pos_reg[15]\(0) => pGDown_n_17,
      \o_y_pos_reg[7]\(3) => pGDown_n_6,
      \o_y_pos_reg[7]\(2) => pGDown_n_7,
      \o_y_pos_reg[7]\(1) => pGDown_n_8,
      \o_y_pos_reg[7]\(0) => pGDown_n_9,
      posReg(14 downto 0) => posReg(31 downto 17),
      s00_axi_aclk => s00_axi_aclk
    );
pGLeft: entity work.decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_pulseGen_3
     port map (
      CO(0) => counter2,
      clear => clear,
      \maxCountReg_reg[31]\(31 downto 0) => \maxCountReg_reg[31]\(31 downto 0),
      o_pulse => o_pulse,
      s00_axi_aclk => s00_axi_aclk
    );
pGRight: entity work.decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_pulseGen_4
     port map (
      CO(0) => pGRight_n_0,
      DI(0) => \o_x_pos[0]_i_6_n_0\,
      O(3) => pGRight_n_3,
      O(2) => pGRight_n_4,
      O(1) => pGRight_n_5,
      O(0) => pGRight_n_6,
      Q(0) => Q(0),
      S(0) => \o_x_pos[0]_i_10_n_0\,
      \maxCoordinateReg_reg[14]\(0) => p_0_in,
      \maxCoordinateReg_reg[15]\(13 downto 0) => \maxCoordinateReg_reg[31]\(15 downto 2),
      \maxCoordinateReg_reg[30]\(0) => p_2_in,
      \maxCountReg_reg[31]\(31 downto 0) => \maxCountReg_reg[31]\(31 downto 0),
      o_intr1_out => o_intr1_out,
      o_press_reg => dbRight_n_0,
      o_pulse => o_pulse,
      o_pulse_reg_0 => pGUp_n_0,
      o_pulse_reg_1 => pGDown_n_0,
      \o_x_pos_reg[11]\(3) => pGRight_n_11,
      \o_x_pos_reg[11]\(2) => pGRight_n_12,
      \o_x_pos_reg[11]\(1) => pGRight_n_13,
      \o_x_pos_reg[11]\(0) => pGRight_n_14,
      \o_x_pos_reg[12]\ => o_intr_i_4_n_0,
      \o_x_pos_reg[15]\(3) => pGRight_n_15,
      \o_x_pos_reg[15]\(2) => pGRight_n_16,
      \o_x_pos_reg[15]\(1) => pGRight_n_17,
      \o_x_pos_reg[15]\(0) => pGRight_n_18,
      \o_x_pos_reg[4]\ => o_intr_i_5_n_0,
      \o_x_pos_reg[7]\(3) => pGRight_n_7,
      \o_x_pos_reg[7]\(2) => pGRight_n_8,
      \o_x_pos_reg[7]\(1) => pGRight_n_9,
      \o_x_pos_reg[7]\(0) => pGRight_n_10,
      p_1_in => p_1_in,
      posReg(14 downto 0) => posReg(15 downto 1),
      s00_axi_aclk => s00_axi_aclk,
      sel => sel
    );
pGUp: entity work.decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_pulseGen_5
     port map (
      CO(0) => pGUp_n_1,
      Q(0) => Q(0),
      \maxCoordinateReg_reg[30]\(0) => p_2_in,
      \maxCountReg_reg[31]\(31 downto 0) => \maxCountReg_reg[31]\(31 downto 0),
      o_press_reg => dbUp_n_0,
      o_pulse_reg_0 => pGDown_n_0,
      \o_y_pos_reg[0]\ => pGUp_n_0,
      \o_y_pos_reg[0]_0\ => pGUp_n_2,
      p_1_in => p_1_in,
      s00_axi_aclk => s00_axi_aclk
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_zyMouse_v1_0_S00_AXI is
  port (
    s00_axi_wready : out STD_LOGIC;
    s00_axi_awready : out STD_LOGIC;
    s00_axi_arready : out STD_LOGIC;
    o_intr : out STD_LOGIC;
    s00_axi_rvalid : out STD_LOGIC;
    s00_axi_bvalid : out STD_LOGIC;
    axi_wready_reg_0 : out STD_LOGIC;
    s00_axi_rdata : out STD_LOGIC_VECTOR ( 31 downto 0 );
    s00_axi_aclk : in STD_LOGIC;
    SR : in STD_LOGIC_VECTOR ( 0 to 0 );
    s00_axi_arvalid : in STD_LOGIC;
    axi_bvalid_reg_0 : in STD_LOGIC;
    axi_bvalid_reg_1 : in STD_LOGIC;
    axi_arready_reg_0 : in STD_LOGIC;
    s00_axi_awaddr : in STD_LOGIC_VECTOR ( 4 downto 0 );
    s00_axi_wdata : in STD_LOGIC_VECTOR ( 31 downto 0 );
    s00_axi_araddr : in STD_LOGIC_VECTOR ( 4 downto 0 );
    s00_axi_wvalid : in STD_LOGIC;
    s00_axi_awvalid : in STD_LOGIC;
    i_button_left : in STD_LOGIC;
    i_button_right : in STD_LOGIC;
    i_button_up : in STD_LOGIC;
    i_button_down : in STD_LOGIC;
    i_button_press : in STD_LOGIC
  );
end decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_zyMouse_v1_0_S00_AXI;

architecture STRUCTURE of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_zyMouse_v1_0_S00_AXI is
  signal \axi_araddr_reg_n_0_[5]\ : STD_LOGIC;
  signal \axi_araddr_reg_n_0_[6]\ : STD_LOGIC;
  signal axi_arready_i_1_n_0 : STD_LOGIC;
  signal axi_awready0 : STD_LOGIC;
  signal \axi_rdata[31]_i_2_n_0\ : STD_LOGIC;
  signal \axi_rdata[31]_i_3_n_0\ : STD_LOGIC;
  signal \axi_rdata[31]_i_5_n_0\ : STD_LOGIC;
  signal axi_wready0 : STD_LOGIC;
  signal \^axi_wready_reg_0\ : STD_LOGIC;
  signal controlReg : STD_LOGIC;
  signal \controlReg[31]_i_2_n_0\ : STD_LOGIC;
  signal \controlReg_reg_n_0_[0]\ : STD_LOGIC;
  signal \controlReg_reg_n_0_[10]\ : STD_LOGIC;
  signal \controlReg_reg_n_0_[11]\ : STD_LOGIC;
  signal \controlReg_reg_n_0_[12]\ : STD_LOGIC;
  signal \controlReg_reg_n_0_[13]\ : STD_LOGIC;
  signal \controlReg_reg_n_0_[14]\ : STD_LOGIC;
  signal \controlReg_reg_n_0_[15]\ : STD_LOGIC;
  signal \controlReg_reg_n_0_[16]\ : STD_LOGIC;
  signal \controlReg_reg_n_0_[17]\ : STD_LOGIC;
  signal \controlReg_reg_n_0_[18]\ : STD_LOGIC;
  signal \controlReg_reg_n_0_[19]\ : STD_LOGIC;
  signal \controlReg_reg_n_0_[1]\ : STD_LOGIC;
  signal \controlReg_reg_n_0_[20]\ : STD_LOGIC;
  signal \controlReg_reg_n_0_[21]\ : STD_LOGIC;
  signal \controlReg_reg_n_0_[22]\ : STD_LOGIC;
  signal \controlReg_reg_n_0_[23]\ : STD_LOGIC;
  signal \controlReg_reg_n_0_[24]\ : STD_LOGIC;
  signal \controlReg_reg_n_0_[25]\ : STD_LOGIC;
  signal \controlReg_reg_n_0_[26]\ : STD_LOGIC;
  signal \controlReg_reg_n_0_[27]\ : STD_LOGIC;
  signal \controlReg_reg_n_0_[28]\ : STD_LOGIC;
  signal \controlReg_reg_n_0_[29]\ : STD_LOGIC;
  signal \controlReg_reg_n_0_[2]\ : STD_LOGIC;
  signal \controlReg_reg_n_0_[30]\ : STD_LOGIC;
  signal \controlReg_reg_n_0_[31]\ : STD_LOGIC;
  signal \controlReg_reg_n_0_[3]\ : STD_LOGIC;
  signal \controlReg_reg_n_0_[4]\ : STD_LOGIC;
  signal \controlReg_reg_n_0_[5]\ : STD_LOGIC;
  signal \controlReg_reg_n_0_[6]\ : STD_LOGIC;
  signal \controlReg_reg_n_0_[7]\ : STD_LOGIC;
  signal \controlReg_reg_n_0_[8]\ : STD_LOGIC;
  signal \controlReg_reg_n_0_[9]\ : STD_LOGIC;
  signal intrEnableReg : STD_LOGIC;
  signal \intrEnableReg_reg_n_0_[0]\ : STD_LOGIC;
  signal \intrEnableReg_reg_n_0_[10]\ : STD_LOGIC;
  signal \intrEnableReg_reg_n_0_[11]\ : STD_LOGIC;
  signal \intrEnableReg_reg_n_0_[12]\ : STD_LOGIC;
  signal \intrEnableReg_reg_n_0_[13]\ : STD_LOGIC;
  signal \intrEnableReg_reg_n_0_[14]\ : STD_LOGIC;
  signal \intrEnableReg_reg_n_0_[15]\ : STD_LOGIC;
  signal \intrEnableReg_reg_n_0_[16]\ : STD_LOGIC;
  signal \intrEnableReg_reg_n_0_[17]\ : STD_LOGIC;
  signal \intrEnableReg_reg_n_0_[18]\ : STD_LOGIC;
  signal \intrEnableReg_reg_n_0_[19]\ : STD_LOGIC;
  signal \intrEnableReg_reg_n_0_[1]\ : STD_LOGIC;
  signal \intrEnableReg_reg_n_0_[20]\ : STD_LOGIC;
  signal \intrEnableReg_reg_n_0_[21]\ : STD_LOGIC;
  signal \intrEnableReg_reg_n_0_[22]\ : STD_LOGIC;
  signal \intrEnableReg_reg_n_0_[23]\ : STD_LOGIC;
  signal \intrEnableReg_reg_n_0_[24]\ : STD_LOGIC;
  signal \intrEnableReg_reg_n_0_[25]\ : STD_LOGIC;
  signal \intrEnableReg_reg_n_0_[26]\ : STD_LOGIC;
  signal \intrEnableReg_reg_n_0_[27]\ : STD_LOGIC;
  signal \intrEnableReg_reg_n_0_[28]\ : STD_LOGIC;
  signal \intrEnableReg_reg_n_0_[29]\ : STD_LOGIC;
  signal \intrEnableReg_reg_n_0_[2]\ : STD_LOGIC;
  signal \intrEnableReg_reg_n_0_[30]\ : STD_LOGIC;
  signal \intrEnableReg_reg_n_0_[31]\ : STD_LOGIC;
  signal \intrEnableReg_reg_n_0_[3]\ : STD_LOGIC;
  signal \intrEnableReg_reg_n_0_[4]\ : STD_LOGIC;
  signal \intrEnableReg_reg_n_0_[5]\ : STD_LOGIC;
  signal \intrEnableReg_reg_n_0_[6]\ : STD_LOGIC;
  signal \intrEnableReg_reg_n_0_[7]\ : STD_LOGIC;
  signal \intrEnableReg_reg_n_0_[8]\ : STD_LOGIC;
  signal \intrEnableReg_reg_n_0_[9]\ : STD_LOGIC;
  signal intrStatReg1 : STD_LOGIC;
  signal \intrStatReg[10]_i_1_n_0\ : STD_LOGIC;
  signal \intrStatReg[11]_i_1_n_0\ : STD_LOGIC;
  signal \intrStatReg[12]_i_1_n_0\ : STD_LOGIC;
  signal \intrStatReg[13]_i_1_n_0\ : STD_LOGIC;
  signal \intrStatReg[14]_i_1_n_0\ : STD_LOGIC;
  signal \intrStatReg[15]_i_1_n_0\ : STD_LOGIC;
  signal \intrStatReg[16]_i_1_n_0\ : STD_LOGIC;
  signal \intrStatReg[17]_i_1_n_0\ : STD_LOGIC;
  signal \intrStatReg[18]_i_1_n_0\ : STD_LOGIC;
  signal \intrStatReg[19]_i_1_n_0\ : STD_LOGIC;
  signal \intrStatReg[20]_i_1_n_0\ : STD_LOGIC;
  signal \intrStatReg[21]_i_1_n_0\ : STD_LOGIC;
  signal \intrStatReg[22]_i_1_n_0\ : STD_LOGIC;
  signal \intrStatReg[23]_i_1_n_0\ : STD_LOGIC;
  signal \intrStatReg[24]_i_1_n_0\ : STD_LOGIC;
  signal \intrStatReg[25]_i_1_n_0\ : STD_LOGIC;
  signal \intrStatReg[26]_i_1_n_0\ : STD_LOGIC;
  signal \intrStatReg[27]_i_1_n_0\ : STD_LOGIC;
  signal \intrStatReg[28]_i_1_n_0\ : STD_LOGIC;
  signal \intrStatReg[29]_i_1_n_0\ : STD_LOGIC;
  signal \intrStatReg[2]_i_1_n_0\ : STD_LOGIC;
  signal \intrStatReg[30]_i_1_n_0\ : STD_LOGIC;
  signal \intrStatReg[31]_i_2_n_0\ : STD_LOGIC;
  signal \intrStatReg[31]_i_3_n_0\ : STD_LOGIC;
  signal \intrStatReg[3]_i_1_n_0\ : STD_LOGIC;
  signal \intrStatReg[4]_i_1_n_0\ : STD_LOGIC;
  signal \intrStatReg[5]_i_1_n_0\ : STD_LOGIC;
  signal \intrStatReg[6]_i_1_n_0\ : STD_LOGIC;
  signal \intrStatReg[7]_i_1_n_0\ : STD_LOGIC;
  signal \intrStatReg[8]_i_1_n_0\ : STD_LOGIC;
  signal \intrStatReg[9]_i_1_n_0\ : STD_LOGIC;
  signal \intrStatReg_reg_n_0_[0]\ : STD_LOGIC;
  signal \intrStatReg_reg_n_0_[10]\ : STD_LOGIC;
  signal \intrStatReg_reg_n_0_[11]\ : STD_LOGIC;
  signal \intrStatReg_reg_n_0_[12]\ : STD_LOGIC;
  signal \intrStatReg_reg_n_0_[13]\ : STD_LOGIC;
  signal \intrStatReg_reg_n_0_[14]\ : STD_LOGIC;
  signal \intrStatReg_reg_n_0_[15]\ : STD_LOGIC;
  signal \intrStatReg_reg_n_0_[16]\ : STD_LOGIC;
  signal \intrStatReg_reg_n_0_[17]\ : STD_LOGIC;
  signal \intrStatReg_reg_n_0_[18]\ : STD_LOGIC;
  signal \intrStatReg_reg_n_0_[19]\ : STD_LOGIC;
  signal \intrStatReg_reg_n_0_[1]\ : STD_LOGIC;
  signal \intrStatReg_reg_n_0_[20]\ : STD_LOGIC;
  signal \intrStatReg_reg_n_0_[21]\ : STD_LOGIC;
  signal \intrStatReg_reg_n_0_[22]\ : STD_LOGIC;
  signal \intrStatReg_reg_n_0_[23]\ : STD_LOGIC;
  signal \intrStatReg_reg_n_0_[24]\ : STD_LOGIC;
  signal \intrStatReg_reg_n_0_[25]\ : STD_LOGIC;
  signal \intrStatReg_reg_n_0_[26]\ : STD_LOGIC;
  signal \intrStatReg_reg_n_0_[27]\ : STD_LOGIC;
  signal \intrStatReg_reg_n_0_[28]\ : STD_LOGIC;
  signal \intrStatReg_reg_n_0_[29]\ : STD_LOGIC;
  signal \intrStatReg_reg_n_0_[2]\ : STD_LOGIC;
  signal \intrStatReg_reg_n_0_[30]\ : STD_LOGIC;
  signal \intrStatReg_reg_n_0_[31]\ : STD_LOGIC;
  signal \intrStatReg_reg_n_0_[3]\ : STD_LOGIC;
  signal \intrStatReg_reg_n_0_[4]\ : STD_LOGIC;
  signal \intrStatReg_reg_n_0_[5]\ : STD_LOGIC;
  signal \intrStatReg_reg_n_0_[6]\ : STD_LOGIC;
  signal \intrStatReg_reg_n_0_[7]\ : STD_LOGIC;
  signal \intrStatReg_reg_n_0_[8]\ : STD_LOGIC;
  signal \intrStatReg_reg_n_0_[9]\ : STD_LOGIC;
  signal mT_n_0 : STD_LOGIC;
  signal maxCoordinateReg : STD_LOGIC;
  signal \maxCoordinateReg_reg_n_0_[0]\ : STD_LOGIC;
  signal \maxCoordinateReg_reg_n_0_[10]\ : STD_LOGIC;
  signal \maxCoordinateReg_reg_n_0_[11]\ : STD_LOGIC;
  signal \maxCoordinateReg_reg_n_0_[12]\ : STD_LOGIC;
  signal \maxCoordinateReg_reg_n_0_[13]\ : STD_LOGIC;
  signal \maxCoordinateReg_reg_n_0_[14]\ : STD_LOGIC;
  signal \maxCoordinateReg_reg_n_0_[15]\ : STD_LOGIC;
  signal \maxCoordinateReg_reg_n_0_[16]\ : STD_LOGIC;
  signal \maxCoordinateReg_reg_n_0_[17]\ : STD_LOGIC;
  signal \maxCoordinateReg_reg_n_0_[18]\ : STD_LOGIC;
  signal \maxCoordinateReg_reg_n_0_[19]\ : STD_LOGIC;
  signal \maxCoordinateReg_reg_n_0_[1]\ : STD_LOGIC;
  signal \maxCoordinateReg_reg_n_0_[20]\ : STD_LOGIC;
  signal \maxCoordinateReg_reg_n_0_[21]\ : STD_LOGIC;
  signal \maxCoordinateReg_reg_n_0_[22]\ : STD_LOGIC;
  signal \maxCoordinateReg_reg_n_0_[23]\ : STD_LOGIC;
  signal \maxCoordinateReg_reg_n_0_[24]\ : STD_LOGIC;
  signal \maxCoordinateReg_reg_n_0_[25]\ : STD_LOGIC;
  signal \maxCoordinateReg_reg_n_0_[26]\ : STD_LOGIC;
  signal \maxCoordinateReg_reg_n_0_[27]\ : STD_LOGIC;
  signal \maxCoordinateReg_reg_n_0_[28]\ : STD_LOGIC;
  signal \maxCoordinateReg_reg_n_0_[29]\ : STD_LOGIC;
  signal \maxCoordinateReg_reg_n_0_[2]\ : STD_LOGIC;
  signal \maxCoordinateReg_reg_n_0_[30]\ : STD_LOGIC;
  signal \maxCoordinateReg_reg_n_0_[31]\ : STD_LOGIC;
  signal \maxCoordinateReg_reg_n_0_[3]\ : STD_LOGIC;
  signal \maxCoordinateReg_reg_n_0_[4]\ : STD_LOGIC;
  signal \maxCoordinateReg_reg_n_0_[5]\ : STD_LOGIC;
  signal \maxCoordinateReg_reg_n_0_[6]\ : STD_LOGIC;
  signal \maxCoordinateReg_reg_n_0_[7]\ : STD_LOGIC;
  signal \maxCoordinateReg_reg_n_0_[8]\ : STD_LOGIC;
  signal \maxCoordinateReg_reg_n_0_[9]\ : STD_LOGIC;
  signal maxCountReg : STD_LOGIC;
  signal \maxCountReg_reg_n_0_[0]\ : STD_LOGIC;
  signal \maxCountReg_reg_n_0_[10]\ : STD_LOGIC;
  signal \maxCountReg_reg_n_0_[11]\ : STD_LOGIC;
  signal \maxCountReg_reg_n_0_[12]\ : STD_LOGIC;
  signal \maxCountReg_reg_n_0_[13]\ : STD_LOGIC;
  signal \maxCountReg_reg_n_0_[14]\ : STD_LOGIC;
  signal \maxCountReg_reg_n_0_[15]\ : STD_LOGIC;
  signal \maxCountReg_reg_n_0_[16]\ : STD_LOGIC;
  signal \maxCountReg_reg_n_0_[17]\ : STD_LOGIC;
  signal \maxCountReg_reg_n_0_[18]\ : STD_LOGIC;
  signal \maxCountReg_reg_n_0_[19]\ : STD_LOGIC;
  signal \maxCountReg_reg_n_0_[1]\ : STD_LOGIC;
  signal \maxCountReg_reg_n_0_[20]\ : STD_LOGIC;
  signal \maxCountReg_reg_n_0_[21]\ : STD_LOGIC;
  signal \maxCountReg_reg_n_0_[22]\ : STD_LOGIC;
  signal \maxCountReg_reg_n_0_[23]\ : STD_LOGIC;
  signal \maxCountReg_reg_n_0_[24]\ : STD_LOGIC;
  signal \maxCountReg_reg_n_0_[25]\ : STD_LOGIC;
  signal \maxCountReg_reg_n_0_[26]\ : STD_LOGIC;
  signal \maxCountReg_reg_n_0_[27]\ : STD_LOGIC;
  signal \maxCountReg_reg_n_0_[28]\ : STD_LOGIC;
  signal \maxCountReg_reg_n_0_[29]\ : STD_LOGIC;
  signal \maxCountReg_reg_n_0_[2]\ : STD_LOGIC;
  signal \maxCountReg_reg_n_0_[30]\ : STD_LOGIC;
  signal \maxCountReg_reg_n_0_[31]\ : STD_LOGIC;
  signal \maxCountReg_reg_n_0_[3]\ : STD_LOGIC;
  signal \maxCountReg_reg_n_0_[4]\ : STD_LOGIC;
  signal \maxCountReg_reg_n_0_[5]\ : STD_LOGIC;
  signal \maxCountReg_reg_n_0_[6]\ : STD_LOGIC;
  signal \maxCountReg_reg_n_0_[7]\ : STD_LOGIC;
  signal \maxCountReg_reg_n_0_[8]\ : STD_LOGIC;
  signal \maxCountReg_reg_n_0_[9]\ : STD_LOGIC;
  signal \o_intr_i_10__0_n_0\ : STD_LOGIC;
  signal o_intr_i_11_n_0 : STD_LOGIC;
  signal o_intr_i_12_n_0 : STD_LOGIC;
  signal o_intr_i_13_n_0 : STD_LOGIC;
  signal o_intr_i_14_n_0 : STD_LOGIC;
  signal o_intr_i_15_n_0 : STD_LOGIC;
  signal o_intr_i_16_n_0 : STD_LOGIC;
  signal o_intr_i_17_n_0 : STD_LOGIC;
  signal \o_intr_i_1__0_n_0\ : STD_LOGIC;
  signal \o_intr_i_2__0_n_0\ : STD_LOGIC;
  signal \o_intr_i_3__0_n_0\ : STD_LOGIC;
  signal \o_intr_i_4__0_n_0\ : STD_LOGIC;
  signal \o_intr_i_5__0_n_0\ : STD_LOGIC;
  signal \o_intr_i_6__0_n_0\ : STD_LOGIC;
  signal \o_intr_i_7__0_n_0\ : STD_LOGIC;
  signal \o_intr_i_8__0_n_0\ : STD_LOGIC;
  signal \o_intr_i_9__0_n_0\ : STD_LOGIC;
  signal p_0_in : STD_LOGIC_VECTOR ( 4 downto 0 );
  signal p_1_in : STD_LOGIC_VECTOR ( 31 downto 0 );
  signal \^s00_axi_arready\ : STD_LOGIC;
  signal \^s00_axi_awready\ : STD_LOGIC;
  signal \^s00_axi_rvalid\ : STD_LOGIC;
  signal \^s00_axi_wready\ : STD_LOGIC;
  signal sel0 : STD_LOGIC_VECTOR ( 2 downto 0 );
  signal \slv_reg_rden__0\ : STD_LOGIC;
  signal spDebounce_n_1 : STD_LOGIC;
  signal w_button_pulse : STD_LOGIC;
  attribute SOFT_HLUTNM : string;
  attribute SOFT_HLUTNM of \axi_rdata[31]_i_2\ : label is "soft_lutpair8";
  attribute SOFT_HLUTNM of \axi_rdata[31]_i_3\ : label is "soft_lutpair8";
  attribute SOFT_HLUTNM of axi_wready_i_1 : label is "soft_lutpair2";
  attribute SOFT_HLUTNM of \controlReg[31]_i_2\ : label is "soft_lutpair2";
  attribute SOFT_HLUTNM of \intrStatReg[10]_i_1\ : label is "soft_lutpair3";
  attribute SOFT_HLUTNM of \intrStatReg[12]_i_1\ : label is "soft_lutpair4";
  attribute SOFT_HLUTNM of \intrStatReg[16]_i_1\ : label is "soft_lutpair6";
  attribute SOFT_HLUTNM of \intrStatReg[20]_i_1\ : label is "soft_lutpair1";
  attribute SOFT_HLUTNM of \intrStatReg[26]_i_1\ : label is "soft_lutpair0";
  attribute SOFT_HLUTNM of \intrStatReg[28]_i_1\ : label is "soft_lutpair7";
  attribute SOFT_HLUTNM of \intrStatReg[4]_i_1\ : label is "soft_lutpair5";
  attribute SOFT_HLUTNM of \o_intr_i_10__0\ : label is "soft_lutpair6";
  attribute SOFT_HLUTNM of o_intr_i_12 : label is "soft_lutpair7";
  attribute SOFT_HLUTNM of o_intr_i_14 : label is "soft_lutpair5";
  attribute SOFT_HLUTNM of o_intr_i_15 : label is "soft_lutpair3";
  attribute SOFT_HLUTNM of o_intr_i_16 : label is "soft_lutpair1";
  attribute SOFT_HLUTNM of o_intr_i_17 : label is "soft_lutpair0";
  attribute SOFT_HLUTNM of \o_intr_i_8__0\ : label is "soft_lutpair4";
begin
  axi_wready_reg_0 <= \^axi_wready_reg_0\;
  s00_axi_arready <= \^s00_axi_arready\;
  s00_axi_awready <= \^s00_axi_awready\;
  s00_axi_rvalid <= \^s00_axi_rvalid\;
  s00_axi_wready <= \^s00_axi_wready\;
aw_en_reg: unisim.vcomponents.FDSE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => axi_bvalid_reg_1,
      Q => \^axi_wready_reg_0\,
      S => SR(0)
    );
\axi_araddr_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => axi_arready_i_1_n_0,
      D => s00_axi_araddr(0),
      Q => sel0(0),
      R => SR(0)
    );
\axi_araddr_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => axi_arready_i_1_n_0,
      D => s00_axi_araddr(1),
      Q => sel0(1),
      R => SR(0)
    );
\axi_araddr_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => axi_arready_i_1_n_0,
      D => s00_axi_araddr(2),
      Q => sel0(2),
      R => SR(0)
    );
\axi_araddr_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => axi_arready_i_1_n_0,
      D => s00_axi_araddr(3),
      Q => \axi_araddr_reg_n_0_[5]\,
      R => SR(0)
    );
\axi_araddr_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => axi_arready_i_1_n_0,
      D => s00_axi_araddr(4),
      Q => \axi_araddr_reg_n_0_[6]\,
      R => SR(0)
    );
axi_arready_i_1: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => s00_axi_arvalid,
      I1 => \^s00_axi_arready\,
      O => axi_arready_i_1_n_0
    );
axi_arready_reg: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => axi_arready_i_1_n_0,
      Q => \^s00_axi_arready\,
      R => SR(0)
    );
\axi_awaddr_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => axi_awready0,
      D => s00_axi_awaddr(0),
      Q => p_0_in(0),
      R => SR(0)
    );
\axi_awaddr_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => axi_awready0,
      D => s00_axi_awaddr(1),
      Q => p_0_in(1),
      R => SR(0)
    );
\axi_awaddr_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => axi_awready0,
      D => s00_axi_awaddr(2),
      Q => p_0_in(2),
      R => SR(0)
    );
\axi_awaddr_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => axi_awready0,
      D => s00_axi_awaddr(3),
      Q => p_0_in(3),
      R => SR(0)
    );
\axi_awaddr_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => axi_awready0,
      D => s00_axi_awaddr(4),
      Q => p_0_in(4),
      R => SR(0)
    );
axi_awready_i_2: unisim.vcomponents.LUT4
    generic map(
      INIT => X"4000"
    )
        port map (
      I0 => \^s00_axi_awready\,
      I1 => s00_axi_awvalid,
      I2 => s00_axi_wvalid,
      I3 => \^axi_wready_reg_0\,
      O => axi_awready0
    );
axi_awready_reg: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => axi_awready0,
      Q => \^s00_axi_awready\,
      R => SR(0)
    );
axi_bvalid_reg: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => axi_bvalid_reg_0,
      Q => s00_axi_bvalid,
      R => SR(0)
    );
\axi_rdata[31]_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"5D"
    )
        port map (
      I0 => sel0(2),
      I1 => sel0(0),
      I2 => sel0(1),
      O => \axi_rdata[31]_i_2_n_0\
    );
\axi_rdata[31]_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"B"
    )
        port map (
      I0 => sel0(1),
      I1 => sel0(2),
      O => \axi_rdata[31]_i_3_n_0\
    );
\axi_rdata[31]_i_5\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \axi_araddr_reg_n_0_[5]\,
      I1 => \axi_araddr_reg_n_0_[6]\,
      O => \axi_rdata[31]_i_5_n_0\
    );
\axi_rdata_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg_rden__0\,
      D => p_1_in(0),
      Q => s00_axi_rdata(0),
      R => SR(0)
    );
\axi_rdata_reg[10]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg_rden__0\,
      D => p_1_in(10),
      Q => s00_axi_rdata(10),
      R => SR(0)
    );
\axi_rdata_reg[11]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg_rden__0\,
      D => p_1_in(11),
      Q => s00_axi_rdata(11),
      R => SR(0)
    );
\axi_rdata_reg[12]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg_rden__0\,
      D => p_1_in(12),
      Q => s00_axi_rdata(12),
      R => SR(0)
    );
\axi_rdata_reg[13]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg_rden__0\,
      D => p_1_in(13),
      Q => s00_axi_rdata(13),
      R => SR(0)
    );
\axi_rdata_reg[14]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg_rden__0\,
      D => p_1_in(14),
      Q => s00_axi_rdata(14),
      R => SR(0)
    );
\axi_rdata_reg[15]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg_rden__0\,
      D => p_1_in(15),
      Q => s00_axi_rdata(15),
      R => SR(0)
    );
\axi_rdata_reg[16]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg_rden__0\,
      D => p_1_in(16),
      Q => s00_axi_rdata(16),
      R => SR(0)
    );
\axi_rdata_reg[17]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg_rden__0\,
      D => p_1_in(17),
      Q => s00_axi_rdata(17),
      R => SR(0)
    );
\axi_rdata_reg[18]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg_rden__0\,
      D => p_1_in(18),
      Q => s00_axi_rdata(18),
      R => SR(0)
    );
\axi_rdata_reg[19]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg_rden__0\,
      D => p_1_in(19),
      Q => s00_axi_rdata(19),
      R => SR(0)
    );
\axi_rdata_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg_rden__0\,
      D => p_1_in(1),
      Q => s00_axi_rdata(1),
      R => SR(0)
    );
\axi_rdata_reg[20]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg_rden__0\,
      D => p_1_in(20),
      Q => s00_axi_rdata(20),
      R => SR(0)
    );
\axi_rdata_reg[21]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg_rden__0\,
      D => p_1_in(21),
      Q => s00_axi_rdata(21),
      R => SR(0)
    );
\axi_rdata_reg[22]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg_rden__0\,
      D => p_1_in(22),
      Q => s00_axi_rdata(22),
      R => SR(0)
    );
\axi_rdata_reg[23]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg_rden__0\,
      D => p_1_in(23),
      Q => s00_axi_rdata(23),
      R => SR(0)
    );
\axi_rdata_reg[24]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg_rden__0\,
      D => p_1_in(24),
      Q => s00_axi_rdata(24),
      R => SR(0)
    );
\axi_rdata_reg[25]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg_rden__0\,
      D => p_1_in(25),
      Q => s00_axi_rdata(25),
      R => SR(0)
    );
\axi_rdata_reg[26]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg_rden__0\,
      D => p_1_in(26),
      Q => s00_axi_rdata(26),
      R => SR(0)
    );
\axi_rdata_reg[27]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg_rden__0\,
      D => p_1_in(27),
      Q => s00_axi_rdata(27),
      R => SR(0)
    );
\axi_rdata_reg[28]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg_rden__0\,
      D => p_1_in(28),
      Q => s00_axi_rdata(28),
      R => SR(0)
    );
\axi_rdata_reg[29]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg_rden__0\,
      D => p_1_in(29),
      Q => s00_axi_rdata(29),
      R => SR(0)
    );
\axi_rdata_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg_rden__0\,
      D => p_1_in(2),
      Q => s00_axi_rdata(2),
      R => SR(0)
    );
\axi_rdata_reg[30]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg_rden__0\,
      D => p_1_in(30),
      Q => s00_axi_rdata(30),
      R => SR(0)
    );
\axi_rdata_reg[31]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg_rden__0\,
      D => p_1_in(31),
      Q => s00_axi_rdata(31),
      R => SR(0)
    );
\axi_rdata_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg_rden__0\,
      D => p_1_in(3),
      Q => s00_axi_rdata(3),
      R => SR(0)
    );
\axi_rdata_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg_rden__0\,
      D => p_1_in(4),
      Q => s00_axi_rdata(4),
      R => SR(0)
    );
\axi_rdata_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg_rden__0\,
      D => p_1_in(5),
      Q => s00_axi_rdata(5),
      R => SR(0)
    );
\axi_rdata_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg_rden__0\,
      D => p_1_in(6),
      Q => s00_axi_rdata(6),
      R => SR(0)
    );
\axi_rdata_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg_rden__0\,
      D => p_1_in(7),
      Q => s00_axi_rdata(7),
      R => SR(0)
    );
\axi_rdata_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg_rden__0\,
      D => p_1_in(8),
      Q => s00_axi_rdata(8),
      R => SR(0)
    );
\axi_rdata_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg_rden__0\,
      D => p_1_in(9),
      Q => s00_axi_rdata(9),
      R => SR(0)
    );
axi_rvalid_reg: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => axi_arready_reg_0,
      Q => \^s00_axi_rvalid\,
      R => SR(0)
    );
axi_wready_i_1: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0080"
    )
        port map (
      I0 => \^axi_wready_reg_0\,
      I1 => s00_axi_wvalid,
      I2 => s00_axi_awvalid,
      I3 => \^s00_axi_wready\,
      O => axi_wready0
    );
axi_wready_reg: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => axi_wready0,
      Q => \^s00_axi_wready\,
      R => SR(0)
    );
\controlReg[31]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000000001"
    )
        port map (
      I0 => p_0_in(2),
      I1 => \controlReg[31]_i_2_n_0\,
      I2 => p_0_in(3),
      I3 => p_0_in(4),
      I4 => p_0_in(1),
      I5 => p_0_in(0),
      O => controlReg
    );
\controlReg[31]_i_2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"7FFF"
    )
        port map (
      I0 => \^s00_axi_wready\,
      I1 => \^s00_axi_awready\,
      I2 => s00_axi_awvalid,
      I3 => s00_axi_wvalid,
      O => \controlReg[31]_i_2_n_0\
    );
\controlReg_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => controlReg,
      D => s00_axi_wdata(0),
      Q => \controlReg_reg_n_0_[0]\,
      R => SR(0)
    );
\controlReg_reg[10]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => controlReg,
      D => s00_axi_wdata(10),
      Q => \controlReg_reg_n_0_[10]\,
      R => SR(0)
    );
\controlReg_reg[11]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => controlReg,
      D => s00_axi_wdata(11),
      Q => \controlReg_reg_n_0_[11]\,
      R => SR(0)
    );
\controlReg_reg[12]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => controlReg,
      D => s00_axi_wdata(12),
      Q => \controlReg_reg_n_0_[12]\,
      R => SR(0)
    );
\controlReg_reg[13]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => controlReg,
      D => s00_axi_wdata(13),
      Q => \controlReg_reg_n_0_[13]\,
      R => SR(0)
    );
\controlReg_reg[14]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => controlReg,
      D => s00_axi_wdata(14),
      Q => \controlReg_reg_n_0_[14]\,
      R => SR(0)
    );
\controlReg_reg[15]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => controlReg,
      D => s00_axi_wdata(15),
      Q => \controlReg_reg_n_0_[15]\,
      R => SR(0)
    );
\controlReg_reg[16]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => controlReg,
      D => s00_axi_wdata(16),
      Q => \controlReg_reg_n_0_[16]\,
      R => SR(0)
    );
\controlReg_reg[17]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => controlReg,
      D => s00_axi_wdata(17),
      Q => \controlReg_reg_n_0_[17]\,
      R => SR(0)
    );
\controlReg_reg[18]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => controlReg,
      D => s00_axi_wdata(18),
      Q => \controlReg_reg_n_0_[18]\,
      R => SR(0)
    );
\controlReg_reg[19]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => controlReg,
      D => s00_axi_wdata(19),
      Q => \controlReg_reg_n_0_[19]\,
      R => SR(0)
    );
\controlReg_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => controlReg,
      D => s00_axi_wdata(1),
      Q => \controlReg_reg_n_0_[1]\,
      R => SR(0)
    );
\controlReg_reg[20]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => controlReg,
      D => s00_axi_wdata(20),
      Q => \controlReg_reg_n_0_[20]\,
      R => SR(0)
    );
\controlReg_reg[21]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => controlReg,
      D => s00_axi_wdata(21),
      Q => \controlReg_reg_n_0_[21]\,
      R => SR(0)
    );
\controlReg_reg[22]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => controlReg,
      D => s00_axi_wdata(22),
      Q => \controlReg_reg_n_0_[22]\,
      R => SR(0)
    );
\controlReg_reg[23]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => controlReg,
      D => s00_axi_wdata(23),
      Q => \controlReg_reg_n_0_[23]\,
      R => SR(0)
    );
\controlReg_reg[24]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => controlReg,
      D => s00_axi_wdata(24),
      Q => \controlReg_reg_n_0_[24]\,
      R => SR(0)
    );
\controlReg_reg[25]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => controlReg,
      D => s00_axi_wdata(25),
      Q => \controlReg_reg_n_0_[25]\,
      R => SR(0)
    );
\controlReg_reg[26]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => controlReg,
      D => s00_axi_wdata(26),
      Q => \controlReg_reg_n_0_[26]\,
      R => SR(0)
    );
\controlReg_reg[27]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => controlReg,
      D => s00_axi_wdata(27),
      Q => \controlReg_reg_n_0_[27]\,
      R => SR(0)
    );
\controlReg_reg[28]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => controlReg,
      D => s00_axi_wdata(28),
      Q => \controlReg_reg_n_0_[28]\,
      R => SR(0)
    );
\controlReg_reg[29]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => controlReg,
      D => s00_axi_wdata(29),
      Q => \controlReg_reg_n_0_[29]\,
      R => SR(0)
    );
\controlReg_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => controlReg,
      D => s00_axi_wdata(2),
      Q => \controlReg_reg_n_0_[2]\,
      R => SR(0)
    );
\controlReg_reg[30]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => controlReg,
      D => s00_axi_wdata(30),
      Q => \controlReg_reg_n_0_[30]\,
      R => SR(0)
    );
\controlReg_reg[31]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => controlReg,
      D => s00_axi_wdata(31),
      Q => \controlReg_reg_n_0_[31]\,
      R => SR(0)
    );
\controlReg_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => controlReg,
      D => s00_axi_wdata(3),
      Q => \controlReg_reg_n_0_[3]\,
      R => SR(0)
    );
\controlReg_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => controlReg,
      D => s00_axi_wdata(4),
      Q => \controlReg_reg_n_0_[4]\,
      R => SR(0)
    );
\controlReg_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => controlReg,
      D => s00_axi_wdata(5),
      Q => \controlReg_reg_n_0_[5]\,
      R => SR(0)
    );
\controlReg_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => controlReg,
      D => s00_axi_wdata(6),
      Q => \controlReg_reg_n_0_[6]\,
      R => SR(0)
    );
\controlReg_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => controlReg,
      D => s00_axi_wdata(7),
      Q => \controlReg_reg_n_0_[7]\,
      R => SR(0)
    );
\controlReg_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => controlReg,
      D => s00_axi_wdata(8),
      Q => \controlReg_reg_n_0_[8]\,
      R => SR(0)
    );
\controlReg_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => controlReg,
      D => s00_axi_wdata(9),
      Q => \controlReg_reg_n_0_[9]\,
      R => SR(0)
    );
\intrEnableReg[31]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000000004"
    )
        port map (
      I0 => p_0_in(0),
      I1 => p_0_in(1),
      I2 => p_0_in(2),
      I3 => \controlReg[31]_i_2_n_0\,
      I4 => p_0_in(3),
      I5 => p_0_in(4),
      O => intrEnableReg
    );
\intrEnableReg_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => intrEnableReg,
      D => s00_axi_wdata(0),
      Q => \intrEnableReg_reg_n_0_[0]\,
      R => SR(0)
    );
\intrEnableReg_reg[10]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => intrEnableReg,
      D => s00_axi_wdata(10),
      Q => \intrEnableReg_reg_n_0_[10]\,
      R => SR(0)
    );
\intrEnableReg_reg[11]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => intrEnableReg,
      D => s00_axi_wdata(11),
      Q => \intrEnableReg_reg_n_0_[11]\,
      R => SR(0)
    );
\intrEnableReg_reg[12]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => intrEnableReg,
      D => s00_axi_wdata(12),
      Q => \intrEnableReg_reg_n_0_[12]\,
      R => SR(0)
    );
\intrEnableReg_reg[13]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => intrEnableReg,
      D => s00_axi_wdata(13),
      Q => \intrEnableReg_reg_n_0_[13]\,
      R => SR(0)
    );
\intrEnableReg_reg[14]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => intrEnableReg,
      D => s00_axi_wdata(14),
      Q => \intrEnableReg_reg_n_0_[14]\,
      R => SR(0)
    );
\intrEnableReg_reg[15]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => intrEnableReg,
      D => s00_axi_wdata(15),
      Q => \intrEnableReg_reg_n_0_[15]\,
      R => SR(0)
    );
\intrEnableReg_reg[16]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => intrEnableReg,
      D => s00_axi_wdata(16),
      Q => \intrEnableReg_reg_n_0_[16]\,
      R => SR(0)
    );
\intrEnableReg_reg[17]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => intrEnableReg,
      D => s00_axi_wdata(17),
      Q => \intrEnableReg_reg_n_0_[17]\,
      R => SR(0)
    );
\intrEnableReg_reg[18]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => intrEnableReg,
      D => s00_axi_wdata(18),
      Q => \intrEnableReg_reg_n_0_[18]\,
      R => SR(0)
    );
\intrEnableReg_reg[19]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => intrEnableReg,
      D => s00_axi_wdata(19),
      Q => \intrEnableReg_reg_n_0_[19]\,
      R => SR(0)
    );
\intrEnableReg_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => intrEnableReg,
      D => s00_axi_wdata(1),
      Q => \intrEnableReg_reg_n_0_[1]\,
      R => SR(0)
    );
\intrEnableReg_reg[20]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => intrEnableReg,
      D => s00_axi_wdata(20),
      Q => \intrEnableReg_reg_n_0_[20]\,
      R => SR(0)
    );
\intrEnableReg_reg[21]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => intrEnableReg,
      D => s00_axi_wdata(21),
      Q => \intrEnableReg_reg_n_0_[21]\,
      R => SR(0)
    );
\intrEnableReg_reg[22]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => intrEnableReg,
      D => s00_axi_wdata(22),
      Q => \intrEnableReg_reg_n_0_[22]\,
      R => SR(0)
    );
\intrEnableReg_reg[23]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => intrEnableReg,
      D => s00_axi_wdata(23),
      Q => \intrEnableReg_reg_n_0_[23]\,
      R => SR(0)
    );
\intrEnableReg_reg[24]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => intrEnableReg,
      D => s00_axi_wdata(24),
      Q => \intrEnableReg_reg_n_0_[24]\,
      R => SR(0)
    );
\intrEnableReg_reg[25]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => intrEnableReg,
      D => s00_axi_wdata(25),
      Q => \intrEnableReg_reg_n_0_[25]\,
      R => SR(0)
    );
\intrEnableReg_reg[26]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => intrEnableReg,
      D => s00_axi_wdata(26),
      Q => \intrEnableReg_reg_n_0_[26]\,
      R => SR(0)
    );
\intrEnableReg_reg[27]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => intrEnableReg,
      D => s00_axi_wdata(27),
      Q => \intrEnableReg_reg_n_0_[27]\,
      R => SR(0)
    );
\intrEnableReg_reg[28]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => intrEnableReg,
      D => s00_axi_wdata(28),
      Q => \intrEnableReg_reg_n_0_[28]\,
      R => SR(0)
    );
\intrEnableReg_reg[29]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => intrEnableReg,
      D => s00_axi_wdata(29),
      Q => \intrEnableReg_reg_n_0_[29]\,
      R => SR(0)
    );
\intrEnableReg_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => intrEnableReg,
      D => s00_axi_wdata(2),
      Q => \intrEnableReg_reg_n_0_[2]\,
      R => SR(0)
    );
\intrEnableReg_reg[30]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => intrEnableReg,
      D => s00_axi_wdata(30),
      Q => \intrEnableReg_reg_n_0_[30]\,
      R => SR(0)
    );
\intrEnableReg_reg[31]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => intrEnableReg,
      D => s00_axi_wdata(31),
      Q => \intrEnableReg_reg_n_0_[31]\,
      R => SR(0)
    );
\intrEnableReg_reg[3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => intrEnableReg,
      D => s00_axi_wdata(3),
      Q => \intrEnableReg_reg_n_0_[3]\,
      R => SR(0)
    );
\intrEnableReg_reg[4]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => intrEnableReg,
      D => s00_axi_wdata(4),
      Q => \intrEnableReg_reg_n_0_[4]\,
      R => SR(0)
    );
\intrEnableReg_reg[5]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => intrEnableReg,
      D => s00_axi_wdata(5),
      Q => \intrEnableReg_reg_n_0_[5]\,
      R => SR(0)
    );
\intrEnableReg_reg[6]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => intrEnableReg,
      D => s00_axi_wdata(6),
      Q => \intrEnableReg_reg_n_0_[6]\,
      R => SR(0)
    );
\intrEnableReg_reg[7]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => intrEnableReg,
      D => s00_axi_wdata(7),
      Q => \intrEnableReg_reg_n_0_[7]\,
      R => SR(0)
    );
\intrEnableReg_reg[8]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => intrEnableReg,
      D => s00_axi_wdata(8),
      Q => \intrEnableReg_reg_n_0_[8]\,
      R => SR(0)
    );
\intrEnableReg_reg[9]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => intrEnableReg,
      D => s00_axi_wdata(9),
      Q => \intrEnableReg_reg_n_0_[9]\,
      R => SR(0)
    );
\intrStatReg[10]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \intrStatReg_reg_n_0_[10]\,
      I1 => s00_axi_wdata(10),
      O => \intrStatReg[10]_i_1_n_0\
    );
\intrStatReg[11]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \intrStatReg_reg_n_0_[11]\,
      I1 => s00_axi_wdata(11),
      O => \intrStatReg[11]_i_1_n_0\
    );
\intrStatReg[12]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \intrStatReg_reg_n_0_[12]\,
      I1 => s00_axi_wdata(12),
      O => \intrStatReg[12]_i_1_n_0\
    );
\intrStatReg[13]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \intrStatReg_reg_n_0_[13]\,
      I1 => s00_axi_wdata(13),
      O => \intrStatReg[13]_i_1_n_0\
    );
\intrStatReg[14]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \intrStatReg_reg_n_0_[14]\,
      I1 => s00_axi_wdata(14),
      O => \intrStatReg[14]_i_1_n_0\
    );
\intrStatReg[15]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \intrStatReg_reg_n_0_[15]\,
      I1 => s00_axi_wdata(15),
      O => \intrStatReg[15]_i_1_n_0\
    );
\intrStatReg[16]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \intrStatReg_reg_n_0_[16]\,
      I1 => s00_axi_wdata(16),
      O => \intrStatReg[16]_i_1_n_0\
    );
\intrStatReg[17]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \intrStatReg_reg_n_0_[17]\,
      I1 => s00_axi_wdata(17),
      O => \intrStatReg[17]_i_1_n_0\
    );
\intrStatReg[18]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \intrStatReg_reg_n_0_[18]\,
      I1 => s00_axi_wdata(18),
      O => \intrStatReg[18]_i_1_n_0\
    );
\intrStatReg[19]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \intrStatReg_reg_n_0_[19]\,
      I1 => s00_axi_wdata(19),
      O => \intrStatReg[19]_i_1_n_0\
    );
\intrStatReg[20]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \intrStatReg_reg_n_0_[20]\,
      I1 => s00_axi_wdata(20),
      O => \intrStatReg[20]_i_1_n_0\
    );
\intrStatReg[21]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \intrStatReg_reg_n_0_[21]\,
      I1 => s00_axi_wdata(21),
      O => \intrStatReg[21]_i_1_n_0\
    );
\intrStatReg[22]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \intrStatReg_reg_n_0_[22]\,
      I1 => s00_axi_wdata(22),
      O => \intrStatReg[22]_i_1_n_0\
    );
\intrStatReg[23]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \intrStatReg_reg_n_0_[23]\,
      I1 => s00_axi_wdata(23),
      O => \intrStatReg[23]_i_1_n_0\
    );
\intrStatReg[24]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \intrStatReg_reg_n_0_[24]\,
      I1 => s00_axi_wdata(24),
      O => \intrStatReg[24]_i_1_n_0\
    );
\intrStatReg[25]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \intrStatReg_reg_n_0_[25]\,
      I1 => s00_axi_wdata(25),
      O => \intrStatReg[25]_i_1_n_0\
    );
\intrStatReg[26]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \intrStatReg_reg_n_0_[26]\,
      I1 => s00_axi_wdata(26),
      O => \intrStatReg[26]_i_1_n_0\
    );
\intrStatReg[27]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \intrStatReg_reg_n_0_[27]\,
      I1 => s00_axi_wdata(27),
      O => \intrStatReg[27]_i_1_n_0\
    );
\intrStatReg[28]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \intrStatReg_reg_n_0_[28]\,
      I1 => s00_axi_wdata(28),
      O => \intrStatReg[28]_i_1_n_0\
    );
\intrStatReg[29]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \intrStatReg_reg_n_0_[29]\,
      I1 => s00_axi_wdata(29),
      O => \intrStatReg[29]_i_1_n_0\
    );
\intrStatReg[2]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \intrStatReg_reg_n_0_[2]\,
      I1 => s00_axi_wdata(2),
      O => \intrStatReg[2]_i_1_n_0\
    );
\intrStatReg[30]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \intrStatReg_reg_n_0_[30]\,
      I1 => s00_axi_wdata(30),
      O => \intrStatReg[30]_i_1_n_0\
    );
\intrStatReg[31]_i_1\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \intrStatReg[31]_i_3_n_0\,
      O => intrStatReg1
    );
\intrStatReg[31]_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \intrStatReg_reg_n_0_[31]\,
      I1 => s00_axi_wdata(31),
      O => \intrStatReg[31]_i_2_n_0\
    );
\intrStatReg[31]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFEFFFFFFFF"
    )
        port map (
      I0 => p_0_in(2),
      I1 => \controlReg[31]_i_2_n_0\,
      I2 => p_0_in(3),
      I3 => p_0_in(4),
      I4 => p_0_in(1),
      I5 => p_0_in(0),
      O => \intrStatReg[31]_i_3_n_0\
    );
\intrStatReg[3]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \intrStatReg_reg_n_0_[3]\,
      I1 => s00_axi_wdata(3),
      O => \intrStatReg[3]_i_1_n_0\
    );
\intrStatReg[4]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \intrStatReg_reg_n_0_[4]\,
      I1 => s00_axi_wdata(4),
      O => \intrStatReg[4]_i_1_n_0\
    );
\intrStatReg[5]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \intrStatReg_reg_n_0_[5]\,
      I1 => s00_axi_wdata(5),
      O => \intrStatReg[5]_i_1_n_0\
    );
\intrStatReg[6]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \intrStatReg_reg_n_0_[6]\,
      I1 => s00_axi_wdata(6),
      O => \intrStatReg[6]_i_1_n_0\
    );
\intrStatReg[7]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \intrStatReg_reg_n_0_[7]\,
      I1 => s00_axi_wdata(7),
      O => \intrStatReg[7]_i_1_n_0\
    );
\intrStatReg[8]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \intrStatReg_reg_n_0_[8]\,
      I1 => s00_axi_wdata(8),
      O => \intrStatReg[8]_i_1_n_0\
    );
\intrStatReg[9]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \intrStatReg_reg_n_0_[9]\,
      I1 => s00_axi_wdata(9),
      O => \intrStatReg[9]_i_1_n_0\
    );
\intrStatReg_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => spDebounce_n_1,
      Q => \intrStatReg_reg_n_0_[0]\,
      R => SR(0)
    );
\intrStatReg_reg[10]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => intrStatReg1,
      D => \intrStatReg[10]_i_1_n_0\,
      Q => \intrStatReg_reg_n_0_[10]\,
      R => SR(0)
    );
\intrStatReg_reg[11]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => intrStatReg1,
      D => \intrStatReg[11]_i_1_n_0\,
      Q => \intrStatReg_reg_n_0_[11]\,
      R => SR(0)
    );
\intrStatReg_reg[12]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => intrStatReg1,
      D => \intrStatReg[12]_i_1_n_0\,
      Q => \intrStatReg_reg_n_0_[12]\,
      R => SR(0)
    );
\intrStatReg_reg[13]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => intrStatReg1,
      D => \intrStatReg[13]_i_1_n_0\,
      Q => \intrStatReg_reg_n_0_[13]\,
      R => SR(0)
    );
\intrStatReg_reg[14]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => intrStatReg1,
      D => \intrStatReg[14]_i_1_n_0\,
      Q => \intrStatReg_reg_n_0_[14]\,
      R => SR(0)
    );
\intrStatReg_reg[15]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => intrStatReg1,
      D => \intrStatReg[15]_i_1_n_0\,
      Q => \intrStatReg_reg_n_0_[15]\,
      R => SR(0)
    );
\intrStatReg_reg[16]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => intrStatReg1,
      D => \intrStatReg[16]_i_1_n_0\,
      Q => \intrStatReg_reg_n_0_[16]\,
      R => SR(0)
    );
\intrStatReg_reg[17]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => intrStatReg1,
      D => \intrStatReg[17]_i_1_n_0\,
      Q => \intrStatReg_reg_n_0_[17]\,
      R => SR(0)
    );
\intrStatReg_reg[18]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => intrStatReg1,
      D => \intrStatReg[18]_i_1_n_0\,
      Q => \intrStatReg_reg_n_0_[18]\,
      R => SR(0)
    );
\intrStatReg_reg[19]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => intrStatReg1,
      D => \intrStatReg[19]_i_1_n_0\,
      Q => \intrStatReg_reg_n_0_[19]\,
      R => SR(0)
    );
\intrStatReg_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => mT_n_0,
      Q => \intrStatReg_reg_n_0_[1]\,
      R => SR(0)
    );
\intrStatReg_reg[20]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => intrStatReg1,
      D => \intrStatReg[20]_i_1_n_0\,
      Q => \intrStatReg_reg_n_0_[20]\,
      R => SR(0)
    );
\intrStatReg_reg[21]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => intrStatReg1,
      D => \intrStatReg[21]_i_1_n_0\,
      Q => \intrStatReg_reg_n_0_[21]\,
      R => SR(0)
    );
\intrStatReg_reg[22]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => intrStatReg1,
      D => \intrStatReg[22]_i_1_n_0\,
      Q => \intrStatReg_reg_n_0_[22]\,
      R => SR(0)
    );
\intrStatReg_reg[23]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => intrStatReg1,
      D => \intrStatReg[23]_i_1_n_0\,
      Q => \intrStatReg_reg_n_0_[23]\,
      R => SR(0)
    );
\intrStatReg_reg[24]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => intrStatReg1,
      D => \intrStatReg[24]_i_1_n_0\,
      Q => \intrStatReg_reg_n_0_[24]\,
      R => SR(0)
    );
\intrStatReg_reg[25]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => intrStatReg1,
      D => \intrStatReg[25]_i_1_n_0\,
      Q => \intrStatReg_reg_n_0_[25]\,
      R => SR(0)
    );
\intrStatReg_reg[26]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => intrStatReg1,
      D => \intrStatReg[26]_i_1_n_0\,
      Q => \intrStatReg_reg_n_0_[26]\,
      R => SR(0)
    );
\intrStatReg_reg[27]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => intrStatReg1,
      D => \intrStatReg[27]_i_1_n_0\,
      Q => \intrStatReg_reg_n_0_[27]\,
      R => SR(0)
    );
\intrStatReg_reg[28]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => intrStatReg1,
      D => \intrStatReg[28]_i_1_n_0\,
      Q => \intrStatReg_reg_n_0_[28]\,
      R => SR(0)
    );
\intrStatReg_reg[29]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => intrStatReg1,
      D => \intrStatReg[29]_i_1_n_0\,
      Q => \intrStatReg_reg_n_0_[29]\,
      R => SR(0)
    );
\intrStatReg_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => intrStatReg1,
      D => \intrStatReg[2]_i_1_n_0\,
      Q => \intrStatReg_reg_n_0_[2]\,
      R => SR(0)
    );
\intrStatReg_reg[30]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => intrStatReg1,
      D => \intrStatReg[30]_i_1_n_0\,
      Q => \intrStatReg_reg_n_0_[30]\,
      R => SR(0)
    );
\intrStatReg_reg[31]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => intrStatReg1,
      D => \intrStatReg[31]_i_2_n_0\,
      Q => \intrStatReg_reg_n_0_[31]\,
      R => SR(0)
    );
\intrStatReg_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => intrStatReg1,
      D => \intrStatReg[3]_i_1_n_0\,
      Q => \intrStatReg_reg_n_0_[3]\,
      R => SR(0)
    );
\intrStatReg_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => intrStatReg1,
      D => \intrStatReg[4]_i_1_n_0\,
      Q => \intrStatReg_reg_n_0_[4]\,
      R => SR(0)
    );
\intrStatReg_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => intrStatReg1,
      D => \intrStatReg[5]_i_1_n_0\,
      Q => \intrStatReg_reg_n_0_[5]\,
      R => SR(0)
    );
\intrStatReg_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => intrStatReg1,
      D => \intrStatReg[6]_i_1_n_0\,
      Q => \intrStatReg_reg_n_0_[6]\,
      R => SR(0)
    );
\intrStatReg_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => intrStatReg1,
      D => \intrStatReg[7]_i_1_n_0\,
      Q => \intrStatReg_reg_n_0_[7]\,
      R => SR(0)
    );
\intrStatReg_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => intrStatReg1,
      D => \intrStatReg[8]_i_1_n_0\,
      Q => \intrStatReg_reg_n_0_[8]\,
      R => SR(0)
    );
\intrStatReg_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => intrStatReg1,
      D => \intrStatReg[9]_i_1_n_0\,
      Q => \intrStatReg_reg_n_0_[9]\,
      R => SR(0)
    );
mT: entity work.decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_mouseTracker
     port map (
      D(31 downto 0) => p_1_in(31 downto 0),
      Q(31) => \controlReg_reg_n_0_[31]\,
      Q(30) => \controlReg_reg_n_0_[30]\,
      Q(29) => \controlReg_reg_n_0_[29]\,
      Q(28) => \controlReg_reg_n_0_[28]\,
      Q(27) => \controlReg_reg_n_0_[27]\,
      Q(26) => \controlReg_reg_n_0_[26]\,
      Q(25) => \controlReg_reg_n_0_[25]\,
      Q(24) => \controlReg_reg_n_0_[24]\,
      Q(23) => \controlReg_reg_n_0_[23]\,
      Q(22) => \controlReg_reg_n_0_[22]\,
      Q(21) => \controlReg_reg_n_0_[21]\,
      Q(20) => \controlReg_reg_n_0_[20]\,
      Q(19) => \controlReg_reg_n_0_[19]\,
      Q(18) => \controlReg_reg_n_0_[18]\,
      Q(17) => \controlReg_reg_n_0_[17]\,
      Q(16) => \controlReg_reg_n_0_[16]\,
      Q(15) => \controlReg_reg_n_0_[15]\,
      Q(14) => \controlReg_reg_n_0_[14]\,
      Q(13) => \controlReg_reg_n_0_[13]\,
      Q(12) => \controlReg_reg_n_0_[12]\,
      Q(11) => \controlReg_reg_n_0_[11]\,
      Q(10) => \controlReg_reg_n_0_[10]\,
      Q(9) => \controlReg_reg_n_0_[9]\,
      Q(8) => \controlReg_reg_n_0_[8]\,
      Q(7) => \controlReg_reg_n_0_[7]\,
      Q(6) => \controlReg_reg_n_0_[6]\,
      Q(5) => \controlReg_reg_n_0_[5]\,
      Q(4) => \controlReg_reg_n_0_[4]\,
      Q(3) => \controlReg_reg_n_0_[3]\,
      Q(2) => \controlReg_reg_n_0_[2]\,
      Q(1) => \controlReg_reg_n_0_[1]\,
      Q(0) => \controlReg_reg_n_0_[0]\,
      \axi_araddr_reg[3]\ => \axi_rdata[31]_i_3_n_0\,
      \axi_araddr_reg[3]_0\(1 downto 0) => sel0(1 downto 0),
      \axi_araddr_reg[4]\ => \axi_rdata[31]_i_2_n_0\,
      \axi_araddr_reg[5]\ => \axi_rdata[31]_i_5_n_0\,
      \axi_awaddr_reg[4]\ => \intrStatReg[31]_i_3_n_0\,
      i_button_down => i_button_down,
      i_button_left => i_button_left,
      i_button_right => i_button_right,
      i_button_up => i_button_up,
      \intrEnableReg_reg[31]\(31) => \intrEnableReg_reg_n_0_[31]\,
      \intrEnableReg_reg[31]\(30) => \intrEnableReg_reg_n_0_[30]\,
      \intrEnableReg_reg[31]\(29) => \intrEnableReg_reg_n_0_[29]\,
      \intrEnableReg_reg[31]\(28) => \intrEnableReg_reg_n_0_[28]\,
      \intrEnableReg_reg[31]\(27) => \intrEnableReg_reg_n_0_[27]\,
      \intrEnableReg_reg[31]\(26) => \intrEnableReg_reg_n_0_[26]\,
      \intrEnableReg_reg[31]\(25) => \intrEnableReg_reg_n_0_[25]\,
      \intrEnableReg_reg[31]\(24) => \intrEnableReg_reg_n_0_[24]\,
      \intrEnableReg_reg[31]\(23) => \intrEnableReg_reg_n_0_[23]\,
      \intrEnableReg_reg[31]\(22) => \intrEnableReg_reg_n_0_[22]\,
      \intrEnableReg_reg[31]\(21) => \intrEnableReg_reg_n_0_[21]\,
      \intrEnableReg_reg[31]\(20) => \intrEnableReg_reg_n_0_[20]\,
      \intrEnableReg_reg[31]\(19) => \intrEnableReg_reg_n_0_[19]\,
      \intrEnableReg_reg[31]\(18) => \intrEnableReg_reg_n_0_[18]\,
      \intrEnableReg_reg[31]\(17) => \intrEnableReg_reg_n_0_[17]\,
      \intrEnableReg_reg[31]\(16) => \intrEnableReg_reg_n_0_[16]\,
      \intrEnableReg_reg[31]\(15) => \intrEnableReg_reg_n_0_[15]\,
      \intrEnableReg_reg[31]\(14) => \intrEnableReg_reg_n_0_[14]\,
      \intrEnableReg_reg[31]\(13) => \intrEnableReg_reg_n_0_[13]\,
      \intrEnableReg_reg[31]\(12) => \intrEnableReg_reg_n_0_[12]\,
      \intrEnableReg_reg[31]\(11) => \intrEnableReg_reg_n_0_[11]\,
      \intrEnableReg_reg[31]\(10) => \intrEnableReg_reg_n_0_[10]\,
      \intrEnableReg_reg[31]\(9) => \intrEnableReg_reg_n_0_[9]\,
      \intrEnableReg_reg[31]\(8) => \intrEnableReg_reg_n_0_[8]\,
      \intrEnableReg_reg[31]\(7) => \intrEnableReg_reg_n_0_[7]\,
      \intrEnableReg_reg[31]\(6) => \intrEnableReg_reg_n_0_[6]\,
      \intrEnableReg_reg[31]\(5) => \intrEnableReg_reg_n_0_[5]\,
      \intrEnableReg_reg[31]\(4) => \intrEnableReg_reg_n_0_[4]\,
      \intrEnableReg_reg[31]\(3) => \intrEnableReg_reg_n_0_[3]\,
      \intrEnableReg_reg[31]\(2) => \intrEnableReg_reg_n_0_[2]\,
      \intrEnableReg_reg[31]\(1) => \intrEnableReg_reg_n_0_[1]\,
      \intrEnableReg_reg[31]\(0) => \intrEnableReg_reg_n_0_[0]\,
      \intrStatReg_reg[0]\ => \intrStatReg_reg_n_0_[0]\,
      \intrStatReg_reg[10]\ => \intrStatReg_reg_n_0_[10]\,
      \intrStatReg_reg[11]\ => \intrStatReg_reg_n_0_[11]\,
      \intrStatReg_reg[12]\ => \intrStatReg_reg_n_0_[12]\,
      \intrStatReg_reg[13]\ => \intrStatReg_reg_n_0_[13]\,
      \intrStatReg_reg[14]\ => \intrStatReg_reg_n_0_[14]\,
      \intrStatReg_reg[15]\ => \intrStatReg_reg_n_0_[15]\,
      \intrStatReg_reg[16]\ => \intrStatReg_reg_n_0_[16]\,
      \intrStatReg_reg[17]\ => \intrStatReg_reg_n_0_[17]\,
      \intrStatReg_reg[18]\ => \intrStatReg_reg_n_0_[18]\,
      \intrStatReg_reg[19]\ => \intrStatReg_reg_n_0_[19]\,
      \intrStatReg_reg[1]\ => mT_n_0,
      \intrStatReg_reg[1]_0\ => \intrStatReg_reg_n_0_[1]\,
      \intrStatReg_reg[20]\ => \intrStatReg_reg_n_0_[20]\,
      \intrStatReg_reg[21]\ => \intrStatReg_reg_n_0_[21]\,
      \intrStatReg_reg[22]\ => \intrStatReg_reg_n_0_[22]\,
      \intrStatReg_reg[23]\ => \intrStatReg_reg_n_0_[23]\,
      \intrStatReg_reg[24]\ => \intrStatReg_reg_n_0_[24]\,
      \intrStatReg_reg[25]\ => \intrStatReg_reg_n_0_[25]\,
      \intrStatReg_reg[26]\ => \intrStatReg_reg_n_0_[26]\,
      \intrStatReg_reg[27]\ => \intrStatReg_reg_n_0_[27]\,
      \intrStatReg_reg[28]\ => \intrStatReg_reg_n_0_[28]\,
      \intrStatReg_reg[29]\ => \intrStatReg_reg_n_0_[29]\,
      \intrStatReg_reg[2]\ => \intrStatReg_reg_n_0_[2]\,
      \intrStatReg_reg[30]\ => \intrStatReg_reg_n_0_[30]\,
      \intrStatReg_reg[31]\ => \intrStatReg_reg_n_0_[31]\,
      \intrStatReg_reg[3]\ => \intrStatReg_reg_n_0_[3]\,
      \intrStatReg_reg[4]\ => \intrStatReg_reg_n_0_[4]\,
      \intrStatReg_reg[5]\ => \intrStatReg_reg_n_0_[5]\,
      \intrStatReg_reg[6]\ => \intrStatReg_reg_n_0_[6]\,
      \intrStatReg_reg[7]\ => \intrStatReg_reg_n_0_[7]\,
      \intrStatReg_reg[8]\ => \intrStatReg_reg_n_0_[8]\,
      \intrStatReg_reg[9]\ => \intrStatReg_reg_n_0_[9]\,
      \maxCoordinateReg_reg[31]\(31) => \maxCoordinateReg_reg_n_0_[31]\,
      \maxCoordinateReg_reg[31]\(30) => \maxCoordinateReg_reg_n_0_[30]\,
      \maxCoordinateReg_reg[31]\(29) => \maxCoordinateReg_reg_n_0_[29]\,
      \maxCoordinateReg_reg[31]\(28) => \maxCoordinateReg_reg_n_0_[28]\,
      \maxCoordinateReg_reg[31]\(27) => \maxCoordinateReg_reg_n_0_[27]\,
      \maxCoordinateReg_reg[31]\(26) => \maxCoordinateReg_reg_n_0_[26]\,
      \maxCoordinateReg_reg[31]\(25) => \maxCoordinateReg_reg_n_0_[25]\,
      \maxCoordinateReg_reg[31]\(24) => \maxCoordinateReg_reg_n_0_[24]\,
      \maxCoordinateReg_reg[31]\(23) => \maxCoordinateReg_reg_n_0_[23]\,
      \maxCoordinateReg_reg[31]\(22) => \maxCoordinateReg_reg_n_0_[22]\,
      \maxCoordinateReg_reg[31]\(21) => \maxCoordinateReg_reg_n_0_[21]\,
      \maxCoordinateReg_reg[31]\(20) => \maxCoordinateReg_reg_n_0_[20]\,
      \maxCoordinateReg_reg[31]\(19) => \maxCoordinateReg_reg_n_0_[19]\,
      \maxCoordinateReg_reg[31]\(18) => \maxCoordinateReg_reg_n_0_[18]\,
      \maxCoordinateReg_reg[31]\(17) => \maxCoordinateReg_reg_n_0_[17]\,
      \maxCoordinateReg_reg[31]\(16) => \maxCoordinateReg_reg_n_0_[16]\,
      \maxCoordinateReg_reg[31]\(15) => \maxCoordinateReg_reg_n_0_[15]\,
      \maxCoordinateReg_reg[31]\(14) => \maxCoordinateReg_reg_n_0_[14]\,
      \maxCoordinateReg_reg[31]\(13) => \maxCoordinateReg_reg_n_0_[13]\,
      \maxCoordinateReg_reg[31]\(12) => \maxCoordinateReg_reg_n_0_[12]\,
      \maxCoordinateReg_reg[31]\(11) => \maxCoordinateReg_reg_n_0_[11]\,
      \maxCoordinateReg_reg[31]\(10) => \maxCoordinateReg_reg_n_0_[10]\,
      \maxCoordinateReg_reg[31]\(9) => \maxCoordinateReg_reg_n_0_[9]\,
      \maxCoordinateReg_reg[31]\(8) => \maxCoordinateReg_reg_n_0_[8]\,
      \maxCoordinateReg_reg[31]\(7) => \maxCoordinateReg_reg_n_0_[7]\,
      \maxCoordinateReg_reg[31]\(6) => \maxCoordinateReg_reg_n_0_[6]\,
      \maxCoordinateReg_reg[31]\(5) => \maxCoordinateReg_reg_n_0_[5]\,
      \maxCoordinateReg_reg[31]\(4) => \maxCoordinateReg_reg_n_0_[4]\,
      \maxCoordinateReg_reg[31]\(3) => \maxCoordinateReg_reg_n_0_[3]\,
      \maxCoordinateReg_reg[31]\(2) => \maxCoordinateReg_reg_n_0_[2]\,
      \maxCoordinateReg_reg[31]\(1) => \maxCoordinateReg_reg_n_0_[1]\,
      \maxCoordinateReg_reg[31]\(0) => \maxCoordinateReg_reg_n_0_[0]\,
      \maxCountReg_reg[31]\(31) => \maxCountReg_reg_n_0_[31]\,
      \maxCountReg_reg[31]\(30) => \maxCountReg_reg_n_0_[30]\,
      \maxCountReg_reg[31]\(29) => \maxCountReg_reg_n_0_[29]\,
      \maxCountReg_reg[31]\(28) => \maxCountReg_reg_n_0_[28]\,
      \maxCountReg_reg[31]\(27) => \maxCountReg_reg_n_0_[27]\,
      \maxCountReg_reg[31]\(26) => \maxCountReg_reg_n_0_[26]\,
      \maxCountReg_reg[31]\(25) => \maxCountReg_reg_n_0_[25]\,
      \maxCountReg_reg[31]\(24) => \maxCountReg_reg_n_0_[24]\,
      \maxCountReg_reg[31]\(23) => \maxCountReg_reg_n_0_[23]\,
      \maxCountReg_reg[31]\(22) => \maxCountReg_reg_n_0_[22]\,
      \maxCountReg_reg[31]\(21) => \maxCountReg_reg_n_0_[21]\,
      \maxCountReg_reg[31]\(20) => \maxCountReg_reg_n_0_[20]\,
      \maxCountReg_reg[31]\(19) => \maxCountReg_reg_n_0_[19]\,
      \maxCountReg_reg[31]\(18) => \maxCountReg_reg_n_0_[18]\,
      \maxCountReg_reg[31]\(17) => \maxCountReg_reg_n_0_[17]\,
      \maxCountReg_reg[31]\(16) => \maxCountReg_reg_n_0_[16]\,
      \maxCountReg_reg[31]\(15) => \maxCountReg_reg_n_0_[15]\,
      \maxCountReg_reg[31]\(14) => \maxCountReg_reg_n_0_[14]\,
      \maxCountReg_reg[31]\(13) => \maxCountReg_reg_n_0_[13]\,
      \maxCountReg_reg[31]\(12) => \maxCountReg_reg_n_0_[12]\,
      \maxCountReg_reg[31]\(11) => \maxCountReg_reg_n_0_[11]\,
      \maxCountReg_reg[31]\(10) => \maxCountReg_reg_n_0_[10]\,
      \maxCountReg_reg[31]\(9) => \maxCountReg_reg_n_0_[9]\,
      \maxCountReg_reg[31]\(8) => \maxCountReg_reg_n_0_[8]\,
      \maxCountReg_reg[31]\(7) => \maxCountReg_reg_n_0_[7]\,
      \maxCountReg_reg[31]\(6) => \maxCountReg_reg_n_0_[6]\,
      \maxCountReg_reg[31]\(5) => \maxCountReg_reg_n_0_[5]\,
      \maxCountReg_reg[31]\(4) => \maxCountReg_reg_n_0_[4]\,
      \maxCountReg_reg[31]\(3) => \maxCountReg_reg_n_0_[3]\,
      \maxCountReg_reg[31]\(2) => \maxCountReg_reg_n_0_[2]\,
      \maxCountReg_reg[31]\(1) => \maxCountReg_reg_n_0_[1]\,
      \maxCountReg_reg[31]\(0) => \maxCountReg_reg_n_0_[0]\,
      s00_axi_aclk => s00_axi_aclk,
      s00_axi_wdata(0) => s00_axi_wdata(1),
      w_button_pulse => w_button_pulse
    );
\maxCoordinateReg[31]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000000008"
    )
        port map (
      I0 => p_0_in(2),
      I1 => p_0_in(0),
      I2 => p_0_in(1),
      I3 => p_0_in(4),
      I4 => p_0_in(3),
      I5 => \controlReg[31]_i_2_n_0\,
      O => maxCoordinateReg
    );
\maxCoordinateReg_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => maxCoordinateReg,
      D => s00_axi_wdata(0),
      Q => \maxCoordinateReg_reg_n_0_[0]\,
      R => SR(0)
    );
\maxCoordinateReg_reg[10]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => maxCoordinateReg,
      D => s00_axi_wdata(10),
      Q => \maxCoordinateReg_reg_n_0_[10]\,
      R => SR(0)
    );
\maxCoordinateReg_reg[11]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => maxCoordinateReg,
      D => s00_axi_wdata(11),
      Q => \maxCoordinateReg_reg_n_0_[11]\,
      R => SR(0)
    );
\maxCoordinateReg_reg[12]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => maxCoordinateReg,
      D => s00_axi_wdata(12),
      Q => \maxCoordinateReg_reg_n_0_[12]\,
      R => SR(0)
    );
\maxCoordinateReg_reg[13]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => maxCoordinateReg,
      D => s00_axi_wdata(13),
      Q => \maxCoordinateReg_reg_n_0_[13]\,
      R => SR(0)
    );
\maxCoordinateReg_reg[14]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => maxCoordinateReg,
      D => s00_axi_wdata(14),
      Q => \maxCoordinateReg_reg_n_0_[14]\,
      R => SR(0)
    );
\maxCoordinateReg_reg[15]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => maxCoordinateReg,
      D => s00_axi_wdata(15),
      Q => \maxCoordinateReg_reg_n_0_[15]\,
      R => SR(0)
    );
\maxCoordinateReg_reg[16]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => maxCoordinateReg,
      D => s00_axi_wdata(16),
      Q => \maxCoordinateReg_reg_n_0_[16]\,
      R => SR(0)
    );
\maxCoordinateReg_reg[17]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => maxCoordinateReg,
      D => s00_axi_wdata(17),
      Q => \maxCoordinateReg_reg_n_0_[17]\,
      R => SR(0)
    );
\maxCoordinateReg_reg[18]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => maxCoordinateReg,
      D => s00_axi_wdata(18),
      Q => \maxCoordinateReg_reg_n_0_[18]\,
      R => SR(0)
    );
\maxCoordinateReg_reg[19]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => maxCoordinateReg,
      D => s00_axi_wdata(19),
      Q => \maxCoordinateReg_reg_n_0_[19]\,
      R => SR(0)
    );
\maxCoordinateReg_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => maxCoordinateReg,
      D => s00_axi_wdata(1),
      Q => \maxCoordinateReg_reg_n_0_[1]\,
      R => SR(0)
    );
\maxCoordinateReg_reg[20]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => maxCoordinateReg,
      D => s00_axi_wdata(20),
      Q => \maxCoordinateReg_reg_n_0_[20]\,
      R => SR(0)
    );
\maxCoordinateReg_reg[21]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => maxCoordinateReg,
      D => s00_axi_wdata(21),
      Q => \maxCoordinateReg_reg_n_0_[21]\,
      R => SR(0)
    );
\maxCoordinateReg_reg[22]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => maxCoordinateReg,
      D => s00_axi_wdata(22),
      Q => \maxCoordinateReg_reg_n_0_[22]\,
      R => SR(0)
    );
\maxCoordinateReg_reg[23]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => maxCoordinateReg,
      D => s00_axi_wdata(23),
      Q => \maxCoordinateReg_reg_n_0_[23]\,
      R => SR(0)
    );
\maxCoordinateReg_reg[24]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => maxCoordinateReg,
      D => s00_axi_wdata(24),
      Q => \maxCoordinateReg_reg_n_0_[24]\,
      R => SR(0)
    );
\maxCoordinateReg_reg[25]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => maxCoordinateReg,
      D => s00_axi_wdata(25),
      Q => \maxCoordinateReg_reg_n_0_[25]\,
      R => SR(0)
    );
\maxCoordinateReg_reg[26]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => maxCoordinateReg,
      D => s00_axi_wdata(26),
      Q => \maxCoordinateReg_reg_n_0_[26]\,
      R => SR(0)
    );
\maxCoordinateReg_reg[27]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => maxCoordinateReg,
      D => s00_axi_wdata(27),
      Q => \maxCoordinateReg_reg_n_0_[27]\,
      R => SR(0)
    );
\maxCoordinateReg_reg[28]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => maxCoordinateReg,
      D => s00_axi_wdata(28),
      Q => \maxCoordinateReg_reg_n_0_[28]\,
      R => SR(0)
    );
\maxCoordinateReg_reg[29]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => maxCoordinateReg,
      D => s00_axi_wdata(29),
      Q => \maxCoordinateReg_reg_n_0_[29]\,
      R => SR(0)
    );
\maxCoordinateReg_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => maxCoordinateReg,
      D => s00_axi_wdata(2),
      Q => \maxCoordinateReg_reg_n_0_[2]\,
      R => SR(0)
    );
\maxCoordinateReg_reg[30]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => maxCoordinateReg,
      D => s00_axi_wdata(30),
      Q => \maxCoordinateReg_reg_n_0_[30]\,
      R => SR(0)
    );
\maxCoordinateReg_reg[31]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => maxCoordinateReg,
      D => s00_axi_wdata(31),
      Q => \maxCoordinateReg_reg_n_0_[31]\,
      R => SR(0)
    );
\maxCoordinateReg_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => maxCoordinateReg,
      D => s00_axi_wdata(3),
      Q => \maxCoordinateReg_reg_n_0_[3]\,
      R => SR(0)
    );
\maxCoordinateReg_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => maxCoordinateReg,
      D => s00_axi_wdata(4),
      Q => \maxCoordinateReg_reg_n_0_[4]\,
      R => SR(0)
    );
\maxCoordinateReg_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => maxCoordinateReg,
      D => s00_axi_wdata(5),
      Q => \maxCoordinateReg_reg_n_0_[5]\,
      R => SR(0)
    );
\maxCoordinateReg_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => maxCoordinateReg,
      D => s00_axi_wdata(6),
      Q => \maxCoordinateReg_reg_n_0_[6]\,
      R => SR(0)
    );
\maxCoordinateReg_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => maxCoordinateReg,
      D => s00_axi_wdata(7),
      Q => \maxCoordinateReg_reg_n_0_[7]\,
      R => SR(0)
    );
\maxCoordinateReg_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => maxCoordinateReg,
      D => s00_axi_wdata(8),
      Q => \maxCoordinateReg_reg_n_0_[8]\,
      R => SR(0)
    );
\maxCoordinateReg_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => maxCoordinateReg,
      D => s00_axi_wdata(9),
      Q => \maxCoordinateReg_reg_n_0_[9]\,
      R => SR(0)
    );
\maxCountReg[31]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000000004"
    )
        port map (
      I0 => p_0_in(0),
      I1 => p_0_in(2),
      I2 => p_0_in(1),
      I3 => p_0_in(4),
      I4 => p_0_in(3),
      I5 => \controlReg[31]_i_2_n_0\,
      O => maxCountReg
    );
\maxCountReg_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => maxCountReg,
      D => s00_axi_wdata(0),
      Q => \maxCountReg_reg_n_0_[0]\,
      R => SR(0)
    );
\maxCountReg_reg[10]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => maxCountReg,
      D => s00_axi_wdata(10),
      Q => \maxCountReg_reg_n_0_[10]\,
      R => SR(0)
    );
\maxCountReg_reg[11]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => maxCountReg,
      D => s00_axi_wdata(11),
      Q => \maxCountReg_reg_n_0_[11]\,
      R => SR(0)
    );
\maxCountReg_reg[12]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => maxCountReg,
      D => s00_axi_wdata(12),
      Q => \maxCountReg_reg_n_0_[12]\,
      R => SR(0)
    );
\maxCountReg_reg[13]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => maxCountReg,
      D => s00_axi_wdata(13),
      Q => \maxCountReg_reg_n_0_[13]\,
      R => SR(0)
    );
\maxCountReg_reg[14]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => maxCountReg,
      D => s00_axi_wdata(14),
      Q => \maxCountReg_reg_n_0_[14]\,
      R => SR(0)
    );
\maxCountReg_reg[15]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => maxCountReg,
      D => s00_axi_wdata(15),
      Q => \maxCountReg_reg_n_0_[15]\,
      R => SR(0)
    );
\maxCountReg_reg[16]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => maxCountReg,
      D => s00_axi_wdata(16),
      Q => \maxCountReg_reg_n_0_[16]\,
      R => SR(0)
    );
\maxCountReg_reg[17]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => maxCountReg,
      D => s00_axi_wdata(17),
      Q => \maxCountReg_reg_n_0_[17]\,
      R => SR(0)
    );
\maxCountReg_reg[18]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => maxCountReg,
      D => s00_axi_wdata(18),
      Q => \maxCountReg_reg_n_0_[18]\,
      R => SR(0)
    );
\maxCountReg_reg[19]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => maxCountReg,
      D => s00_axi_wdata(19),
      Q => \maxCountReg_reg_n_0_[19]\,
      R => SR(0)
    );
\maxCountReg_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => maxCountReg,
      D => s00_axi_wdata(1),
      Q => \maxCountReg_reg_n_0_[1]\,
      R => SR(0)
    );
\maxCountReg_reg[20]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => maxCountReg,
      D => s00_axi_wdata(20),
      Q => \maxCountReg_reg_n_0_[20]\,
      R => SR(0)
    );
\maxCountReg_reg[21]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => maxCountReg,
      D => s00_axi_wdata(21),
      Q => \maxCountReg_reg_n_0_[21]\,
      R => SR(0)
    );
\maxCountReg_reg[22]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => maxCountReg,
      D => s00_axi_wdata(22),
      Q => \maxCountReg_reg_n_0_[22]\,
      R => SR(0)
    );
\maxCountReg_reg[23]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => maxCountReg,
      D => s00_axi_wdata(23),
      Q => \maxCountReg_reg_n_0_[23]\,
      R => SR(0)
    );
\maxCountReg_reg[24]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => maxCountReg,
      D => s00_axi_wdata(24),
      Q => \maxCountReg_reg_n_0_[24]\,
      R => SR(0)
    );
\maxCountReg_reg[25]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => maxCountReg,
      D => s00_axi_wdata(25),
      Q => \maxCountReg_reg_n_0_[25]\,
      R => SR(0)
    );
\maxCountReg_reg[26]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => maxCountReg,
      D => s00_axi_wdata(26),
      Q => \maxCountReg_reg_n_0_[26]\,
      R => SR(0)
    );
\maxCountReg_reg[27]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => maxCountReg,
      D => s00_axi_wdata(27),
      Q => \maxCountReg_reg_n_0_[27]\,
      R => SR(0)
    );
\maxCountReg_reg[28]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => maxCountReg,
      D => s00_axi_wdata(28),
      Q => \maxCountReg_reg_n_0_[28]\,
      R => SR(0)
    );
\maxCountReg_reg[29]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => maxCountReg,
      D => s00_axi_wdata(29),
      Q => \maxCountReg_reg_n_0_[29]\,
      R => SR(0)
    );
\maxCountReg_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => maxCountReg,
      D => s00_axi_wdata(2),
      Q => \maxCountReg_reg_n_0_[2]\,
      R => SR(0)
    );
\maxCountReg_reg[30]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => maxCountReg,
      D => s00_axi_wdata(30),
      Q => \maxCountReg_reg_n_0_[30]\,
      R => SR(0)
    );
\maxCountReg_reg[31]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => maxCountReg,
      D => s00_axi_wdata(31),
      Q => \maxCountReg_reg_n_0_[31]\,
      R => SR(0)
    );
\maxCountReg_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => maxCountReg,
      D => s00_axi_wdata(3),
      Q => \maxCountReg_reg_n_0_[3]\,
      R => SR(0)
    );
\maxCountReg_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => maxCountReg,
      D => s00_axi_wdata(4),
      Q => \maxCountReg_reg_n_0_[4]\,
      R => SR(0)
    );
\maxCountReg_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => maxCountReg,
      D => s00_axi_wdata(5),
      Q => \maxCountReg_reg_n_0_[5]\,
      R => SR(0)
    );
\maxCountReg_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => maxCountReg,
      D => s00_axi_wdata(6),
      Q => \maxCountReg_reg_n_0_[6]\,
      R => SR(0)
    );
\maxCountReg_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => maxCountReg,
      D => s00_axi_wdata(7),
      Q => \maxCountReg_reg_n_0_[7]\,
      R => SR(0)
    );
\maxCountReg_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => maxCountReg,
      D => s00_axi_wdata(8),
      Q => \maxCountReg_reg_n_0_[8]\,
      R => SR(0)
    );
\maxCountReg_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => maxCountReg,
      D => s00_axi_wdata(9),
      Q => \maxCountReg_reg_n_0_[9]\,
      R => SR(0)
    );
\o_intr_i_10__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"F888"
    )
        port map (
      I0 => \intrEnableReg_reg_n_0_[16]\,
      I1 => \intrStatReg_reg_n_0_[16]\,
      I2 => \intrEnableReg_reg_n_0_[17]\,
      I3 => \intrStatReg_reg_n_0_[17]\,
      O => \o_intr_i_10__0_n_0\
    );
o_intr_i_11: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00000777"
    )
        port map (
      I0 => \intrStatReg_reg_n_0_[23]\,
      I1 => \intrEnableReg_reg_n_0_[23]\,
      I2 => \intrStatReg_reg_n_0_[22]\,
      I3 => \intrEnableReg_reg_n_0_[22]\,
      I4 => o_intr_i_16_n_0,
      O => o_intr_i_11_n_0
    );
o_intr_i_12: unisim.vcomponents.LUT4
    generic map(
      INIT => X"F888"
    )
        port map (
      I0 => \intrEnableReg_reg_n_0_[28]\,
      I1 => \intrStatReg_reg_n_0_[28]\,
      I2 => \intrEnableReg_reg_n_0_[29]\,
      I3 => \intrStatReg_reg_n_0_[29]\,
      O => o_intr_i_12_n_0
    );
o_intr_i_13: unisim.vcomponents.LUT5
    generic map(
      INIT => X"F888FFFF"
    )
        port map (
      I0 => \intrStatReg_reg_n_0_[25]\,
      I1 => \intrEnableReg_reg_n_0_[25]\,
      I2 => \intrStatReg_reg_n_0_[24]\,
      I3 => \intrEnableReg_reg_n_0_[24]\,
      I4 => o_intr_i_17_n_0,
      O => o_intr_i_13_n_0
    );
o_intr_i_14: unisim.vcomponents.LUT4
    generic map(
      INIT => X"F888"
    )
        port map (
      I0 => \intrEnableReg_reg_n_0_[4]\,
      I1 => \intrStatReg_reg_n_0_[4]\,
      I2 => \intrEnableReg_reg_n_0_[5]\,
      I3 => \intrStatReg_reg_n_0_[5]\,
      O => o_intr_i_14_n_0
    );
o_intr_i_15: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0777"
    )
        port map (
      I0 => \intrEnableReg_reg_n_0_[10]\,
      I1 => \intrStatReg_reg_n_0_[10]\,
      I2 => \intrEnableReg_reg_n_0_[11]\,
      I3 => \intrStatReg_reg_n_0_[11]\,
      O => o_intr_i_15_n_0
    );
o_intr_i_16: unisim.vcomponents.LUT4
    generic map(
      INIT => X"F888"
    )
        port map (
      I0 => \intrEnableReg_reg_n_0_[20]\,
      I1 => \intrStatReg_reg_n_0_[20]\,
      I2 => \intrEnableReg_reg_n_0_[21]\,
      I3 => \intrStatReg_reg_n_0_[21]\,
      O => o_intr_i_16_n_0
    );
o_intr_i_17: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0777"
    )
        port map (
      I0 => \intrEnableReg_reg_n_0_[26]\,
      I1 => \intrStatReg_reg_n_0_[26]\,
      I2 => \intrEnableReg_reg_n_0_[27]\,
      I3 => \intrStatReg_reg_n_0_[27]\,
      O => o_intr_i_17_n_0
    );
\o_intr_i_1__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FBFF"
    )
        port map (
      I0 => \o_intr_i_2__0_n_0\,
      I1 => \o_intr_i_3__0_n_0\,
      I2 => \o_intr_i_4__0_n_0\,
      I3 => \o_intr_i_5__0_n_0\,
      O => \o_intr_i_1__0_n_0\
    );
\o_intr_i_2__0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFEAEAEAFFFFFFFF"
    )
        port map (
      I0 => \o_intr_i_6__0_n_0\,
      I1 => \intrEnableReg_reg_n_0_[2]\,
      I2 => \intrStatReg_reg_n_0_[2]\,
      I3 => \intrEnableReg_reg_n_0_[3]\,
      I4 => \intrStatReg_reg_n_0_[3]\,
      I5 => \o_intr_i_7__0_n_0\,
      O => \o_intr_i_2__0_n_0\
    );
\o_intr_i_3__0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000151515"
    )
        port map (
      I0 => \o_intr_i_8__0_n_0\,
      I1 => \intrEnableReg_reg_n_0_[14]\,
      I2 => \intrStatReg_reg_n_0_[14]\,
      I3 => \intrEnableReg_reg_n_0_[15]\,
      I4 => \intrStatReg_reg_n_0_[15]\,
      I5 => \o_intr_i_9__0_n_0\,
      O => \o_intr_i_3__0_n_0\
    );
\o_intr_i_4__0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFEAEAEAFFFFFFFF"
    )
        port map (
      I0 => \o_intr_i_10__0_n_0\,
      I1 => \intrEnableReg_reg_n_0_[18]\,
      I2 => \intrStatReg_reg_n_0_[18]\,
      I3 => \intrEnableReg_reg_n_0_[19]\,
      I4 => \intrStatReg_reg_n_0_[19]\,
      I5 => o_intr_i_11_n_0,
      O => \o_intr_i_4__0_n_0\
    );
\o_intr_i_5__0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000151515"
    )
        port map (
      I0 => o_intr_i_12_n_0,
      I1 => \intrEnableReg_reg_n_0_[31]\,
      I2 => \intrStatReg_reg_n_0_[31]\,
      I3 => \intrEnableReg_reg_n_0_[30]\,
      I4 => \intrStatReg_reg_n_0_[30]\,
      I5 => o_intr_i_13_n_0,
      O => \o_intr_i_5__0_n_0\
    );
\o_intr_i_6__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"F888"
    )
        port map (
      I0 => \intrEnableReg_reg_n_0_[0]\,
      I1 => \intrStatReg_reg_n_0_[0]\,
      I2 => \intrEnableReg_reg_n_0_[1]\,
      I3 => \intrStatReg_reg_n_0_[1]\,
      O => \o_intr_i_6__0_n_0\
    );
\o_intr_i_7__0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00000777"
    )
        port map (
      I0 => \intrStatReg_reg_n_0_[7]\,
      I1 => \intrEnableReg_reg_n_0_[7]\,
      I2 => \intrStatReg_reg_n_0_[6]\,
      I3 => \intrEnableReg_reg_n_0_[6]\,
      I4 => o_intr_i_14_n_0,
      O => \o_intr_i_7__0_n_0\
    );
\o_intr_i_8__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"F888"
    )
        port map (
      I0 => \intrEnableReg_reg_n_0_[12]\,
      I1 => \intrStatReg_reg_n_0_[12]\,
      I2 => \intrEnableReg_reg_n_0_[13]\,
      I3 => \intrStatReg_reg_n_0_[13]\,
      O => \o_intr_i_8__0_n_0\
    );
\o_intr_i_9__0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"F888FFFF"
    )
        port map (
      I0 => \intrStatReg_reg_n_0_[9]\,
      I1 => \intrEnableReg_reg_n_0_[9]\,
      I2 => \intrStatReg_reg_n_0_[8]\,
      I3 => \intrEnableReg_reg_n_0_[8]\,
      I4 => o_intr_i_15_n_0,
      O => \o_intr_i_9__0_n_0\
    );
o_intr_reg: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \o_intr_i_1__0_n_0\,
      Q => o_intr,
      R => '0'
    );
slv_reg_rden: unisim.vcomponents.LUT3
    generic map(
      INIT => X"40"
    )
        port map (
      I0 => \^s00_axi_rvalid\,
      I1 => \^s00_axi_arready\,
      I2 => s00_axi_arvalid,
      O => \slv_reg_rden__0\
    );
spDebounce: entity work.decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_singlePulseDebounce
     port map (
      \axi_awaddr_reg[4]\ => \intrStatReg[31]_i_3_n_0\,
      i_button_press => i_button_press,
      \intrStatReg_reg[0]\ => spDebounce_n_1,
      \intrStatReg_reg[0]_0\ => \intrStatReg_reg_n_0_[0]\,
      s00_axi_aclk => s00_axi_aclk,
      s00_axi_wdata(0) => s00_axi_wdata(0),
      w_button_pulse => w_button_pulse
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_zyMouse_v1_0 is
  port (
    S_AXI_ARREADY : out STD_LOGIC;
    S_AXI_WREADY : out STD_LOGIC;
    S_AXI_AWREADY : out STD_LOGIC;
    s00_axi_rdata : out STD_LOGIC_VECTOR ( 31 downto 0 );
    o_intr : out STD_LOGIC;
    s00_axi_rvalid : out STD_LOGIC;
    s00_axi_bvalid : out STD_LOGIC;
    s00_axi_arvalid : in STD_LOGIC;
    s00_axi_aclk : in STD_LOGIC;
    s00_axi_awaddr : in STD_LOGIC_VECTOR ( 4 downto 0 );
    s00_axi_wdata : in STD_LOGIC_VECTOR ( 31 downto 0 );
    s00_axi_araddr : in STD_LOGIC_VECTOR ( 4 downto 0 );
    i_button_left : in STD_LOGIC;
    i_button_right : in STD_LOGIC;
    i_button_up : in STD_LOGIC;
    i_button_down : in STD_LOGIC;
    i_button_press : in STD_LOGIC;
    s00_axi_wvalid : in STD_LOGIC;
    s00_axi_awvalid : in STD_LOGIC;
    s00_axi_aresetn : in STD_LOGIC;
    s00_axi_bready : in STD_LOGIC;
    s00_axi_rready : in STD_LOGIC
  );
end decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_zyMouse_v1_0;

architecture STRUCTURE of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_zyMouse_v1_0 is
  signal \^s_axi_arready\ : STD_LOGIC;
  signal \^s_axi_awready\ : STD_LOGIC;
  signal \^s_axi_wready\ : STD_LOGIC;
  signal aw_en_i_1_n_0 : STD_LOGIC;
  signal axi_awready_i_1_n_0 : STD_LOGIC;
  signal axi_bvalid_i_1_n_0 : STD_LOGIC;
  signal axi_rvalid_i_1_n_0 : STD_LOGIC;
  signal \^s00_axi_bvalid\ : STD_LOGIC;
  signal \^s00_axi_rvalid\ : STD_LOGIC;
  signal zyMouse_v1_0_S00_AXI_inst_n_6 : STD_LOGIC;
begin
  S_AXI_ARREADY <= \^s_axi_arready\;
  S_AXI_AWREADY <= \^s_axi_awready\;
  S_AXI_WREADY <= \^s_axi_wready\;
  s00_axi_bvalid <= \^s00_axi_bvalid\;
  s00_axi_rvalid <= \^s00_axi_rvalid\;
aw_en_i_1: unisim.vcomponents.LUT6
    generic map(
      INIT => X"F0FFFFFF88888888"
    )
        port map (
      I0 => s00_axi_bready,
      I1 => \^s00_axi_bvalid\,
      I2 => \^s_axi_awready\,
      I3 => s00_axi_awvalid,
      I4 => s00_axi_wvalid,
      I5 => zyMouse_v1_0_S00_AXI_inst_n_6,
      O => aw_en_i_1_n_0
    );
axi_awready_i_1: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => s00_axi_aresetn,
      O => axi_awready_i_1_n_0
    );
axi_bvalid_i_1: unisim.vcomponents.LUT6
    generic map(
      INIT => X"7444444444444444"
    )
        port map (
      I0 => s00_axi_bready,
      I1 => \^s00_axi_bvalid\,
      I2 => s00_axi_wvalid,
      I3 => s00_axi_awvalid,
      I4 => \^s_axi_awready\,
      I5 => \^s_axi_wready\,
      O => axi_bvalid_i_1_n_0
    );
axi_rvalid_i_1: unisim.vcomponents.LUT4
    generic map(
      INIT => X"08F8"
    )
        port map (
      I0 => s00_axi_arvalid,
      I1 => \^s_axi_arready\,
      I2 => \^s00_axi_rvalid\,
      I3 => s00_axi_rready,
      O => axi_rvalid_i_1_n_0
    );
zyMouse_v1_0_S00_AXI_inst: entity work.decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_zyMouse_v1_0_S00_AXI
     port map (
      SR(0) => axi_awready_i_1_n_0,
      axi_arready_reg_0 => axi_rvalid_i_1_n_0,
      axi_bvalid_reg_0 => axi_bvalid_i_1_n_0,
      axi_bvalid_reg_1 => aw_en_i_1_n_0,
      axi_wready_reg_0 => zyMouse_v1_0_S00_AXI_inst_n_6,
      i_button_down => i_button_down,
      i_button_left => i_button_left,
      i_button_press => i_button_press,
      i_button_right => i_button_right,
      i_button_up => i_button_up,
      o_intr => o_intr,
      s00_axi_aclk => s00_axi_aclk,
      s00_axi_araddr(4 downto 0) => s00_axi_araddr(4 downto 0),
      s00_axi_arready => \^s_axi_arready\,
      s00_axi_arvalid => s00_axi_arvalid,
      s00_axi_awaddr(4 downto 0) => s00_axi_awaddr(4 downto 0),
      s00_axi_awready => \^s_axi_awready\,
      s00_axi_awvalid => s00_axi_awvalid,
      s00_axi_bvalid => \^s00_axi_bvalid\,
      s00_axi_rdata(31 downto 0) => s00_axi_rdata(31 downto 0),
      s00_axi_rvalid => \^s00_axi_rvalid\,
      s00_axi_wdata(31 downto 0) => s00_axi_wdata(31 downto 0),
      s00_axi_wready => \^s_axi_wready\,
      s00_axi_wvalid => s00_axi_wvalid
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix is
  port (
    s00_axi_awaddr : in STD_LOGIC_VECTOR ( 7 downto 0 );
    s00_axi_awprot : in STD_LOGIC_VECTOR ( 2 downto 0 );
    s00_axi_awvalid : in STD_LOGIC;
    s00_axi_awready : out STD_LOGIC;
    s00_axi_wdata : in STD_LOGIC_VECTOR ( 31 downto 0 );
    s00_axi_wstrb : in STD_LOGIC_VECTOR ( 3 downto 0 );
    s00_axi_wvalid : in STD_LOGIC;
    s00_axi_wready : out STD_LOGIC;
    s00_axi_bresp : out STD_LOGIC_VECTOR ( 1 downto 0 );
    s00_axi_bvalid : out STD_LOGIC;
    s00_axi_bready : in STD_LOGIC;
    s00_axi_araddr : in STD_LOGIC_VECTOR ( 7 downto 0 );
    s00_axi_arprot : in STD_LOGIC_VECTOR ( 2 downto 0 );
    s00_axi_arvalid : in STD_LOGIC;
    s00_axi_arready : out STD_LOGIC;
    s00_axi_rdata : out STD_LOGIC_VECTOR ( 31 downto 0 );
    s00_axi_rresp : out STD_LOGIC_VECTOR ( 1 downto 0 );
    s00_axi_rvalid : out STD_LOGIC;
    s00_axi_rready : in STD_LOGIC;
    i_button_left : in STD_LOGIC;
    i_button_right : in STD_LOGIC;
    i_button_up : in STD_LOGIC;
    i_button_down : in STD_LOGIC;
    i_button_press : in STD_LOGIC;
    o_intr : out STD_LOGIC;
    s00_axi_aclk : in STD_LOGIC;
    s00_axi_aresetn : in STD_LOGIC
  );
  attribute NotValidForBitStream : boolean;
  attribute NotValidForBitStream of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is true;
  attribute CHECK_LICENSE_TYPE : string;
  attribute CHECK_LICENSE_TYPE of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is "system_zyMouse_0_0,zyMouse_v1_0,{}";
  attribute DowngradeIPIdentifiedWarnings : string;
  attribute DowngradeIPIdentifiedWarnings of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is "yes";
  attribute X_CORE_INFO : string;
  attribute X_CORE_INFO of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is "zyMouse_v1_0,Vivado 2017.4";
end decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix;

architecture STRUCTURE of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix is
  signal \<const0>\ : STD_LOGIC;
  attribute X_INTERFACE_INFO : string;
  attribute X_INTERFACE_INFO of o_intr : signal is "xilinx.com:signal:interrupt:1.0 o_intr INTERRUPT";
  attribute X_INTERFACE_PARAMETER : string;
  attribute X_INTERFACE_PARAMETER of o_intr : signal is "XIL_INTERFACENAME o_intr, SENSITIVITY LEVEL_HIGH, PortWidth 1";
  attribute X_INTERFACE_INFO of s00_axi_aclk : signal is "xilinx.com:signal:clock:1.0 S00_AXI_CLK CLK";
  attribute X_INTERFACE_PARAMETER of s00_axi_aclk : signal is "XIL_INTERFACENAME S00_AXI_CLK, ASSOCIATED_BUSIF S00_AXI, ASSOCIATED_RESET s00_axi_aresetn, FREQ_HZ 99776785, PHASE 0.0, CLK_DOMAIN /clk_wiz_0_clk_out1";
  attribute X_INTERFACE_INFO of s00_axi_aresetn : signal is "xilinx.com:signal:reset:1.0 S00_AXI_RST RST";
  attribute X_INTERFACE_PARAMETER of s00_axi_aresetn : signal is "XIL_INTERFACENAME S00_AXI_RST, POLARITY ACTIVE_LOW";
  attribute X_INTERFACE_INFO of s00_axi_arready : signal is "xilinx.com:interface:aximm:1.0 S00_AXI ARREADY";
  attribute X_INTERFACE_INFO of s00_axi_arvalid : signal is "xilinx.com:interface:aximm:1.0 S00_AXI ARVALID";
  attribute X_INTERFACE_INFO of s00_axi_awready : signal is "xilinx.com:interface:aximm:1.0 S00_AXI AWREADY";
  attribute X_INTERFACE_INFO of s00_axi_awvalid : signal is "xilinx.com:interface:aximm:1.0 S00_AXI AWVALID";
  attribute X_INTERFACE_INFO of s00_axi_bready : signal is "xilinx.com:interface:aximm:1.0 S00_AXI BREADY";
  attribute X_INTERFACE_INFO of s00_axi_bvalid : signal is "xilinx.com:interface:aximm:1.0 S00_AXI BVALID";
  attribute X_INTERFACE_INFO of s00_axi_rready : signal is "xilinx.com:interface:aximm:1.0 S00_AXI RREADY";
  attribute X_INTERFACE_PARAMETER of s00_axi_rready : signal is "XIL_INTERFACENAME S00_AXI, WIZ_DATA_WIDTH 32, WIZ_NUM_REG 4, SUPPORTS_NARROW_BURST 0, DATA_WIDTH 32, PROTOCOL AXI4LITE, FREQ_HZ 99776785, ID_WIDTH 0, ADDR_WIDTH 8, AWUSER_WIDTH 0, ARUSER_WIDTH 0, WUSER_WIDTH 0, RUSER_WIDTH 0, BUSER_WIDTH 0, READ_WRITE_MODE READ_WRITE, HAS_BURST 0, HAS_LOCK 0, HAS_PROT 1, HAS_CACHE 0, HAS_QOS 0, HAS_REGION 0, HAS_WSTRB 1, HAS_BRESP 1, HAS_RRESP 1, NUM_READ_OUTSTANDING 2, NUM_WRITE_OUTSTANDING 2, MAX_BURST_LENGTH 1, PHASE 0.0, CLK_DOMAIN /clk_wiz_0_clk_out1, NUM_READ_THREADS 1, NUM_WRITE_THREADS 1, RUSER_BITS_PER_BYTE 0, WUSER_BITS_PER_BYTE 0";
  attribute X_INTERFACE_INFO of s00_axi_rvalid : signal is "xilinx.com:interface:aximm:1.0 S00_AXI RVALID";
  attribute X_INTERFACE_INFO of s00_axi_wready : signal is "xilinx.com:interface:aximm:1.0 S00_AXI WREADY";
  attribute X_INTERFACE_INFO of s00_axi_wvalid : signal is "xilinx.com:interface:aximm:1.0 S00_AXI WVALID";
  attribute X_INTERFACE_INFO of s00_axi_araddr : signal is "xilinx.com:interface:aximm:1.0 S00_AXI ARADDR";
  attribute X_INTERFACE_INFO of s00_axi_arprot : signal is "xilinx.com:interface:aximm:1.0 S00_AXI ARPROT";
  attribute X_INTERFACE_INFO of s00_axi_awaddr : signal is "xilinx.com:interface:aximm:1.0 S00_AXI AWADDR";
  attribute X_INTERFACE_INFO of s00_axi_awprot : signal is "xilinx.com:interface:aximm:1.0 S00_AXI AWPROT";
  attribute X_INTERFACE_INFO of s00_axi_bresp : signal is "xilinx.com:interface:aximm:1.0 S00_AXI BRESP";
  attribute X_INTERFACE_INFO of s00_axi_rdata : signal is "xilinx.com:interface:aximm:1.0 S00_AXI RDATA";
  attribute X_INTERFACE_INFO of s00_axi_rresp : signal is "xilinx.com:interface:aximm:1.0 S00_AXI RRESP";
  attribute X_INTERFACE_INFO of s00_axi_wdata : signal is "xilinx.com:interface:aximm:1.0 S00_AXI WDATA";
  attribute X_INTERFACE_INFO of s00_axi_wstrb : signal is "xilinx.com:interface:aximm:1.0 S00_AXI WSTRB";
begin
  s00_axi_bresp(1) <= \<const0>\;
  s00_axi_bresp(0) <= \<const0>\;
  s00_axi_rresp(1) <= \<const0>\;
  s00_axi_rresp(0) <= \<const0>\;
GND: unisim.vcomponents.GND
     port map (
      G => \<const0>\
    );
inst: entity work.decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_zyMouse_v1_0
     port map (
      S_AXI_ARREADY => s00_axi_arready,
      S_AXI_AWREADY => s00_axi_awready,
      S_AXI_WREADY => s00_axi_wready,
      i_button_down => i_button_down,
      i_button_left => i_button_left,
      i_button_press => i_button_press,
      i_button_right => i_button_right,
      i_button_up => i_button_up,
      o_intr => o_intr,
      s00_axi_aclk => s00_axi_aclk,
      s00_axi_araddr(4 downto 0) => s00_axi_araddr(6 downto 2),
      s00_axi_aresetn => s00_axi_aresetn,
      s00_axi_arvalid => s00_axi_arvalid,
      s00_axi_awaddr(4 downto 0) => s00_axi_awaddr(6 downto 2),
      s00_axi_awvalid => s00_axi_awvalid,
      s00_axi_bready => s00_axi_bready,
      s00_axi_bvalid => s00_axi_bvalid,
      s00_axi_rdata(31 downto 0) => s00_axi_rdata(31 downto 0),
      s00_axi_rready => s00_axi_rready,
      s00_axi_rvalid => s00_axi_rvalid,
      s00_axi_wdata(31 downto 0) => s00_axi_wdata(31 downto 0),
      s00_axi_wvalid => s00_axi_wvalid
    );
end STRUCTURE;
