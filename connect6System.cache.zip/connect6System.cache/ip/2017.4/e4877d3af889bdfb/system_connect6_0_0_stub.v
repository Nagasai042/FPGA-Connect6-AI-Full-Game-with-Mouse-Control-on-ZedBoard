// Copyright 1986-2017 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2017.4 (win64) Build 2086221 Fri Dec 15 20:55:39 MST 2017
// Date        : Thu Apr  2 23:13:28 2026
// Host        : DESKTOP-VKRMBR2 running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode synth_stub -rename_top decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix -prefix
//               decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_ system_connect6_0_0_stub.v
// Design      : system_connect6_0_0
// Purpose     : Stub declaration of top-level module interface
// Device      : xc7z020clg484-1
// --------------------------------------------------------------------------------

// This empty module with port declaration file causes synthesis tools to infer a black box for IP.
// The synthesis directives are for Synopsys Synplify support to prevent IO buffer insertion.
// Please paste the declaration into a Verilog source file or add the file as an additional source.
(* X_CORE_INFO = "connect6,Vivado 2017.4" *)
module decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix(i_clk, i_rst, i_uart_rx_data, o_uart_tx_data, 
  o_fpga_act)
/* synthesis syn_black_box black_box_pad_pin="i_clk,i_rst,i_uart_rx_data,o_uart_tx_data,o_fpga_act" */;
  input i_clk;
  input i_rst;
  input i_uart_rx_data;
  output o_uart_tx_data;
  output o_fpga_act;
endmodule
