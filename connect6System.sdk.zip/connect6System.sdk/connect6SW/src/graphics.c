/*
 * imageProcess.c
 *
 *  Created on: Apr 13, 2020
 *      Author: VIPIN
 */

#include "graphics.h"
#include "font.h"

/*****************************************************************************/
/**
 * This function copies the buffer data from image buffer to video buffer
 */
int drawImage(u32 displayHSize,u32 displayVSize,u32 imageHSize,u32 imageVSize,u32 hOffset, u32 vOffset,int numColors,char *imagePointer,char *videoFramePointer){
	Xil_DCacheInvalidateRange((u32)imagePointer,(imageHSize*imageVSize));
	for(int i=0;i<displayVSize;i++){
		for(int j=0;j<displayHSize;j++){
			if(i<vOffset || i >= vOffset+imageVSize){
				videoFramePointer[(i*displayHSize*3)+(j*3)]   = 0x00;
				videoFramePointer[(i*displayHSize*3)+(j*3)+1] = 0x00;
				videoFramePointer[(i*displayHSize*3)+(j*3)+2] = 0x00;
			}
			else if(j<hOffset || j >= hOffset+imageHSize){
				videoFramePointer[(i*displayHSize*3)+(j*3)]   = 0x00;
				videoFramePointer[(i*displayHSize*3)+(j*3)+1] = 0x00;
				videoFramePointer[(i*displayHSize*3)+(j*3)+2] = 0x00;
			}
			else {
				if(numColors==1){
					videoFramePointer[(i*displayHSize*3)+j*3]     = *imagePointer/16;
					videoFramePointer[(i*displayHSize*3)+(j*3)+1] = *imagePointer/16;
					videoFramePointer[(i*displayHSize*3)+(j*3)+2] = *imagePointer/16;
					imagePointer++;
				}
				else if(numColors==3){
					videoFramePointer[(i*displayHSize*3)+j*3]     = *imagePointer/16;
					videoFramePointer[(i*displayHSize*3)+(j*3)+1] = *(imagePointer++)/16;
					videoFramePointer[(i*displayHSize*3)+(j*3)+2] = *(imagePointer++)/16;
					imagePointer++;
				}
			}
		}
	}
	Xil_DCacheFlush();
	return 0;
}


int drawFrame(u32 displayHSize,u32 displayVSize,u32 grdSize,u32 frameVOffset,u32 frameHOffset,u32 framewidth,u32 color,char* videoFramePointer){
	u32 vOffset = frameVOffset*grdSize;
	u32 hOffset = frameHOffset*grdSize;
	u32 width = framewidth*grdSize;
	//Top line
	for(int i=vOffset;i<vOffset+width;i++){
		for(int j=hOffset;j<displayHSize-hOffset;j++){
			videoFramePointer[(i*displayHSize*3)+(j*3)]   = color&0xff;
			videoFramePointer[(i*displayHSize*3)+(j*3)+1] = (color&0x00ff00)>>8;
			videoFramePointer[(i*displayHSize*3)+(j*3)+2] = (color&0xff0000)>>16;
		}
	}
	//Bottom line
	for(int i=(displayVSize-vOffset-width);i<displayVSize-vOffset;i++){
		for(int j=hOffset;j<displayHSize-hOffset;j++){
			videoFramePointer[(i*displayHSize*3)+(j*3)]   = color&0xff;
			videoFramePointer[(i*displayHSize*3)+(j*3)+1] = (color&0x00ff00)>>8;
			videoFramePointer[(i*displayHSize*3)+(j*3)+2] = (color&0xff0000)>>16;
		}
	}
	//Left line
	for(int i=width+vOffset;i<displayVSize-width-vOffset;i++){
		for(int j=hOffset;j<hOffset+width;j++){
			videoFramePointer[(i*displayHSize*3)+(j*3)]   = color&0xff;
			videoFramePointer[(i*displayHSize*3)+(j*3)+1] = (color&0x00ff00)>>8;
			videoFramePointer[(i*displayHSize*3)+(j*3)+2] = (color&0xff0000)>>16;
		}
	}
	//Right line
	for(int i=width+vOffset;i<displayVSize-width-vOffset;i++){
		for(int j=displayHSize-width-hOffset;j<displayHSize-hOffset;j++){
			videoFramePointer[(i*displayHSize*3)+(j*3)]   = color&0xff;
			videoFramePointer[(i*displayHSize*3)+(j*3)+1] = (color&0x00ff00)>>8;
			videoFramePointer[(i*displayHSize*3)+(j*3)+2] = (color&0xff0000)>>16;
		}
	}
	Xil_DCacheFlush();
	return 0;
}


void printString(u32 displayHSize,char *printString,u32 hOffset, u32 vOffset,u32 zoom,u32 color,char* videoFramePointer){
	u32 charPos = hOffset;
	u32 charArrayPos;
	while(*printString != 0){
		charArrayPos = (*printString-32)*8;
		printChar(displayHSize,(char *)&fontBitMat[charArrayPos],charPos,vOffset,zoom,color,videoFramePointer);
		charPos += zoom*8;
		printString++;
	}
}


void printChar(u32 displayHSize,char *charBitMap,u32 hOffset, u32 vOffset,u32 zoom,u32 color,char* videoFramePointer){
	for(int i=0;i<8*zoom;i++){
		for(int j=0;j<8*zoom;j++){
			videoFramePointer[((j+vOffset)*displayHSize*3)+((i+hOffset)*3)]   = ((*(charBitMap+(i/zoom))>>(j/zoom))&0x1)*(color&0xff);
			videoFramePointer[((j+vOffset)*displayHSize*3)+((i+hOffset)*3)+1] = ((*(charBitMap+(i/zoom))>>(j/zoom))&0x1)*(color&0x00ff00)>>8;
			videoFramePointer[((j+vOffset)*displayHSize*3)+((i+hOffset)*3)+2] = ((*(charBitMap+(i/zoom))>>(j/zoom))&0x1)*(color&0xff0000)>>16;
		}
	}
	Xil_DCacheFlush();
}


void readGridData(u32 displayHSize,char *charBitMap,u32 hOffset, u32 vOffset,u32 pntrSize,char* videoFramePointer){
	for(int i=0;i<pntrSize;i++){
		for(int j=0;j<pntrSize;j++){
			charBitMap[i*pntrSize*3+j*3]   = videoFramePointer[((j+vOffset)*displayHSize*3)+((i+hOffset)*3)];
			charBitMap[i*pntrSize*3+j*3+1] = videoFramePointer[((j+vOffset)*displayHSize*3)+((i+hOffset)*3)+1];
			charBitMap[i*pntrSize*3+j*3+2] = videoFramePointer[((j+vOffset)*displayHSize*3)+((i+hOffset)*3)+2];
		}
	}
}

void writeGridData(u32 displayHSize,char *charBitMap,u32 hOffset, u32 vOffset,u32 grdSize,char* videoFramePointer){
	for(int i=0;i<grdSize;i++){
		for(int j=0;j<grdSize;j++){
			videoFramePointer[((j+vOffset)*displayHSize*3)+((i+hOffset)*3)]   = charBitMap[i*grdSize*3+j*3];
			videoFramePointer[((j+vOffset)*displayHSize*3)+((i+hOffset)*3)+1] = charBitMap[i*grdSize*3+j*3+1];
			videoFramePointer[((j+vOffset)*displayHSize*3)+((i+hOffset)*3)+2] = charBitMap[i*grdSize*3+j*3+2];
		}
	}
	Xil_DCacheFlush();
}


int drawSquare(u16 xPos, u16 yPos,u32 grdSize,u32 displayHSize,char* videoFramePointer,u32 color){
	for(int i=1;i<grdSize-1;i++){
		for(int j=1;j<grdSize-1;j++){
			videoFramePointer[((i+yPos*grdSize)*displayHSize*3)+((j+xPos*grdSize)*3)]   = color&0xff;
			videoFramePointer[((i+yPos*grdSize)*displayHSize*3)+((j+xPos*grdSize)*3)+1] = (color&0x00ff00)>>8;
			videoFramePointer[((i+yPos*grdSize)*displayHSize*3)+((j+xPos*grdSize)*3)+2] = (color&0xff0000)>>16;
		}
	}
	Xil_DCacheFlush();
	return 0;
}

void drawPointer(u16 xPos,u16 yPos,u32 pntrSize,u32 displayHSize,char *videoFramePointer){
	u32 zoom = pntrSize/8;
	char *charBitMap = (char *)&fontBitMat[0];
	for(int i=0;i<8*zoom;i++){
		for(int j=0;j<8*zoom;j++){
			videoFramePointer[((j+yPos)*displayHSize*3)+((i+xPos)*3)]   = (((*(charBitMap+(i/zoom))>>(j/zoom))&0x1)*0xff)|videoFramePointer[((j+yPos)*displayHSize*3)+((i+xPos)*3)];
			videoFramePointer[((j+yPos)*displayHSize*3)+((i+xPos)*3)+1] = (((*(charBitMap+(i/zoom))>>(j/zoom))&0x1)*0xff)|videoFramePointer[((j+yPos)*displayHSize*3)+((i+xPos)*3)+1];
			videoFramePointer[((j+yPos)*displayHSize*3)+((i+xPos)*3)+2] = (((*(charBitMap+(i/zoom))>>(j/zoom))&0x1)*0xff)|videoFramePointer[((j+yPos)*displayHSize*3)+((i+xPos)*3)+2];
		}
	}
	Xil_DCacheFlush();
}

void placeStone(u16 xPos, u16 yPos, u32 grdSize, u32 displayHSize,
                u32 color, char *videoFramePointer){
    int radius = grdSize/2 - 2;

    // Extract bytes in BGR order (matching framebuffer format)
    int byte0 = (color)       & 0xFF;
    int byte1 = (color >> 8)  & 0xFF;
    int byte2 = (color >> 16) & 0xFF;

    for(int i = -radius; i <= radius; i++){
        for(int j = -radius; j <= radius; j++){
            if(i*i + j*j <= radius*radius){
                int px = xPos + j;
                int py = yPos + i;
                int index = (py * displayHSize + px) * 3;
                videoFramePointer[index]     = byte0;
                videoFramePointer[index + 1] = byte1;
                videoFramePointer[index + 2] = byte2;
            }
        }
    }
    Xil_DCacheFlush();
}

/*****************************************************************************/
/**
 * NEW FUNCTION: Draws a circular ring (outline) around a stone.
 * Used to highlight the last FPGA move (red ring) and winning stones.
 *
 * @param xPos         Pixel X centre of the stone
 * @param yPos         Pixel Y centre of the stone
 * @param grdSize      Grid cell size in pixels
 * @param displayHSize Horizontal resolution of the display
 * @param color        Ring colour (use redColor for highlights)
 * @param videoFramePointer Pointer to the frame buffer
 *****************************************************************************/
void drawStoneOutline(u16 xPos, u16 yPos, u32 grdSize, u32 displayHSize,
                      u32 color, char *videoFramePointer){
    int radius    = grdSize/2 - 2;
    int thickness = 2;   // ring thickness in pixels

    int byte0 = (color)       & 0xFF;
    int byte1 = (color >> 8)  & 0xFF;
    int byte2 = (color >> 16) & 0xFF;

    int outer2 = radius * radius;
    int inner2 = (radius - thickness) * (radius - thickness);

    for(int i = -radius; i <= radius; i++){
        for(int j = -radius; j <= radius; j++){
            int dist2 = i*i + j*j;
            if(dist2 <= outer2 && dist2 >= inner2){
                int px = xPos + j;
                int py = yPos + i;
                int index = (py * displayHSize + px) * 3;
                videoFramePointer[index]     = byte0;
                videoFramePointer[index + 1] = byte1;
                videoFramePointer[index + 2] = byte2;
            }
        }
    }
    Xil_DCacheFlush();
}


void drawPlayTable(char *Buffer,u32 FrameSize,u32 HSize,u32 VSize,u32 grdSize){
	memset(Buffer,blackColor,FrameSize);
	for(int i=(HSize/grdSize-18)/2;i<(HSize/grdSize-18)/2+18;i++){
		for(int j=(VSize/grdSize-18)/2;j<(VSize/grdSize-18)/2+18;j++){
			drawSquare(i,j,grdSize,HSize,Buffer,brownColor);
		}
	}
	// Columns A-S
	for(int i=0;i<19;i++){
		char col[2];
		col[0]='A'+i; col[1]='\0';
		printString(HSize,col,
			((HSize/grdSize-18)/2+i)*grdSize,
			((VSize/grdSize-18)/2)*grdSize-20,
			2,whiteColor,Buffer);
	}
	// Rows 1-19
	for(int i=0;i<19;i++){
		char row[3];
		sprintf(row,"%d",i+1);
		printString(HSize,row,
			((HSize/grdSize-18)/2)*grdSize-30,
			((VSize/grdSize-18)/2+i)*grdSize,
			2,whiteColor,Buffer);
	}
}
