/*
 * vdmaTest.c
 *
 *  Created on: Apr 9, 2020
 *      Author: VIPIN
 */
#include "xparameters.h"
#include "video.h"
#include "sleep.h"
#include <stdio.h>
#include "zyMouse.h"
#include "xscugic.h"
#include "xil_cache.h"
#include "xuartps.h"
#include "connect6.h"
#include "graphics.h"
#include <string.h>


#define HSize     1920
#define VSize     1080
#define FrameSize HSize*VSize*3

char Buffer[FrameSize];

#define clockFreq    100000000
#define updateRate   0.005
#define CounterValue clockFreq*updateRate

connect6 myConnect6;
pointer  myPointer;

u8  mouseClicks   = 0;
u8  firstMove     = 1;
int fpgaWon       = 0;
u8  fpgaStartGame;

/* ---- User chosen colour: 1 = user plays BLACK, 0 = user plays WHITE ---- */
u8  userIsBlack = 1;

/* ---- Separate move counters ---- */
int fpgaMoveCount = 0;
int userMoveCount = 0;

/* ---- Track last FPGA stone pixel position for red-outline refresh ---- */
u16 lastFpgaPixelX = 0;
u16 lastFpgaPixelY = 0;
u8  lastFpgaPlaced = 0;

/* Dark grey — visible on white background, used for "WHITE" label text */
#define darkGrayColor  0x333333

/* ------------------------------------------------------------------ */
/*  Helper: convert board coord to pixel centre                       */
/* ------------------------------------------------------------------ */
static inline u16 boardColToPixel(u8 col){
    return ((HSize/gridSize - 18)/2 + (col - 1)) * gridSize + gridSize/2;
}
static inline u16 boardRowToPixel(u8 row){
    return ((VSize/gridSize - 18)/2 + (row - 1)) * gridSize + gridSize/2;
}

/* ------------------------------------------------------------------ */
/*  Helper: highlight all 6 winning stones with green outline         */
/* ------------------------------------------------------------------ */
static void highlightWinners(void){
    for(int k = 0; k < 6; k++){
        if(win_positions[k][0] < 0) continue;
        u16 wx = boardColToPixel(win_positions[k][1]);
        u16 wy = boardRowToPixel(win_positions[k][0]);
        drawStoneOutline(wx, wy, gridSize, HSize, greenColor, Buffer);
    }
    Xil_DCacheFlush();
}

/* ------------------------------------------------------------------ */
/*  Helper: refresh move counter display immediately                  */
/* ------------------------------------------------------------------ */
static void refreshCounters(void){
    char fpgaMoveStr[20];
    char userMoveStr[20];
    sprintf(fpgaMoveStr, "FPGA Move:%d", fpgaMoveCount);
    sprintf(userMoveStr, "Your Move:%d", userMoveCount);
    printString(HSize, fpgaMoveStr, 50, 50, 3, whiteColor, Buffer);
    printString(HSize, userMoveStr, 50, 80, 3, whiteColor, Buffer);
    Xil_DCacheFlush();
}

/* ------------------------------------------------------------------ */
/*  Helper: black-fill the right-side turn label area                 */
/* ------------------------------------------------------------------ */
static void clearTurnLabel(void){
    char zoom = 5;
    int x = HSize - 5*8*zoom - 10;
    int w = 5*8*zoom + 10;
    int y = VSize/3;
    int h = zoom*8*2 + 4;
    for(int row = y; row < y + h; row++){
        for(int col = x; col < x + w; col++){
            int idx = (row * HSize + col) * 3;
            Buffer[idx]     = 0;
            Buffer[idx + 1] = 0;
            Buffer[idx + 2] = 0;
        }
    }
    Xil_DCacheFlush();
}

/* ------------------------------------------------------------------ */
/*  Helper: show "FPGA / THINKING" on left (green)                   */
/* ------------------------------------------------------------------ */
static void showFpgaThinking(void){
    char zoom = 5;
    printString(HSize, (char *)"FPGA",     50, VSize/3,          zoom, greenColor, Buffer);
    printString(HSize, (char *)"THINKING", 50, VSize/3 + zoom*8, zoom, greenColor, Buffer);
    Xil_DCacheFlush();
}

/* ------------------------------------------------------------------ */
/*  Helper: show "FPGA / WAITING" on left (green) during user turn   */
/* ------------------------------------------------------------------ */
static void showFpgaWaiting(void){
    char zoom = 5;
    printString(HSize, (char *)"FPGA",    50, VSize/3,          zoom, greenColor, Buffer);
    printString(HSize, (char *)"WAITING", 50, VSize/3 + zoom*8, zoom, greenColor, Buffer);
    Xil_DCacheFlush();
}

/* ------------------------------------------------------------------ */
/*  black-fill the left-side FPGA label area                  */
/* ------------------------------------------------------------------ */
static void clearFpgaThinkingLabel(void){
    char zoom = 5;
    int x = 50;
    int w = 8*8*zoom;
    int y = VSize/3;
    int h = zoom*8*2 + 4;
    for(int row = y; row < y + h; row++){
        for(int col = x; col < x + w; col++){
            int idx = (row * HSize + col) * 3;
            Buffer[idx]     = 0;
            Buffer[idx + 1] = 0;
            Buffer[idx + 2] = 0;
        }
    }
    Xil_DCacheFlush();
}

/* ------------------------------------------------------------------ */
/*  Helper: draw a filled rectangle                                   */
/* ------------------------------------------------------------------ */
static void fillRect(int x, int y, int w, int h, u32 color){
    u8 b0 = (color)       & 0xFF;
    u8 b1 = (color >> 8)  & 0xFF;
    u8 b2 = (color >> 16) & 0xFF;
    for(int row = y; row < y + h; row++){
        for(int col = x; col < x + w; col++){
            int idx = (row * HSize + col) * 3;
            Buffer[idx]     = b0;
            Buffer[idx + 1] = b1;
            Buffer[idx + 2] = b2;
        }
    }
}

/* ------------------------------------------------------------------ */
/*  Helper: draw a hollow rectangle border                            */
/* ------------------------------------------------------------------ */
static void drawRect(int x, int y, int w, int h, int thickness, u32 color){
    fillRect(x,                  y,                  w,         thickness, color);
    fillRect(x,                  y + h - thickness,  w,         thickness, color);
    fillRect(x,                  y,                  thickness, h,         color);
    fillRect(x + w - thickness,  y,                  thickness, h,         color);
}

/* ------------------------------------------------------------------ */
/*  showColorChoice                                                    */
/*  LEFT  box : BLACK fill + WHITE border  → "BLACK" label in white  */
/*  RIGHT box : WHITE fill + WHITE border  → "WHITE" label in grey   */
/*                                                                     */
/*  NOTE: printChar multiplies pixel by color value, so pure black   */
/*  (0x000000) produces invisible text. Use darkGrayColor for text   */
/*  on white backgrounds.                                             */
/* ------------------------------------------------------------------ */
void showColorChoice(void){
    memset(Buffer, 0, FrameSize);

    /* ---- Title ---- */
    /* zoom=5, each char = 40px wide. "CHOOSE YOUR COLOR" = 17 chars  */
    int  zoom      = 5;
    int  charW     = zoom * 8;
    int  titleLen  = 17;
    int  titleX    = (HSize - titleLen * charW) / 2;
    int  titleY    = VSize / 6;
    printString(HSize, (char *)"CHOOSE YOUR COLOR",
                titleX, titleY, zoom, whiteColor, Buffer);

    /* ---- Box geometry ---- */
    int boxW   = 500;
    int boxH   = 300;
    int boxY   = VSize / 2 - boxH / 2;
    int border = 8;

    /* Left box: centred in left half  (HSize/4) */
    int leftBoxX  = HSize / 4 - boxW / 2;
    /* Right box: centred in right half (3*HSize/4) */
    int rightBoxX = 3 * HSize / 4 - boxW / 2;

    /* ---- LEFT: black fill + white border ---- */
    fillRect(leftBoxX, boxY, boxW, boxH, 0x000000);
    drawRect(leftBoxX, boxY, boxW, boxH, border, whiteColor);

    /* ---- RIGHT: white fill + white border ---- */
    fillRect(rightBoxX, boxY, boxW, boxH, whiteColor);
    drawRect(rightBoxX, boxY, boxW, boxH, border, whiteColor);

    /* ---- Labels inside boxes ---- */
    /* zoom=4 → charW=32, "BLACK"/"WHITE" = 5 chars = 160px wide      */
    int lblZoom  = 4;
    int lblCharW = lblZoom * 8;
    int lblCharH = lblZoom * 8;
    int lblLen   = 5;
    int lblY     = boxY + boxH / 2 - lblCharH / 2;

    /* "BLACK" in white on left (black) box */
    int lblLeftX  = leftBoxX  + boxW / 2 - (lblLen * lblCharW) / 2;
    printString(HSize, (char *)"BLACK", lblLeftX, lblY, lblZoom, whiteColor, Buffer);

    /* "WHITE" in dark grey on right (white) box — pure black = invisible */
    int lblRightX = rightBoxX + boxW / 2 - (lblLen * lblCharW) / 2;
    printString(HSize, (char *)"WHITE", lblRightX, lblY, lblZoom, whiteColor, Buffer);

    /* ---- Subtitle hint ---- */
    int hintZoom = 2;
    int hintLen  = 15;   /* "CLICK TO SELECT" */
    int hintX    = (HSize - hintLen * hintZoom * 8) / 2;
    int hintY    = boxY + boxH + 50;
    printString(HSize, (char *)"CLICK TO SELECT", hintX, hintY, hintZoom, whiteColor, Buffer);

    Xil_DCacheFlush();

    /* Wait for one mouse click */
    mouseClicks = 0;
    while(mouseClicks == 0);
    mouseClicks = 0;

    u16 clickX = myPointer.xPos;

    if(clickX < HSize / 2){
        userIsBlack   = 1;
        fpgaStartGame = 0;   /* user (black) goes first */
    } else {
        userIsBlack   = 0;
        fpgaStartGame = 1;   /* FPGA (black) goes first */
    }

    memset(Buffer, 0, FrameSize);
    Xil_DCacheFlush();
}

/* ------------------------------------------------------------------ */

int  initIntrController(XScuGic *IntcInstancePtr);
void PressCallBack(void *callBackRef);
void MoveCallBack(void *callBackRef);
int  fpgaPlay(void);
int  userPlay(void);
void showWelcome(void);


int main(){
    XScuGic Intc;
    zyMouse  myMouse;
    u16 xPos = HSize - gridSize;
    u16 yPos = VSize - gridSize;
    u32 pos  = xPos | (yPos << 16);

    initIntrController(&Intc);

    initVideo(Buffer, VSize, HSize, &Intc);
    initConnect6(&myConnect6, XPAR_PS7_UART_0_DEVICE_ID);
    initZyMouse(&myMouse, XPAR_ZYMOUSE_0_S00_AXI_BASEADDR);
    setupZymouseInterrupt(&myMouse, &Intc, XPAR_FABRIC_ZYMOUSE_0_O_INTR_INTR);
    setInterruptZyMouse(&myMouse, AllInterruptMask);
    setZymouseCallBack(&myMouse, moveHandler,  MoveCallBack);
    setZymouseCallBack(&myMouse, pressHandler, PressCallBack);
    setCoordinateZyMouse(&myMouse, pos);
    setTimerZymouse(&myMouse, CounterValue);
    startZymouse(&myMouse);

    showWelcome();

    while(1){
        myPointer.disableMouseClick = 0;
        showColorChoice();

        Xil_Out32(XPAR_AXI_GPIO_0_BASEADDR, 0x1);
        Xil_Out32(XPAR_AXI_GPIO_0_BASEADDR, 0x0);

        clearBoard(&myConnect6);
        drawPlayTable(Buffer, FrameSize, HSize, VSize, gridSize);
        MoveCallBack(&myMouse);

        firstMove      = 1;
        lastFpgaPlaced = 0;
        lastFpgaPixelX = 0;
        lastFpgaPixelY = 0;
        fpgaWon        = 0;
        fpgaMoveCount  = 0;
        userMoveCount  = 0;

        while(1){
            refreshCounters();

            if(fpgaStartGame){
                /* FPGA goes first */
                if(fpgaPlay()){
                    clearTurnLabel();
                    clearFpgaThinkingLabel();
                    highlightWinners();
                    printString(HSize, (char *)"FPGA Won!",
                                HSize-9*8*5-10, VSize/3, 5, redColor, Buffer);
                    Xil_DCacheFlush();
                    break;
                }
                /* FPGA done → switch to WAITING while user plays */
                clearFpgaThinkingLabel();
                showFpgaWaiting();

                if(userPlay()){
                    clearTurnLabel();
                    clearFpgaThinkingLabel();
                    highlightWinners();
                    printString(HSize, (char *)"You Won!",
                                HSize-8*8*5-10, VSize/3, 5, redColor, Buffer);
                    Xil_DCacheFlush();
                    break;
                }
                clearTurnLabel();
            }
            else{
                /* User goes first — show FPGA WAITING from the start
                   EXCEPT on the very first move (firstMove==1)        */
                if(!firstMove){
                    clearFpgaThinkingLabel();
                    showFpgaWaiting();
                }

                if(userPlay()){
                    clearTurnLabel();
                    clearFpgaThinkingLabel();
                    highlightWinners();
                    printString(HSize, (char *)"You Won!",
                                HSize-8*8*5-10, VSize/3, 5, redColor, Buffer);
                    Xil_DCacheFlush();
                    break;
                }
                clearTurnLabel();

                if(fpgaPlay()){
                    clearTurnLabel();
                    clearFpgaThinkingLabel();
                    highlightWinners();
                    printString(HSize, (char *)"FPGA Won!",
                                HSize-9*8*5-10, VSize/3, 5, redColor, Buffer);
                    Xil_DCacheFlush();
                    break;
                }
            }
        }

        sleep(5);
        myPointer.init = 0;
    }

    return 0;
}


int initIntrController(XScuGic *IntcInstancePtr){
    int Status;
    XScuGic_Config *IntcConfig;
    IntcConfig = XScuGic_LookupConfig(XPAR_PS7_SCUGIC_0_DEVICE_ID);
    Status = XScuGic_CfgInitialize(IntcInstancePtr, IntcConfig,
                                   IntcConfig->CpuBaseAddress);
    if(Status != XST_SUCCESS){
        xil_printf("Interrupt controller initialization failed..");
        return -1;
    }
    Xil_ExceptionInit();
    Xil_ExceptionRegisterHandler(XIL_EXCEPTION_ID_INT,
        (Xil_ExceptionHandler)XScuGic_InterruptHandler,
        (void *)IntcInstancePtr);
    Xil_ExceptionEnable();
    return XST_SUCCESS;
}


/* ================================================================== */
/*  PressCallBack                                                     */
/* ================================================================== */
void PressCallBack(void *callBackRef){
    u32 status;
    u16 xPos, yPos;
    u32 pos;
    u8  xCord, yCord;
    zyMouse *zyMouseInst = (zyMouse *)callBackRef;

    pos  = Xil_In32(zyMouseInst->baseAddress + posRegOffset);
    xPos = pos & 0xffff;
    yPos = (pos & 0xffff0000) >> 16;

    /* Always store position so showColorChoice can read it */
    myPointer.xPos = xPos;
    myPointer.yPos = yPos;

    yCord = (yPos/gridSize) - (VSize/gridSize - 18)/2 + 1;
    xCord = (xPos/gridSize) - (HSize/gridSize - 18)/2 + 1;

    if(myPointer.disableMouseClick == 1){
        /* Color-choice screen: count click but don't place stone */
        mouseClicks++;
        return;
    }

    if(xCord >= 19 || yCord >= 19)
        return;
    if(checkValidPlacement(&myConnect6, yCord, xCord) != 0)
        return;

    writeGridData(HSize, (char *)myPointer.gridData,
                  myPointer.xPos, myPointer.yPos, pointerSize, (char *)Buffer);

    u32 userColor = userIsBlack ? blackColor : whiteColor;
    placeStone(((xPos/gridSize)*gridSize + gridSize/2),
               ((yPos/gridSize)*gridSize + gridSize/2),
               gridSize, HSize, userColor, Buffer);

    readGridData(HSize, (char *)myPointer.gridData,
                 xPos, yPos, pointerSize, (char *)Buffer);
    drawPointer(xPos, yPos, pointerSize, HSize, Buffer);

    sendCoordinate(&myConnect6, yCord);
    sendCoordinate(&myConnect6, xCord);
    updateBoard(&myConnect6, yCord, xCord, playerCell);
    status = checkGameOver(&myConnect6, yCord, xCord);
    if(status)
        fpgaWon = 1;

    mouseClicks++;
}


/* ================================================================== */
/*  MoveCallBack                                                      */
/* ================================================================== */
void MoveCallBack(void *callBackRef){
    u16 xPos, yPos;
    u32 pos;
    zyMouse *zyMouseInst = (zyMouse *)callBackRef;

    pos  = Xil_In32(zyMouseInst->baseAddress + posRegOffset);
    xPos = pos & 0xffff;
    yPos = (pos & 0xffff0000) >> 16;

    if(myPointer.init == 1){
        writeGridData(HSize, (char *)myPointer.gridData,
                      myPointer.xPos, myPointer.yPos, pointerSize, (char *)Buffer);
    }
    else{
        myPointer.init = 1;
    }
    myPointer.xPos = xPos;
    myPointer.yPos = yPos;
    readGridData(HSize, (char *)myPointer.gridData,
                 xPos, yPos, pointerSize, (char *)Buffer);
    drawPointer(xPos, yPos, pointerSize, HSize, Buffer);
}


/* ================================================================== */
/*  fpgaPlay                                                          */
/*  Left:  FPGA THINKING (while computing)                           */
/*  Right: FPGA TURN                                                  */
/* ================================================================== */
int fpgaPlay(){
    u8 FpgaYCord, FpgaXCord, xCord, yCord;
    int stat;
    char zoom = 5;

    /* Left: switch from WAITING → THINKING */
    clearFpgaThinkingLabel();
    showFpgaThinking();

    /* Right: FPGA TURN */
    printString(HSize, (char *)"FPGA", HSize-5*8*zoom-10, VSize/3,          zoom, greenColor, Buffer);
    printString(HSize, (char *)"TURN", HSize-4*8*zoom-10, VSize/3 + zoom*8, zoom, greenColor, Buffer);

    myPointer.disableMouseClick = 1;

    if(firstMove && fpgaStartGame)
        startGame(&myConnect6, fpgaBlack);

    u32 fpgaColor = userIsBlack ? whiteColor : blackColor;

    /* ===== FIRST FPGA STONE ===== */
    FpgaYCord = getCoordinate(&myConnect6);
    yCord     = (VSize/gridSize - 18)/2 + (FpgaYCord - 1);
    FpgaXCord = getCoordinate(&myConnect6);
    xCord     = (HSize/gridSize - 18)/2 + (FpgaXCord - 1);

    u16 px1 = xCord * gridSize + gridSize/2;
    u16 py1 = yCord * gridSize + gridSize/2;

    if(lastFpgaPlaced){
        drawStoneOutline(lastFpgaPixelX, lastFpgaPixelY,
                         gridSize, HSize, fpgaColor, Buffer);
    }

    placeStone(px1, py1, gridSize, HSize, fpgaColor, Buffer);
    drawStoneOutline(px1, py1, gridSize, HSize, redColor, Buffer);
    lastFpgaPixelX = px1;
    lastFpgaPixelY = py1;
    lastFpgaPlaced = 1;

    updateBoard(&myConnect6, FpgaYCord, FpgaXCord, fpgaCell);
    fpgaMoveCount++;
    refreshCounters();

    stat = checkGameOver(&myConnect6, FpgaYCord, FpgaXCord);
    if(stat) return 1;

    if(firstMove && fpgaStartGame){
        firstMove = 0;
        return 0;
    }

    /* ===== SECOND FPGA STONE ===== */
    FpgaYCord = getCoordinate(&myConnect6);
    yCord     = (VSize/gridSize - 18)/2 + (FpgaYCord - 1);
    FpgaXCord = getCoordinate(&myConnect6);
    xCord     = (HSize/gridSize - 18)/2 + (FpgaXCord - 1);

    u16 px2 = xCord * gridSize + gridSize/2;
    u16 py2 = yCord * gridSize + gridSize/2;

    drawStoneOutline(px1, py1, gridSize, HSize, fpgaColor, Buffer);
    placeStone(px2, py2, gridSize, HSize, fpgaColor, Buffer);
    drawStoneOutline(px2, py2, gridSize, HSize, redColor, Buffer);
    lastFpgaPixelX = px2;
    lastFpgaPixelY = py2;

    updateBoard(&myConnect6, FpgaYCord, FpgaXCord, fpgaCell);
    fpgaMoveCount++;
    refreshCounters();

    stat = checkGameOver(&myConnect6, FpgaYCord, FpgaXCord);
    if(stat) return 1;

    return 0;
}


/* ================================================================== */
/*  userPlay                                                          */
/*  Right: BLACK TURN / WHITE TURN                                    */
/*  Left:  FPGA WAITING (set by caller before userPlay is called)    */
/* ================================================================== */
int userPlay(){
    char zoom = 5;

    if(userIsBlack){
        printString(HSize, (char *)"BLACK", HSize-5*8*zoom-10, VSize/3,          zoom, greenColor, Buffer);
        printString(HSize, (char *)"TURN",  HSize-4*8*zoom-10, VSize/3 + zoom*8, zoom, greenColor, Buffer);
    }
    else{
        printString(HSize, (char *)"WHITE", HSize-5*8*zoom-10, VSize/3,          zoom, greenColor, Buffer);
        printString(HSize, (char *)"TURN",  HSize-4*8*zoom-10, VSize/3 + zoom*8, zoom, greenColor, Buffer);
    }

    myPointer.disableMouseClick = 0;

    if(firstMove && !fpgaStartGame)
        startGame(&myConnect6, fpgaWhite);

    /* FIRST CLICK */
    while(mouseClicks != 1);
    userMoveCount++;
    refreshCounters();

    if(firstMove && !fpgaStartGame){
        firstMove   = 0;
        mouseClicks = 0;
        return 0;
    }

    /* SECOND CLICK */
    while(mouseClicks != 2);
    userMoveCount++;
    refreshCounters();

    mouseClicks = 0;
    return (fpgaWon == 1) ? 1 : 0;
}


/* ================================================================== */
/*  showWelcome                                                       */
/* ================================================================== */
void showWelcome(){
    char count[10];
    memset(Buffer, blackColor, FrameSize);
    char *myString   = "CONNECT6";
    char  stringSize = 8;
    char  zoom       = 20;
    printString(HSize, (char *)myString,
                (HSize - stringSize*8*zoom)/2, VSize/3, zoom, redColor, Buffer);
    for(int i = 5; i > 0; i--){
        sprintf(count, "%d", i);
        printString(HSize, (char *)count,
                    (HSize - 8*zoom)/2, 2*VSize/3, zoom, redColor, Buffer);
        sleep(1);
    }
    memset(Buffer, blackColor, FrameSize);
}
