################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
LD_SRCS += \
../src/lscript.ld 

C_SRCS += \
../src/connect6.c \
../src/gameTop.c \
../src/graphics.c \
../src/video.c \
../src/zyMouse.c 

OBJS += \
./src/connect6.o \
./src/gameTop.o \
./src/graphics.o \
./src/video.o \
./src/zyMouse.o 

C_DEPS += \
./src/connect6.d \
./src/gameTop.d \
./src/graphics.d \
./src/video.d \
./src/zyMouse.d 


# Each subdirectory must supply rules for building sources it contributes
src/%.o: ../src/%.c
	@echo 'Building file: $<'
	@echo 'Invoking: ARM v7 gcc compiler'
	arm-none-eabi-gcc -Wall -O0 -g3 -c -fmessage-length=0 -MT"$@" -mcpu=cortex-a9 -mfpu=vfpv3 -mfloat-abi=hard -I../../connect6SW_bsp/ps7_cortexa9_0/include -MMD -MP -MF"$(@:%.o=%.d)" -MT"$(@)" -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


