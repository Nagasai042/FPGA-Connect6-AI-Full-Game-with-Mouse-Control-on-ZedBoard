src/connect6.o src/connect6.o: ../src/connect6.c ../src/connect6.h \
 ../../connect6SW_bsp/ps7_cortexa9_0/include/xil_types.h \
 ../../connect6SW_bsp/ps7_cortexa9_0/include/xuartps.h \
 ../../connect6SW_bsp/ps7_cortexa9_0/include/xil_types.h \
 ../../connect6SW_bsp/ps7_cortexa9_0/include/xil_assert.h \
 ../../connect6SW_bsp/ps7_cortexa9_0/include/xstatus.h \
 ../../connect6SW_bsp/ps7_cortexa9_0/include/xuartps_hw.h \
 ../../connect6SW_bsp/ps7_cortexa9_0/include/xil_io.h \
 ../../connect6SW_bsp/ps7_cortexa9_0/include/xil_printf.h \
 ../../connect6SW_bsp/ps7_cortexa9_0/include/xparameters.h \
 ../../connect6SW_bsp/ps7_cortexa9_0/include/xparameters_ps.h \
 ../../connect6SW_bsp/ps7_cortexa9_0/include/xpseudo_asm.h \
 ../../connect6SW_bsp/ps7_cortexa9_0/include/xreg_cortexa9.h \
 ../../connect6SW_bsp/ps7_cortexa9_0/include/xpseudo_asm_gcc.h \
 ../../connect6SW_bsp/ps7_cortexa9_0/include/xplatform_info.h \
 ../../connect6SW_bsp/ps7_cortexa9_0/include/xil_printf.h

../src/connect6.h:

../../connect6SW_bsp/ps7_cortexa9_0/include/xil_types.h:

../../connect6SW_bsp/ps7_cortexa9_0/include/xuartps.h:

../../connect6SW_bsp/ps7_cortexa9_0/include/xil_types.h:

../../connect6SW_bsp/ps7_cortexa9_0/include/xil_assert.h:

../../connect6SW_bsp/ps7_cortexa9_0/include/xstatus.h:

../../connect6SW_bsp/ps7_cortexa9_0/include/xuartps_hw.h:

../../connect6SW_bsp/ps7_cortexa9_0/include/xil_io.h:

../../connect6SW_bsp/ps7_cortexa9_0/include/xil_printf.h:

../../connect6SW_bsp/ps7_cortexa9_0/include/xparameters.h:

../../connect6SW_bsp/ps7_cortexa9_0/include/xparameters_ps.h:

../../connect6SW_bsp/ps7_cortexa9_0/include/xpseudo_asm.h:

../../connect6SW_bsp/ps7_cortexa9_0/include/xreg_cortexa9.h:

../../connect6SW_bsp/ps7_cortexa9_0/include/xpseudo_asm_gcc.h:

../../connect6SW_bsp/ps7_cortexa9_0/include/xplatform_info.h:

../../connect6SW_bsp/ps7_cortexa9_0/include/xil_printf.h:
